#ifndef _SPMIDI_JUKEBOX_SONG_IDS_H
#define _SPMIDI_JUKEBOX_SONG_IDS_H
/**
 * Song IDs for JukeBox.
 * Generated automatically by Mobileer Editor
 * Do NOT edit by hand!
 * (C) Mobileer, Inc. CONFIDENTIAL and PROPRIETARY
 */

#define SONG_ECHOECHO_RT (0)
#define SONG_BONYPARTECALL_RT (1)
#define SONG_PACO_DE_LUCIA_GUAJIRAS_LUCIA (2)
#define SONG_024ACGUITAR (3)

#endif /* _SPMIDI_JUKEBOX_SONG_IDS_H */
