//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glStencilOp.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glStencilOp (GLenum fail, GLenum zfail, GLenum zpass)
{
	CALL_LOG;
	if( GL_KEEP    != fail &&
		GL_ZERO    != fail &&
		GL_REPLACE != fail &&
		GL_INCR    != fail &&
		GL_DECR    != fail &&
		GL_INVERT  != fail )
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}
	if( GL_KEEP    != zfail &&
		GL_ZERO    != zfail &&
		GL_REPLACE != zfail &&
		GL_INCR    != zfail &&
		GL_DECR    != zfail &&
		GL_INVERT  != zfail )
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}
	if( GL_KEEP    != zpass &&
		GL_ZERO    != zpass &&
		GL_REPLACE != zpass &&
		GL_INCR    != zpass &&
		GL_DECR    != zpass &&
		GL_INVERT  != zpass )
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}
		
	__GLSTATE__.m_StencilFail  = fail;
	__GLSTATE__.m_StencilZFail = zfail;
	__GLSTATE__.m_StencilZPass = zpass;


}
