//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : hwbufferobject.cpp
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2007/10/17 Yuni  HW buffer object ��� �� ���� ���� �� ����
//		2007/06/12 Yuni  first implementation
//------------------------------------------------------------------------------
#include "hwbufferobject.h"

namespace __MES_OPENGL_ES__
{
	//ObjectPool<__HWBUFFER__ ,128,2> __HWBUFFER_POOL__;
	//GLuint		g_BindedHWBuffer[2];

	void __Initialize_HWBuffer__( void )
	{
		// hardware buffer object ���� �ʱ�ȭ
		glDisableClientState( GL_HARDWAREBUFFER_ARRAY_OES  );
		glBindHWBufferOES  (GL_ARRAY_BUFFER, 0);
		glBindHWBufferOES  (GL_ELEMENT_ARRAY_BUFFER, 0);
	}

	GLboolean	SetupHWBufferToBufferObject( GLboolean IsIndex )
	{
		if( !__GLSTATE__.m_BindedHWBuffer[0] )
			return GL_FALSE;

		__HWBUFFER__* pcurrentbuffer;
		pcurrentbuffer = __HWBUFFER_POOL__.GetObject( __GLSTATE__.m_BindedHWBuffer[0] );

		if( !pcurrentbuffer || !pcurrentbuffer->m_Buffer )
			return GL_FALSE;
		
		glBindBuffer( GL_ARRAY_BUFFER, pcurrentbuffer->m_Buffer );

		switch( pcurrentbuffer->m_Format )
		{
		case GL_HWBUFFER_XV_OES:
				glVertexPointer( 4, GL_FIXED, 0, 0 );
				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_COLOR_ARRAY );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );				
				
			break;
		case GL_HWBUFFER_FV_OES:
				glVertexPointer( 4, GL_FLOAT, 0, 0 );
				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_COLOR_ARRAY );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );					
			break;

		case GL_HWBUFFER_XVN_OES:	
			{
				glVertexPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, 0 );
				glNormalPointer( GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfixed)) );
				glPointSizePointerOES( GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(7*sizeof(GLfixed)) );
				
				glEnableClientState( GL_NORMAL_ARRAY );
				glEnableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_COLOR_ARRAY );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );					
			}
			break;
		case GL_HWBUFFER_FVN_OES:	
			{
				glVertexPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, 0 );
				glNormalPointer( GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfloat)) );
				glPointSizePointerOES( GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(7*sizeof(GLfloat)) );
				
				glEnableClientState( GL_NORMAL_ARRAY );
				glEnableClientState( GL_POINT_SIZE_ARRAY_OES );

				glDisableClientState( GL_COLOR_ARRAY );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );					
			}
			break;

		case GL_HWBUFFER_XVC_OES:
			{
				glVertexPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, 0 );
				glColorPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfixed)) );
				
				glEnableClientState( GL_COLOR_ARRAY );
				
				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );					
			}
			break;
		case GL_HWBUFFER_FVC_OES:
			{
				glVertexPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, 0 );
				glColorPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfloat)) );
				
				glEnableClientState( GL_COLOR_ARRAY );
				
				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );					
			}
			break;

		case GL_HWBUFFER_XVT_OES:	
			{
				glVertexPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, 0 );
				
				glClientActiveTexture(GL_TEXTURE0);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfixed)) );
				
				glClientActiveTexture(GL_TEXTURE1);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(6*sizeof(GLfixed)) );

				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_COLOR_ARRAY );				
				
			}
			break;
		case GL_HWBUFFER_FVT_OES:
			{
				glVertexPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, 0 );

				glClientActiveTexture(GL_TEXTURE0);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfloat)) );
				
				glClientActiveTexture(GL_TEXTURE1);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(6*sizeof(GLfloat)) );
				
				glDisableClientState( GL_NORMAL_ARRAY );
				glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
				glDisableClientState( GL_COLOR_ARRAY );
			}
			break;

		case GL_HWBUFFER_XVCTN_OES:
			{
				glVertexPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, 0 );
				glColorPointer( 4, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfixed)) );

				glClientActiveTexture(GL_TEXTURE0);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(8*sizeof(GLfixed)) );
				
				glClientActiveTexture(GL_TEXTURE1);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(10*sizeof(GLfixed)) );

				glNormalPointer( GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(12*sizeof(GLfixed)) );
				glPointSizePointerOES( GL_FIXED, pcurrentbuffer->m_Stride, (const void*)(15*sizeof(GLfixed)) );
				
				glEnableClientState( GL_NORMAL_ARRAY );
				glEnableClientState( GL_POINT_SIZE_ARRAY_OES );
				glEnableClientState( GL_COLOR_ARRAY );
			}
			break;
		case GL_HWBUFFER_FVCTN_OES:
			{
				glVertexPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, 0 );
				glColorPointer( 4, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(4*sizeof(GLfloat)) );

				glClientActiveTexture(GL_TEXTURE0);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(8*sizeof(GLfloat)) );
				
				glClientActiveTexture(GL_TEXTURE1);
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
				glTexCoordPointer( 2, GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(10*sizeof(GLfloat)) );

				glNormalPointer( GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(12*sizeof(GLfloat)) );
				glPointSizePointerOES( GL_FLOAT, pcurrentbuffer->m_Stride, (const void*)(15*sizeof(GLfloat)) );
				
				glEnableClientState( GL_NORMAL_ARRAY );
				glEnableClientState( GL_POINT_SIZE_ARRAY_OES );
				glEnableClientState( GL_COLOR_ARRAY );
			}
			break;
		default:
			return GL_FALSE;
		}
		
		glEnableClientState( GL_VERTEX_ARRAY );

		if( IsIndex )
		{
			__HWBUFFER__* pcurindexbuffer;
			pcurindexbuffer = __HWBUFFER_POOL__.GetObject( __GLSTATE__.m_BindedHWBuffer[1] );

			if( !pcurindexbuffer || !pcurindexbuffer->m_Buffer )
				return GL_FALSE;

			glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, pcurindexbuffer->m_Buffer );
		}

		return GL_TRUE;
	}
	
	void GetCurrentBufferObjectState( __CURRENT_BO_STATE__* pCurState )
	{
		glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &pCurState->m_BindArrayBuffer );
		glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &pCurState->m_BindElementBuffer );		
				
		glGetBooleanv(GL_VERTEX_ARRAY, 			&pCurState->m_IsVertexPointerEnable );
		glGetIntegerv(GL_VERTEX_ARRAY_SIZE, &pCurState->m_VertexArraySize );
		glGetIntegerv(GL_VERTEX_ARRAY_STRIDE, &pCurState->m_VertexArrayStride );
		glGetIntegerv(GL_VERTEX_ARRAY_TYPE, &pCurState->m_VertexArrayType );
		
		pCurState->m_VertexArrayBuffer = __GLSTATE__.m_VertexPointer.m_Buffer;
		pCurState->m_pVertexArrayPointer = __GLSTATE__.m_VertexPointer.m_Pointer;			
	
		glGetBooleanv(GL_COLOR_ARRAY, 			&pCurState->m_IsColorPointerEnable );
		glGetIntegerv(GL_COLOR_ARRAY_SIZE, &pCurState->m_ColorArraySize );
		glGetIntegerv(GL_COLOR_ARRAY_STRIDE, &pCurState->m_ColorArrayStride );
		glGetIntegerv(GL_COLOR_ARRAY_TYPE, &pCurState->m_ColorArrayType );
		
		pCurState->m_ColorArrayBuffer = __GLSTATE__.m_ColorPointer.m_Buffer;
		pCurState->m_pColorArrayPointer = __GLSTATE__.m_ColorPointer.m_Pointer;			
		
		glGetIntegerv( GL_CLIENT_ACTIVE_TEXTURE, &pCurState->m_BindActiveClientTexture );
		for( int i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			glClientActiveTexture(GL_TEXTURE0 + i);
			glGetBooleanv(GL_TEXTURE_COORD_ARRAY, 	&pCurState->m_IsTexCoordPointerEnable[i] );
			glGetIntegerv(GL_TEXTURE_COORD_ARRAY_SIZE, &pCurState->m_TexCoordArraySize[i] );
			glGetIntegerv(GL_TEXTURE_COORD_ARRAY_STRIDE, &pCurState->m_TexCoordArrayStride[i] );
			glGetIntegerv(GL_TEXTURE_COORD_ARRAY_TYPE, &pCurState->m_TexCoordArrayType[i] );
			
			pCurState->m_TexCoordArrayBuffer[i] = __GLSTATE__.m_TexturePointer[i].m_Buffer;
			pCurState->m_pTexCoordArrayPointer[i] = __GLSTATE__.m_TexturePointer[i].m_Pointer;	
		}
		
		glGetBooleanv(GL_NORMAL_ARRAY, &pCurState->m_IsNormalPointerEnable );
		glGetIntegerv(GL_NORMAL_ARRAY_STRIDE, &pCurState->m_NormalArrayStride );
		glGetIntegerv(GL_NORMAL_ARRAY_TYPE, &pCurState->m_NormalArrayType );
		
		pCurState->m_NormalArrayBuffer = __GLSTATE__.m_NormalPointer.m_Buffer;
		pCurState->m_pNormalArrayPointer = __GLSTATE__.m_NormalPointer.m_Pointer;	
				
		glGetBooleanv(GL_POINT_SIZE_ARRAY_OES, 	&pCurState->m_IsPointSizePointerEnable );
		glGetIntegerv(GL_POINT_SIZE_ARRAY_STRIDE_OES, &pCurState->m_PointSizeArrayStride );
		glGetIntegerv(GL_POINT_SIZE_ARRAY_TYPE_OES, &pCurState->m_PointSizeArrayType );
		
		pCurState->m_PointSizeArrayBuffer = __GLSTATE__.m_PointSizePointer.m_Buffer;
		pCurState->m_pPointSizeArrayPointer = __GLSTATE__.m_PointSizePointer.m_Pointer;	
	}
	
	void SetCurrentBufferObjectState( const __CURRENT_BO_STATE__* pCurState )
	{
		if( pCurState->m_IsVertexPointerEnable )
			glEnableClientState( GL_VERTEX_ARRAY );
		else
			glDisableClientState( GL_VERTEX_ARRAY );
		
		glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_VertexArrayBuffer );
		glVertexPointer( pCurState->m_VertexArraySize, 
						pCurState->m_VertexArrayType, 
						pCurState->m_VertexArrayStride, 
						pCurState->m_pVertexArrayPointer );
						
		if( pCurState->m_IsColorPointerEnable )
			glEnableClientState( GL_COLOR_ARRAY );
		else
			glDisableClientState( GL_COLOR_ARRAY );
		
		glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_ColorArrayBuffer );
		glColorPointer( pCurState->m_ColorArraySize, 
						pCurState->m_ColorArrayType, 
						pCurState->m_ColorArrayStride, 
						pCurState->m_pColorArrayPointer );

		if( pCurState->m_IsNormalPointerEnable )
			glEnableClientState( GL_NORMAL_ARRAY );
		else
			glDisableClientState( GL_NORMAL_ARRAY );
			
		glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_NormalArrayBuffer );
		glNormalPointer( pCurState->m_NormalArrayType, 
						pCurState->m_NormalArrayStride, 
						pCurState->m_pNormalArrayPointer );	

		for( int i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{		
			glClientActiveTexture( GL_TEXTURE0 + i );
			
			if( pCurState->m_IsTexCoordPointerEnable )
				glEnableClientState( GL_TEXTURE_COORD_ARRAY );
			else
				glDisableClientState( GL_TEXTURE_COORD_ARRAY );
						
			glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_TexCoordArrayBuffer[i] );
			glTexCoordPointer( pCurState->m_TexCoordArraySize[i], 
							pCurState->m_TexCoordArrayType[i], 
							pCurState->m_TexCoordArrayStride[i], 
							pCurState->m_pTexCoordArrayPointer[i] );
		}
		glClientActiveTexture( pCurState->m_BindActiveClientTexture );	// ���ִ� �� ���� ��.
			
		if( pCurState->m_IsPointSizePointerEnable )
			glEnableClientState( GL_POINT_SIZE_ARRAY_OES );
		else
			glDisableClientState( GL_POINT_SIZE_ARRAY_OES );
															
		glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_PointSizeArrayBuffer );
		glPointSizePointerOES( pCurState->m_PointSizeArrayType, 
						pCurState->m_PointSizeArrayStride, 
						pCurState->m_pPointSizeArrayPointer );	
						
		glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, pCurState->m_BindElementBuffer );
		glBindBuffer( GL_ARRAY_BUFFER, pCurState->m_BindArrayBuffer );
		//glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, 0 );
		//glBindBuffer( GL_ARRAY_BUFFER, 0 );								
			
	}

} // namespace __MES_OPENGL_ES__
