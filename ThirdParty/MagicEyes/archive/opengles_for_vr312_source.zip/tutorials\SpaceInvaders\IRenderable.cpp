#include <math.h>
#include "IRenderable.h"

void IRenderable::DrawBoundingBox()
{
  static GLubyte i1[] = {0,1,2,3};
  static GLubyte i2[] = {4,5,6,7};
  static GLubyte i3[] = {0,1,5,4};
  static GLubyte i4[] = {3,2,6,7};
  static GLubyte i5[] = {0,4,7,3};
  static GLubyte i6[] = {1,5,6,2};     
 
  glEnableClientState(GL_VERTEX_ARRAY);  
    glVertexPointer(3, GL_FIXED, 0, m_boundingBoxVertices);               
    glDisable(GL_TEXTURE_2D);
    glColor4x(ONE,ONE,ONE,ONE);        
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i1);
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i2);
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i3);
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i4);
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i5);
    glDrawElements(GL_LINE_LOOP, 4, GL_UNSIGNED_BYTE, i6);  
    glEnable(GL_TEXTURE_2D);
  glDisableClientState(GL_VERTEX_ARRAY);

}
//----------------------------------------------------------------------------
//This function needs the bound box values to compute correctly the bsphere
void IRenderable::ComputeBSphere()
{
  m_sphereCenter[0] = DivideFixed(m_maxAABBCorner[0] + m_minorAABBCorner[0], FixedFromInt(2));
  m_sphereCenter[1] = DivideFixed(m_maxAABBCorner[1] + m_minorAABBCorner[1], FixedFromInt(2));
  m_sphereCenter[2] = DivideFixed(m_maxAABBCorner[2] + m_minorAABBCorner[2], FixedFromInt(2));
  float aux[3];
  aux[0] = FloatFromFixed(m_maxAABBCorner[0] - m_sphereCenter[0]);
  aux[1] = FloatFromFixed(m_maxAABBCorner[1] - m_sphereCenter[1]);
  aux[2] = FloatFromFixed(m_maxAABBCorner[2] - m_sphereCenter[2]);
  m_sphereRadius = FixedFromFloat((float)sqrt(aux[0]*aux[0]  +  aux[1]*aux[1]  +  aux[2]*aux[2]));
  
  //we want the sphere inside the box, so we will project the radius modulus 45�
  GLfixed cos45 = FixedFromFloat(0.7071f); 
  m_sphereRadius = MultiplyFixed(m_sphereRadius, cos45); 
}
