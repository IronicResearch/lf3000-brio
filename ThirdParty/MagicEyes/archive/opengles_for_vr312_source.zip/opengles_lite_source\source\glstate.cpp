//------------------------------------------------------------------------------
//
//  Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//  MagicEyes Digital Co. Proprietary & Confidential
//
//  MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//  AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//  BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//  FITNESS FOR A PARTICULAR PURPOSE.
//
//  Module     :
//  File       : glstate.cpp
//  Description: 
//  Author     : Gamza(nik@mesdigital.com)
//  Export     :
//  History    :
//	   2007/09/12 Gamza	sprintf ����.
//	   2007/09/11 Yuni	Default texture�� Texture pool�� ������ __GLSTATE__�� ��������� ����.
//     2007/09/06 Gamza GL/EGL ������ ���ڷ� ����ϱ����� �Լ� �߰�.
//                      GLERROR_TO_STRING / EGLERROR_TO_STRING
//     2007/09/04 Gamza EGLSETERROR(EGL_SUCCESS) -> EGLCLRERROR
//     2007/09/04 Gamza FSAA�� ���� SAMPLE_BUFFERS�� 1�� config�߰�.
//     2006/12/15 Yuni  add LIGHTMODE enumeration and SetTextureSize()
//     2006/03/08 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#include <string.h> // memset
#include "glstate.h"
#include "gles_surface.h"
#include "hwbufferobject.h"
#include "gtecode.h"

inline void* operator new( size_t, void * p ){ return p; }
template< class T >
void ClearClass( T* pInstance )
{
        pInstance->T::~T();
        memset( pInstance, 0, sizeof(pInstance[0]) );
        new(pInstance) T();
};


namespace __MES_OPENGL_ES__
{
    __GLSTATESET__ __GLSTATE__;
    ObjectPool<__BUFFER__ ,128,2> __BUFFER_POOL__;
    ObjectPool<__HWBUFFER__ ,128,2> __HWBUFFER_POOL__;
    ObjectPool<__TEXTURE__,128,2> __TEXTURE_POOL__;
    //__GLSTATESET__* __pCurContext = 0;

	unsigned __int64 __TEXTURE__::m_IDGEN=1;


    // EGL�� ���������
    __EGLSTATESET__ __EGLSTATE__ = {0};

    //EGLint         __EGL_Error__;
    int             __NumberOfContext__ = 0;
    int				__eglSwapInterval__ = 1;
	unsigned int	__EGL_SURFACE__		= 0;

    const __CONFIG__     __EGL_Configuration__[] =
    {
        {
            EGLCONFIG_FLAG,
            16, // m_BUFFER_SIZE
            0, // m_ALPHA_SIZE
            5, // m_BLUE_SIZE
            6, // m_GREEN_SIZE
            5, // m_RED_SIZE
            EGL_SLOW_CONFIG, // m_CONFIG_CAVEAT
            1, // m_CONFIG_ID
            16, // m_DEPTH_SIZE
            0, // m_LEVEL
            1024, // m_MAX_PBUFFER_WIDTH
            1024, // m_MAX_PBUFFER_HEIGHT
            1024*1024, // m_MAX_PBUFFER_PIXELS
            EGL_FALSE, // m_NATIVE_RENDERABLE
            0, // m_NATIVE_VISUAL_ID
            EGL_NONE, // m_NATIVE_VISUAL_TYPE
            0, // m_SAMPLE_BUFFERS
            1, // m_SAMPLES
            0, // m_STENCIL_SIZE
            EGL_PBUFFER_BIT | EGL_WINDOW_BIT, // m_SURFACE_TYPE
            EGL_NONE, // m_TRANSPARENT_TYPE
            0x1F, // m_TRANSPARENT_BLUE_VALUE
            0x00, // m_TRANSPARENT_GREEN_VALUE
            0x1F, // m_TRANSPARENT_RED_VALUE
            1, // m_MIN_SWAP_INTERVAL
            256, // m_MAX_SWAP_INTERVAL
            EGL_FALSE, // m_BIND_TO_TEXTURE_RGB
            EGL_FALSE  // m_BIND_TO_TEXTURE_RGBA
        },
        {
            EGLCONFIG_FLAG,
            16, // m_BUFFER_SIZE
            0, // m_ALPHA_SIZE
            5, // m_BLUE_SIZE
            6, // m_GREEN_SIZE
            5, // m_RED_SIZE
            EGL_SLOW_CONFIG, // m_CONFIG_CAVEAT
            2, // m_CONFIG_ID
            16, // m_DEPTH_SIZE
            0, // m_LEVEL
            1024, // m_MAX_PBUFFER_WIDTH
            1024, // m_MAX_PBUFFER_HEIGHT
            1024*1024, // m_MAX_PBUFFER_PIXELS
            EGL_FALSE, // m_NATIVE_RENDERABLE
            0, // m_NATIVE_VISUAL_ID
            EGL_NONE, // m_NATIVE_VISUAL_TYPE
            1, // m_SAMPLE_BUFFERS
            1, // m_SAMPLES
            0, // m_STENCIL_SIZE
            EGL_PBUFFER_BIT | EGL_WINDOW_BIT, // m_SURFACE_TYPE
            EGL_NONE, // m_TRANSPARENT_TYPE
            0x1F, // m_TRANSPARENT_BLUE_VALUE
            0x00, // m_TRANSPARENT_GREEN_VALUE
            0x1F, // m_TRANSPARENT_RED_VALUE
            1, // m_MIN_SWAP_INTERVAL
            256, // m_MAX_SWAP_INTERVAL
            EGL_FALSE, // m_BIND_TO_TEXTURE_RGB
            EGL_FALSE  // m_BIND_TO_TEXTURE_RGBA
        }
    };
    
    const int __EGL_Number_Of_Configurations__ = sizeof(__EGL_Configuration__)/sizeof(__EGL_Configuration__[0]);
    

    const GLenum COMPRESSED_TEXTURE_FORMATS[GLPARAM_NUM_COMPRESSED_TEXTURE_FORMATS] = 
    {
        //GLPARAM_COMPRESSED_TEXTURE_FORMATS    
        GL_PALETTE4_RGB8_OES    ,
        GL_PALETTE4_RGBA8_OES   ,
        GL_PALETTE4_R5_G6_B5_OES,
        GL_PALETTE4_RGBA4_OES   ,
        GL_PALETTE4_RGB5_A1_OES ,
        GL_PALETTE8_RGB8_OES    ,       
        GL_PALETTE8_RGBA8_OES   ,
        GL_PALETTE8_R5_G6_B5_OES,
        GL_PALETTE8_RGBA4_OES   ,
        GL_PALETTE8_RGB5_A1_OES             
    };
    
    GLvoid 		TextureInitialize( __TEXTURE__* ptexture )
    {
	    while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
	    
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
		if ( ptexture->m_PaletteMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );	

		ptexture->m_TEXTURE_MIN_FILTER		= GL_NEAREST_MIPMAP_LINEAR;
		ptexture->m_TEXTURE_MAG_FILTER		= GL_LINEAR;
		ptexture->m_TEXTURE_WRAP_S			= GL_REPEAT;
		ptexture->m_TEXTURE_WRAP_T			= GL_REPEAT;
		ptexture->m_GENERATE_MIPMAP			= GL_FALSE;
		ptexture->m_TILE_INDEX_ENABLE		= GL_FALSE;
		ptexture->m_TEXTURE_CROP_RECT_U		= 0;		
		ptexture->m_TEXTURE_CROP_RECT_V		= 0;
		ptexture->m_TEXTURE_CROP_RECT_WIDTH	= 0;
		ptexture->m_TEXTURE_CROP_RECT_HEIGHT= 0;
		ptexture->m_Target					= GL_TEXTURE_2D;	// must GL_TEXTURE_2D
		ptexture->m_Level					= 0;
		ptexture->m_Width					= 0;
		ptexture->m_Height					= 0;
		ptexture->m_Border					= 0;				// must 0
		ptexture->m_Format					= 0;				// �ʱⰪ��..???		
		ptexture->m_Type					= 0;				// �ʱⰪ��..???
		ptexture->m_IsCompessed				= GL_FALSE;
		ptexture->m_PaletteSize				= 0;
		ptexture->m_Bpp						= 0;
		ptexture->m_UsedPoint				= 0;
		ptexture->m_IsUpdated				= GL_FALSE;
		ptexture->m_ContentsIsUpdated       = GL_FALSE;

		ptexture->m_TextureDataMemory2D.MemoryHandle	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegment	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegX	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegY	= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegment	= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegX		= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegY		= 0;

		ptexture->m_PaletteMemory2D.MemoryHandle		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegment		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegX		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegY		= 0;
		ptexture->m_PaletteMemory2D.VirtualSegment		= 0;
		ptexture->m_PaletteMemory2D.VirtualSegX			= 0;
		ptexture->m_PaletteMemory2D.VirtualSegY			= 0;

		ptexture->m_WidthPowerOf2  						= 0;
		ptexture->m_HeightPowerOf2 						= 0;
		ptexture->m_ScaleX 								= 1;
		ptexture->m_ScaleY 								= 1;		
    }
    
    GLboolean MakeDefaultTexture( __GLSTATESET__* pGLSTATE )
    {
        //__TEXTURE_POOL__.Alloc( 1, &(pGLSTATE->m_DefaultTextureIndex) );

        __TEXTURE__* pTexture = &pGLSTATE->m_DefaultTexture;
        //pTexture = __TEXTURE_POOL__.GetObject( pGLSTATE->m_DefaultTextureIndex );   //!! ...?
        if( ! pTexture )
        {
            return GL_FALSE;
        }
        pTexture->m_Width           = 2;
        pTexture->m_Height          = 2;
        pTexture->m_WidthPowerOf2   = 2;
        pTexture->m_HeightPowerOf2  = 2;
        pTexture->m_Format          = GL_RGB;
        pTexture->m_Type            = GL_UNSIGNED_SHORT_5_6_5;
        pTexture->m_Bpp             = 16;

		if ( pTexture->m_TextureDataMemory2D.MemoryHandle )	// Ȥ�ó� �ٽ� �����Ϸ� ����� ���� ������..
			GLESOAL_Free2D( &pTexture->m_TextureDataMemory2D );
			
        if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
            pTexture->m_WidthPowerOf2*2, pTexture->m_HeightPowerOf2, 1, 1, 
            &pTexture->m_TextureDataMemory2D ) ) // align??
        {
            //__TEXTURE_POOL__.Free( 1, &(pGLSTATE->m_DefaultTextureIndex) );
            return GL_FALSE;
        }

        unsigned short imgData[ 2*2 ];
        int i;
        int j;
        for( i=0; i<(pTexture->m_Height); i++ )
        for( j=0; j<(pTexture->m_Width); j++ )
        {
            imgData[i*pTexture->m_Width+j] = 0xFFFF;    // white
            //if( (i^j) & (1<<5) )
            //  imgData[i*pTexture->m_Width+j] = 0xFFFF;    // white
            //else
            //  imgData[i*pTexture->m_Width+j] = 0xF800;    // red
        }
        //imgData[0] = 30000;
        if( !GLESOAL_UploadTexture_R5G6B5( &pTexture->m_TextureDataMemory2D, 
                                          0, 0, 
                                          pTexture->m_Width, pTexture->m_Height, 
                                          (void*)imgData, pTexture->m_Width * 2 ) )
        {
            GLESOAL_Free2D( &pTexture->m_TextureDataMemory2D );
            //__TEXTURE_POOL__.Free( 1, &(pGLSTATE->m_DefaultTextureIndex) );
            return GL_FALSE;
        }
        
        //pGLSTATE->m_pDefaultTexture = pTexture;
        return GL_TRUE;
    }

    GLvoid DeleteDefaultTexture( __GLSTATESET__* pGLSTATE )
    {
	    //__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject( pGLSTATE->m_DefaultTextureIndex );  
	    __TEXTURE__* ptexture = &pGLSTATE->m_DefaultTexture;
	    
	    TextureInitialize( ptexture );
	    /*
	    while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
		if ( ptexture->m_PaletteMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );	

        //__TEXTURE_POOL__.Free( 1, &pGLSTATE->m_DefaultTextureIndex );
        //pGLSTATE->m_pDefaultTexture = 0;
		
		// Texture �ʱ�ȭ. ���� �ؾ� �ϳ� �ͱ� ������... ������ ��츦 ����.
		ptexture->m_TEXTURE_MIN_FILTER		= GL_NEAREST_MIPMAP_LINEAR;
		ptexture->m_TEXTURE_MAG_FILTER		= GL_LINEAR;
		ptexture->m_TEXTURE_WRAP_S			= GL_REPEAT;
		ptexture->m_TEXTURE_WRAP_T			= GL_REPEAT;
		ptexture->m_GENERATE_MIPMAP			= GL_FALSE;
		ptexture->m_TILE_INDEX_ENABLE		= GL_FALSE;
		ptexture->m_TEXTURE_CROP_RECT_U		= 0;		
		ptexture->m_TEXTURE_CROP_RECT_V		= 0;
		ptexture->m_TEXTURE_CROP_RECT_WIDTH	= 0;
		ptexture->m_TEXTURE_CROP_RECT_HEIGHT= 0;
		ptexture->m_Target					= GL_TEXTURE_2D;	// must GL_TEXTURE_2D
		ptexture->m_Level					= 0;
		ptexture->m_Width					= 0;
		ptexture->m_Height					= 0;
		ptexture->m_Border					= 0;				// must 0
		ptexture->m_Format					= GL_RGB;			// �ʱⰪ��..???		
		ptexture->m_Type					= GL_UNSIGNED_SHORT_5_6_5;	// �ʱⰪ��..???
		ptexture->m_IsCompessed				= GL_FALSE;
		ptexture->m_PaletteSize				= 0;
		ptexture->m_Bpp						= 0;
		ptexture->m_UsedPoint				= 0;
		ptexture->m_IsUpdated				= GL_FALSE;
		ptexture->m_ContentsIsUpdated       = GL_FALSE;

		ptexture->m_TextureDataMemory2D.MemoryHandle	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegment	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegX	= 0;
		ptexture->m_TextureDataMemory2D.PhysicalSegY	= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegment	= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegX		= 0;
		ptexture->m_TextureDataMemory2D.VirtualSegY		= 0;

		ptexture->m_PaletteMemory2D.MemoryHandle		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegment		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegX		= 0;
		ptexture->m_PaletteMemory2D.PhysicalSegY		= 0;
		ptexture->m_PaletteMemory2D.VirtualSegment		= 0;
		ptexture->m_PaletteMemory2D.VirtualSegX			= 0;
		ptexture->m_PaletteMemory2D.VirtualSegY			= 0;

		ptexture->m_WidthPowerOf2  						= 0;
		ptexture->m_HeightPowerOf2 						= 0;
		*/
    }

    void __Reset_GLSTATESET__( __GLSTATESET__* pGLSTATE )
    {
        int i;
        unsigned int reservedobject;
        
        ClearClass( pGLSTATE );
        
		pGLSTATE->m_OldGLState=0;
		pGLSTATE->m_CurGLState=0;
		pGLSTATE->m_TexEnv[0].m_IsUpdated = GL_TRUE;
		pGLSTATE->m_TexEnv[1].m_IsUpdated = GL_TRUE;

		pGLSTATE->m_DefaultPositionBuffer_Index=0;
		pGLSTATE->m_DefaultColorBuffer_Index=0;
		pGLSTATE->m_DefaultTexCoordBuffer_Index=0;
		pGLSTATE->m_DefaultNormalBuffer_Index=0;
		pGLSTATE->m_DefaultPointSizeBuffer_Index=0;
		pGLSTATE->m_DefaultWeightBuffer_Index=0;
		pGLSTATE->m_DefaultMatrixIndexBuffer_Index=0;
		pGLSTATE->m_DefaultIndexBuffer_Index=0;

        __BUFFER_POOL__.Reset();
        __HWBUFFER_POOL__.Reset();
        __TEXTURE_POOL__.Reset();
        __BUFFER_POOL__.Alloc ( 1, &reservedobject );
        __HWBUFFER_POOL__.Alloc (1, &reservedobject );
        __TEXTURE_POOL__.Alloc( 1, &pGLSTATE->m_DefaultTextureIndex );
        
        MakeDefaultTexture( pGLSTATE );

        //pGLSTATE->m_Config = __EGL_Configuration__;
        //pGLSTATE->m_pDisplay    = NULL;
        pGLSTATE->m_pSurface= NULL;
        //pGLSTATE->m_pDrawSurface= NULL;
        
        pGLSTATE->m_PixelStoreUnpackAlignment= 4;
        pGLSTATE->m_PixelStorePackAlignment  = 4;
        pGLSTATE->m_ActiveTexture       = GL_TEXTURE0 - GL_TEXTURE0;
        pGLSTATE->m_ClientActiveTexture = GL_TEXTURE0 - GL_TEXTURE0;
            
        pGLSTATE->m_AlphaFunc  = GL_ALWAYS;
        pGLSTATE->m_AlphaRef   = F2VCF(0);
        
        pGLSTATE->m_BindedBuffer[0] = 0;
        pGLSTATE->m_BindedBuffer[1] = 0;
        for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
            pGLSTATE->m_BindedTexture[i] = 0;
//      [!!!]
//      for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
//          __TEXENV__  m_TexEnv[i] = ...;
        
        pGLSTATE->m_BlendFunc_Src = GL_ONE;
        pGLSTATE->m_BlendFunc_Dst = GL_ZERO;
        
        //pGLSTATE->m_ClearColor.color32   = 0;
        pGLSTATE->m_ClearColor[0] = F2VF(0.0f);
        pGLSTATE->m_ClearColor[1] = F2VF(0.0f);
        pGLSTATE->m_ClearColor[2] = F2VF(0.0f);
        pGLSTATE->m_ClearColor[3] = F2VF(0.0f);

        pGLSTATE->m_ClearDepth   = F2VCF(1);
        pGLSTATE->m_ClearStencil = 0;
            
#if GLPARAM_MAX_CLIP_PLANES > 0
        for( i=0; i<GLPARAM_MAX_CLIP_PLANES; i++ )
        {
            pGLSTATE->m_ClipPlane[i].x = 0;
            pGLSTATE->m_ClipPlane[i].y = 0;
            pGLSTATE->m_ClipPlane[i].z = 0;
            pGLSTATE->m_ClipPlane[i].w = 0;
        }
#endif
        //pGLSTATE->m_CurrentColor.color32 = 0;
        pGLSTATE->m_CurrentColor[0] = F2VF(0.0f);
        pGLSTATE->m_CurrentColor[1] = F2VF(0.0f);
        pGLSTATE->m_CurrentColor[2] = F2VF(0.0f);
        pGLSTATE->m_CurrentColor[3] = F2VF(0.0f);
		pGLSTATE->m_UpdateCurrentColor = true;
		
		for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
			pGLSTATE->m_UpdateDefaultTexCoord[i] = true;

		pGLSTATE->m_UpdateDefaultNormal= true;

		pGLSTATE->m_UpdataPointSize=true;
        
        pGLSTATE->m_ColorMask[0] = GL_TRUE;
        pGLSTATE->m_ColorMask[1] = GL_TRUE;
        pGLSTATE->m_ColorMask[2] = GL_TRUE;
        pGLSTATE->m_ColorMask[3] = GL_TRUE;
        
        pGLSTATE->m_CullFace = GL_BACK;
        pGLSTATE->m_FrontFace= GL_CCW;
        
        pGLSTATE->m_DepthFunc = GL_LESS;
        pGLSTATE->m_DepthMask = GL_TRUE;
        
        pGLSTATE->m_DepthRangeNear = F2VCF(0);
        pGLSTATE->m_DepthRangeFar  = F2VCF(1);

        pGLSTATE->m_FogMode   = GL_EXP; // GL_LINEAR, GL_EXP, and GL_EXP2. The default fog mode is GL_EXP. 
        pGLSTATE->m_FogDensity= F2VF(1);
        pGLSTATE->m_FogStart  = F2VF(0);
        pGLSTATE->m_FogEnd    = F2VF(1);
        //pGLSTATE->m_FogColor.color32 = 0;
        pGLSTATE->m_FogColor[0] = F2VF(0.0f);
        pGLSTATE->m_FogColor[1] = F2VF(0.0f);
        pGLSTATE->m_FogColor[2] = F2VF(0.0f);
        pGLSTATE->m_FogColor[3] = F2VF(0.0f);

        pGLSTATE->m_MatrixMode         = GL_MODELVIEW;
        pGLSTATE->m_pCurrentMatrixMode = &pGLSTATE->m_ModelViewMatrix;
        pGLSTATE->m_CurrentPaletteMatrix = 0;
        pGLSTATE->m_ProjectionMatrix.Initialize(GLPARAM_MAX_PROJECTION_STACK_DEPTH);
        pGLSTATE->m_ModelViewMatrix .Initialize(GLPARAM_MAX_MODELVIEW_STACK_DEPTH);
        for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
            pGLSTATE->m_TextureMatrix[i].Initialize(GLPARAM_MAX_TEXTURE_STACK_DEPTH);
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
        for( i=0; i<GLPARAM_MAX_PALETTE_MATRICES_OES; i++ )
            pGLSTATE->m_MatrixPalette[i].Initialize(GLPARAM_MAX_PALETTE_MATRICES_OES_STACK_DEPTH);
#endif
        
        GLCLRERROR;
            
        pGLSTATE->m_TwoSidedLightning = GL_FALSE;

        pGLSTATE->m_LightModelAmbientColor[0] = F2VF(0.2f);
        pGLSTATE->m_LightModelAmbientColor[1] = F2VF(0.2f);
        pGLSTATE->m_LightModelAmbientColor[2] = F2VF(0.2f);
        pGLSTATE->m_LightModelAmbientColor[3] = F2VF(1.0f);

        pGLSTATE->m_Enable_ALPHA_TEST              = GL_FALSE;
        pGLSTATE->m_Enable_BLEND                   = GL_FALSE;
        //pGLSTATE->m_Enable_CLIP_PLANE[GLPARAM_MAX_CLIP_PLANES];   // ���ǰ� �ȵǾ��ִ�??
        pGLSTATE->m_Enable_COLOR_LOGIC_OP          = GL_FALSE;
        pGLSTATE->m_Enable_COLOR_MATERIAL          = GL_FALSE;
        pGLSTATE->m_Enable_CULL_FACE               = GL_FALSE;
        pGLSTATE->m_Enable_DEPTH_TEST              = GL_FALSE;
        pGLSTATE->m_Enable_DITHER                  = GL_TRUE;
        pGLSTATE->m_Enable_FOG                     = GL_FALSE;
        pGLSTATE->m_Enable_LIGHTING                = GL_FALSE;

        for( i=0; i<GLPARAM_MAX_LIGHTS; i++ )
        {
            pGLSTATE->m_Enable_LIGHT[i] = GL_FALSE;
        }

        pGLSTATE->m_Enable_LINE_SMOOTH             = GL_FALSE;
        pGLSTATE->m_Enable_MATRIX_PALETTE_OES      = GL_FALSE;
        pGLSTATE->m_Enable_MULTISAMPLE             = GL_TRUE;
        pGLSTATE->m_Enable_NORMALIZE               = GL_FALSE;
        pGLSTATE->m_Enable_POINT_SMOOTH            = GL_FALSE;
        pGLSTATE->m_Enable_POINT_SPRITE_OES        = GL_FALSE;
        pGLSTATE->m_Enable_POLYGON_OFFSET_FILL     = GL_FALSE;
        pGLSTATE->m_Enable_RESCALE_NORMAL          = GL_FALSE;
        pGLSTATE->m_Enable_SAMPLE_ALPHA_TO_COVERAGE= GL_FALSE;
        pGLSTATE->m_Enable_SAMPLE_ALPHA_TO_ONE     = GL_FALSE;
        pGLSTATE->m_Enable_SAMPLE_COVERAGE         = GL_FALSE;
        pGLSTATE->m_Enable_SCISSOR_TEST            = GL_FALSE;
        pGLSTATE->m_Enable_STENCIL_TEST            = GL_FALSE;
        //pGLSTATE->m_Enable_TEXTURE_2D              = GL_FALSE;
    
        pGLSTATE->m_IsGlobalLightingUpdated         = GL_TRUE;
		pGLSTATE->m_IsLightTurnON					= GL_FALSE;
        //pGLSTATE->m_CurrentLightMode              = LIGHTMODE_NONE;
        pGLSTATE->m_IsPrimitiveCacheClear           = GL_FALSE;
        pGLSTATE->m_DrawMode                        = 0xFFFF;

        for( i=0; i<GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES; i++ )
        {
            // size : 16 * 2(inverse matrix ����) * matrix palette ���� 
            GLESOAL_Malloc1D( sizeof(float)*32* GLPARAM_MAX_PALETTE_MATRICES_OES, 8, 
                            &pGLSTATE->m_DefaultMatrixPalette[i].m_DataMemory1D );
            pGLSTATE->m_DefaultMatrixPalette[i].m_Size = 16*2;
            
            for( int j=0; j<SIZEOF_MATRIXPALETTEBUFFER_FLAG; j++ )
                pGLSTATE->m_MatrixPaletteUpdateFlag[i][j]= 255;     // ó���� ��� update ������ϹǷ�.
        }
        pGLSTATE->m_CurMatrixPaletteBufferIndex     = 0;
        pGLSTATE->m_CurrentPrimitive.m_pMatrixPalette = 
                    &pGLSTATE->m_DefaultMatrixPalette[pGLSTATE->m_CurMatrixPaletteBufferIndex];

        pGLSTATE->m_IsTextureUpdated    = GL_FALSE;
        pGLSTATE->m_IsFogUpdated 		= GL_TRUE;
        
        __Initialize_HWBuffer__();

        Initialize_GLState();
    }

    GLboolean IsValidTextureSize(GLsizei value) 
    {
        if( !value )
            return GL_FALSE;
        //return ( 0 == ((value)&(value-1)) ); // is this power of 2?
        return GL_TRUE;
    }

	GLboolean IsValidMipmapTextureSize( GLint Level, GLint OrgWidth, GLint OrgHeight, GLint MipmapWidth, GLint MipmapHeight )
	{
		int value = 1<<Level;
		if( ( ( MipmapWidth * value) != OrgWidth ) || ( (MipmapHeight * value) != OrgHeight ) )
			return GL_FALSE;
		else
			return GL_TRUE;
	}

    GLboolean IsValidTextureFormat(GLenum internalFormat,
                              GLenum externalFormat, 
                              GLenum type) 
    {
        if ( internalFormat != externalFormat ) 
        {
            GLSETERROR( GL_INVALID_VALUE );
            return GL_FALSE;
        }

        switch (internalFormat) 
        {
            case GL_ALPHA:
            case GL_LUMINANCE:
            case GL_LUMINANCE_ALPHA:
                if (type != GL_UNSIGNED_BYTE) 
                {
                    GLSETERROR( GL_INVALID_OPERATION );
                    return GL_FALSE;
                }

                break;

            case GL_RGB:
                if (type != GL_UNSIGNED_BYTE && type != GL_UNSIGNED_SHORT_5_6_5) 
                {
                    GLSETERROR( GL_INVALID_OPERATION );
                    return GL_FALSE;
                }

                break;

            case GL_RGBA:
                if (type != GL_UNSIGNED_BYTE &&
                    type != GL_UNSIGNED_SHORT_4_4_4_4 &&
                    type != GL_UNSIGNED_SHORT_5_5_5_1) 
                {
                    GLSETERROR( GL_INVALID_OPERATION );
                    return GL_FALSE;
                }
                break;
            default:
                GLSETERROR( GL_INVALID_VALUE );
                return GL_FALSE;

        }

        return GL_TRUE;
    }


    void SetTextureSize( __TEXTURE__ *pTexture, GLsizei width, GLsizei height )
    {

        if( ( 1 != pTexture->m_ScaleX ) || ( pTexture->m_Width != width ) )
        {
            for( pTexture->m_WidthPowerOf2=1; pTexture->m_WidthPowerOf2<(width*pTexture->m_ScaleX); pTexture->m_WidthPowerOf2<<=1) {}
            //pTexture->m_WidthPowerOf2 = width;
            pTexture->m_Width = width;
            //__GLSTATE__.m_TextureMatrix[__GLSTATE__.m_ActiveTexture].m_IsUpdated = GL_TRUE;
        }
        if( ( 1 != pTexture->m_ScaleY ) || (pTexture->m_Height != height ) )
        {
            for( pTexture->m_HeightPowerOf2=1; pTexture->m_HeightPowerOf2<(height*pTexture->m_ScaleY); pTexture->m_HeightPowerOf2<<=1){}
            //pTexture->m_HeightPowerOf2 = height;
            pTexture->m_Height = height;
            //__GLSTATE__.m_TextureMatrix[__GLSTATE__.m_ActiveTexture].m_IsUpdated = GL_TRUE;
        }
    }

    GLESHAL_COLORFORMAT GetHALTexColorFormat( unsigned int format, unsigned int type )
    {
        GLESHAL_COLORFORMAT colorFormat = GLESHAL_COLORFORMAT_FORCES32;

        switch( format )
        {
        case GL_ALPHA:
            {
                if ( type == GL_UNSIGNED_BYTE )
                    colorFormat = GLESHAL_COLORFORMAT_A8;
            }
            break;
        case GL_RGB:
            {
                if ( type == GL_UNSIGNED_BYTE )
                    colorFormat = GLESHAL_COLORFORMAT_R5G6B5;

                else if ( type == GL_UNSIGNED_SHORT_5_6_5 )
                    colorFormat = GLESHAL_COLORFORMAT_R5G6B5;
            }
            break;
        case GL_RGBA:
            {
                if ( type == GL_UNSIGNED_BYTE )
                    //colorFormat = GLESHAL_COLORFORMAT_R5G6B5;
                    colorFormat = GLESHAL_COLORFORMAT_R4G4B4A4;
                else if ( type == GL_UNSIGNED_SHORT_4_4_4_4 )
                    colorFormat = GLESHAL_COLORFORMAT_R4G4B4A4;
                else if ( type == GL_UNSIGNED_SHORT_5_5_5_1 )
                    colorFormat = GLESHAL_COLORFORMAT_R5G5B5A1;
            }
            break;
        case GL_LUMINANCE:
            {
                if ( type == GL_UNSIGNED_BYTE )
                    colorFormat = GLESHAL_COLORFORMAT_L8;
            }
            break;
        case GL_LUMINANCE_ALPHA:
            {
                if ( type == GL_UNSIGNED_BYTE )
                    colorFormat = GLESHAL_COLORFORMAT_A8L8;
            }
            break;
        default:
            break;
        }

        return colorFormat;
    }

    GLESHAL_COLORFORMAT GetHALCompressedTexColorFormat( unsigned int type )
    {
        GLESHAL_COLORFORMAT colorFormat = GLESHAL_COLORFORMAT_FORCES32;

        switch( type )
        {
        case GL_PALETTE4_RGB8_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R5G6B5;
            break;
        case GL_PALETTE4_RGBA8_OES:
            //colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R5G6B5;
            colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R4G4B4A4;
            break;
        case GL_PALETTE4_R5_G6_B5_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R5G6B5;
            break;
        case GL_PALETTE4_RGBA4_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R4G4B4A4;
            break;
        case GL_PALETTE4_RGB5_A1_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R5G5B5A1;
            break;
        case GL_PALETTE8_RGB8_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
            break;
        case GL_PALETTE8_RGBA8_OES:
            //colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
            colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R4G4B4A4;
            break;
        case GL_PALETTE8_R5_G6_B5_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
            break;
        case GL_PALETTE8_RGBA4_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R4G4B4A4;
            break;
        case GL_PALETTE8_RGB5_A1_OES:
            colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G5B5A1;
            break;
        default:
            break;
        }
        return colorFormat;
    }
    
	GLboolean		GetValidMinTextureSizeWithScale( GLint bpp, GLint width, GLint height, GLint& scaleX, GLint& scaleY )
	{
		GLboolean isScale = GL_FALSE;	// texture�� ���� ���� �ʿ䰡 �ִ°�?
		
		GLint pixelSize = 32/bpp;
		
		if( !width || !height )			// texture size�� 0�̶�� ���ο� textrue�� ���� �ʿ䰡 ����.
		{
			scaleX = 1;
			scaleY = 1;
			return GL_FALSE;	
		}
		
		if( width >= pixelSize )
			scaleX = 1;
		else
		{
			int curCount = 2;
			while( width * curCount < pixelSize )
				curCount*=2;
				
			scaleX = curCount;
			isScale = GL_TRUE;
		}
		
		if( height > 1 )
			scaleY = 1;
		else
		{
			scaleY = 2;	
			isScale	= GL_TRUE;
		}
		
		return isScale;
	}
	
	GLboolean		MakeValidMinTexture( void* pDst, const GLvoid* pSrc, GLint bpp, GLint width, GLint height, GLint scaleX, GLint scaleY )
	{
		int i, j;
		switch( bpp )
		{
			case 4:	// 2�� ����� ���̴�.
				for( j = 0; j < height; j++ )
				{
					for( i = 0; i < (width+1)/2; i++ )
					{
						unsigned char value = ((unsigned char*)pSrc)[((j*width) + i)/2];
						unsigned short dstValue = (unsigned short)((value&0xF0) | (value>>4) 
												| ((value&0x0F) | (value&0x0F)<<4 ) );	// �³� �𸣰ڴ�. -_-;;
						
						for( int y = 0; y < scaleY; y++ )
							for( int x = 0; x < (scaleX)/2; x++ )
								((unsigned short*)pDst)[(width * scaleX/4) * (j * scaleY + y) + (i * scaleX/4) + x] = dstValue;
					}
					
				}
				break;
			case 8:
				for( j = 0; j < height; j++ )
				{
					for( i = 0; i < width; i++ )
					{
						unsigned char value = ((unsigned char*)pSrc)[(j * width) + i];
						
						for( int y = 0; y < scaleY; y++ )
							for( int x = 0; x < scaleX; x++ )
								((unsigned char*)pDst)[(width * scaleX) * (j * scaleY + y) + (i * scaleX) + x] = value;
					}
				}
				break;
			case 16:
				for( j = 0; j < height; j++ )
				{
					for( i = 0; i < width; i++ )
					{
						unsigned short value = ((unsigned short*)pSrc)[(j*width) + i];
						
						for( int y = 0; y < scaleY; y++ )
							for( int x = 0; x < scaleX; x++ )
								((unsigned short*)pDst)[(width * scaleX) * (j * scaleY + y) + (i * scaleX) + x] = value;
					}
				}			
				break;
			case 24:
				for( j = 0; j < height; j++ )
				{
					for( i = 0; i < width; i++ )
					{
						unsigned char val0 = ((unsigned char*)pSrc)[((j*width) + i) * 3 + 0];
						unsigned char val1 = ((unsigned char*)pSrc)[((j*width) + i) * 3 + 1];
						unsigned char val2 = ((unsigned char*)pSrc)[((j*width) + i) * 3 + 2];
						
						for( int y = 0; y < scaleY; y++ )
							for( int x = 0; x < scaleX; x++ )
							{
								int index = ((width * scaleX) * (j * scaleY + y) + (i * scaleX) + x) * 3;
								
								((unsigned char*)pDst)[index + 0] = val0;
								((unsigned char*)pDst)[index + 1] = val1;
								((unsigned char*)pDst)[index + 2] = val2;
							}								
					}
				}			
				break;
			case 32:
				for( j = 0; j < height; j++ )
				{
					for( i = 0; i < width; i++ )
					{
						unsigned short val0 = ((unsigned short*)pSrc)[((j*width) + i) * 2 + 0];
						unsigned short val1 = ((unsigned short*)pSrc)[((j*width) + i) * 2 + 1];
						
						for( int y = 0; y < scaleY; y++ )
							for( int x = 0; x < scaleX; x++ )
							{
								int index = ((width * scaleX) * (j * scaleY + y) + (i * scaleX) + x) * 2;
								
								((unsigned short*)pDst)[index + 0] = val0;
								((unsigned short*)pDst)[index + 1] = val1;
							}								
					}
				}		
				break;								
			default:
				return GL_FALSE;
		}
		
		return GL_TRUE;
	}
    
    
    

    EGLBoolean InitializeOAL( int FSAA )
    {
        //return GL_TRUE;
        
        if ( __EGLSTATE__.m_isInit )
        {
            return EGL_TRUE;
        }
        
        if( GLESOAL_Initialize_Internal( FSAA ) )
        {
            GLESHAL_InitializeWithAddress( GLESOAL_GetVirtualAddressOf3DCore() );
            //GLESHAL_Initialize();

            GLESHAL_OpenModule();

            // point�� line rendering �ÿ� �̿��ϰ� �� �������.
            // GTE const register�� ���Ƶ��ϱ� �� ����. 
            float gteconst[ 4*8 ] = {
                -1.0f,  1.0f, 0.0f, 0.0f,
                -1.0f, -1.0f, 0.0f, 0.0f,
                 1.0f,  1.0f, 0.0f, 0.0f,
                 1.0f, -1.0f, 0.0f, 0.0f,

                 0.0f,  0.0f, 0.0f, 0.0f,
                 0.0f,  1.0f, 0.0f, 1.0f,
                 1.0f,  0.0f, 1.0f, 0.0f,
                 1.0f,  1.0f, 1.0f, 1.0f
            };
            GLESHAL_SetGTEConst( __Render_const_dest, sizeof(gteconst), gteconst );      // page 9



            #if 0 < SIZEOFCOMMANDQUEUE
            {
                if( !GLESOAL_Malloc1D( SIZEOFCOMMANDQUEUE, 8, &(__EGLSTATE__.m_CommandQueue) ) )
                    return EGL_FALSE;
                

                if( !( __EGLSTATE__.m_CommandQueue.MemoryHandle ) ){ return EGL_FALSE; }
                // front pointer�� �ʱ�ȭ�� �� �Լ� �ȿ��� �̷������.
                GLESHAL_OpenCommandQueue( (unsigned int*)(__EGLSTATE__.m_CommandQueue.VirtualAddress), 
                                          (unsigned int*)(__EGLSTATE__.m_CommandQueue.PhysicalAddress), 
                                          SIZEOFCOMMANDQUEUE/8 );
            }
            #endif

            EGLCLRERROR;

            __EGLSTATE__.m_isInit = EGL_TRUE;

            return EGL_TRUE;        
        }
        else
        {
            EGLSETERROR( GL_INVALID_OPERATION );
            return EGL_FALSE;   
        }
    }

    void FinalizeOAL( void )
    {
        if ( ! __EGLSTATE__.m_isInit )
        {
            return;
        }
        if( __EGLSTATE__.m_CommandQueue.MemoryHandle )
        {
            GLESHAL_CloseCommandQueue();
            GLESOAL_Free1D( &(__EGLSTATE__.m_CommandQueue) );
        }

        while( GLESHAL_CheckBusy() ){ }
        GLESHAL_CloseModule();

        GLESOAL_Finalize();
        
        ClearClass( &__EGLSTATE__ );
        
        __EGLSTATE__.m_isInit = EGL_FALSE;
    }

    const char* GLERROR_TO_STRING( int error_code )
    {
        switch( error_code )
        {
        case GL_NO_ERROR          : return "GL_NO_ERROR         " ;
        case GL_INVALID_ENUM      : return "GL_INVALID_ENUM     " ;
        case GL_INVALID_VALUE     : return "GL_INVALID_VALUE    " ;
        case GL_INVALID_OPERATION : return "GL_INVALID_OPERATION" ;
        case GL_STACK_OVERFLOW    : return "GL_STACK_OVERFLOW   " ;
        case GL_STACK_UNDERFLOW   : return "GL_STACK_UNDERFLOW  " ;
        case GL_OUT_OF_MEMORY     : return "GL_OUT_OF_MEMORY    " ;
        }
        //static char error_string[16];
        //sprintf( error_string, "%04x", error_code );
        //return error_string;
        return "Unknown             ";
    }
    
    const char* EGLERROR_TO_STRING( int error_code )
    {
        switch( error_code )
        {
        case EGL_SUCCESS             : return "EGL_SUCCESS              ";
        case EGL_NOT_INITIALIZED     : return "EGL_NOT_INITIALIZED      ";
        case EGL_BAD_ACCESS          : return "EGL_BAD_ACCESS           ";
        case EGL_BAD_ALLOC           : return "EGL_BAD_ALLOC            ";
        case EGL_BAD_ATTRIBUTE       : return "EGL_BAD_ATTRIBUTE        ";
        case EGL_BAD_CONFIG          : return "EGL_BAD_CONFIG           ";
        case EGL_BAD_CONTEXT         : return "EGL_BAD_CONTEXT          ";
        case EGL_BAD_CURRENT_SURFACE : return "EGL_BAD_CURRENT_SURFACE  ";
        case EGL_BAD_DISPLAY         : return "EGL_BAD_DISPLAY          ";
        case EGL_BAD_MATCH           : return "EGL_BAD_MATCH            ";
        case EGL_BAD_NATIVE_PIXMAP   : return "EGL_BAD_NATIVE_PIXMAP    ";
        case EGL_BAD_NATIVE_WINDOW   : return "EGL_BAD_NATIVE_WINDOW    ";
        case EGL_BAD_PARAMETER       : return "EGL_BAD_PARAMETER        ";
        case EGL_BAD_SURFACE         : return "EGL_BAD_SURFACE          ";
        case EGL_CONTEXT_LOST        : return "EGL_CONTEXT_LOST         ";
        }
        //static char error_string[16];
        //sprintf( error_string, "%04x", error_code );
        //return error_string;
        return "Unknown             ";
    }

} // namespace __MES_OPENGL_ES__

using namespace __MES_OPENGL_ES__;

// @Gamza 2008/07/31
void glPowerOff( void )
{
	if ( ! __EGLSTATE__.m_isInit )
	{
		return;
	}
	GLESHAL_Flush();
	if( __EGLSTATE__.m_CommandQueue.MemoryHandle )
	{
		GLESHAL_CloseCommandQueue();
	}
	while( GLESHAL_CheckBusy() ){ }
	//GLESHAL_CloseModule();
	//GLESOAL_Finalize();
	//ClearClass( &__EGLSTATE__ );
	__EGLSTATE__.m_isInit = EGL_FALSE;
}
// @Gamza 2008/07/31
void glPowerOn ( void )
{
	if ( __EGLSTATE__.m_isInit )
	{
		return;
	}
	GLESHAL_RestoreModule();
	#if 0 < SIZEOFCOMMANDQUEUE
	{
		if( !( __EGLSTATE__.m_CommandQueue.MemoryHandle ) ){ return; }
		// front pointer�� �ʱ�ȭ�� �� �Լ� �ȿ��� �̷������.
		GLESHAL_OpenCommandQueue( (unsigned int*)(__EGLSTATE__.m_CommandQueue.VirtualAddress), 
								  (unsigned int*)(__EGLSTATE__.m_CommandQueue.PhysicalAddress), 
								  SIZEOFCOMMANDQUEUE/8 );
	}
	#endif
	__EGLSTATE__.m_isInit = EGL_TRUE;
}

void glTextureDither ( int Enable )
{
	GLESOAL_SetDither( Enable );	
}


#if defined(WIN32) || defined(UNDER_CE)
#ifndef NODLLMAIN
BOOL WINAPI DllMain( HANDLE, DWORD dwReason, LPVOID ) 
{
    //FILE *fd;
    //fd = fopen("DllMain.txt", "at");
    //fprintf( fd, "-------DLLMain in GLES Lite excuted--------\n" );
    switch(dwReason)
    {
    case DLL_PROCESS_ATTACH:		
#if defined(DEBUG) || defined(_DEBUG) 
		RETAILMSG( 1, (TEXT("opengles_lite.dll : attached [") TEXT(__DATE__) TEXT("/") TEXT( __TIME__ ) TEXT("/DEBUG]\n") ) ); 
#else
		RETAILMSG( 1, (TEXT("opengles_lite.dll : attached [") TEXT(__DATE__) TEXT("/") TEXT( __TIME__ ) TEXT("/RELEASE]\n") ) ); 
#endif
        break;
    case DLL_THREAD_ATTACH :
        break;
    case DLL_THREAD_DETACH :
        break;
    case DLL_PROCESS_DETACH:
        //fprintf( fd, "DLL_PROCESS_DETACH!\n" );
        eglDestroySurface( __EGLSTATE__.m_pCurDisplay, __EGLSTATE__.m_pCurDrawSurface );
        //fprintf( fd, "eglDestroySurface!\n" );
        eglTerminate( __EGLSTATE__.m_pCurDisplay );
        //fprintf( fd, "eglTerminate!\n" );
		
#if defined(DEBUG) || defined(_DEBUG) 
		RETAILMSG( 1, (TEXT("opengles_lite.dll : detached [") TEXT( __DATE__ ) TEXT( "/" ) TEXT( __TIME__ ) TEXT("/DEBUG]\n") ) ); 
#else
		RETAILMSG( 1, (TEXT("opengles_lite.dll : detached [") TEXT( __DATE__ ) TEXT( "/" ) TEXT( __TIME__ ) TEXT("/RELEASE]\n") ) ); 
#endif
        break;
    }
    //fclose(fd);
    return TRUE;
}
#endif // NODLLMAIN
#endif
