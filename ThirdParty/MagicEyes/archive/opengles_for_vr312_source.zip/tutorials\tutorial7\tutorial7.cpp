#include "t7_render.h"
#include "t7_timer.h"
#include <stdio.h>

namespace __TUTORIAL7__
{

//Some useful global handles
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.

Timer *timer = NULL;

}//namespace
using namespace __TUTORIAL7__;

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial7Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;

  //Create our timer
  timer = new Timer();
  
  if(!InitOGLES()) //OpenGL ES Initialization
  {
    printf("OpenGL ES init error.");
    return false; 
  }
  
  //Bring the window to front, focus it and refresh it
  //SetWindowText(hWnd, L"OpenGLES ortho");
  //ShowWindow(hWnd, nCmdShow); 
  //UpdateWindow(hWnd);
 
  unsigned int frames = 1800;
  //Message Loop
  //while(!done)
  while(frames--)  
  {
    Render();
    timer->UpdateTimer(); //update the timer
  }
  
  //Clean up all
  Clean();
  delete timer;
  
  return 0;
}


