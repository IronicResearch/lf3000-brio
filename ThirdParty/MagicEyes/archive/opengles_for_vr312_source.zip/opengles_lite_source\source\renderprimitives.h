//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : renderprimitives.h
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2007/06/01 Yuni  first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : renderprimitives.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/17 Gamza first implementation
//------------------------------------------------------------------------------
#ifndef _RENDERPRIMITIVES_H
#define _RENDERPRIMITIVES_H

//	����������� �ϳ� �����.
//------------------------------------------------------------------------------
#ifndef MES_ASSERT
#if defined(WIN32) || defined(UNDER_CE)
#pragma warning(disable:4127)
#endif
#define MES_ASSERT(exp)	
#define MES_SPY(exp)	
#define MES_ASSERT_RETURN(exp,return_exp)	{ MES_ASSERT(exp); if( !(exp) ){ return_exp; } }
#endif
//------------------------------------------------------------------------------

#include "objectpool.h"

namespace __MES_OPENGL_ES__
{
/*
struct __PRIMITIVEPARAMETER__
{
	__BUFFER__*		m_pPosition;
	__BUFFER__*		m_pColor;
	__BUFFER__*		m_pNormal;
	__BUFFER__*		m_pPointSize;
	__BUFFER__*		m_pWeight;
	__BUFFER__*		m_pTexCoord[2];
	__BUFFER__*		m_pMatrixIndex;
	__BUFFER__*		m_pPaletteMatrix;

	float	m_GTEConst[16];
};
*/
void UpdateTexture( void );
unsigned int Preparerendering( GLint first, GLsizei count );
//void SetBufferUseLog( void );
GLboolean SetPrimitiveControlParam( GLenum mode );
void DestroyDefaultBuffer( void );
void SetCurMatrixPaletteBufferIndex( void );
void EnableMatrixPaletteUpdate( GLint index );

GLboolean RenderPrimitiveArrays( unsigned int StreamValidFlag, GLenum mode, GLint first, GLsizei count );
GLboolean RenderPrimitiveElements( unsigned int StreamValidFlag, GLenum mode, GLsizei count );

//void SetTextureBlendMode( unsigned int textureStage, __TEXTURE__* ptexture );
//GLboolean UpdateMatrixPaletteState( void );

} // namespace __MES_OPENGL_ES__

using namespace __MES_OPENGL_ES__;

#endif // #ifndef _RENDERPRIMITIVES_H
