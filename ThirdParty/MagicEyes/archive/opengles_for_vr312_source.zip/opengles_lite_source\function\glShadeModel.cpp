//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glShadeModel.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glShadeModel (GLenum mode)
{
	CALL_LOG;
	unsigned long curRenderState = GLESHAL_GetRenderState();

	switch (mode)
	{
	case GL_FLAT:
		//curRenderState &= ~GLESHAL_RS_SHADE_ENB;
		break;
	case GL_SMOOTH:
		curRenderState |= GLESHAL_RS_SHADE_ENB;
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
	curRenderState |= GLESHAL_RS_SHADE_ENB;
	__GLSTATE__.m_ShadingModel = mode;
	GLESHAL_SetRenderState( curRenderState );
}
