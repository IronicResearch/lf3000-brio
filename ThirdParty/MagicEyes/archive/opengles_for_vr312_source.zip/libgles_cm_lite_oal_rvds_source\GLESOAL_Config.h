//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_config.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2007/01/04 Yuni first implementation
//------------------------------------------------------------------------------

#ifndef _GLES_OAL_CONFIG_H
#define _GLES_OAL_CONFIG_H


//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#if defined(WIN32) || defined(UNDER_CE)
#pragma warning( push, 3 )
#include <windows.h>
#pragma warning( pop )
#pragma warning( disable:4514 )
#endif

//------------------------------------------------------------------------------
//	Native display/window type
//------------------------------------------------------------------------------
//#if defined(WIN32) || defined(UNDER_CE)
//typedef	HDC			NativeDisplayType;
//typedef HWND		NativeWindowType;

//#else
typedef	void*		NativeDisplay;
typedef void*		NativeWindow;

//#endif


//------------------------------------------------------------------------------
//	Display size
//------------------------------------------------------------------------------
#define DISPLAY_WIDTH	480
#define DISPLAY_HEIGHT	272


//------------------------------------------------------------------------------
//	Non C 1D/2D allocator
//------------------------------------------------------------------------------
#define	CFGMESMEM_BASE									0x0000000


#define	CFGMESMEM_1D_REGION0_VIRTUAL_ADDR				(CFGMESMEM_BASE+0x02000000)
#define	CFGMESMEM_1D_REGION0_PHYSICAL_ADDR				(CFGMESMEM_BASE+0x02000000)
#define	CFGMESMEM_1D_REGION0_SIZEINMB					16

#define	CFGMESMEM_1D_REGION1_VIRTUAL_ADDR				0
#define	CFGMESMEM_1D_REGION1_PHYSICAL_ADDR				0
#define	CFGMESMEM_1D_REGION1_SIZEINMB					0

#define	CFGMESMEM_1D_REGION2_VIRTUAL_ADDR				0
#define	CFGMESMEM_1D_REGION2_PHYSICAL_ADDR				0
#define	CFGMESMEM_1D_REGION2_SIZEINMB					0

#define	CFGMESMEM_2D_REGION0_VIRTUAL_ADDR				(CFGMESMEM_BASE+0x03000000)
#define	CFGMESMEM_2D_REGION0_PHYSICAL_ADDR				(CFGMESMEM_BASE+0x03000000)
#define	CFGMESMEM_2D_REGION0_SIZEINMB					16
#define	CFGMESMEM_2D_REGION0_STRIDE						4096

#define	CFGMESMEM_2D_REGION1_VIRTUAL_ADDR				0
#define	CFGMESMEM_2D_REGION1_PHYSICAL_ADDR				0
#define	CFGMESMEM_2D_REGION1_SIZEINMB					0
#define	CFGMESMEM_2D_REGION1_STRIDE						0

#define	CFGMESMEM_2D_REGION2_VIRTUAL_ADDR				0
#define	CFGMESMEM_2D_REGION2_PHYSICAL_ADDR				0
#define	CFGMESMEM_2D_REGION2_SIZEINMB					0
#define	CFGMESMEM_2D_REGION2_STRIDE						0

#define DEFAULT_HEAP_ID									0


#endif // _GLES_OAL_CONFIG_H
