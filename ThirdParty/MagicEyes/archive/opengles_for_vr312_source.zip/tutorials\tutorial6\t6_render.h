#ifndef RENDER_H
#define RENDER_H

#include <Fake_OS.h>

#include <GLES/gl.h>
#include <GLES/egl.h>

namespace __TUTORIAL6__
{

GLboolean InitOGLES();
void Render();  
void SetOrtho2D();
void SetOrtho();
void SetPerspective();
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar);
void Clean();   

}//namespace

#endif
