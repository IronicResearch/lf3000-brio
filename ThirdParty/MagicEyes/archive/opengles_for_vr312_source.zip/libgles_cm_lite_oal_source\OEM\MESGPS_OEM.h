//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : 
//	File       : MESGPS_OEM.h
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2007/07/23 Gamza	MESGPSOEM_SetDisplayAddress �߰�.
//		2007/07/23 Gamza	Initialize/Finalize �������̽� �߰�.
//		2006/08/31 Gamza	CHIP ID �������̽� �߰�.
//		2006/08/31 Gamza	memory interface����.
//							��¥ �޸� �ϳ��� �Ҵ�޾� ����ϱ����.
//		2006/08/22 Gamza	first implementation
//------------------------------------------------------------------------------
#ifndef _MESGPS_OEM_H
#define _MESGPS_OEM_H

#ifndef MESGPSOEMAPI
#	ifndef UNDER_CE
#		define MESGPSOEMAPI
#	else // UNDER_CE
#		ifdef MESGPS_OEM_EXPORTS
#			define MESGPSOEMAPI __declspec(dllexport)
#		else // MESGPS_OEM_EXPORTS
#			define MESGPSOEMAPI extern
#		endif // MESGPS_OEM_EXPORTS
#	endif // UNDER_CE
#endif // MESGPSOEMAPI

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
	typedef bool	CBOOL;
#else
	typedef int		CBOOL;
#endif

typedef	unsigned long	U32;

//------------------------------------------------------------------------------
//	hardware base address (virtual address)
//------------------------------------------------------------------------------
typedef enum
{
	MESGPSOEM_CHIPID_VR3511F = 1,
	MESGPSOEM_CHIPID_MP2530F = 2,
	MESGPSOEM_CHIPID_FORCEU32 = 0x7FFFFFFF,
} MESGPSOEM_CHIPID;
MESGPSOEMAPI MESGPSOEM_CHIPID MESGPSOEM_GetChipID( void );

//------------------------------------------------------------------------------
//	hardware base address (virtual address)
//------------------------------------------------------------------------------
MESGPSOEMAPI unsigned int MESGPSOEM_GetVirtualAddress( void );

//------------------------------------------------------------------------------
//	Initialize/Finalize
//------------------------------------------------------------------------------
typedef struct 
{
	U32 m_Size; // Specifies the size, in bytes, of this structure. Set this member to sizeof(MESGPSOEM_Config). 
	U32 m_FSAA; // [0] FSAA disable [1] FSAA enable
} MESGPSOEM_Config;
MESGPSOEMAPI CBOOL MESGPSOEM_Initialize( const MESGPSOEM_Config* pMESGPSConfig );
MESGPSOEMAPI CBOOL MESGPSOEM_Finalize( void );

//------------------------------------------------------------------------------
//	clock control
//------------------------------------------------------------------------------
MESGPSOEMAPI CBOOL MESGPSOEM_ClockEnable( void );
MESGPSOEMAPI CBOOL MESGPSOEM_ClockDisable( void );

//------------------------------------------------------------------------------
//	display control
//------------------------------------------------------------------------------
MESGPSOEMAPI CBOOL MESGPSOEM_Show3D( int X, int Y, int Width, int Height );
MESGPSOEMAPI CBOOL MESGPSOEM_Hide3D( void );
MESGPSOEMAPI CBOOL MESGPSOEM_SetOverlay( int bEnable, 
										unsigned char R,
										unsigned char G, 
										unsigned char B );

//------------------------------------------------------------------------------
//	memory management
//------------------------------------------------------------------------------
MESGPSOEMAPI CBOOL MESGPSOEM_OpenMalloc(void);
MESGPSOEMAPI CBOOL MESGPSOEM_CloseMalloc(void);

typedef struct
{
	U32 MemoryHandle;	///< memory handle for internal (do not modified it)
	U32 VirtualAddress; ///< virtual address of memory block (16byte aligned)
	U32 PhysicalAddress;///< physical address of memory block (16byte aligned)
	U32 Size;           ///< byte size of memory block
} MESGPSOEM_Memory1D;
MESGPSOEMAPI CBOOL MESGPSOEM_Malloc1D( U32 ByteSize, MESGPSOEM_Memory1D* pMemory1D );
MESGPSOEMAPI CBOOL MESGPSOEM_Free1D( MESGPSOEM_Memory1D* pMemory1D );

///	@brief 2D memory information structure
typedef struct
{
	U32 MemoryHandle;	///< memory handle for internal (do not modified it)
	U32 VirtualAddress; ///< virtual address of memory block
	U32 PhysicalAddress;///< physical address of memory block
	U32 Stride;         ///< bytes per line
	U32 X;              ///< x position in 2D memory heap (unit: 8bit)
	U32 Y;              ///< y position in 2D memory heap
	U32 Width;          ///< memory block width (unit: 8bit)
	U32 Height;         ///< memory block height
} MESGPSOEM_Memory2D;
MESGPSOEMAPI CBOOL MESGPSOEM_Malloc2D( U32 Width, U32 Height, U32 AlignX, U32 AlignY,
					MESGPSOEM_Memory2D* pMemory2D );
MESGPSOEMAPI CBOOL MESGPSOEM_Free2D( MESGPSOEM_Memory2D* pMemory2D );

MESGPSOEMAPI void MESGPSOEM_SetDisplayAddress( const MESGPSOEM_Memory2D* pMemory2D );
MESGPSOEMAPI void MESGPSOEM_WaitForDirtyFlagCleared( void );
MESGPSOEMAPI void MESGPSOEM_SetDirtyFlag( void );
MESGPSOEMAPI CBOOL MESGPSOEM_IsDualDisplay( void );

#ifdef __cplusplus
	};
#endif
#endif // #ifndef _MESGPS_OEM_H
