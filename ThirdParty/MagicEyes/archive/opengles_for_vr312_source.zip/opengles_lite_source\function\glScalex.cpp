//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glScalex.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_1691.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glScalex (GLfixed x, GLfixed y, GLfixed z)
{
	CALL_LOG;
	Vfloat _x = X2VF( x );
	Vfloat _y = X2VF( y );
	Vfloat _z = X2VF( z );
	__GLSTATE__.m_pCurrentMatrixMode->Scale( _x, _y, _z );	
	__GLSTATE__.m_pCurrentMatrixMode->m_IsUpdated = GL_TRUE;

	if( GL_MATRIX_PALETTE_OES == __GLSTATE__.m_MatrixMode )
		EnableMatrixPaletteUpdate( __GLSTATE__.m_CurrentPaletteMatrix );
}

