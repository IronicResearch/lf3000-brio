//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLoadMatrixf.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_3260.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// The glLoadMatrixd and glLoadMatrixf functions replace the current matrix with an arbitrary matrix.


//	glGet with argument GL_MATRIX_MODE
//	glGet with argument GL_MODELVIEW_MATRIX
//	glGet with argument GL_PROJECTION_MATRIX
//	glGet with argument GL_TEXTURE_MATRIX

//	GL_INVALID_OPERATION  glLineWidth was called between a call to glBegin and the corresponding call to glEnd. 

void glLoadMatrixf (const GLfloat *m)
{
	CALL_LOG;
	Matrix4x4 mat;
	mat.m[0][0] = F2VF(m[0]); mat.m[0][1] = F2VF(m[4]); mat.m[0][2] = F2VF(m[ 8]); mat.m[0][3] = F2VF(m[12]); 
	mat.m[1][0] = F2VF(m[1]); mat.m[1][1] = F2VF(m[5]); mat.m[1][2] = F2VF(m[ 9]); mat.m[1][3] = F2VF(m[13]); 
	mat.m[2][0] = F2VF(m[2]); mat.m[2][1] = F2VF(m[6]); mat.m[2][2] = F2VF(m[10]); mat.m[2][3] = F2VF(m[14]); 
	mat.m[3][0] = F2VF(m[3]); mat.m[3][1] = F2VF(m[7]); mat.m[3][2] = F2VF(m[11]); mat.m[3][3] = F2VF(m[15]); 
	__GLSTATE__.m_pCurrentMatrixMode->LoadMatrix(mat);
	__GLSTATE__.m_pCurrentMatrixMode->m_IsUpdated = GL_TRUE;

	if( GL_MATRIX_PALETTE_OES == __GLSTATE__.m_MatrixMode )
		EnableMatrixPaletteUpdate( __GLSTATE__.m_CurrentPaletteMatrix );
}

//void glLoadMatrixd (const GLdouble *m)
//{
//	DONOTCALL_BEGINEND;
//	Matrix4x4& mat = __GLSTATE__.pCurrentMatrixMode->CurrentMatrix();
//	mat.m[0][0] = F2VF(m[0]); mat.m[0][1] = F2VF(m[4]); mat.m[0][2] = F2VF(m[ 8]); mat.m[0][3] = F2VF(m[12]); 
//	mat.m[1][0] = F2VF(m[1]); mat.m[1][1] = F2VF(m[5]); mat.m[1][2] = F2VF(m[ 9]); mat.m[1][3] = F2VF(m[13]); 
//	mat.m[2][0] = F2VF(m[2]); mat.m[2][1] = F2VF(m[6]); mat.m[2][2] = F2VF(m[10]); mat.m[2][3] = F2VF(m[14]); 
//	mat.m[3][0] = F2VF(m[3]); mat.m[3][1] = F2VF(m[7]); mat.m[3][2] = F2VF(m[11]); mat.m[3][3] = F2VF(m[15]); 
//}
//
