#include <Fake_OS.h>
#include "timer.h"

Timer::Timer()
{   
  //we must initialize all our variables
  m_diffTime = 0;
  m_accumTime = 0;
  m_fps = 0;
  m_lastTime = 0;		
	m_frameTime = 0; 
}
//-----------------------------------------------------
void Timer::UpdateTimer()
{
  long currentTime;
  static long framesPerSecond = 0;		
  static bool sw = false;
  static unsigned long firstTime = 0;
  if(!sw)
  {
    firstTime = OS_GetTickCount();
    sw = true;
    
  }

  currentTime = OS_GetTickCount() - firstTime; //compute time elapsed since the first UpdateTimer call
  
  m_diffTime   = currentTime - m_frameTime; //compute time elapsed since the last frame
  m_accumTime += m_diffTime;               //compute accumulated time
  m_frameTime  = currentTime;

  //compute frames per second
  framesPerSecond++;
  if(currentTime - m_lastTime > 1000 )
  {
	  m_lastTime = currentTime;
    m_fps = framesPerSecond;
    framesPerSecond = 0;
  }
}
//---------------------------------------------------------------------------
//returns the elapsed time between the current frame and the last frame
unsigned long Timer::GetTimeBetweenTwoFrames()   
{
  /*HACK: Because we make a sleep(3000) in the program, we do not want return 3000
    because that will disturb our animations so, lets  do a little hack...*/
  if(m_diffTime > 2000)
    return 110; //a good empirical value
  return m_diffTime;
}; 
