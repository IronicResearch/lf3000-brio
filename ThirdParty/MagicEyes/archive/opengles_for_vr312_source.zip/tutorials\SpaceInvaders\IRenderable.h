#ifndef IRENDERABLE_H
#define IRENDERABLE_H
#include <GLES/gl.h>
#include "fixed.h"

/* Interfaz for almost all drawable objects. Provides with frustum culling tests and bounding volume
   construction*/
class IRenderable  
{
public:
  IRenderable() {};	  
  virtual int Draw(unsigned long elapsedTime,bool showBB) = 0;
  void DrawBoundingBox();
  
  virtual void ComputeBSphere();
  virtual bool IsInFrustum() = 0;
  virtual void ComputeAABB() = 0;  

  GLfixed m_minorAABBCorner[3];
  GLfixed m_maxAABBCorner[3];
  GLfixed m_boundingBoxVertices[24];
  GLfixed m_sphereCenter[3];
  GLfixed m_sphereRadius;

};


#endif 
