#ifndef FIXED_H
#define FIXED_H

namespace __TUTORIAL5__
{

const unsigned int PRECISION = 16;
const GLfixed ONE  = 1 << PRECISION;
const GLfixed ZERO = 0;

inline GLfixed FixedFromInt(int value) {return value << PRECISION;};
inline GLfixed FixedFromFloat(float value) {return static_cast<GLfixed>(value * static_cast<float>(ONE));};
inline GLfixed MultiplyFixed(GLfixed op1, GLfixed op2) {return static_cast<GLfixed>(((__int64)op1 * (__int64)op2) >> PRECISION);};


inline GLfixed DivideFixed(GLfixed op1, GLfixed op2) 
{
  __int64  o1 = (__int64)op1 << PRECISION;
  __int64 result = o1 / (__int64)op2;
  return (GLfixed)result;
};

}// namespace
#endif
