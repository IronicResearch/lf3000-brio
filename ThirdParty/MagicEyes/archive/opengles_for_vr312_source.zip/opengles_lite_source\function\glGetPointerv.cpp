//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetPointerv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_8uwm.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glGetPointerv (GLenum pname, void **params)
{
	CALL_LOG;
	switch (pname) {
	case GL_VERTEX_ARRAY_POINTER:
		params[0] = const_cast<void *>(__GLSTATE__.m_VertexPointer.m_Pointer);
		break;

	case GL_NORMAL_ARRAY_POINTER:
		params[0] = const_cast<void *>(__GLSTATE__.m_NormalPointer.m_Pointer);
		break;

	case GL_COLOR_ARRAY_POINTER:
		params[0] = const_cast<void *>(__GLSTATE__.m_ColorPointer.m_Pointer);
		break;

	case GL_TEXTURE_COORD_ARRAY_POINTER:
		params[0] = const_cast<void *>(__GLSTATE__.m_TexturePointer[__GLSTATE__.m_ClientActiveTexture].m_Pointer);
		break;

	case GL_MATRIX_INDEX_ARRAY_POINTER_OES:
		params[0] = const_cast<void *>(__GLSTATE__.m_MatrixIndexPointer.m_Pointer);
		break;

	case GL_POINT_SIZE_ARRAY_POINTER_OES:
		params[0] = const_cast<void *>(__GLSTATE__.m_PointSizePointer.m_Pointer);
		break;

	case GL_WEIGHT_ARRAY_POINTER_OES:
		params[0] = const_cast<void *>(__GLSTATE__.m_WeightPointer.m_Pointer);
		break;

	default:
		GLSETERROR(GL_INVALID_ENUM);
		break;
	}
}
