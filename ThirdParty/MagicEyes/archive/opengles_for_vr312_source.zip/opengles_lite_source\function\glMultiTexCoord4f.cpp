//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glMultiTexCoord4f.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glMultiTexCoord.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glMultiTexCoord4f (GLenum target, GLfloat s, GLfloat t, GLfloat r, GLfloat q)
{
	CALL_LOG;
	if (target < GL_TEXTURE0 || target >= GL_TEXTURE0 + GLPARAM_MAX_TEXTURE_UNITS)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	signed int unit = target - GL_TEXTURE0;

	__GLSTATE__.m_UpdateDefaultTexCoord[unit] = __GLSTATE__.m_UpdateDefaultTexCoord[unit]
		|| (__GLSTATE__.m_DefaultTexCoord[unit][0] != F2VF(s))
		|| (__GLSTATE__.m_DefaultTexCoord[unit][1] != F2VF(t))
		|| (__GLSTATE__.m_DefaultTexCoord[unit][2] != F2VF(r))
		|| (__GLSTATE__.m_DefaultTexCoord[unit][3] != F2VF(q))
		;

	__GLSTATE__.m_DefaultTexCoord[unit][0] = F2VF(s);
	__GLSTATE__.m_DefaultTexCoord[unit][1] = F2VF(t);
	__GLSTATE__.m_DefaultTexCoord[unit][2] = F2VF(r);
	__GLSTATE__.m_DefaultTexCoord[unit][3] = F2VF(q);
}



