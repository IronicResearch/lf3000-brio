//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDrawPixels.cpp
//	Description: �ϵ��������
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2009/04/16 Yuni first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

/*
GL_INVALID_ENUM is generated if format is not GL_RGBA or the value of GL_IMPLEMENTATION_COLOR_READ_FORMAT_OES.
GL_INVALID_ENUM is generated if type is not GL_UNSIGNED_BYTE or the value of GL_IMPLEMENTATION_COLOR_READ_TYPE_OES.
GL_INVALID_VALUE is generated if either width or height is negative.
GL_INVALID_OPERATION is generated if format and type are neither (GL_RGBA, GL_UNSIGNED_BYTE) nor the values of (GL_IMPLEMENTATION_COLOR_READ_FORMAT_OES, GL_IMPLEMENTATION_COLOR_READ_TYPE_OES).

 */

void glDrawPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{
	CALL_LOG;
	if (format != GL_RGBA && format != GL_RGB/*GLPARAM_IMPLEMENTATION_COLOR_READ_FORMAT_OES*/)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (type != GL_UNSIGNED_BYTE && type != GLPARAM_IMPLEMENTATION_COLOR_READ_TYPE_OES)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (width < 0 || height < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( !pixels )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( format == GL_RGBA && type == GL_UNSIGNED_BYTE )
	{
	//	GLESHAL_WaitToIdleState();	// Frame buffer�� �����ؾ� �ϹǷ� �۾��� ���� ������ ��ٸ���.
		GLESHAL_Flush();
		while( !GLESHAL_IsIdleState() )
			GLESOAL_Sleep(0);

		GLESOAL_CopyMemoryToDisplay_RGBA8( pixels, width*4,
										   x,  y, width, height,
										   __GLSTATE__.m_pSurface->GetColorBuffer(),
										   __GLSTATE__.m_SAMPLE_BUFFERS );
	}
	//else if( format == GLPARAM_IMPLEMENTATION_COLOR_READ_FORMAT_OES && type == GLPARAM_IMPLEMENTATION_COLOR_READ_TYPE_OES )
	else if( format == GL_RGB && ((type == GL_UNSIGNED_SHORT) || (type == GL_UNSIGNED_SHORT_5_6_5)))
	{
		//GLESHAL_WaitToIdleState();	// Frame buffer�� �����ؾ� �ϹǷ� �۾��� ���� ������ ��ٸ���.
		GLESHAL_Flush();
		while( !GLESHAL_IsIdleState() )
			GLESOAL_Sleep(0);

		GLESOAL_CopyMemoryToDisplay_RGB565( pixels, width*2,
										    x,  y, width, height,
											__GLSTATE__.m_pSurface->GetColorBuffer(),
											__GLSTATE__.m_SAMPLE_BUFFERS );
	}
	else
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
	
	//if (!result) {
	//	GLSETERROR(GL_INVALID_VALUE);
	//}
}
