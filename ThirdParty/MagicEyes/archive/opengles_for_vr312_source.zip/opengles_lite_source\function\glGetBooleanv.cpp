//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetBooleanv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_5ub8.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/08/23 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	for GL
//	glGetDoublev

//	for GL-ES
//	glGetBooleanv, glGetFloatv, glGetIntegerv

//	These functions return the value or values of a selected parameter.

//	GL_INVALID_ENUM  pname was not an accepted value. 
//	GL_INVALID_OPERATION  glGet was called between a call to glBegin and the corresponding call to glEnd. 

#define _C( c )		GLboolean(((c)==0) ? GL_FALSE : GL_TRUE )
#define _I( i )		GLboolean(((i)==0) ? GL_FALSE : GL_TRUE )
#define _B( b )		GLboolean(( b    ) ? GL_TRUE  : GL_FALSE)
#define _BUF( buf )	GLboolean(((buf)==0) ? GL_FALSE : GL_TRUE )
#define _VF( v )	GLboolean(((v)==0) ? GL_FALSE : GL_TRUE )
#define _VCF( v )	GLboolean(((v)==0) ? GL_FALSE : GL_TRUE )

void glGetBooleanv (GLenum pname, GLboolean *params)
{
	CALL_LOG;
#	include "glGet.inl"
}


