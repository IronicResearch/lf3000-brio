//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : 
//	File       : 
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/08/30 Gamza first implementation
//------------------------------------------------------------------------------
#define MESGPSOEMAPI
#include "MESGPS_OEM.h"

static MESGPSOEM_CHIPID (*s_pMESGPSOEM_GetChipID)( void );
static unsigned int     (*s_pMESGPSOEM_GetVirtualAddress)( void );
static CBOOL            (*s_pMESGPSOEM_Initialize)( const MESGPSOEM_Config* pMESGPSConfig );
static CBOOL            (*s_pMESGPSOEM_Finalize)( void );
static CBOOL            (*s_pMESGPSOEM_ClockEnable)( void );
static CBOOL            (*s_pMESGPSOEM_ClockDisable)( void );
static CBOOL            (*s_pMESGPSOEM_Show3D)( int X, int Y, int Width, int Height );
static CBOOL            (*s_pMESGPSOEM_Hide3D)( void );
static CBOOL            (*s_pMESGPSOEM_SetOverlay)( int bEnable, unsigned char R, unsigned char G,  unsigned char B );
static CBOOL            (*s_pMESGPSOEM_OpenMalloc)(void);
static CBOOL            (*s_pMESGPSOEM_CloseMalloc)(void);
static CBOOL            (*s_pMESGPSOEM_Malloc1D)( U32 ByteSize, MESGPSOEM_Memory1D* pMemory1D );
static CBOOL            (*s_pMESGPSOEM_Free1D)( MESGPSOEM_Memory1D* pMemory1D );
static CBOOL            (*s_pMESGPSOEM_Malloc2D)( U32 Width, U32 Height, U32 AlignX, U32 AlignY, MESGPSOEM_Memory2D* pMemory2D );
static CBOOL            (*s_pMESGPSOEM_Free2D)( MESGPSOEM_Memory2D* pMemory2D );
static void             (*s_pMESGPSOEM_SetDisplayAddress)( const MESGPSOEM_Memory2D* pMemory2D );
static void             (*s_pMESGPSOEM_WaitForDirtyFlagCleared)( void );
static void             (*s_pMESGPSOEM_SetDirtyFlag)( void );
static CBOOL            (*s_pMESGPSOEM_IsDualDisplay)( void );

static bool __LoadLibrary__( void );
static void __UnloadLibrary__( void );

MESGPSOEM_CHIPID MESGPSOEM_GetChipID( void )
{
	return s_pMESGPSOEM_GetChipID();
}
unsigned int     MESGPSOEM_GetVirtualAddress( void )
{
	return s_pMESGPSOEM_GetVirtualAddress();
}
CBOOL            MESGPSOEM_Initialize( const MESGPSOEM_Config* pMESGPSConfig )
{
	if( ! __LoadLibrary__() ){ return 0; }
	return s_pMESGPSOEM_Initialize(pMESGPSConfig);
}
CBOOL            MESGPSOEM_Finalize( void )
{
	CBOOL result = s_pMESGPSOEM_Finalize();
	__UnloadLibrary__();
	return result;
}
CBOOL            MESGPSOEM_ClockEnable( void )
{
	return s_pMESGPSOEM_ClockEnable();
}
CBOOL            MESGPSOEM_ClockDisable( void )
{
	return s_pMESGPSOEM_ClockDisable();
}
CBOOL            MESGPSOEM_Show3D( int X, int Y, int Width, int Height )
{
	return s_pMESGPSOEM_Show3D( X, Y, Width, Height );
}
CBOOL            MESGPSOEM_Hide3D( void )
{
	return s_pMESGPSOEM_Hide3D();
}
CBOOL            MESGPSOEM_SetOverlay( int bEnable, unsigned char R, unsigned char G,  unsigned char B )
{
	return s_pMESGPSOEM_SetOverlay(bEnable, R, G,  B );
}
CBOOL            MESGPSOEM_OpenMalloc(void)
{
	return s_pMESGPSOEM_OpenMalloc();
}
CBOOL            MESGPSOEM_CloseMalloc(void)
{
	return s_pMESGPSOEM_CloseMalloc();
}
CBOOL            MESGPSOEM_Malloc1D( U32 ByteSize, MESGPSOEM_Memory1D* pMemory1D )
{
	return s_pMESGPSOEM_Malloc1D( ByteSize, pMemory1D );
}
CBOOL            MESGPSOEM_Free1D( MESGPSOEM_Memory1D* pMemory1D )
{
	return s_pMESGPSOEM_Free1D( pMemory1D );
}
CBOOL            MESGPSOEM_Malloc2D( U32 Width, U32 Height, U32 AlignX, U32 AlignY, MESGPSOEM_Memory2D* pMemory2D )
{
	return s_pMESGPSOEM_Malloc2D( Width, Height, AlignX, AlignY, pMemory2D );
}
CBOOL            MESGPSOEM_Free2D( MESGPSOEM_Memory2D* pMemory2D )
{
	return s_pMESGPSOEM_Free2D( pMemory2D );
}
void             MESGPSOEM_SetDisplayAddress( const MESGPSOEM_Memory2D* pMemory2D )
{
	s_pMESGPSOEM_SetDisplayAddress( pMemory2D );
}
void             MESGPSOEM_WaitForDirtyFlagCleared( void )
{
	s_pMESGPSOEM_WaitForDirtyFlagCleared();
}
void             MESGPSOEM_SetDirtyFlag( void )
{
	s_pMESGPSOEM_SetDirtyFlag();
}
CBOOL            MESGPSOEM_IsDualDisplay( void )
{
	return s_pMESGPSOEM_IsDualDisplay();
}


#pragma warning( disable: 4514 )
#pragma warning( push, 3 )
#include <windows.h>
#pragma warning( pop )
static HMODULE g_dll_module = 0;

template<typename DSTTYPE, typename SRCTYPE>
void dachagocha_cast( DSTTYPE& dst, SRCTYPE src )
{
	dst = (DSTTYPE)src;
}

template<typename DSTTYPE>
bool GetProcAddress( DSTTYPE& dst, HMODULE hmodule, const TCHAR* pFunctionName )
{
	FARPROC pfunction = GetProcAddress( hmodule, pFunctionName);
	if( ! pfunction )
	{
		MessageBox( 0, pFunctionName, L"Cannot found a dll function", MB_OK );
		return false;
	}
	dachagocha_cast( dst, pfunction );
	return true;
}

bool __LoadLibrary__( void )
{
	if( g_dll_module ){ __UnloadLibrary__(); }

	g_dll_module = ::LoadLibrary( L"MESGPS_OEM.dll" );
	if( !g_dll_module )
	{
		MessageBox( 0, L"Cannot open MESGPS_OEM.dll", L"DLL load error", MB_OK );
		return false;
	}

	if( ! GetProcAddress( s_pMESGPSOEM_GetChipID               , g_dll_module, L"MESGPSOEM_GetChipID"               ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_GetVirtualAddress       , g_dll_module, L"MESGPSOEM_GetVirtualAddress"       ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Initialize              , g_dll_module, L"MESGPSOEM_Initialize"              ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Finalize                , g_dll_module, L"MESGPSOEM_Finalize"                ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_ClockEnable             , g_dll_module, L"MESGPSOEM_ClockEnable"             ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_ClockDisable            , g_dll_module, L"MESGPSOEM_ClockDisable"            ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Show3D                  , g_dll_module, L"MESGPSOEM_Show3D"                  ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Hide3D                  , g_dll_module, L"MESGPSOEM_Hide3D"                  ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_SetOverlay              , g_dll_module, L"MESGPSOEM_SetOverlay"              ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_OpenMalloc              , g_dll_module, L"MESGPSOEM_OpenMalloc"              ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_CloseMalloc             , g_dll_module, L"MESGPSOEM_CloseMalloc"             ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Malloc1D                , g_dll_module, L"MESGPSOEM_Malloc1D"                ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Free1D                  , g_dll_module, L"MESGPSOEM_Free1D"                  ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Malloc2D                , g_dll_module, L"MESGPSOEM_Malloc2D"                ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_Free2D                  , g_dll_module, L"MESGPSOEM_Free2D"                  ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_SetDisplayAddress       , g_dll_module, L"MESGPSOEM_SetDisplayAddress"       ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_WaitForDirtyFlagCleared , g_dll_module, L"MESGPSOEM_WaitForDirtyFlagCleared" ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_SetDirtyFlag            , g_dll_module, L"MESGPSOEM_SetDirtyFlag"            ) ){ __UnloadLibrary__(); return false; }
	if( ! GetProcAddress( s_pMESGPSOEM_IsDualDisplay           , g_dll_module, L"MESGPSOEM_IsDualDisplay"           ) ){ __UnloadLibrary__(); return false; }

	return true;
}

void __UnloadLibrary__( void )
{
	if( g_dll_module ) ::FreeLibrary( g_dll_module );
	g_dll_module = 0;
}

