//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#ifndef _GLESOAL_PRIVATE_H
#define _GLESOAL_PRIVATE_H

#include "libgles_cm_lite_oal.h"
#pragma warning( push, 3 )
#include <windows.h>
#pragma warning( pop )
#pragma warning( disable:4514 )

namespace __GLESOAL__ {

#define Segment( Address )	((((Address)>>22)<<1) | (((Address)>>11)&1))
#define SegmentX( Address )	((Address)&((1<<11)-1))
#define SegmentY( Address )	(((Address)>>12)&((1<<10)-1))

extern GLESOALbool	g_IsOpened;
extern HDC			g_NativeDisplay;
extern HWND			g_NativeWindow;
extern int			g_WindowWidth;
extern int			g_WindowHeight;

} // namespace __GLESOAL__

using namespace __GLESOAL__;

#endif // _GLESOAL_PRIVATE_H
