#ifndef ACTOR_H
#define ACTOR_H

#include <GLES/gl.h>
#include "mesh.h"
#include "fixed.h"
#include "IRenderable.h"
#include "global.h"

class Actor : public IRenderable
{
public:
  //this contructor creates the mesh	
  Actor(const char *filename, const char *texture,int lives, int hitpoints,bool hotOnTop = true);
  //this constructor is used with shared meshes
  Actor(Mesh *mesh,int lifes, int hitpoints,bool hotOnTop = true);
	~Actor();
  
  virtual int Draw(unsigned long elapsedtime,bool showBB = false);    
  virtual bool IsInFrustum();

  //returns the current state of the actor: 0 = alive, otherwise dying or dead
  inline GLfixed IsDying()                                   { return m_dying;}; //dying = dead 
  //update dying time 
  inline void UpdateDyingTime(unsigned long elapsedTime)     {m_dying += FixedFromInt(elapsedTime);};
  
  //revive the actor
  void Revive();
  //recompute the hot point
  void ComputeHotPoint(bool hotOnTop);

  GLfixed m_position[3];
  GLfixed m_rotation[4];
  GLfixed m_hotPoint[3];
  int m_lives;
  int m_hitPoints;
  
private:        
  int m_maxHitPoints;
  int m_maxLives;
  virtual void ComputeAABB();   
  GLfixed m_dying; //diying time (milliseconds) 0 = alive, [0-DYING_TIME] dying but dissapearing, > DIYING_TIME dissapeared (dead)
  Mesh *m_mesh;  
  bool m_ownedMesh;
};

#endif 
