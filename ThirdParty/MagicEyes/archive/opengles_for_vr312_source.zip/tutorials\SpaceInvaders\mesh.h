#ifndef MESH_H
#define MESH_H
#include <GLES/gl.h>
#include "texture.h"
#include "fixed.h"
#include "IRenderable.h"

//Structure to hold the optimized mesh data for rendering
struct FixedMesh
{
  GLshort indexCounter;
  GLshort vertexCounter;  
  GLshort *Indices;
  GLfixed *Geometry;
  //GLfixed *Normals; //wont need them
  GLfixed *TexCoord;  
};

//Structure to hold the data readed from the file
struct GenericObjectData
{
  char Name[128];
  char ParentName[128];
  unsigned int *Indices;
  float *Geometry;
  float *Normals;
  float *TexCoord;
  unsigned long iC;
  unsigned long vC;  
};

//GSD file header 
struct GSDHeader
{
  char id[32];
  char version[16];
  int numberOfSubObjects;
};
 
class Mesh : public IRenderable
{
public:
  Mesh(const char *filename, const char *texture, GLenum filter, GLenum wrap);
  ~Mesh();  
  bool GetState () {return m_state;};      
  virtual int Draw(unsigned long elapsedTime,bool showBB = false);
  virtual bool IsInFrustum();

private:  
  virtual void ComputeAABB();  
  bool m_state;
  FixedMesh m_mesh;  
  Texture *m_texture; //every mesh owns its own texture
};
#endif









