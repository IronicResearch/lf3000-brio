//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glAlphaFuncx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_5qhv.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//The glAlphaFunc function enables your application to set the alpha test function.

//	func 
//	The alpha comparison function. The following are the accepted symbolic constants and their meanings. Symbolic constant Meaning 
//	GL_NEVER Never passes.  
//	GL_LESS Passes if the incoming alpha value is less than the reference value.  
//	GL_EQUAL Passes if the incoming alpha value is equal to the reference value.  
//	GL_LEQUAL Passes if the incoming alpha value is less than or equal to the reference value.  
//	GL_GREATER  Passes if the incoming alpha value is greater than the reference value.  
//	GL_NOTEQUAL Passes if the incoming alpha value is not equal to the reference value.  
//	GL_GEQUAL Passes if the incoming alpha value is greater than or equal to the reference value.  
//	GL_ALWAYS Always passes. This is the default. 
//	
//	ref 
//	The reference value to which incoming alpha values are compared. This value is clamped to the range 0 through 1, where 0 represents the lowest possible alpha value and 1 the highest possible value. The default reference is 0. 
//
//	GL_ALPHA_TEST, see glEnable
//	glGet with argument GL_ALPHA_TEST_FUNC
//	glGet with argument GL_ALPHA_TEST_REF
//	glIsEnabled with argument GL_ALPHA_TEST
//
//
//	GL_INVALID_ENUM  func was not an accepted value. 
//	GL_INVALID_OPERATION  glAlphaFunc was called between a call to glBegin and the corresponding call to glEnd. 

void glAlphaFuncx (GLenum func, GLclampx ref)
{
	CALL_LOG;
	/*
	if( GL_NEVER    != func && 
		GL_LESS     != func && 
		GL_EQUAL    != func && 
		GL_LEQUAL   != func && 
		GL_GREATER  != func && 
		GL_NOTEQUAL != func && 
		GL_GEQUAL   != func && 
		GL_ALWAYS   != func )
	{
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}
	*/
	GLESHAL_ALPHAFUNC HALtype = GLESHAL_ALPHAFUNC_FORCE32;
	
	switch( func )
	{
		case GL_NEVER:
			HALtype = GLESHAL_ALPHAFUNC_NEVER;
			break;
		case GL_LESS:
			HALtype = GLESHAL_ALPHAFUNC_LESS;
			break;
		case GL_EQUAL:
			HALtype = GLESHAL_ALPHAFUNC_EQUAL;
			break;
		case GL_LEQUAL:
			HALtype = GLESHAL_ALPHAFUNC_LESSEQUAL;
			break;
		case GL_GREATER:
			HALtype = GLESHAL_ALPHAFUNC_GREATER;
			break;
		case GL_NOTEQUAL:
			HALtype = GLESHAL_ALPHAFUNC_NOTEQUAL;
			break;
		case GL_GEQUAL:
			HALtype = GLESHAL_ALPHAFUNC_GREATEREQUAL;
			break;
		case GL_ALWAYS:
			HALtype = GLESHAL_ALPHAFUNC_ALWAYS;
			break;
		default:
			GLSETERROR( GL_INVALID_ENUM );
			return;			
	}
	
	if( !GLESHAL_SetAlphaFunction( X2VCF(ref), HALtype ) )
	{
		GLSETERROR( GL_INVALID_OPERATION );
		return;
	}
	
	__GLSTATE__.m_AlphaFunc = func;
	__GLSTATE__.m_AlphaRef  = X2VCF(ref);
}


