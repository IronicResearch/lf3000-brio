//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglGetConfigAttrib.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	EGL_FALSE is returned on failure, EGL_TRUE otherwise. value is not modified when EGL_FALSE is returned.
//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
//	EGL_NOT_INITIALIZED is generated if display has not been initialized.
//	EGL_BAD_CONFIG is generated if config is not an EGL frame buffer configuration.
//	EGL_BAD_ATTRIBUTE is generated if attribute is not a valid frame buffer configuration attribute.

EGLBoolean eglGetConfigAttrib (EGLDisplay dpy, EGLConfig config, EGLint attribute, EGLint *value)
{
	CALL_LOG;
	const __CONFIG__* pcurconfig = (const __CONFIG__*)config;
	if( ! pcurconfig || EGLCONFIG_FLAG != pcurconfig->m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_CONFIG );
		return EGL_FALSE;
	}
	switch (attribute)
	{
	case EGL_BUFFER_SIZE            : *value = pcurconfig->m_BUFFER_SIZE            ; break;
	case EGL_RED_SIZE               : *value = pcurconfig->m_RED_SIZE               ; break;
	case EGL_GREEN_SIZE             : *value = pcurconfig->m_GREEN_SIZE             ; break;
	case EGL_BLUE_SIZE              : *value = pcurconfig->m_BLUE_SIZE              ; break;
	case EGL_ALPHA_SIZE             : *value = pcurconfig->m_ALPHA_SIZE             ; break;
	case EGL_BIND_TO_TEXTURE_RGB    : *value = pcurconfig->m_BIND_TO_TEXTURE_RGB    ; break;
	case EGL_BIND_TO_TEXTURE_RGBA   : *value = pcurconfig->m_BIND_TO_TEXTURE_RGBA   ; break;
	case EGL_CONFIG_CAVEAT          : *value = pcurconfig->m_CONFIG_CAVEAT          ; break;
	case EGL_CONFIG_ID              : *value = pcurconfig->m_CONFIG_ID              ; break;
	case EGL_DEPTH_SIZE             : *value = pcurconfig->m_DEPTH_SIZE             ; break;
	case EGL_LEVEL                  : *value = pcurconfig->m_LEVEL                  ; break;
	case EGL_MAX_PBUFFER_WIDTH      : *value = pcurconfig->m_MAX_PBUFFER_WIDTH      ; break;
	case EGL_MAX_PBUFFER_HEIGHT     : *value = pcurconfig->m_MAX_PBUFFER_HEIGHT     ; break;
	case EGL_MAX_PBUFFER_PIXELS     : *value = pcurconfig->m_MAX_PBUFFER_PIXELS     ; break;
	case EGL_MAX_SWAP_INTERVAL      : *value = pcurconfig->m_MAX_SWAP_INTERVAL      ; break;
	case EGL_MIN_SWAP_INTERVAL      : *value = pcurconfig->m_MIN_SWAP_INTERVAL      ; break;
	case EGL_NATIVE_RENDERABLE      : *value = pcurconfig->m_NATIVE_RENDERABLE      ; break;
	case EGL_NATIVE_VISUAL_ID       : *value = pcurconfig->m_NATIVE_VISUAL_ID       ; break;
	case EGL_NATIVE_VISUAL_TYPE     : *value = pcurconfig->m_NATIVE_VISUAL_TYPE     ; break;
	case EGL_SAMPLE_BUFFERS         : *value = pcurconfig->m_SAMPLE_BUFFERS         ; break;
	case EGL_SAMPLES                : *value = pcurconfig->m_SAMPLES                ; break;
	case EGL_STENCIL_SIZE           : *value = pcurconfig->m_STENCIL_SIZE           ; break;
	case EGL_SURFACE_TYPE           : *value = pcurconfig->m_SURFACE_TYPE           ; break;
	case EGL_TRANSPARENT_TYPE       : *value = pcurconfig->m_TRANSPARENT_TYPE       ; break;
	case EGL_TRANSPARENT_RED_VALUE  : *value = pcurconfig->m_TRANSPARENT_RED_VALUE  ; break;
	case EGL_TRANSPARENT_GREEN_VALUE: *value = pcurconfig->m_TRANSPARENT_GREEN_VALUE; break;
	case EGL_TRANSPARENT_BLUE_VALUE : *value = pcurconfig->m_TRANSPARENT_BLUE_VALUE ; break;
	default : 
		EGLSETERROR( EGL_BAD_ATTRIBUTE );
		return EGL_FALSE;
	}
	return EGL_TRUE;
}
