//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glCompressedTexImage2D.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glCompressedTexImage2D.html
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/07 Yuni	size�� 0�̾ error�� �ƴ�. ���, memory�� �Ҵ���� �ʴ´�.
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//GL_INVALID_ENUM is generated if target is not GL_TEXTURE_2D.
//GL_INVALID_VALUE may be generated if if level is greater than 0 or the absolute value of level is greater than log2max, where max is the returned value of GL_MAX_TEXTURE_SIZE.
//GL_INVALID_ENUMis generated if internalformat is not one of the accepted symbolic constants.
//GL_INVALID_VALUE is generated if width or height is less than 0 or greater than 2 + GL_MAX_TEXTURE_SIZE, or if either cannot be represented as 2k + 2border for some integer k.
//GL_INVALID_VALUEis generated if border is not 0.
//GL_INVALID_VALUEis generated if imageSize is not consistent with format, dimentions, and contents of the compressed image.

namespace{

	GLint (* UploadTexture)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* UploadMipmap)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* CopyTexture)( const GLESOAL_MEMORY2D* pSrcMemory2D, 
							const GLESOAL_MEMORY2D* pDstMemory2D, 
							unsigned int Width, unsigned int Height );

	GLint (* GetMipmapPosition)(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y );

	GLboolean GetInfomation( GLenum format, int &PaletteBitCount, int &MemBitCount )
	{
		//if( (0 != width) && (0 != height) )	// size�� 0�� �ƴ� ������ �޸� �Ҵ�.
		{
			switch (format) 
			{
			case GL_PALETTE4_RGB8_OES:
				PaletteBitCount = 4;
				MemBitCount = 3;
				UploadTexture = GLESOAL_UploadTexture_RGB8;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U8;
				CopyTexture	 = GLESOAL_CopyTexture_U8;
				break;

			case GL_PALETTE4_RGBA8_OES:
				PaletteBitCount = 4;
				MemBitCount = 4;
				UploadTexture = GLESOAL_UploadTexture_RGBA8;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U8;
				CopyTexture	 = GLESOAL_CopyTexture_U8;
				break;

			case GL_PALETTE4_R5_G6_B5_OES:
				PaletteBitCount = 4;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_R5G6B5;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U8;
				CopyTexture	 = GLESOAL_CopyTexture_U8;
				break;

			case GL_PALETTE4_RGBA4_OES:
				PaletteBitCount = 4;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_RGBA4;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U8;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R4G4B4A4;
				CopyTexture	 = GLESOAL_CopyTexture_U8;
				break;

			case GL_PALETTE4_RGB5_A1_OES:
				PaletteBitCount = 4;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_RGB5A1;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U8;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED4_R5G5B5A1;
				CopyTexture	 = GLESOAL_CopyTexture_U8;
				break;

			case GL_PALETTE8_RGB8_OES:
				PaletteBitCount = 8;
				MemBitCount = 3;
				UploadTexture = GLESOAL_UploadTexture_RGB8;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U16;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
				CopyTexture	 = GLESOAL_CopyTexture_U16;
				break;

			case GL_PALETTE8_RGBA8_OES:
				PaletteBitCount = 8;
				MemBitCount = 4;
				UploadTexture = GLESOAL_UploadTexture_RGBA8;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U16;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
				CopyTexture	 = GLESOAL_CopyTexture_U16;
				break;

			case GL_PALETTE8_R5_G6_B5_OES:
				PaletteBitCount = 8;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_R5G6B5;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U16;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G6B5;
				CopyTexture	 = GLESOAL_CopyTexture_U16;
				break;

			case GL_PALETTE8_RGBA4_OES:
				PaletteBitCount = 8;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_RGBA4;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U16;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED8_A4R4G4B4;
				CopyTexture	 = GLESOAL_CopyTexture_U16;
				break;

			case GL_PALETTE8_RGB5_A1_OES:
				PaletteBitCount = 8;
				MemBitCount = 2;
				UploadTexture = GLESOAL_UploadTexture_RGB5A1;
				GetMipmapPosition = GLESOAL_GetMipmapPosition_U16;
				//colorFormat = GLESHAL_COLORFORMAT_INDEXED8_R5G5B5A1;
				CopyTexture	 = GLESOAL_CopyTexture_U16;
				break;

			default:
				GLSETERROR(GL_INVALID_VALUE);
				return false;
			}

			return true;
		}
	}
}

void glCompressedTexImage2D (GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const GLvoid *data)
{
	CALL_LOG;
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}

	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	 if ( (width < 0 || width > GLPARAM_MAX_TEXTURE_SIZE ) ||
	   (height < 0 || height > GLPARAM_MAX_TEXTURE_SIZE ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if( !IsValidTextureSize( width ) || !IsValidTextureSize( height ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( border != 0 )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.

	// ������ �̹����� ������ ���� �ִ� ���¶�� �޸� ���� �� �ٽ� �Ҵ�.
	//if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
	if ( ptexture->m_PaletteMemory2D.MemoryHandle )
		GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );

	ptexture->m_Target	= target;
	ptexture->m_Level	= level;
	ptexture->m_Border	= border;


	//SetTextureSize( ptexture, width, height );	// �ؿ��� ���ְ� �ֻ�.
	ptexture->m_IsCompessed	= GL_TRUE;		// �⺻���� false�̹Ƿ� true�� ����.
	ptexture->m_Format = internalformat;

	int paletteBits;
	int colorSize;
	int paletteWidth = 8;
	int widthByteSize;
	int memoryByteSize;
	unsigned char* pNewSrc = NULL;

	__TEXTURE__ curTexture;	// ������ ���� ������ ���� �ӽ� ���� ����.

	GetInfomation( internalformat, paletteBits, colorSize );

	if( paletteBits == 4 )
	{
		if( ! GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
			16, 2, 1, 1, &ptexture->m_PaletteMemory2D ) )
			return;
		UploadTexture( &ptexture->m_PaletteMemory2D, 
									0, 0, paletteWidth, 2,
	 								data, paletteWidth*colorSize );
	}
	else if( paletteBits == 8 )
	{
		if( ! GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
			16, 32, 1, 1, &ptexture->m_PaletteMemory2D ) )
			return;
		UploadTexture( &ptexture->m_PaletteMemory2D, 
						0, 0, paletteWidth, 32,
	 					data, paletteWidth*colorSize );
	}
	else
		goto error;

		
	ptexture->m_PaletteSize = 1<<paletteBits;	// palette size ( 16 or 256 )
	ptexture->m_Bpp			= paletteBits;
	
	if ( ( ( (width*paletteBits)+7 )/8 * height + ptexture->m_PaletteSize*colorSize ) != imageSize )
	{
		GLSETERROR(GL_INVALID_VALUE);
		goto error;
	}		
	
	if( level == 0 )
	{
		const GLvoid* pSrc = NULL;
		
		GLboolean result = GetValidMinTextureSizeWithScale( paletteBits, width, height, curTexture.m_ScaleX, curTexture.m_ScaleY );
		SetTextureSize( &curTexture, width, height );	
		
		widthByteSize = ( (width*curTexture.m_ScaleX*paletteBits)+7 )/8;
		memoryByteSize= ( (curTexture.m_WidthPowerOf2*paletteBits)+7 )/8;
		
		if( result )
		{
			int size = (int)( ( width * curTexture.m_ScaleX ) * ( height * curTexture.m_ScaleY ) * paletteBits );
			pNewSrc = MES_NEW_ARRAY( unsigned char, size );
			
			MakeValidMinTexture( pNewSrc, ((unsigned char*)data+(ptexture->m_PaletteSize*colorSize)), 
							paletteBits, curTexture.m_Width, curTexture.m_Height, curTexture.m_ScaleX, curTexture.m_ScaleY );
			pSrc = (GLvoid*)pNewSrc;
		}
		else
			pSrc = ((unsigned char*)data+(ptexture->m_PaletteSize*colorSize));	

		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

		GLESOAL_MEMORY2D_TYPE memType = ( ptexture->m_GENERATE_MIPMAP ) ? GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE : GLESOAL_MEMORY2D_TYPE_TEXTURE;

		if( !GLESOAL_Malloc2D( memType, memoryByteSize, curTexture.m_HeightPowerOf2, 1, 1, &ptexture->m_TextureDataMemory2D ))	
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}

		// ���� ����.
		if( data )
		{
			if( ptexture->m_PaletteSize )
				GLESOAL_UploadTexture_index8( &ptexture->m_TextureDataMemory2D,
								0, 0, widthByteSize, height * curTexture.m_ScaleY, pSrc, widthByteSize );	
		}

		ptexture->m_Width			= curTexture.m_Width;
		ptexture->m_WidthPowerOf2	= curTexture.m_WidthPowerOf2;
		ptexture->m_Height			= curTexture.m_Height;
		ptexture->m_HeightPowerOf2	= curTexture.m_HeightPowerOf2;
		ptexture->m_ScaleX			= curTexture.m_ScaleX;
		ptexture->m_ScaleY			= curTexture.m_ScaleY;
	}
	else // �ؽ��� ������ 0�� �ƴ϶��..
	{
		// ���� ������ ���
		int orgWidth = width * (1<<level);
		int orgHeight = height * (1<<level);
		
		int scaleX, scaleY;
		GetValidMinTextureSizeWithScale( paletteBits, orgWidth, orgHeight, scaleX, scaleY );

		widthByteSize = ( width * paletteBits+7 )/8;

		// �̹� ������ ���� �ִ� texture�ΰ�?
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
		{
			if( ( ptexture->m_Format != internalformat ) || ( ptexture->m_Width != orgWidth ) || ( ptexture->m_Height != orgHeight ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			else
			{
				if( !IsValidMipmapTextureSize( level, ptexture->m_Width, ptexture->m_Height, width, height ) )
				{
					GLSETERROR(GL_INVALID_VALUE);
					return;
				}
				if( ptexture->m_TextureDataMemory2D.Type != GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
				{
					// 1. ���ο� �޸� �Ҵ�	2. ���� ����	3. �Ӹ� ���ε�
					GLESOAL_MEMORY2D newTexMemory2D;
					if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
						orgWidth * scaleX, orgHeight * scaleY, 1, 1, &newTexMemory2D ) )
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
						//goto error;
					}
					CopyTexture( &ptexture->m_TextureDataMemory2D, &newTexMemory2D, orgWidth * scaleX, orgHeight * scaleY );
					GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
					ptexture->m_TextureDataMemory2D = newTexMemory2D;
				}
				if( data )
				{
					unsigned int x, y;
					if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					if( !UploadMipmap( &ptexture->m_TextureDataMemory2D, x, y, width, height, data, widthByteSize ) )
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
				}
			}
		}
		// ó�� ����� texture�ΰ�?
		else
		{
			if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
					orgWidth * scaleX, orgHeight * scaleY, 1, 1, &ptexture->m_TextureDataMemory2D ))
			{
				//GLSETERROR(GL_INVALID_OPERATION);
				//return;
				goto error;
			}
			if( data )
			{
				unsigned int x, y;
				if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				if( !UploadMipmap( &ptexture->m_TextureDataMemory2D, x, y, width, height, data, widthByteSize ) )
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
			}
		}
	}

	ptexture->m_IsUpdated = GL_TRUE;
	ptexture->m_ContentsIsUpdated = GL_TRUE;
	__GLSTATE__.m_IsTextureUpdated = GL_TRUE;

	return;

error:
	//if( ptexture->m_PaletteMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );
	//if( ptexture->m_TextureDataMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
	TextureInitialize( ptexture );	
	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );
	
	GLSETERROR(GL_INVALID_OPERATION);
	return;
}


