//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glClear.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_8koi.asp
//				 �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza ���ٽǹ��� clear�õ��� ����ó������ ����.
//	   2006/10/24 Gamza clear color value(R5G6B5)������ ����.
//	   2006/10/20 Gamza Viewport�� Scissor�� �����ձ��ϱ� ���׼���.
//						������꿡 surfaceũ�� �ݿ�.
//						Clear???Bufferȣ��� width,height�� ex,ey�� �Ѱ��ִ�
//						���� ����.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//#define Max(a,b) ( ((a)>(b)) ? (a) : (b) )
//#define Min(a,b) ( ((a)<(b)) ? (a) : (b) )

void glClear (GLbitfield mask)
{
	CALL_LOG;
	if ((mask & (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT)) != mask)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (mask & GL_COLOR_BUFFER_BIT)
	{
		// float color value
		GLESHAL_ClearColorBuffer( VF2F(__GLSTATE__.m_ClearColor[0]),
								  VF2F(__GLSTATE__.m_ClearColor[1]),
								  VF2F(__GLSTATE__.m_ClearColor[2]),
								  VF2F(__GLSTATE__.m_ClearColor[3])	);
	}

	if (mask & GL_DEPTH_BUFFER_BIT && __GLSTATE__.m_DepthMask )
	{
		// unsigned short���� ����ؼ� �� �ѱ��.
		unsigned short fillDepth = (unsigned short)VF2I(VFMUL(__GLSTATE__.m_ClearDepth,I2VF(65535)));
		GLESHAL_ClearDepthBuffer( fillDepth );
	}

	if (mask & GL_STENCIL_BUFFER_BIT && __GLSTATE__.m_StencilMask )
	{
		//GLSETERROR(GL_INVALID_VALUE); 
		return;
	}
}
