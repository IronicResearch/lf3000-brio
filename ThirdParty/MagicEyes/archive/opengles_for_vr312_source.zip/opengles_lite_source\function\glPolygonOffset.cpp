//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glPolygonOffset.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_87g4.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza ���� �Լ� ȣ�⵵ ������Ŀ� ������ �ش�.
//						glDepthRangef/glDepthRangex/glPolygonOffset/glPolygonOffsetx
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glPolygonOffset (GLfloat factor, GLfloat units)
{
	CALL_LOG;
	__GLSTATE__.m_OffsetFactor = F2VF(factor);
	__GLSTATE__.m_OffsetUnits  = F2VF(units);	
	__GLSTATE__.m_ProjectionMatrix.m_IsUpdated = 1;
}
