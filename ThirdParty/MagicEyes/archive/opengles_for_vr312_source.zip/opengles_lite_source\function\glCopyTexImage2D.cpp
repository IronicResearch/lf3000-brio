//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glCopyTexImage2D.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_6gv8.asp
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/07 Yuni	size�� 0�̾ error�� �ƴ�. ���, memory�� �Ҵ���� �ʴ´�.
//	   2007/09/06 Gamza error: �տ� return; ���� ���� ���� ����.
//	   2007/09/06 Gamza 2�� ��� ������ IsValidTextureSize�Լ������� Ǯ�����.
//	   2007/09/06 Gamza internalformat �˻���� ���� (|| -> &&)
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//GL_INVALID_ENUM is generated if target is not GL_TEXTURE_2D.
//GL_INVALID_OPERATION is generated if internalformat is not compatible with the color buffer format.
//GL_INVALID_VALUE is generated if level is less than 0.
//GL_INVALID_VALUE may be generated if level is greater than log2max, where max is the returned value of GL_MAX_TEXTURE_SIZE.
//GL_INVALID_VALUE is generated if width or height is less than 0, greater than GL_MAX_TEXTURE_SIZE, or if width or height cannot be represented as 2k + 2border for some integer k.
//GL_INVALID_VALUE is generated if border is not 0.
//GL_INVALID_ENUM is generated if internalformat is not an accepted constant.
namespace {

	GLint (* CopyDisplayToTexture)( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA );

	GLint (* CreateMipmapTexture)( const GLESOAL_MEMORY2D* pMemory2D, 
										unsigned int X, unsigned int Y,
										unsigned int Width, unsigned int Height );

	GLint (* UploadMipmap)( const GLESOAL_MEMORY2D* pSrcMemory2D, 
										const GLESOAL_MEMORY2D* pTexMemory2D, 
										unsigned int X, unsigned int Y,
										unsigned int OffsetX, unsigned int OffsetY,
										unsigned int Width, unsigned int Height );

	GLint (* CopyTexture)( const GLESOAL_MEMORY2D* pSrcMemory2D, 
							const GLESOAL_MEMORY2D* pDstMemory2D, 
							unsigned int Width, unsigned int Height );

	GLint (* GetMipmapPosition)(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
								  unsigned int *X, unsigned int *Y );
}

void glCopyTexImage2D (GLenum target, GLint level, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border)
{
	CALL_LOG;
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}

	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( border != 0 )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	// FrameBuffer format�� RGB�̹Ƿ�..
	if( ( GL_LUMINANCE != internalformat ) && 
		( GL_RGB != internalformat ) )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if ( (width < 0 || width > GL_MAX_TEXTURE_SIZE ) ||
		 (height < 0 || height > GL_MAX_TEXTURE_SIZE ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	/*
	// �������̾�� �Ѵٴ� ������ �ϴ��� Ǯ�������. -> IsValidTextureSize �Լ����ο��� Ǯ�������
	if( !IsValidTextureSize( width ) || !IsValidTextureSize( height ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	*/

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	// ������ �̹����� ������ ���� �ִ� ���¶�� �޸� ���� �� �ٽ� �Ҵ�.
	ptexture->m_IsCompessed = GL_FALSE;
    ptexture->m_PaletteSize = 0;	

	while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.

	//if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
	//if ( ptexture->m_PaletteMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );

	GLESHAL_Flush();
	while( !GLESHAL_IsIdleState() )
		GLESOAL_Sleep(0);


	__TEXTURE__ curTexture;		// ���� ������ texture�� ������ ���� ������ ���� ����.

	switch( internalformat )
	{
	//case GL_ALPHA:
	//	break;
	case GL_LUMINANCE:
		CopyDisplayToTexture = GLESOAL_CopyDisplayToTexture_L8;
		CreateMipmapTexture  = GLESOAL_CreateMipmapCopyTexture_L8;
		UploadMipmap		 = GLESOAL_UploadCopyTextureMipmap_L8;
		CopyTexture			 = GLESOAL_CopyTexture_U8;
		GetMipmapPosition	 = GLESOAL_GetMipmapPosition_U8;
		ptexture->m_Bpp      = 8;
		ptexture->m_Type	 = GL_UNSIGNED_BYTE;

		break;
	//case GL_LUMINANCE_ALPHA:
	//	break;
	case GL_RGB:
		CopyDisplayToTexture = GLESOAL_CopyDisplayToTexture_R5G6B5;
		CreateMipmapTexture  = GLESOAL_CreateMipmapCopyTexture_R5G6B5;
		UploadMipmap		 = GLESOAL_UploadCopyTextureMipmap_U16;
		CopyTexture			 = GLESOAL_CopyTexture_U16;
		GetMipmapPosition	 = GLESOAL_GetMipmapPosition_U16;
		ptexture->m_Bpp      = 16;
		ptexture->m_Type	 = GL_UNSIGNED_SHORT_5_6_5;
		break;
	//case GL_RGBA:
	//	break;
	default:
		goto error;
	}

	if ( ptexture->m_PaletteMemory2D.MemoryHandle )
	GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );

 	if( level == 0 )
	{
		GetValidMinTextureSizeWithScale( ptexture->m_Bpp, width, height, curTexture.m_ScaleX, curTexture.m_ScaleY );
		SetTextureSize( &curTexture, width * curTexture.m_ScaleX, height * curTexture.m_ScaleY );

		// mipmap auto generation
		if( ptexture->m_GENERATE_MIPMAP )
		{
			if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
				GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

			if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
					curTexture.m_WidthPowerOf2 * ptexture->m_Bpp / 8, 
					curTexture.m_HeightPowerOf2, 
					1, 1, &ptexture->m_TextureDataMemory2D ) )	
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}

			// ���� �� mipmap ����.
			CopyDisplayToTexture( __GLSTATE__.m_pSurface->GetColorBuffer(),
					x, y, width, height, 
					ptexture->m_ScaleX, ptexture->m_ScaleY,
					&ptexture->m_TextureDataMemory2D, 0, 0,
					__GLSTATE__.m_SAMPLE_BUFFERS );

			CreateMipmapTexture( &ptexture->m_TextureDataMemory2D, 0, 0, curTexture.m_WidthPowerOf2, curTexture.m_HeightPowerOf2 );
		}
		else
		{
			// �̹� �Ҵ�� ���� �ִ� �ؽ��Ķ��..
			if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			{
				if( ( ptexture->m_Format != internalformat ) || 
					( ptexture->m_Width != width ) || ( ptexture->m_Height != height ) )
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}

				CopyDisplayToTexture( __GLSTATE__.m_pSurface->GetColorBuffer(),
					x, y, width, height, 
					ptexture->m_ScaleX, ptexture->m_ScaleY,
					&ptexture->m_TextureDataMemory2D, 0, 0,
					__GLSTATE__.m_SAMPLE_BUFFERS );
			}
			// ó�� ����� �ؽ��Ķ��..
			else
			{
				if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
					curTexture.m_WidthPowerOf2 * ptexture->m_Bpp / 8, 
					curTexture.m_HeightPowerOf2, 
					1, 1, &ptexture->m_TextureDataMemory2D ) )	
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				CopyDisplayToTexture( __GLSTATE__.m_pSurface->GetColorBuffer(),
					x, y, width, height, 
					ptexture->m_ScaleX, ptexture->m_ScaleY,
					&ptexture->m_TextureDataMemory2D, 0, 0,
					__GLSTATE__.m_SAMPLE_BUFFERS );
			}
		}

		ptexture->m_Width			= curTexture.m_Width;
		ptexture->m_WidthPowerOf2	= curTexture.m_WidthPowerOf2;
		ptexture->m_Height			= curTexture.m_Height;
		ptexture->m_HeightPowerOf2	= curTexture.m_HeightPowerOf2;
		ptexture->m_ScaleX			= curTexture.m_ScaleX;
		ptexture->m_ScaleY			= curTexture.m_ScaleY;
	}
	else // �ؽ��� ������ 0�� �ƴ϶��..
	{
		// ���� ������ ���
		
		int orgWidth = width * (1<<level);
		int orgHeight = height * (1<<level);

		GetValidMinTextureSizeWithScale( ptexture->m_Bpp, orgWidth, orgHeight, curTexture.m_ScaleX, curTexture.m_ScaleY );
		SetTextureSize( &curTexture, orgWidth * curTexture.m_ScaleX, orgHeight * curTexture.m_ScaleY );

		// �̹� ������ ���� �ִ� texture�ΰ�?
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
		{
			if( ( ptexture->m_Format != internalformat ) || 
					( ptexture->m_Width != orgWidth ) || ( ptexture->m_Height != orgHeight ) )
			{
				GLSETERROR(GL_INVALID_VALUE);
				return;
			}
			else
			{
				if( !IsValidMipmapTextureSize( level, ptexture->m_Width, ptexture->m_Height, width, height ) )
				{
					GLSETERROR(GL_INVALID_VALUE);
					return;
				}
				if( ptexture->m_TextureDataMemory2D.Type != GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
				{
					// 1. ���ο� �޸� �Ҵ�	2. ���� ����	3. �Ӹ� ���ε�
					GLESOAL_MEMORY2D newTexMemory2D;
					if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
						curTexture.m_WidthPowerOf2 * ptexture->m_Bpp / 8, 
						curTexture.m_HeightPowerOf2, 
						1, 1, &newTexMemory2D ) )
					{
						//GLSETERROR(GL_INVALID_OPERATION);
						//return;
						goto error;
					}
					CopyTexture( &ptexture->m_TextureDataMemory2D, &newTexMemory2D, 
						curTexture.m_WidthPowerOf2, curTexture.m_HeightPowerOf2 );
					GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
					ptexture->m_TextureDataMemory2D = newTexMemory2D;
				}

				unsigned int offsetX, offsetY;
				if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &offsetX, &offsetY ) )
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				if( !UploadMipmap( __GLSTATE__.m_pSurface->GetColorBuffer(), &ptexture->m_TextureDataMemory2D, x, y, offsetX, offsetY, width, height ) )
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
			}
		}
		// ó�� ����� texture�ΰ�?
		else
		{
			//if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

			if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
				curTexture.m_WidthPowerOf2 * ptexture->m_Bpp / 8, 
				curTexture.m_HeightPowerOf2, 
				1, 1, &ptexture->m_TextureDataMemory2D ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			unsigned int offsetX, offsetY;
			if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &offsetX, &offsetY ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			if( !UploadMipmap( __GLSTATE__.m_pSurface->GetColorBuffer(), &ptexture->m_TextureDataMemory2D, x, y, offsetX, offsetY, width, height ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
	}	

	ptexture->m_Target	= target;
	ptexture->m_Level	= level;
	ptexture->m_Border	= border;
	ptexture->m_Format	= internalformat;

	ptexture->m_IsUpdated = GL_TRUE;
	ptexture->m_ContentsIsUpdated = GL_TRUE;
	__GLSTATE__.m_IsTextureUpdated = GL_TRUE;

	return;
	
error:
	TextureInitialize( ptexture );
	
	GLSETERROR(GL_INVALID_OPERATION);
	return;

}	
