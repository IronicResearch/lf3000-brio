#ifndef FONT_H
#define FONT_H

#include <stdarg.h>
#include <stdio.h>
#include <GLES/gl.h>
#include <GLES/egl.h>
#include "t6_fixed.h"
#include "t6_texture.h"

namespace __TUTORIAL6__
{

class BitmappedFont
{
public:
  BitmappedFont(const char *textureFont, int fontWidth = 15, int fontHeight = 15);
  ~BitmappedFont();
  static void EnableStates(); //Enable all needed states to print the text, but does not set the ortho2D mode
  void Print(int x, int y, const char *fmt, ...);
  static void DisableStates(); //Disable states actived by EnableStates()
  
  inline bool GetState()             const {return m_state;};
  inline const Texture *GetTexture() const {return m_texture;};


private:  
  bool m_state;
  Texture *m_texture;  
  int m_fontWidth,m_fontHeight;  
  static GLfixed m_textureCoordinates[2 * 4 * 8 * 16]; 
  static bool m_instanced;
};

}//namespace

#endif
