//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glClearColorx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_0rhu.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//The glClearColor function specifies clear values for the color buffers.

//red, green, blue, alpha 
//	The red, green, blue, and alpha values that glClear uses to clear the color buffers. The default values are all zero. 
//	Values specified by glClearColor are clamped to the range [0,1].
//
//	glGet with argument GL_ACCUM_CLEAR_VALUE
//	glGet with argument GL_COLOR_CLEAR_VALUE
//
//	GL_INVALID_OPERATION  glClearColor was called between a call to glBegin and the corresponding call to glEnd. 
//

void glClearColorx (GLclampx red, GLclampx green, GLclampx blue, GLclampx alpha)
{
	CALL_LOG;
	__GLSTATE__.m_ClearColor[0] = X2VF( CLAMPX(red) );
	__GLSTATE__.m_ClearColor[1] = X2VF( CLAMPX(green) );
	__GLSTATE__.m_ClearColor[2] = X2VF( CLAMPX(blue) );
	__GLSTATE__.m_ClearColor[3] = X2VF( CLAMPX(alpha) );
}

