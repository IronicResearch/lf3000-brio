//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBindTexture.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_3bad.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glBindTexture (GLenum target, GLuint texture)
{
	CALL_LOG;
	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
	
	GLuint newbinded;
	if ( __TEXTURE_POOL__.Alloc(texture) )
	{
		newbinded = texture;		
	}
	else
	{
		newbinded = __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture];
		GLSETERROR( GL_OUT_OF_MEMORY );
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(newbinded);

	if( !ptexture )
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if( __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] != newbinded )
	{
		__GLSTATE__.m_IsTextureUpdated = GL_TRUE;
		__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] = newbinded;
	}

/*
	// ��Ÿ ��� Texture ���� HAL �Լ��� ȣ�����־�� ��.
	GLESHAL_COLORFORMAT colorFormat = GetHALCompressedTexColorFormat( ptexture->m_Type );
	
	if( ptexture->m_TextureDataMemory2D.MemoryHandle )
	{
		// compressed texture�̸� palette ����
		if( ptexture->m_IsCompessed && (ptexture->m_PaletteMemory2D.MemoryHandle) )
		{
			switch( ptexture->m_PaletteSize )
			{
			case 16:
				if( !GLESHAL_SetPalette16( 0,
										   ptexture->m_PaletteMemory2D.PhysicalSegment,
										   ptexture->m_PaletteMemory2D.PhysicalSegX/2,
										   ptexture->m_PaletteMemory2D.PhysicalSegY ))
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				break;

			case 256:
				if( !GLESHAL_SetPalette256( 0, 
										   ptexture->m_PaletteMemory2D.PhysicalSegment,
										   ptexture->m_PaletteMemory2D.PhysicalSegX/2,
										   ptexture->m_PaletteMemory2D.PhysicalSegY ))
				{
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				break;

			default:
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		GLESHAL_SetTextureSegment( __GLSTATE__.m_ActiveTexture, ptexture->m_TextureDataMemory2D.PhysicalSegment );
		GLESHAL_SetTexture( __GLSTATE__.m_ActiveTexture, colorFormat,
							(ptexture->m_TextureDataMemory2D.PhysicalSegX)/2, 
							ptexture->m_TextureDataMemory2D.PhysicalSegY, 
							ptexture->m_WidthPowerOf2, ptexture->m_HeightPowerOf2 );

		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ptexture->m_TEXTURE_WRAP_S);
	}
	else	// default texture setting
	{
		
		GLESHAL_SetTextureSegment( __GLSTATE__.m_ActiveTexture, 
							__GLSTATE__.m_pDefaultTexture->m_TextureDataMemory2D.PhysicalSegment );
		GLESHAL_SetTexture(  __GLSTATE__.m_ActiveTexture, GLESHAL_COLORFORMAT_R5G6B5,
							__GLSTATE__.m_pDefaultTexture->m_TextureDataMemory2D.PhysicalSegX/2, 
							__GLSTATE__.m_pDefaultTexture->m_TextureDataMemory2D.PhysicalSegY, 
							__GLSTATE__.m_pDefaultTexture->m_WidthPowerOf2, 
							__GLSTATE__.m_pDefaultTexture->m_HeightPowerOf2 );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, __GLSTATE__.m_pDefaultTexture->m_TEXTURE_WRAP_S);
		
		ptexture = __GLSTATE__.m_pDefaultTexture;
	}
                   
	// texture size�� �޶����� texture matrix�� update �Ǿ�� �ϹǷ�.
	__GLSTATE__.m_TextureMatrix[__GLSTATE__.m_ActiveTexture].m_IsUpdated = GL_TRUE;

	GLESHAL_SetTextureSegment( __GLSTATE__.m_ActiveTexture, ptexture->m_TextureDataMemory2D.PhysicalSegment );
	GLESHAL_SetTexture( __GLSTATE__.m_ActiveTexture, colorFormat,
						(ptexture->m_TextureDataMemory2D.PhysicalSegX)/2, 
						ptexture->m_TextureDataMemory2D.PhysicalSegY, 
						ptexture->m_WidthPowerOf2, ptexture->m_HeightPowerOf2 );
*/
	
}
