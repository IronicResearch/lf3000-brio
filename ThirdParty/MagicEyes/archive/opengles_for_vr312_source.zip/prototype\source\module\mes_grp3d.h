//------------------------------------------------------------------------------
//
//	Copyright (C) 2007 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//  AND	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//  BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
//  FOR A PARTICULAR PURPOSE.
//
//	Module     : GRP3D
//	File       : mes_grp3d.h
//	Description: support 3D Graphics
//	Author     : Yuni
//	Export     : 
//	History    : 
//		2007.04.23	Yuni First implementaion.
//------------------------------------------------------------------------------
#ifndef __MES_GRP3D_H__
#define	__MES_GRP3D_H__


#include "../mes_base/mes_prototype.h"

#ifdef  __cplusplus
extern "C"
{
#endif

//------------------------------------------------------------------------------
/// @defgroup   GRP3D GRP3D
//------------------------------------------------------------------------------
//@{
 
/// @brief  GRP3D Module's Register List
struct  MES_GRP3D_RegisterSet
{
		volatile U32 	CPCONTROL       ;     ///< 0x000 : 
		volatile U32 	CMDQSTART       ;     ///< 0x004 : 
		volatile U32 	CMDQEND         ;     ///< 0x008 : 
		volatile U32 	CMDQFRONT       ;     ///< 0x00C : 
		volatile U32 	CMDQREAR        ;     ///< 0x010 : 
		volatile U32 	STATUS          ;     ///< 0x014 : 
		volatile U32 	INTC            ;     ///< 0x018 : 
		volatile U32 	reserved00      ;     ///< 0x01C : 
		volatile U32 	CONTROL         ;     ///< 0x020 : 
		volatile U32 	POWERCONTROL	;     ///< 0x024 :
		volatile U32 	RENDERSTATE     ;     ///< 0x028 :		
		volatile U32 	reserved01      ;     ///< 0x02C :  
		volatile U32 	ALPHABLEND      ;     ///< 0x030 :
		volatile U32 	reserved02      ;     ///< 0x034 :
		volatile U32 	TEXSUBSEGMENT   ;     ///< 0x038 :
		volatile U32 	reserved03      ;     ///< 0x03C :
		volatile U32 	TPCOLOR         ;     ///< 0x040 :
		volatile U32 	MIPMAPBIAS      ;     ///< 0x044 :
		volatile U32 	LUTPARAM        ;     ///< 0x048 :
		volatile U32 	reserved04      ;     ///< 0x04C :
		volatile U32 	TEXINFO0_0      ;     ///< 0x050 :
		volatile U32 	TEXINFO0_1      ;     ///< 0x054 :
		volatile U32 	TEXINFO1_0      ;     ///< 0x058 :
		volatile U32 	TEXINFO1_1      ;     ///< 0x05C :
		volatile U32 	TEXBLEND0       ;     ///< 0x060 :
		volatile U32 	reserved05      ;     ///< 0x064 :
		volatile U32 	TEXBLEND1       ;     ///< 0x068 :
		volatile U32 	reserved06[7]   ;     ///< 0x06C ~ 0x084 :
		volatile U32 	ALPHATEST		;     ///< 0x088 :
		volatile U32 	TEXCONST		;     ///< 0x08C :		
		volatile U32 	FOGCOLOR        ;     ///< 0x090 :
		volatile U32 	FOGMAXZ         ;     ///< 0x094 :
		volatile U32 	DISPINFO        ;     ///< 0x098 :
		volatile U32 	reserved07      ;     ///< 0x09C :
		volatile U32 	MFILLPARAM0     ;     ///< 0x0A0 :
		volatile U32 	MFILLPARAM1     ;     ///< 0x0A4 :
		volatile U32 	MFILLPARAM2     ;     ///< 0x0A8 :
		volatile U32 	reserved08      ;     ///< 0x0AC :
		volatile U32 	RENDTRG0        ;     ///< 0x0B0 :
		volatile U32 	RENDTRG1        ;     ///< 0x0B4 :
		volatile U32 	RENDTRG2        ;     ///< 0x0B8 :
		volatile U32 	reserved09      ;     ///< 0x0BC :
		volatile U32 	ZBINFO          ;     ///< 0x0C0 :
		volatile U32 	ZVBINFO         ;     ///< 0x0C4 :
		volatile U32 	ZSCALE          ;     ///< 0x0C8 :
		volatile U32 	reserved10[9]   ;     ///< 0x0CC ~ 0x0EC :
		volatile U32 	VPORTBOT        ;     ///< 0x0F0 :
		volatile U32 	VPORTH          ;     ///< 0x0F4 :
		volatile U32 	VPORTLEFT       ;     ///< 0x0F8 :
		volatile U32 	VPORTW          ;     ///< 0x0FC :
		volatile U32 	PRIMCON1		;     ///< 0x100 :
		volatile U32 	IDXSTART		;     ///< 0x104 :
		volatile U32 	IDXEND			;     ///< 0x108 :
		volatile U32 	PRAMLOOPCTRL	;     ///< 0x10C :
		volatile U32	PPARAMS[4]		;	  ///< 0x10C ~ 0x1FC
		volatile U32	VERTEXSTREAM[3*8]	;
		volatile U32 	reserved11	[(0xA400-0xA180)/4]	;	///< 0xA180 ~ 0xA3FF :
		volatile U16 	FOGTBL		[16*4]	 			;	///< 0xA400 ~ 0xA47F :
		volatile U32 	reserved12	[(0xA500-0xA480)/4]	;	///< 0xA480 ~ 0xA4FF :
		volatile float 	TSEINPUT	[(0xA5B0-0xA500)/4]	;	///< 0xA500 ~ 0xA5AF :
		volatile U32 	reserved13	[(0xA700-0xA5B0)/4]	;	///< 0xA5B0 ~ 0xA6FF :
		volatile float	GTEOUT		[(0xA790-0xA700)/4]	;	///< 0xA700 ~ 0xA78F :
		volatile U32 	reserved20	[(0xA800-0xA790)/4]	;	///< 0xA790 ~ 0xA7FF :
		volatile U32 	GTECODE		[(0xB000-0xA800)/4]	;	///< 0xA800 ~ 0xAFFF :
		volatile float 	GTECONST	[(0xBFC0-0xB000)/4]	;	///< 0xB000 ~ 0xBFBF :
		volatile U32	CLKENB					 		;	///< 0xBFC0 ~ 0xBFFF
				
};


//------------------------------------------------------------------------------
// Export constant definitions
//------------------------------------------------------------------------------
const U32 MES_GRP3D_RS_PERSPECTIVE_ENB      = (1<<0) ;
const U32 MES_GRP3D_RS_TEXTURE0_ENB         = (1<<1) ;
const U32 MES_GRP3D_RS_TEXTURE1_ENB         = (1<<2) ;
const U32 MES_GRP3D_RS_TRANSPARENCY_ENB     = (1<<3) ;
const U32 MES_GRP3D_RS_SHADE_ENB            = (1<<4) ;
const U32 MES_GRP3D_RS_BILINEAR_FILTER_ENB  = (1<<5) ;
const U32 MES_GRP3D_RS_ABILINEAR_FILTER_ENB = (1<<6) ;
const U32 MES_GRP3D_RS_ALPHA_ENB            = (1<<7) ;
const U32 MES_GRP3D_RS_ZBUFFER_ENB          = (1<<8) ;
const U32 MES_GRP3D_RS_ZBUFFERWRITE_ENB     = (1<<9) ;
const U32 MES_GRP3D_RS_FOG_ENB              = (1<<10);
const U32 MES_GRP3D_RS_DITHER               = (1<<11);
const U32 MES_GRP3D_RS_BACKFACECULL_ENB     = (1<<12);
const U32 MES_GRP3D_RS_BACKFACECULL_CW      = (1<<13);
const U32 MES_GRP3D_RS_BACKFACECULL_CCW     = (0<<13);
const U32 MES_GRP3D_RS_ALPHATESTENB			= (1<<14);

const U32 MES_GRP3D_WAIT_RASTERIZERIDLE    = 0x8000;
const U32 MES_GRP3D_WAIT_TSEIDLE           = 0x4000;
const U32 MES_GRP3D_WAIT_GTEIDLE           = 0x2000;
const U32 MES_GRP3D_WAIT_ALLIDLE           = 0xE000;
const U32 MES_GRP3D_WAIT_VSYNC             = 0x1000;
//const U32 MES_GRP3D_WAIT_VSYNC_IGNOREFIELD = 0x1800;



//------------------------------------------------------------------------------
/// @name   Module Interface
//@{
CBOOL   MES_GRP3D_Initialize( void );
void    MES_GRP3D_SelectModule( U32 ModuleIndex );
U32     MES_GRP3D_GetCurrentModule( void );
U32     MES_GRP3D_GetNumberOfModule( void );
//@} 

//------------------------------------------------------------------------------
///  @name   Basic Interface
//@{
U32     MES_GRP3D_GetPhysicalAddress( void );
U32     MES_GRP3D_GetSizeOfRegisterSet( void );
void    MES_GRP3D_SetBaseAddress( U32 BaseAddress );
U32     MES_GRP3D_GetBaseAddress( void );
CBOOL   MES_GRP3D_OpenModule( void );
CBOOL   MES_GRP3D_CloseModule( void );
CBOOL   MES_GRP3D_CheckBusy( void );
CBOOL   MES_GRP3D_CanPowerDown( void );
//@} 
// @Gamza 2008/07/31
void    MES_GRP3D_RestoreModule( void );

//------------------------------------------------------------------------------
///  @name   Interrupt Interface
//@{
//S32     MES_GRP3D_GetInterruptNumber( void );
void    MES_GRP3D_SetInterruptEnable( S32 IntNum, CBOOL Enable );
CBOOL   MES_GRP3D_GetInterruptEnable( S32 IntNum );
CBOOL   MES_GRP3D_GetInterruptPending( S32 IntNum );
void    MES_GRP3D_ClearInterruptPending( S32 IntNum );
void    MES_GRP3D_SetInterruptEnableAll( CBOOL Enable );
CBOOL   MES_GRP3D_GetInterruptEnableAll( void );
CBOOL   MES_GRP3D_GetInterruptPendingAll( void );
void    MES_GRP3D_ClearInterruptPendingAll( void );
S32     MES_GRP3D_GetInterruptPendingNumber( void );  // -1 if None
//@} 

/*
//------------------------------------------------------------------------------
///  @name   DMA Interface
//@{
U32     MES_GRP3D_GetDMAIndexPCMIn( void );
U32     MES_GRP3D_GetDMAIndexPCMOut( void );
U32     MES_GRP3D_GetDMABusWidth( void );
//@}
*/

//------------------------------------------------------------------------------
///  @name   Clock Control Interface
//@{

void            MES_GRP3D_SetClockPClkMode( MES_PCLKMODE mode );
MES_PCLKMODE    MES_GRP3D_GetClockPClkMode( void );
void            MES_GRP3D_SetClockBClkMode( MES_BCLKMODE mode );
MES_BCLKMODE    MES_GRP3D_GetClockBClkMode( void );



//--------------------------------------------------------------------------
///	@name	Module customized operations
//--------------------------------------------------------------------------
//@{	
//--------------------------------------------------------------------------
// Register Address : REG_BASE + 0x00~0x18
//--------------------------------------------------------------------------
void MES_GRP3D_SetTimeOutValue( U32 TimeOutValue );

// Command queue control
void MES_GRP3D_OpenCommandQueue( U32* pCommand_Virtual, U32* pCommand_Physical, U32 Size64 );
void MES_GRP3D_CloseCommandQueue( void );

// Command buffer control
void MES_GRP3D_OpenCommandBuffer( U32* pCommand_Virtual, U32 Size64 );
U32  MES_GRP3D_CheckCommandBuffer( void );
U32  MES_GRP3D_CloseCommandBuffer( void );
void MES_GRP3D_ExecuteCommandBuffer( U32* pCommand_Physical, U32 Size64 );

//--------------------------------------------------------------------------
// CONTROL
// Register Address : REG_BASE + 0x20
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_Nop( void );
CBOOL MES_GRP3D_Nops( U32 count );
CBOOL MES_GRP3D_ClearTextureCache( void );
CBOOL MES_GRP3D_RunGTE ( U32 Vnum, CBOOL Rendering, CBOOL InverseCullMode );
CBOOL MES_GRP3D_RunTSE_Triangle( CBOOL InverseCullMode );
CBOOL MES_GRP3D_RunTSE_Rectangle( void );
CBOOL MES_GRP3D_RunPrimitive( void );

//--------------------------------------------------------------------------
// RENDERSTATE
// Register Address : REG_BASE + 0x28
//--------------------------------------------------------------------------


CBOOL MES_GRP3D_SetRenderState( U32 RenderState );
U32   MES_GRP3D_GetRenderState( void );

//--------------------------------------------------------------------------
// ALPHABLEND
// Register Address : REG_BASE + 0x30
//--------------------------------------------------------------------------
/// @brief	alpha blending parameter
typedef enum 
{
    MES_GRP3D_BLEND_ZERO               = 0,
    MES_GRP3D_BLEND_ONE                = 1,
    MES_GRP3D_BLEND_SRCCOLOR           = 2,
    MES_GRP3D_BLEND_INVSRCCOLOR        = 3,
    MES_GRP3D_BLEND_SRCALPHA           = 4,
    MES_GRP3D_BLEND_INVSRCALPHA        = 5,
    MES_GRP3D_BLEND_DESTCOLOR          = 6,
    MES_GRP3D_BLEND_INVDESTCOLOR       = 7,
	MES_GRP3D_BLEND_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_BLEND;

CBOOL MES_GRP3D_SetBlendFactor( MES_GRP3D_BLEND SrcBlend, MES_GRP3D_BLEND DstBlend );

//--------------------------------------------------------------------------
// TEXSEGMENT
// Register Address : REG_BASE + 0x38
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetTextureSegment( U32 TextureStage, U32 TextureSegment );

//--------------------------------------------------------------------------
// TPCOLOR,MIPMAPBIAS
// Register Address : REG_BASE + 0x40
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetTransparencyColor( U16 TransparencyColor );
CBOOL MES_GRP3D_SetMipmapBias( U16 MipmapBias );

//--------------------------------------------------------------------------
// LUTPARAM
// Register Address : REG_BASE + 0x48
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetPalette16( U32 TextureStage, U32 Bank, U32 X, U32 Y );
CBOOL MES_GRP3D_SetPalette256( U32 TextureStage, U32 X, U32 Y );

/*
//--------------------------------------------------------------------------
// TEXINFO0_0,TEXINFO0_1,TEXINFO1_0,TEXINFO1_1
// Register Address : REG_BASE + 0x50,0x54,0x58,0x5C
//--------------------------------------------------------------------------
/// @brief	texture type ( normal bitmap or tile-indexed )
typedef enum
{
    MES_GRP3D_TEXTURETYPE_BITMAP  = (0<<16), ///< each pixel is 16bit RGB or
                                   ///  palette index.
    MES_GRP3D_TEXTURETYPE_TILEMAP = (1<<16), ///< each pixel is 16bit tile index.
    MES_GRP3D_TEXTURETYPE_FORCEU32 = 0x7FFFFFFF
} MES_GRP3D_TEXTURETYPE;

/// @brief	texture pixel format
typedef enum 
{
    MES_GRP3D_PIXELFORMAT_4P    = (0<<19), ///< 4-bit color indexed.
    MES_GRP3D_PIXELFORMAT_8P    = (1<<19), ///< 8-bit color indexed.
    MES_GRP3D_PIXELFORMAT_R5G6B5= (2<<19), ///< 16-bit RGB pixel format with
                                 ///  5 bits for red, 6 bits for green,
                                 ///  and 5 bits for blue
    MES_GRP3D_PIXELFORMAT_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_PIXELFORMAT;
*/


typedef enum
{
	MES_GRP3D_POWERMODE_DOWN		= 0,
	MES_GRP3D_POWERMODE_SLEEP		= 1,
	MES_GRP3D_POWERMODE_PROHIBIT	= 2,
	MES_GRP3D_POWERMODE_OPERATION	= 3,
	MES_GRP3D_POWERMODE_FORCEU32  	= 0x7FFFFFFF
}MES_GRP3D_POWERMODE;

CBOOL MES_GRP3D_SetPowerControl( MES_GRP3D_POWERMODE VertexCache, MES_GRP3D_POWERMODE GTEReg, 
						MES_GRP3D_POWERMODE GTEProg, MES_GRP3D_POWERMODE ClipReg, 
						MES_GRP3D_POWERMODE Perspective, 
						MES_GRP3D_POWERMODE TexCache0, MES_GRP3D_POWERMODE TexCache1, 
						MES_GRP3D_POWERMODE TexPalette );

typedef enum 
{
    MES_GRP3D_COLORFORMAT_INDEXED4_R5G6B5	=  0, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_R4G4B4A4	=  1, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_R5G5B5A1	=  2, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_A8L8		=  3, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_A4R4G4B4	=  4, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_A1R5G5B5	=  5, ///
    MES_GRP3D_COLORFORMAT_INDEXED4_L8A8		=  6, ///
    MES_GRP3D_COLORFORMAT_A4				=  9, ///
    MES_GRP3D_COLORFORMAT_L4				= 15, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_R5G6B5	= 16, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_R4G4B4A4	= 17, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_R5G5B5A1	= 18, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_A8L8		= 19, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_A4R4G4B4	= 20, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_A1R5G5B5	= 21, ///
    MES_GRP3D_COLORFORMAT_INDEXED8_L8A8		= 22, ///
    MES_GRP3D_COLORFORMAT_L4A4				= 25, ///
    MES_GRP3D_COLORFORMAT_L8				= 27, ///
    MES_GRP3D_COLORFORMAT_A8				= 30, ///
    MES_GRP3D_COLORFORMAT_A4L4				= 31, ///
    MES_GRP3D_COLORFORMAT_R5G6B5			= 40, ///
    MES_GRP3D_COLORFORMAT_R4G4B4A4			= 41, ///
    MES_GRP3D_COLORFORMAT_R5G5B5A1			= 42, ///
    MES_GRP3D_COLORFORMAT_A8L8				= 43, ///
    MES_GRP3D_COLORFORMAT_A4R4G4B4			= 44, ///
    MES_GRP3D_COLORFORMAT_A1R5G5B5			= 45, ///
    MES_GRP3D_COLORFORMAT_L8A8				= 46, ///    
    MES_GRP3D_COLORFORMAT_FORCEU32 			= 0x7FFFFFFF
} MES_GRP3D_COLORFORMAT;


/// @brief	texture addressing mode
typedef enum 
{
    MES_GRP3D_TEXTUREADDRESS_WRAP  = 0,
    MES_GRP3D_TEXTUREADDRESS_CLAMP = 1,
    MES_GRP3D_TEXTUREADDRESS_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_TEXTUREADDRESS;

CBOOL MES_GRP3D_SetTexture ( U32 TextureStage,      
							U32 SegmentSelector, 
							 MES_GRP3D_COLORFORMAT ColorFormat, 
							 CBOOL MipmapEnb, CBOOL TileIndexEnb,
							 MES_GRP3D_TEXTUREADDRESS TextureAddressingModeU,
							 MES_GRP3D_TEXTUREADDRESS TextureAddressingModeV,
							 U32 X, U32 Y, U32 Width, U32 Height );

typedef enum 
{
	MES_GRP3D_RGBARG_SOURCE_C		= 0,
	MES_GRP3D_RGBARG_SOURCE_1_C		= 1,
	MES_GRP3D_RGBARG_SOURCE_A		= 2,
	MES_GRP3D_RGBARG_SOURCE_1_A		= 3,
	MES_GRP3D_RGBARG_CONST_C		= 4,
	MES_GRP3D_RGBARG_CONST_1_C		= 5,
	MES_GRP3D_RGBARG_CONST_A		= 6,
	MES_GRP3D_RGBARG_CONST_1_A		= 7,	
	MES_GRP3D_RGBARG_FRAGMENT_C		= 8,
	MES_GRP3D_RGBARG_FRAGMENT_1_C	= 9,
	MES_GRP3D_RGBARG_FRAGMENT_A		= 10,
	MES_GRP3D_RGBARG_FRAGMENT_1_A	= 11,	
	MES_GRP3D_RGBARG_PREVIOUS_C		= 12,
	MES_GRP3D_RGBARG_PREVIOUS_1_C	= 13,
	MES_GRP3D_RGBARG_PREVIOUS_A		= 14,
	MES_GRP3D_RGBARG_PREVIOUS_1_A	= 15,	
	MES_GRP3D_RGBARG_FORCEU32  = 0x7FFFFFFF
}MES_GRP3D_RGBARG;

typedef enum 
{
	MES_GRP3D_RGBOP_REPLACE		= 0,
	MES_GRP3D_RGBOP_MODULATE	= 1,
	MES_GRP3D_RGBOP_ADD			= 2,
	MES_GRP3D_RGBOP_ADD_SIGNED	= 3,
	MES_GRP3D_RGBOP_INTERPOLATE	= 4,
	MES_GRP3D_RGBOP_SUBTRACT	= 5,
	MES_GRP3D_RGBOP_DOT3_RGB	= 6,
	MES_GRP3D_RGBOP_DOT3_RGBA	= 7,
	MES_GRP3D_RGBOP_FORCEU32  = 0x7FFFFFFF
}MES_GRP3D_RGBOP;

typedef enum 
{
	MES_GRP3D_AARG_SOURCE_A		= 0,
	MES_GRP3D_AARG_SOURCE_1_A	= 1,
	MES_GRP3D_AARG_CONST_A		= 2,
	MES_GRP3D_AARG_CONST_1_A	= 3,	
	MES_GRP3D_AARG_FRAGMENT_A	= 4,
	MES_GRP3D_AARG_FRAGMENT_1_A	= 5,	
	MES_GRP3D_AARG_PREVIOUS_A	= 6,
	MES_GRP3D_AARG_PREVIOUS_1_A	= 7,
	MES_GRP3D_AARG_FORCEU32  = 0x7FFFFFFF
}MES_GRP3D_AARG;

typedef enum 
{
	MES_GRP3D_AOP_REPLACE		= 0,
	MES_GRP3D_AOP_MODULATE		= 1,
	MES_GRP3D_AOP_ADD			= 2,
	MES_GRP3D_AOP_ADD_SIGNED	= 3,
	MES_GRP3D_AOP_INTERPOLATE	= 4,
	MES_GRP3D_AOP_SUBTRACT		= 5,
	MES_GRP3D_AOP_FORCEU32  = 0x7FFFFFFF
}MES_GRP3D_AOP;

CBOOL MES_GRP3D_SetTextureBlend( U32 TextureStage, 
								MES_GRP3D_RGBARG RGBArg0, MES_GRP3D_RGBARG RGBArg1, MES_GRP3D_RGBARG RGBArg2,
								MES_GRP3D_RGBOP	RGBOp,
								MES_GRP3D_AARG AlphaArg0, MES_GRP3D_AARG AlphaArg1, MES_GRP3D_AARG AlphaArg2,
								MES_GRP3D_AOP	AlphaOp );

typedef enum
{
	MES_GRP3D_ALPHAFUNC_NEVER 		= 0,
	MES_GRP3D_ALPHAFUNC_LESS 		= 1, 
	MES_GRP3D_ALPHAFUNC_EQUAL		= 2,
	MES_GRP3D_ALPHAFUNC_LESSEQUAL	= 3,
	MES_GRP3D_ALPHAFUNC_GREATER		= 4,
	MES_GRP3D_ALPHAFUNC_NOTEQUAL	= 5,
	MES_GRP3D_ALPHAFUNC_GREATEREQUAL= 6,
	MES_GRP3D_ALPHAFUNC_ALWAYS		= 7,
	MES_GRP3D_ALPHAFUNC_FORCE32		= 0x7FFFFFFF
}MES_GRP3D_ALPHAFUNC;

CBOOL MES_GRP3D_SetAlphaFunction( U32 RefValue, MES_GRP3D_ALPHAFUNC AlphaFunction );
								
//CBOOL MES_GRP3D_SetTextureConstColor( U32 ConstColor );
CBOOL MES_GRP3D_SetTextureConstColor( U8 A, U8 R, U8 G, U8 B );


typedef enum
{
	MES_GRP3D_MEMBUST_4 		= 0,
	MES_GRP3D_MEMBUST_8 		= 1,
	MES_GRP3D_MEMBUST_16 		= 2,
	MES_GRP3D_MEMBUST_FORCEU32  = 0x7FFFFFFF
}MES_GRP3D_MEMBUST;

typedef enum 
{
	MES_GRP3D_VSTYPE_NORMALIZED_U8 	= 0,
	MES_GRP3D_VSTYPE_U8				= 1,
	MES_GRP3D_VSTYPE_S8				= 2,
	MES_GRP3D_VSTYPE_S16			= 3,
	MES_GRP3D_VSTYPE_S32			= 4,
	MES_GRP3D_VSTYPE_FIXED			= 5,
	MES_GRP3D_VSTYPE_FLOAT			= 7,
	MES_GRP3D_VSTYPE_FORCEU32		= 0x7FFFFFFF
}MES_GRP3D_VSTYPE;

typedef enum 
{
	MES_GRP3D_INDEXTYPE_8			= 0,
	MES_GRP3D_INDEXTYPE_16			= 1,
	MES_GRP3D_INDEXTYPE_FORCES32	= 0x7FFFFFFF
}MES_GRP3D_INDEXTYPE;

CBOOL MES_GRP3D_SetPrimitiveControl( MES_GRP3D_MEMBUST LockIndex, MES_GRP3D_MEMBUST LockVertex, 
							U32 StreamValid, MES_GRP3D_INDEXTYPE IndexType, 
							CBOOL ClearCache, CBOOL LoopEnb, 
							CBOOL UseIndexEnb, CBOOL UseMatrixPaletteEnb,
							CBOOL UseGTEEnb );
CBOOL MES_GRP3D_SetPrimitiveControlWithIndexPointer( MES_GRP3D_MEMBUST LockIndex, MES_GRP3D_MEMBUST LockVertex, 
							U32 StreamValid, MES_GRP3D_INDEXTYPE IndexType, 
							CBOOL ClearCache, CBOOL LoopEnb, 
							CBOOL UseIndexEnb, CBOOL UseMatrixPaletteEnb,
							CBOOL UseGTEEnb,
							unsigned int StartIndex, 
							unsigned int EndIndex );

CBOOL MES_GRP3D_SetVertexStream( U32 StreamIndex, const void* Addr, U32 Stride, 
						U32 DstOffset, U32 Size, MES_GRP3D_VSTYPE Type );
CBOOL MES_GRP3D_SetVertexStreams( const U32* Data, unsigned int StreamValid );

CBOOL MES_GRP3D_SetIndexStart( U32 Start );

CBOOL MES_GRP3D_SetIndexEnd( U32 End );

CBOOL MES_GRP3D_SetPrimitiveParamLoopControl( U32 ParamLoop, U32 ParamEnd );

//CBOOL MES_GRP3D_SetParamData( U32 PrimitiveIndex, CBOOL RectanbleEnb, CBOOL InverseCullingEnb, U32 VertexNum );
CBOOL MES_GRP3D_SetParamData( U32 Index, U8 Param0, U8 Param1, U8 Param2, U8 Param3 );



/*

//--------------------------------------------------------------------------
// PRIMCON,PRIMIDX,PRIMVTX0,PRIMVTX1,PRIMVTX2,PRIMVTX3
// Register Address : REG_BASE + 0x70~0x84
//--------------------------------------------------------------------------
/// @brief	primitive types
typedef enum 
{
    MES_GRP3D_PRIMITIVETYPE_TLIST   = (0<<21),
    MES_GRP3D_PRIMITIVETYPE_TFAN    = (1<<21),
    MES_GRP3D_PRIMITIVETYPE_TSTRIP  = (2<<21),
    MES_GRP3D_PRIMITIVETYPE_RECTLIST= (3<<21),
    MES_GRP3D_PRIMITIVETYPE_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_PRIMITIVETYPE;

/// @brief	vertex-index data format
typedef enum 
{
    MES_GRP3D_INDEXFORMAT_8  = (0<<24),
    MES_GRP3D_INDEXFORMAT_16 = (1<<24),
    MES_GRP3D_INDEXFORMAT_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_INDEXFORMAT;

typedef enum 
{
	MES_GRP3D_SUBSTRIDE_0   = 6,
    MES_GRP3D_SUBSTRIDE_8   = 0,
    MES_GRP3D_SUBSTRIDE_16  = 1,
    MES_GRP3D_SUBSTRIDE_32  = 2,
    MES_GRP3D_SUBSTRIDE_64  = 3,
    MES_GRP3D_SUBSTRIDE_128 = 4,
    MES_GRP3D_SUBSTRIDE_256 = 5,
    MES_GRP3D_SUBSTRIDE_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_SUBSTRIDE;	

static U32 MES_GRP3D_StrideToBytes( MES_GRP3D_SUBSTRIDE Stride )
{
	const U32 c_StrideToBytes[] = { 8,16,32,64,128,256,0 };
	return c_StrideToBytes[Stride];
}

CBOOL MES_GRP3D_DrawPrimitive ( 			CBOOL TransformRequest,
								MES_GRP3D_PRIMITIVETYPE PrimitiveType,
								U32 NumberOfVertex,
								const void* pVertex0,
								MES_GRP3D_SUBSTRIDE SubStride0,
								const void* pVertex1,
								MES_GRP3D_SUBSTRIDE SubStride1,
								const void* pVertex2,
								MES_GRP3D_SUBSTRIDE SubStride2,
								const void* pVertex3,
								MES_GRP3D_SUBSTRIDE SubStride3 );

CBOOL MES_GRP3D_DrawIndexedPrimitive (	CBOOL TransformRequest,
								MES_GRP3D_PRIMITIVETYPE PrimitiveType,
								U32 NumberOfVertex,
								const void* pIndex,
								MES_GRP3D_INDEXFORMAT IndexFormat,
								const void* pVertex0,
								MES_GRP3D_SUBSTRIDE SubStride0,
								const void* pVertex1,
								MES_GRP3D_SUBSTRIDE SubStride1,
								const void* pVertex2,
								MES_GRP3D_SUBSTRIDE SubStride2,
								const void* pVertex3,
								MES_GRP3D_SUBSTRIDE SubStride3 );								
*/
//--------------------------------------------------------------------------
// RegisterFill
//--------------------------------------------------------------------------
// @brief	wait flags for register fill
/*
static const U32 MES_GRP3D_WAIT_RASTERIZERIDLE   ;
static const U32 MES_GRP3D_WAIT_TSEIDLE          ;
static const U32 MES_GRP3D_WAIT_GTEIDLE          ;
static const U32 MES_GRP3D_WAIT_ALLIDLE          ;
static const U32 MES_GRP3D_WAIT_VSYNC            ;
static const U32 MES_GRP3D_WAIT_VSYNC_IGNOREFIELD;
*/
CBOOL MES_GRP3D_RegisterFill ( U32 RegisterOffset32, U32 NumberOfData32,
							   const U32* pData32, U32 WaitFalg,
							   CBOOL InterruptRequest );



//--------------------------------------------------------------------------
// CONTROL
// Register Address : REG_BASE + 0x20
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_InterruptNop( void );

//--------------------------------------------------------------------------
// FOGCOLOR
// Register Address : REG_BASE + 0x90
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetFogColor( U32 FogColor );

//--------------------------------------------------------------------------
// FOGMAXZ
// Register Address : REG_BASE + 0x94
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetFogMaxZ( float Zmax );

//--------------------------------------------------------------------------
// FOGTBL
// Register Address : REG_BASE + 0x100~0x17F
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetFogTable( const U16* pFogTable );

//--------------------------------------------------------------------------
// fog parameter setup utility
//--------------------------------------------------------------------------
void MES_GRP3D_SetLinearFog ( float Zmin, float Zmax );

//--------------------------------------------------------------------------
// DISPINFO
// Register Address : REG_BASE + 0x98
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_Flip( U32 Segment, U8 TableX, U8 TableY,
                    CBOOL WaitSync, CBOOL IgnoreField, CBOOL FSAAEnb );

//--------------------------------------------------------------------------
// MFILLPARAM0,MFILLPARAM1,MFILLPARAM2
// Register Address : REG_BASE + 0xA0~0xA8
//--------------------------------------------------------------------------
/// @brief	block addressing mode
typedef enum 
{
    MES_GRP3D_BLOCKADDRESSMODE_DISPLAY =0,
    MES_GRP3D_BLOCKADDRESSMODE_TEXTURE =1,
    MES_GRP3D_BLOCKADDRESSMODE_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_BLOCKADDRESSMODE;

CBOOL MES_GRP3D_FillRectangle( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                    U32 Segment, U32 X, U32 Y, U32 Width, U32 Height,
                    U16 R5G6B5 );

//--------------------------------------------------------------------------
// RENDTRG0,RENDTRG1,RENDTRG2
// Register Address : REG_BASE + 0xB0~0xB8
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetRenderTarget( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                            U32 Segment, U8 TableX, U8 TableY,
                            U32 ScissorRect_X, U32 ScissorRect_Y,
                            U32 ScissorRect_Width, U32 ScissorRect_Height,
                            CBOOL FSAAEnb );

//--------------------------------------------------------------------------
// ZBINFO,ZVBINFO,ZSCALE
// Register Address : REG_BASE + 0xC0~0xC8
//--------------------------------------------------------------------------
/// @brief	z-buffer function
typedef enum 
{
    MES_GRP3D_CMPFUNC_NEVER         = 0,
    MES_GRP3D_CMPFUNC_LESS          = 1,
    MES_GRP3D_CMPFUNC_EQUAL         = 2,
    MES_GRP3D_CMPFUNC_LESSEQUAL     = 3,
    MES_GRP3D_CMPFUNC_GREATER       = 4,
    MES_GRP3D_CMPFUNC_NOTEQUAL      = 5,
    MES_GRP3D_CMPFUNC_GREATEREQUAL  = 6,
    MES_GRP3D_CMPFUNC_ALWAYS        = 7,
    MES_GRP3D_CMPFUNC_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_CMPFUNC;

CBOOL MES_GRP3D_SetZBuffer( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                       U32 Segment, U8 TableX, U8 TableY,
                       MES_GRP3D_CMPFUNC ZFunc );
CBOOL MES_GRP3D_SetZValidBuffer( CBOOL ZV_Enb,
								 U32 ZV_X, U32 ZV_Y, U16 ZV_Value );
CBOOL MES_GRP3D_SetZScale( float Z_Max );

/*
//--------------------------------------------------------------------------
// VBFIXED,VBFORMAT0,VBFORMAT1,VBFORMAT2,VBFORMAT3
// Register Address : REG_BASE + 0xD0~0xE0
//--------------------------------------------------------------------------
/// @brief	vertex buffer value type
typedef enum
{
	MES_GRP3D_VALUETYPE_BYTEX4 =  0UL,
	MES_GRP3D_VALUETYPE_WORDX2 =  1UL,
	MES_GRP3D_VALUETYPE_DWORD  =  2UL,
	MES_GRP3D_VALUETYPE_FLOAT  =  3UL,
	MES_GRP3D_VALUETYPE_FORCEU32  = 0x7FFFFFFF
} MES_GRP3D_VALUETYPE;

/// @brief	vertex format structure
typedef struct 
{
	unsigned VT00:2, VT01:2, VT02:2, VT03:2, VT04:2, VT05:2, VT06:2, VT07:2;
	unsigned VT08:2, VT09:2, VT10:2, VT11:2, VT12:2, VT13:2, VT14:2, VT15:2;
	unsigned VT16:2, VT17:2, VT18:2, VT19:2, VT20:2, VT21:2, VT22:2, VT23:2;
	unsigned VT24:2, VT25:2, VT26:2, VT27:2, VT28:2, VT29:2, VT30:2, VT31:2;
	unsigned VT32:2, VT33:2, VT34:2, VT35:2, VT36:2, VT37:2, VT38:2, VT39:2;
	unsigned VT40:2, VT41:2, VT42:2, VT43:2, VT44:2, VT45:2, VT46:2, VT47:2;
	unsigned VT48:2, VT49:2, VT50:2, VT51:2, VT52:2, VT53:2, VT54:2, VT55:2;
	unsigned VT56:2, VT57:2, VT58:2, VT59:2, VT60:2, VT61:2, VT62:2, VT63:2;
} MES_GRP3D_VertexFormat;

CBOOL MES_GRP3D_SetVertexFormat( U32 Fixed32_Resolution,
                            	 U32 Fixed16_Resolution,
	                             U32 Fixed8_Resolution,
	                             MES_GRP3D_VertexFormat* pVertexFormat );
*/
//--------------------------------------------------------------------------
// VPORTBOT,VPORTH,VPORTLEFT,VPORTW
// Register Address : REG_BASE + 0xF0~0xFC
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetViewport( float X, float Y, float Width, float Height );

//--------------------------------------------------------------------------
// GTECODE
// Register Address : REG_BASE + 0x200~0x2FF
//--------------------------------------------------------------------------
//CBOOL MES_GRP3D_SetGTECode( const U32* pCodeList, U32 CodeSize32 );
CBOOL MES_GRP3D_SetGTECode( const U32* pCodeList, U32 CodeBase32, U32 CodeSize32 );

//--------------------------------------------------------------------------
// GTECONST
// Register Address : REG_BASE + 0x300~0x3FF
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetGTEConst( U32 Index, U32 NumberOfValue,
							 const float* pValueList );

/*
//--------------------------------------------------------------------------
// GTEINPUT
// Register Address : REG_BASE + 0x400~0x4FF
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetGTEInput( U32 Index, U32 NumberOfValue,
							 const float* pValueList );
*/

//--------------------------------------------------------------------------
// TSEINPUT
// Register Address : REG_BASE + 0x500~0x5FF
//--------------------------------------------------------------------------
CBOOL MES_GRP3D_SetTSEInput ( U32 Index, U32 NumberOfValue,
							  const float* pValueList );




//--------------------------------------------------------------------------
//	GLESHAL�� ���� �߰��� �Լ�
//--------------------------------------------------------------------------
unsigned __int64 MES_GRP3D_GetFrontOfCommandQueue( void );
unsigned __int64 MES_GRP3D_GetRearOfCommandQueue( void );



//--------------------------------------------------------------------------
// volume culling interface
//--------------------------------------------------------------------------
/// @brief	volume culling state
typedef enum 
{
	MES_GRP3D_VOLUMECULLSTATE_NONE     = 0,
	MES_GRP3D_VOLUMECULLSTATE_TEST     = 1,
	MES_GRP3D_VOLUMECULLSTATE_CULLING  = 2,
	MES_GRP3D_VOLUMECULLSTATE_FORCEU32 = 0x7FFFFFFF
} MES_GRP3D_VOLUMECULLSTATE;

void MES_GRP3D_SetVolumeCullingState ( MES_GRP3D_VOLUMECULLSTATE State );

/*
//--------------------------------------------------------------------------
//	simple rendering interface
//	mes_grp3d00_render.cpp
//--------------------------------------------------------------------------
typedef struct
{
	float x,y,z,w;
	float a,r,g,b;
	float u0,v0,u1,v1;	
} MES_GRP3D_SimpleRenderVertex;

void MES_GRP3D_Render_TLVERTEX( const MES_GRP3D_SimpleRenderVertex *pv0,
					  const MES_GRP3D_SimpleRenderVertex *pv1,
					  const MES_GRP3D_SimpleRenderVertex *pv2 );
void MES_GRP3D_Render_VERTEX( const MES_GRP3D_SimpleRenderVertex *pv0,
					const MES_GRP3D_SimpleRenderVertex *pv1,
					const MES_GRP3D_SimpleRenderVertex *pv2 );
void MES_GRP3D_Render_RECT( const MES_GRP3D_SimpleRenderVertex *pv0,
				  const MES_GRP3D_SimpleRenderVertex *pv1 );
*/
//--------------------------------------------------------------------------
// R5G6B5 inline functions
//--------------------------------------------------------------------------
static U32 MES_GRP3D_MAKE_R8G8B8( U8 r, U8 g, U8 b )
{
	return	(U32)((((U32)r&0xff)<<16)|(((U32)g&0xff)<<8)|(((U32)b&0xff)));
}	
static U16 MES_GRP3D_MAKE_R5G6B5( U8 r, U8 g, U8 b )
{
	return	(U16)((((U32)r&0xf8)<<8)|(((U32)g&0xfc)<<3)|(((U32)b&0xf8)>>3));
}
static U8 MES_GRP3D_GETR8_R5G6B5( U16 r5g6b5)
{ return (U8)((((r5g6b5)>>11)<<3) & 0xff); }
static U8 MES_GRP3D_GETG8_R5G6B5( U16 r5g6b5)
{ return (U8)((((r5g6b5)>> 5)<<2) & 0xff); }
static U8 MES_GRP3D_GETB8_R5G6B5( U16 r5g6b5)
{ return (U8)((((r5g6b5)<< 3)   ) & 0xff); }

//@}


/// @brief	error code
typedef enum 
{
	MES_GRP3D_ERR_NONE,
	MES_GRP3D_ERR_TIMEOUT,
	MES_GRP3D_ERR_BUFFEROVERFLOW,
	MES_GRP3D_ERR_FORCEU32 = 0x7FFFFFFF
} MES_GRP3D_ERR;
/// @brief	get last error

MES_GRP3D_ERR MES_GRP3D_GetLastError( void );




//@} 

#ifdef  __cplusplus
}
#endif


#endif	//  __MES_GRP3D_H__
