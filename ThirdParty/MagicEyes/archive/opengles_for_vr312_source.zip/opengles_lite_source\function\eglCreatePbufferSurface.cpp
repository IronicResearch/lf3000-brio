//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglCreatePbufferSurface.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : ��Ʈ
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	EGL_NO_SURFACE is returned if creation of the context fails.
//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
//	EGL_NOT_INITIALIZED is generated if display has not been initialized.
///	EGL_BAD_CONFIG is generated if config is not an EGL frame buffer configuration.
//	EGL_BAD_ATTRIBUTE is generated if attrib_list contains an invalid pixel buffer attribute or if an attribute value is not recognized or out of range.
//	EGL_BAD_ALLOC is generated if there are not enough resources to allocate the new surface.
///	EGL_BAD_MATCH is generated if config does not support rendering to pixel buffers (the EGL_SURFACE_TYPE attribute does not contain EGL_PBUFFER_BIT).
///	EGL_BAD_VALUE is generated if The EGL_TEXTURE_FORMAT attribute is not EGL_NO_TEXTURE, and EGL_WIDTH and/or EGL_HEIGHT specify an invalid size (e.g., the texture size is not a power of 2, and the underlying OpenGL ES implementation does not support non-power-of-two textures).
///	EGL_BAD_VALUE can also be generated if The EGL_TEXTURE_FORMAT attribute is EGL_NO_TEXTURE, and EGL_TEXTURE_TARGET is something other than EGL_NO_TEXTURE; or, EGL_TEXTURE_FORMAT is something other than EGL_NO_TEXTURE, and EGL_TEXTURE_TARGET is EGL_NO_TEXTURE.

static bool GetAttribValue( __SURFACECONFIG__* psurfaceconfig, const EGLint *source_list );

EGLSurface eglCreatePbufferSurface (EGLDisplay dpy, EGLConfig config, const EGLint *attrib_list)
{
	CALL_LOG;
	const __CONFIG__* pconfig = (const __CONFIG__*)config;

	if( ! pconfig || EGLCONFIG_FLAG != pconfig->m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_CONFIG );
		return EGL_NO_SURFACE;
	}

	if( 0 == (pconfig->m_SURFACE_TYPE & EGL_PBUFFER_BIT) )
	{
		EGLSETERROR( EGL_BAD_MATCH );
		return EGL_NO_SURFACE;
	} 
	
	__SURFACECONFIG__ surfaceconfig = { EGLSURFACE_FLAG,
										pconfig->m_CONFIG_ID,
		                                0              ,
										0              ,
										EGL_FALSE      ,
										EGL_NO_TEXTURE ,
										EGL_NO_TEXTURE ,
										EGL_FALSE      ,
										0
										};
	if( ! GetAttribValue( &surfaceconfig, attrib_list ) )
	{
		EGLSETERROR(EGL_BAD_ATTRIBUTE);
		return EGL_NO_SURFACE;
	}
	
	if( EGL_NO_TEXTURE == surfaceconfig.m_TEXTURE_FORMAT &&
		EGL_NO_TEXTURE != surfaceconfig.m_TEXTURE_TARGET )
	{
		EGLSETERROR(EGL_BAD_ATTRIBUTE); // EGLSETERROR( EGL_BAD_VALUE );
		return EGL_NO_SURFACE;
	}
	if( EGL_NO_TEXTURE != surfaceconfig.m_TEXTURE_FORMAT &&
		EGL_NO_TEXTURE == surfaceconfig.m_TEXTURE_TARGET )
	{
		EGLSETERROR(EGL_BAD_ATTRIBUTE); // EGLSETERROR( EGL_BAD_VALUE );
		return EGL_NO_SURFACE;
	}
	
	if( EGL_TEXTURE_RGB == surfaceconfig.m_TEXTURE_FORMAT &&
		EGL_FALSE == pconfig->m_BIND_TO_TEXTURE_RGB )
	{
		EGLSETERROR(EGL_BAD_ATTRIBUTE) // EGLSETERROR( EGL_BAD_VALUE );
		return EGL_NO_SURFACE;
	}
	if( EGL_TEXTURE_RGBA == surfaceconfig.m_TEXTURE_FORMAT &&
		EGL_FALSE == pconfig->m_BIND_TO_TEXTURE_RGBA )
	{
		EGLSETERROR(EGL_BAD_ATTRIBUTE) // EGLSETERROR( EGL_BAD_VALUE );
		return EGL_NO_SURFACE;
	}

	//struct __SURFACECONFIG__
	//{
	//	EGLint m_WIDTH          ;
	//	EGLint m_HEIGHT         ;
	//	EGLint m_LARGEST_PBUFFER; // EGL_TRUE���, �־��� ũ���� �Ҵ��� ������ ��� ��밡���� ����ū ũ���� ���۸� �����Ѵ�.
	//	EGLint m_TEXTURE_FORMAT ;
	//	EGLint m_TEXTURE_TARGET ;
	//	EGLint m_MIPMAP_TEXTURE ;
	//};
	//surfaceconfig
	return EGL_NO_SURFACE;
}


bool GetAttribValue( __SURFACECONFIG__* psurfaceconfig, const EGLint *source_list )
{
	const EGLint* psource = source_list;
	while( EGL_NONE != psource[0] )
	{
		switch( psource[0] )
		{
		case EGL_WIDTH          :
			psurfaceconfig->m_WIDTH = psource[1];
			break;
		case EGL_HEIGHT         :
			psurfaceconfig->m_HEIGHT = psource[1];
			break;
		case EGL_LARGEST_PBUFFER:
			psurfaceconfig->m_LARGEST_PBUFFER = psource[1];
			break;
		case EGL_TEXTURE_FORMAT :
			psurfaceconfig->m_TEXTURE_FORMAT = psource[1];
			if( EGL_NO_TEXTURE   != psource[1] &&
				EGL_TEXTURE_RGB  != psource[1] &&
				EGL_TEXTURE_RGBA != psource[1] ){ return false; }
			break;
		case EGL_TEXTURE_TARGET :
			psurfaceconfig->m_TEXTURE_TARGET = psource[1];
			if( EGL_NO_TEXTURE != psource[1] &&
				EGL_TEXTURE_2D != psource[1] ){ return false; }
			break;
		case EGL_MIPMAP_TEXTURE :
			psurfaceconfig->m_MIPMAP_TEXTURE = psource[1];
			break;
		default:
			return false;
		}
		psource += 2;
	}
	return true;
}

