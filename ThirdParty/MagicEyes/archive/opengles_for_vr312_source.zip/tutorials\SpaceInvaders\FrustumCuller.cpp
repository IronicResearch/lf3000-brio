// FrustumCuller.cpp: implementation of the FrustumCuller class.
//
#include <Fake_OS.h>
#include "FrustumCuller.h"
#include <math.h>

FrustumCuller *FrustumCuller::m_instance = NULL;

FrustumCuller::~FrustumCuller()
{
  m_instance = NULL;
}
//----------------------------------------------------------------------
FrustumCuller *FrustumCuller::Instance()
{
  if(!m_instance)
    m_instance = new FrustumCuller();
  return m_instance;
}
//----------------------------------------------------------------------
void FrustumCuller::ExtractFrustumPlanes()
{

  GLfixed projection[16];
  GLfixed modelview[16];
  GLfixed clip[16];

  /* Get the current projectionECTION matrix from OpenGL */
  glGetFixedv(GL_PROJECTION_MATRIX, projection);

  /* Get the current MODELVIEW matrix from OpenGL */
  glGetFixedv( GL_MODELVIEW_MATRIX, modelview);

  /* Combine the two matrices (multiply projectionection by modelview) */
  clip[0] = MultiplyFixed(modelview[0], projection[0]) + MultiplyFixed(modelview[1], projection[4]) + MultiplyFixed(modelview[2], projection[8]) + MultiplyFixed(modelview[3], projection[12]);
  clip[1] = MultiplyFixed(modelview[0], projection[1]) + MultiplyFixed(modelview[1], projection[5]) + MultiplyFixed(modelview[2], projection[9]) + MultiplyFixed(modelview[3], projection[13]);
  clip[2] = MultiplyFixed(modelview[0], projection[2]) + MultiplyFixed(modelview[1], projection[6]) + MultiplyFixed(modelview[2], projection[10]) + MultiplyFixed(modelview[3], projection[14]);
  clip[3] = MultiplyFixed(modelview[0], projection[3]) + MultiplyFixed(modelview[1], projection[7]) + MultiplyFixed(modelview[2], projection[11]) + MultiplyFixed(modelview[3], projection[15]);

  clip[4] = MultiplyFixed(modelview[4], projection[0]) + MultiplyFixed(modelview[5], projection[4]) + MultiplyFixed(modelview[6], projection[8]) + MultiplyFixed(modelview[7], projection[12]);
  clip[5] = MultiplyFixed(modelview[4], projection[1]) + MultiplyFixed(modelview[5], projection[5]) + MultiplyFixed(modelview[6], projection[9]) + MultiplyFixed(modelview[7], projection[13]);
  clip[6] = MultiplyFixed(modelview[4], projection[2]) + MultiplyFixed(modelview[5], projection[6]) + MultiplyFixed(modelview[6], projection[10]) + MultiplyFixed(modelview[7], projection[14]);
  clip[7] = MultiplyFixed(modelview[4], projection[3]) + MultiplyFixed(modelview[5], projection[7]) + MultiplyFixed(modelview[6], projection[11]) + MultiplyFixed(modelview[7], projection[15]);

  clip[8] = MultiplyFixed(modelview[8], projection[0]) + MultiplyFixed(modelview[9], projection[4]) + MultiplyFixed(modelview[10], projection[8]) + MultiplyFixed(modelview[11], projection[12]);
  clip[9] = MultiplyFixed(modelview[8], projection[1]) + MultiplyFixed(modelview[9], projection[5]) + MultiplyFixed(modelview[10], projection[9]) + MultiplyFixed(modelview[11], projection[13]);
  clip[10]= MultiplyFixed(modelview[8], projection[2]) + MultiplyFixed(modelview[9], projection[6]) + MultiplyFixed(modelview[10], projection[10]) + MultiplyFixed(modelview[11], projection[14]);
  clip[11]= MultiplyFixed(modelview[8], projection[3]) + MultiplyFixed(modelview[9], projection[7]) + MultiplyFixed(modelview[10], projection[11]) + MultiplyFixed(modelview[11], projection[15]);

  clip[12]= MultiplyFixed(modelview[12], projection[0]) + MultiplyFixed(modelview[13], projection[4]) + MultiplyFixed(modelview[14], projection[8]) + MultiplyFixed(modelview[15], projection[12]);
  clip[13]= MultiplyFixed(modelview[12], projection[1]) + MultiplyFixed(modelview[13], projection[5]) + MultiplyFixed(modelview[14], projection[9]) + MultiplyFixed(modelview[15], projection[13]);
  clip[14]= MultiplyFixed(modelview[12], projection[2]) + MultiplyFixed(modelview[13], projection[6]) + MultiplyFixed(modelview[14], projection[10]) + MultiplyFixed(modelview[15], projection[14]);
  clip[15]= MultiplyFixed(modelview[12], projection[3]) + MultiplyFixed(modelview[13], projection[7]) + MultiplyFixed(modelview[14], projection[11]) + MultiplyFixed(modelview[15], projection[15]);

  /* Extract the numbers for the RIGHT plane */
  m_frustum[0][0] = clip[3] - clip[0];
  m_frustum[0][1] = clip[7] - clip[4];
  m_frustum[0][2] = clip[11] - clip[ 8];
  m_frustum[0][3] = clip[15] - clip[12];
  /* Normalize the result */
  NormalizePlane(m_frustum[0]);
  
  /* Extract the numbers for the LEFT m_frustum */
  m_frustum[1][0] = clip[3] + clip[0];
  m_frustum[1][1] = clip[7] + clip[4];
  m_frustum[1][2] = clip[11] + clip[8];
  m_frustum[1][3] = clip[15] + clip[12];
  /* Normalize the result */
  NormalizePlane(m_frustum[1]);
  
  /* Extract the BOTTOM m_frustum */
  m_frustum[2][0] = clip[3] + clip[1];
  m_frustum[2][1] = clip[7] + clip[5];
  m_frustum[2][2] = clip[11] + clip[9];
  m_frustum[2][3] = clip[15] + clip[13];
  /* Normalize the result */
  NormalizePlane(m_frustum[2]);
  /* Extract the TOP m_frustum */
  m_frustum[3][0] = clip[3] - clip[1];
  m_frustum[3][1] = clip[7] - clip[5];
  m_frustum[3][2] = clip[11] - clip[9];
  m_frustum[3][3] = clip[15] - clip[13];
  /* Normalize the result */
  NormalizePlane(m_frustum[3]);
  
  /* Extract the FAR m_frustum */
  m_frustum[4][0] = clip[3] - clip[2];
  m_frustum[4][1] = clip[7] - clip[6];
  m_frustum[4][2] = clip[11] - clip[10];
  m_frustum[4][3] = clip[15] - clip[14];
  /* Normalize the result */
  NormalizePlane(m_frustum[4]);
  
  /* Extract the NEAR m_frustum */
  m_frustum[5][0] = clip[3] + clip[2];
  m_frustum[5][1] = clip[7] + clip[6];
  m_frustum[5][2] = clip[11] + clip[10];
  m_frustum[5][3] = clip[15] + clip[14];
  /* Normalize the result */
  NormalizePlane(m_frustum[5]);  
}

//----------------------------------------------------------------------
void FrustumCuller::NormalizePlane(GLfixed *plane)
{
  //forced to do in float point because the fixed point lack of precison
  float aux1 = FloatFromFixed(plane[0]) * FloatFromFixed(plane[0]); 
  float aux2 = FloatFromFixed(plane[1]) * FloatFromFixed(plane[1]); 
  float aux3 = FloatFromFixed(plane[2]) * FloatFromFixed(plane[2]);
  aux1 = aux1+aux2+aux3;  
  GLfixed t = FixedFromFloat((float)sqrt(aux1));
  if(!t)
    return;
  plane[0] = DivideFixed(plane[0],t);
  plane[1] = DivideFixed(plane[1],t);
  plane[2] = DivideFixed(plane[2],t);
  plane[3] = DivideFixed(plane[3],t);
}
//----------------------------------------------------------------------
bool FrustumCuller::IsCubeInFrustum(GLfixed *vertices)
{  
  for(int i=0;i<6;i++)
  {
    if(MultiplyFixed(m_frustum[i][0], vertices[0]) + MultiplyFixed(m_frustum[i][1], vertices[1]) + MultiplyFixed(m_frustum[i][2], vertices[2]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[3]) + MultiplyFixed(m_frustum[i][1], vertices[4]) + MultiplyFixed(m_frustum[i][2], vertices[5]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[6]) + MultiplyFixed(m_frustum[i][1], vertices[7]) + MultiplyFixed(m_frustum[i][2], vertices[8]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[9]) + MultiplyFixed(m_frustum[i][1], vertices[10]) + MultiplyFixed(m_frustum[i][2], vertices[11]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[12]) + MultiplyFixed(m_frustum[i][1], vertices[13]) + MultiplyFixed(m_frustum[i][2], vertices[14]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[15]) + MultiplyFixed(m_frustum[i][1], vertices[16]) + MultiplyFixed(m_frustum[i][2], vertices[17]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[18]) + MultiplyFixed(m_frustum[i][1], vertices[19]) + MultiplyFixed(m_frustum[i][2], vertices[20]) + m_frustum[i][3] > 0 )
       continue;

    if(MultiplyFixed(m_frustum[i][0], vertices[21]) + MultiplyFixed(m_frustum[i][1], vertices[22]) + MultiplyFixed(m_frustum[i][2], vertices[23]) + m_frustum[i][3] > 0 )
       continue;
    return false;
  }
   
  return true;
}
//----------------------------------------------------------------------
bool FrustumCuller::IsSphereInFrustum(GLfixed *center, GLfixed radius)
{
  for(int i=0;i<6;i++)
    if((MultiplyFixed(m_frustum[i][0], center[0]) + 
        MultiplyFixed(m_frustum[i][1], center[1]) + 
        MultiplyFixed(m_frustum[i][2], center[2]) + 
        m_frustum[i][3])  <= -radius)
      return false;
  return true;
}
//----------------------------------------------------------------------
bool FrustumCuller::SphereVsSphere(GLfixed p1[3], GLfixed rad1,GLfixed p2[3], GLfixed rad2)
{
  //true = they collide
  GLfixed distance,aux[3];
  aux[0] = p1[0] - p2[0]; aux[0] = MultiplyFixed(aux[0], aux[0]);
  aux[1] = p1[1] - p2[1]; aux[1] = MultiplyFixed(aux[1], aux[1]);
  aux[2] = p1[2] - p2[2]; aux[2] = MultiplyFixed(aux[2], aux[2]);
  distance = aux[0] + aux[1] + aux[2];  
  GLfixed delta = rad1 + rad2;
  delta = MultiplyFixed(delta,delta); //d^2 > r^2? instead of sqrt(d) > r
  return distance <= delta;    
}
//----------------------------------------------------------------------
bool FrustumCuller::PointVsSphere(GLfixed sphere[3], GLfixed radious,GLfixed p[3])
{
  GLfixed distance,aux[3];
  aux[0] = sphere[0] - p[0]; aux[0] = MultiplyFixed(aux[0], aux[0]);
  aux[1] = sphere[1] - p[1]; aux[1] = MultiplyFixed(aux[1], aux[1]);
  aux[2] = sphere[2] - p[2]; aux[2] = MultiplyFixed(aux[2], aux[2]);
  distance = aux[0] + aux[1] + aux[2];  //d^2
  distance = FixedFromFloat((float)sqrt(FloatFromFixed(distance)));
  return distance <= radious; //d^2 > r^2? instead of sqrt(d) > r
    
}
