#ifndef CAMERA_H
#define CAMERA_H

#include <GLES/gl.h>
#include <GLES/egl.h>
#include <math.h>
#include "fixed.h"

//Simple camera class, only provides with the basic functions to manage the OpenGL matrices
class Camera  
{
public:
  static void SetPerspective(NativeWindowType hNativeWnd, GLfixed fov, GLfixed znear, GLfixed zfar);  
  static void SetOrtho();
  static void SetOrtho2D(int width, int height);
  static void LookAt(GLfixed eyex, GLfixed eyey, GLfixed eyez,GLfixed centerx, GLfixed centery, GLfixed centerz,GLfixed upx, GLfixed upy, GLfixed upz);

private:
  static void Perspective (GLfixed fovy, GLfixed aspect, GLfixed zNear,  GLfixed zFar);
};

#endif 
