#ifndef FRUSTUM_CULLER_H
#define FRUSTUM_CULLER_H
#include <GLES/gl.h>
#include <math.h>
#include "fixed.h"

//Singleton class for the frustum culler
class FrustumCuller  
{
public:
  ~FrustumCuller();
  static FrustumCuller *Instance();	

  /*This function must be called just after LookAt (it is done inside the camera class) 
     if the camera values have changed.*/
  void ExtractFrustumPlanes(); 

  //frustum culling test
  bool IsCubeInFrustum(GLfixed *vertices);
  bool IsSphereInFrustum(GLfixed *center, GLfixed radius);

  //collision tests (note: they could be static...)
  bool SphereVsSphere(GLfixed p1[3], GLfixed rad1, GLfixed p2[3], GLfixed rad2);
  bool PointVsSphere(GLfixed p1[3], GLfixed rad1, GLfixed p2[3]);
  
private:
  FrustumCuller() {};
  void NormalizePlane(GLfixed *plane);
  static FrustumCuller *m_instance;
  GLfixed m_frustum[6][4]; //frustum clipping planes
};

#endif 
