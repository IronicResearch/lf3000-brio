//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDeleteTextures.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_6vqr.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glDeleteTextures (GLsizei n, const GLuint *textures)
{
	CALL_LOG;
	if (n < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__TEXTURE__* ptexture;
	
	int i;
	for( i=0; i<n; i++ )
	{
		ptexture = __TEXTURE_POOL__.GetObject(textures[i]);
		if( ! ptexture )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}

		while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		
		if( ptexture->m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
		if( ptexture->m_PaletteMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );
	}
	__TEXTURE_POOL__.Free( n , textures );
}

