//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLightfv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_88z8.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	These functions set light-source parameters.

//	for GL
//	glLightf, glLighti, glLightfv, glLightiv

//	for GL-ES
//	glLightf, glLightfv, glLightx, glLightxv

//	A single-valued light-source parameter for light
//	GL_SPOT_EXPONENT 	
//	GL_SPOT_CUTOFF
//	GL_CONSTANT_ATTENUATION
//	GL_LINEAR_ATTENUATION
//	GL_QUADRATIC_ATTENUATION 

//	A light source parameter for light
//	GL_AMBIENT
//	GL_DIFFUSE
//	GL_SPECULAR
//	GL_POSITION
//	GL_SPOT_DIRECTION

//	glGetLight
//	glIsEnabled with argument GL_LIGHTING

//	GL_INVALID_ENUM       light or pname was not an accepted value. 
//	GL_INVALID_VALUE      a spot exponent value was specified outside the range [0,128], or if spot cutoff was specified outside the range [0,90] (except for the special value 180), or if a negative attenuation factor was specified. 
//	GL_INVALID_OPERATION  glLight was called between a call to glBegin and the corresponding call to glEnd. 


void glLightfv (GLenum light, GLenum pname, const GLfloat *params)
{
	CALL_LOG;
	if (light < GL_LIGHT0 || light >= GL_LIGHT0 + GLPARAM_MAX_LIGHTS ) {
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}

	__LIGHT__ * pLight = __GLSTATE__.m_Lights + (light - GL_LIGHT0);

	//GLclampf red  ;
	//GLclampf green;
	//GLclampf blue ;
	//GLclampf alpha;
	
	switch (pname) {

	case GL_AMBIENT:
		pLight->m_AmbientColor[0] =  F2VF( CLAMPF(params[0]) );
		pLight->m_AmbientColor[1] =  F2VF( CLAMPF(params[1]) );
		pLight->m_AmbientColor[2] =  F2VF( CLAMPF(params[2]) );
		pLight->m_AmbientColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_DIFFUSE:
		pLight->m_DiffuseColor[0] =  F2VF( CLAMPF(params[0]) );
		pLight->m_DiffuseColor[1] =  F2VF( CLAMPF(params[1]) );
		pLight->m_DiffuseColor[2] =  F2VF( CLAMPF(params[2]) );
		pLight->m_DiffuseColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_SPECULAR:
		pLight->m_SpecularColor[0] =  F2VF( CLAMPF(params[0]) );
		pLight->m_SpecularColor[1] =  F2VF( CLAMPF(params[1]) );
		pLight->m_SpecularColor[2] =  F2VF( CLAMPF(params[2]) );
		pLight->m_SpecularColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_POSITION:
		{
			const Matrix4x4& modelview = __GLSTATE__.m_ModelViewMatrix.CurrentMatrix();
			Vec4D pos = { F2VF(params[0]),F2VF(params[1]),F2VF(params[2]),F2VF(params[3]) };
			M4_MUL_V4( pLight->m_Position, modelview, pos );
		}
		break;

	case GL_SPOT_DIRECTION:
		{
			//	�̰���...�̻��ϳ�...
			//	MSDN���� �Ʒ�ó�� ���ִµ�...
			//	The spot direction is transformed by the inverse of the modelview matrix
			//	when glLight is called (just as if it were a normal), 
			//	��Ʈ������ �׳� modelview 3x3�� ���ϳ�...	

			// spec������ �׳� modelview 3x3�� ���϶��ϴ�. 
			const Matrix4x4& modelview = __GLSTATE__.m_ModelViewMatrix.CurrentMatrix();
			Vec3D pos = { F2VF(params[0]),F2VF(params[1]),F2VF(params[2]) };
			M4_MUL_V3_ROT( pLight->m_Direction, modelview, pos );
			
			/*
			const Matrix4x4& inv_modelview = __GLSTATE__.m_ModelViewMatrix.CurrentInverseMatrix();
			Matrix4x4 invtrans_modelview;
			M4_TRANSPOSE( invtrans_modelview, inv_modelview );
			Vec3D pos = { F2VF(params[0]),F2VF(params[1]),F2VF(params[2]) };
			M4_MUL_V3_ROT( pLight->m_Direction, invtrans_modelview, pos );
			*/
			//pLight->m_Direction.x = F2VF(0.0f);
			//pLight->m_Direction.y = F2VF(0.0f);
			//pLight->m_Direction.z = F2VF(-1.0f);
		}
		break;

	default:
		glLightf(light, pname, *params);
		return;
	}

	pLight->m_IsUpdated = GL_TRUE;
}
