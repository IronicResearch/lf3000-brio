//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLightf.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_88z8.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	These functions set light-source parameters.

//	for GL
//	glLightf, glLighti, glLightfv, glLightiv

//	for GL-ES
//	glLightf, glLightfv, glLightx, glLightxv

//	A single-valued light-source parameter for light
//	GL_SPOT_EXPONENT 	
//	GL_SPOT_CUTOFF
//	GL_CONSTANT_ATTENUATION
//	GL_LINEAR_ATTENUATION
//	GL_QUADRATIC_ATTENUATION 

//	A light source parameter for light
//	GL_AMBIENT
//	GL_DIFFUSE
//	GL_SPECULAR
//	GL_POSITION
//	GL_SPOT_DIRECTION

//	glGetLight
//	glIsEnabled with argument GL_LIGHTING

//	GL_INVALID_ENUM       light or pname was not an accepted value. 
//	GL_INVALID_VALUE      a spot exponent value was specified outside the range [0,128], or if spot cutoff was specified outside the range [0,90] (except for the special value 180), or if a negative attenuation factor was specified. 
//	GL_INVALID_OPERATION  glLight was called between a call to glBegin and the corresponding call to glEnd. 


void glLightf (GLenum light, GLenum pname, GLfloat param)
{
	CALL_LOG;
	if (light < GL_LIGHT0 || light >= GL_LIGHT0 + GLPARAM_MAX_LIGHTS ) {
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}

	__LIGHT__ * pLight = __GLSTATE__.m_Lights + (light - GL_LIGHT0);

	switch (pname) {
	case GL_SPOT_EXPONENT:
		if (param < 0 || param > 128) {
			GLSETERROR( GL_INVALID_VALUE );
		} else {
			pLight->m_SpotExponent = F2VF(param);
		}
		break;

	case GL_SPOT_CUTOFF:
		if (param < 0 || param > 90 && param != 180) {
			GLSETERROR(GL_INVALID_VALUE);
		} else {
			pLight->m_SpotCutoff = F2VF(param);
		}
		break;

	case GL_CONSTANT_ATTENUATION:
		pLight->m_ConstantAttenuation = F2VF(param);
		break;

	case GL_LINEAR_ATTENUATION:
		pLight->m_LinearAttenuation = F2VF(param);
		break;

	case GL_QUADRATIC_ATTENUATION:
		pLight->m_QuadraticAttenuation = F2VF(param);
		break;

	default:
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}
	pLight->m_IsUpdated = GL_TRUE;
}
