//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gles_surface.h
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2006/11/02 Yuni  HAL �������� ���� ���ʿ��� �Լ� �� ��� ���� ����
//		2006/10/20 Gamza scissor rect �߰�.
//		2006/10/20 Gamza gles_surface ũ�⸦ ���ڷ� �޵��� ����.
//		2006/10/16 Yuni  first implementation
//------------------------------------------------------------------------------
#ifndef _GLES_SURFACE_H
#define _GLES_SURFACE_H

#include <GLES/gl.h>
#include <GLES/egl.h>
#include <GLES/glext.h>
#include "gltypes.h"
#include "glfixed.h"

#include "../../libgles_cm_lite_oal/libgles_cm_lite_oal.h"
#include "../../libgles_cm_lite_hal/libgles_cm_lite_hal.h"

class GLES_Surface
{
protected:
	int m_FrontBufferIndex;
	int m_BackBufferIndex;

	//GLESOAL_MEMORY2D* m_pFrontBuffer;	// ȭ�鿡 ������ buffer.
	//GLESOAL_MEMORY2D* m_pBackBuffer;	// �׸��� �׸� buffer
	//GLESOAL_MEMORY2D* m_pDepthBuffer;

	GLESOAL_MEMORY2D m_Buffer[3];
	GLESOAL_MEMORY2D m_DepthBuffer;

	unsigned long m_MemWidth;
	unsigned long m_MemHeight;

	int m_Width;
	int m_Height;
	int m_FSAA;

public:

	EGLBoolean CreateSurface( NativeWindowType NativeWindow, int FSAA );
	void BufferSwap( void );
	void DestroySurface( void );
	int GetWidth ( void ){ return m_Width ; }
	int GetHeight( void ){ return m_Height; }
	const GLESOAL_MEMORY2D* GetColorBuffer( void ){ return &m_Buffer[m_BackBufferIndex]; }
};

#endif // _GLES_SURFACE_H
