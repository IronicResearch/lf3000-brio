//------------------------------------------------------------------------------
//
//	Copyright (C) 2007 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//  AND	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//  BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS
//  FOR A PARTICULAR PURPOSE.
//
//	Module     : GRP3D
//	File       : mes_grp3d.c
//	Description: support 3D Graphics
//	Author     : Yuni
//	Export     : 
//	History    : 
//		2007.09.06  Gamza MES_GRP3D_MIN_TEX_WIDTH/MES_GRP3D_MIN_TEX_HEIGHT 2->1
//		2007.04.23	Yuni First implementaion.
//------------------------------------------------------------------------------
#include "mes_grp3d.h"
#include <stdio.h>
#include <string.h>

	#		define	OUTPUT_DEBUG_STRING(string)	\
									{			\
										wchar_t wchar_buffer[256];	\
										mbstowcs( wchar_buffer, string, strlen(string)+1 );	\
										OutputDebugString(wchar_buffer);	\
									}

static  struct
{
    struct MES_GRP3D_RegisterSet *pRegister;

} __g_ModuleVariables[NUMBER_OF_GRP3D_MODULE] = { CNULL, };

static  U32 __g_CurModuleIndex = 0;
static  struct MES_GRP3D_RegisterSet *__g_pRegister = CNULL;



const U32 MES_GRP3D_MODULEID_PRIMITIVE	= 0;
const U32 MES_GRP3D_MODULEID_GTE		= 1;
const U32 MES_GRP3D_MODULEID_TSE		= 2;
const U32 MES_GRP3D_MODULEID_RASTERIZER	= 3;
const U32 MES_GRP3D_MODULEID_NOP		= 4;

/// @brief buffer control mode
typedef enum 
{
	MES_GRP3D_CONTROLMODE_DIRECT, ///< direct register access
	MES_GRP3D_CONTROLMODE_BUFFER, ///< command buffer mode
	MES_GRP3D_CONTROLMODE_QUEUE , ///< command queue mode
	MES_GRP3D_CONTROLMODE_FORCEU32 = 0x7FFFFFFF
} MES_GRP3D_CONTROLMODE;


/// @brief	Command pointer type
typedef volatile U32* MES_GRP3D_PCMD;

void MES_GRP3D_ResetCommandSystem( void );
CBOOL MES_GRP3D_IsDirectMode( void );
CBOOL MES_GRP3D_BeginCommand( MES_GRP3D_PCMD* ppCMD,
					U32 RegisterOffset32, U32 ReserveSize32 );
void MES_GRP3D_EndCommand( void );


/// ??? ����������� �ʱ�ȭ ������ �ʿ����� ������?
/// @brief  GRP3D Module's Member Variables List
typedef struct 
{
		MES_GRP3D_VOLUMECULLSTATE  	m_VolumeCullingState;
		U32              			m_CullingEnable;
		U32              			m_CullingTestEnable;
		MES_GRP3D_CONTROLMODE 		m_GRP3DControlMode;
		U32  						m_TimeOutValue;	
		MES_GRP3D_PCMD 				m_CommandBufferPointer;
		U32  						m_CommandBufferSize32;
		U32  						m_CommandBufferPos32;	
		MES_GRP3D_PCMD 				m_CommandQueueClosePoint;
		U32  						m_CommandQueueSize32;	
		U32  						m_CommandQueue_VirtualOffset;
		
		unsigned __int64			m_CommandQueueFrontPointer;	// ��� �����ϴ� command queue front pointer
		
		U32 						m_CurrentRenderState;
		U32 						m_CurrentTransparencyColor;
		U32 						m_CurrentMipmapBias;
		U32							m_CurrentPrimitiveParamDatas[4];
		U32							m_TexSegment[2];
		MES_GRP3D_ERR 				m_LastError;
		
		CBOOL 						m_CommandOpenFlag;
		// @Gamza 2008/07/31
		struct MES_GRP3D_RegisterSet m_BackupRegister;
		
} MES_GRP3D_MemberVariableSet;

MES_GRP3D_MemberVariableSet __m_MemberVariables[NUMBER_OF_GRP3D_MODULE];

static  MES_GRP3D_MemberVariableSet *__m_pValues = CNULL;



	

//------------------------------------------------------------------------------
// Loacal constant definitions
//------------------------------------------------------------------------------
MES_DEBUG_CODE (
	static const U32 INVALID_CMD_PEDING_MASK = 0x00000002;
)

static const U32 MES_GRP3D_CONTROL_START	= 1;
static const U32 MES_GRP3D_CONTROL_STOP		= 2;
// static const U32 CONTROL_PAUSE	= 4;

MES_DEBUG_CODE (
	static const U32 MES_GRP3D_MIN_COMMANDQUEUE_SIZE = 1;
	static const U32 MES_GRP3D_REGFILL_MINADDR		 = (0x0020/4);
	static const U32 MES_GRP3D_REGFILL_MAXADDR		 = (0x2000/4)-1;
	static const U32 MES_GRP3D_REGFILL_MINDATA		 = 1;
	static const U32 MES_GRP3D_REGFILL_MAXDATA		 = ((0x2000/4)-(0x0020/4));
)



//------------------------------------------------------------------------------
// Loacal #defines
//------------------------------------------------------------------------------
#define MES_GRP3D_POS2PAGE( X,Y )  ((((Y) >> 9) << 1) | ((X) >> 9))
#define MES_GRP3D_POS2PAGEX( X )   (((X) & 0x1ff ) >> 1)
#define MES_GRP3D_POS2PAGEY( Y )   (((Y) & 0x1ff ) >> 1)

// �������� �̸��� offset32�� ��ȯ�Ѵ�.
#define MES_GRP3D_REGOFFSET(name)	( (U32)(&(((struct MES_GRP3D_RegisterSet*)0)->name)) / 4 )

//------------------------------------------------------------------------------
// Loacal typedefs
//------------------------------------------------------------------------------
typedef enum
{
	MES_GRP3D_TSEMODE_RECTANGLE	= (0UL<<10),
	MES_GRP3D_TSEMODE_TRIANGLE	= (1UL<<10)
} MES_GRP3D_TSEMODE;
typedef enum
{
	MES_GRP3D_RASTMODE_RENDER		= (0UL<<3),
	MES_GRP3D_RASTMODE_MEMFILL		= (1UL<<3),
	MES_GRP3D_RASTMODE_LUTFILL		= (2UL<<3),
	MES_GRP3D_RASTMODE_CACHECLEAR	= (3UL<<3)
} MES_GRP3D_RASTMODE;

typedef struct tag_CommandParameter
{
	U32 uID;       // command id
	U32 uOffset32; // register offset ( 32bit ���� )
	U32 uSize32;   // command size ( 32bit ���� )
} MES_GRP3D_CommandParameter;

//------------------------------------------------------------------------------
// Loacal constant definitions
//------------------------------------------------------------------------------
static const MES_GRP3D_CommandParameter MES_GRP3D_CMD_PARAM_LIST[] =
{
	{ ( 4UL << 28), ( 4UL * 2), 1 },  // CONTROL
	{ ( 5UL << 28), ( 5UL * 2), 1 },  // RENDERSTATE
	{ ( 6UL << 28), ( 6UL * 2), 1 },  // ALPHABLEND
	{ ( 7UL << 28), ( 7UL * 2), 1 },  // TEXSEGMENT
	{ ( 8UL << 28), ( 8UL * 2), 2 },  // MAPPARAM
	{ ( 9UL << 28), ( 9UL * 2), 1 },  // LUTFILL
	{ (10UL << 28), (10UL * 2), 2 },  // TEXINFO0
	{ (11UL << 28), (11UL * 2), 2 },  // TEXINFO1
	{ (12UL << 28), (12UL * 2), 1 },  // TEXBLEND0
	{ (13UL << 28), (13UL * 2), 1 },  // TEXBLEND1
	{ (14UL << 28), (14UL * 2), 6 },  // NOP
 	{ (15UL << 28),			 0, 0 }	  // REGFILL
};


//static const U32 MES_GRP3D_PRIMMODE[]   	= { (0<<25), (1<<25) };
//static const U32 MES_GRP3D_MAINSTRIDE_LSB   = 16;

MES_DEBUG_CODE (
	static const U32 MES_GRP3D_CMD_ID_MASK 			= 0xF0000000;
	static const U32 MES_GRP3D_MAX_TEXTURE_STAGE	= 2;
	static const U32 MES_GRP3D_MAX_PAGE_X			= 1024;
	static const U32 MES_GRP3D_MAX_PAGE_Y			= 1024;
	static const U32 MES_GRP3D_MIN_TEX_WIDTH		= 1;
	static const U32 MES_GRP3D_MIN_TEX_HEIGHT		= 1;
	static const U32 MES_GRP3D_SEGMENT_WIDTH 		= 1024;
	static const U32 MES_GRP3D_SEGMENT_HEIGHT		= 1024;
)
/*	// ��������.
MES_DEBUG_CODE (
	static const U32 MES_GRP3D_MAX_LUT4P_BANK	= 16;
	static const U32 MES_GRP3D_MAX_LUTALIGN_X	= 8;
	static const U32 MES_GRP3D_MAX_LUT4PALIGN_Y	= 2;
	static const U32 MES_GRP3D_MAX_LUT8PALIGN_Y	= 32;
)

MES_DEBUG_CODE (
	static const U32 MES_GRP3D_MAX_VERTEX         = 0x10000;
	static const U32 MES_GRP3D_VERTEXBUFFER_ALIGN = 8;
	static const U32 MES_GRP3D_INDEXBUFFER16_ALIGN= 2;
)
*/



MES_DEBUG_CODE (
	static const U32 MES_GRP3D_RS_VALIDMASK = ((1<<15)-1);
)



// internal functions
CBOOL MES_GRP3D_SetLastError( MES_GRP3D_ERR Error );

/*
// interrupt control�� ��ü.
//--------------------------------------------------------------------------
///	@name	MES_IInterruptable32 implementation
//--------------------------------------------------------------------------
//@{
void	MES_GRP3D_SetInterruptEnable32 ( U32 EnableFlag );
U32		MES_GRP3D_GetInterruptEnable32 ( void );
U32		MES_GRP3D_GetInterruptPending32 ( void );	
void	MES_GRP3D_ClearInterruptPending32 ( U32 PendingFlag );
//@}
		
*/









//--------------------------------------------------------------------------
//	command buffer/queue control 
//--------------------------------------------------------------------------
#define MES_GRP3D_CHECK_INVALID_COMMAND	\
			((__g_pRegister->INTC & INVALID_CMD_PEDING_MASK) == 0)

#define MES_GRP3D_CHECK_TIMEOUT( utimoutcounter )					\
	{                                 		            \
		if( utimeoutcounter >= __m_pValues->m_TimeOutValue )  \
		{                                               \
			return MES_GRP3D_SetLastError(MES_GRP3D_ERR_TIMEOUT);  \
		}                                               \
		utimeoutcounter++;                              \
	}
	


CBOOL (*MES_GRP3D_CurrentBeginCommand)( MES_GRP3D_PCMD* ppCMD,
						   U32 RegisterOffset32, U32 ReserveSize32 );
void (*MES_GRP3D_CurrentEndCommand)( void );

static CBOOL MES_GRP3D_BeginCommand_Direct( MES_GRP3D_PCMD* ppCMD,
						U32 RegisterOffset32, U32 ReserveSize32 );
static CBOOL MES_GRP3D_BeginCommand_CommandBuffer( MES_GRP3D_PCMD* ppCMD,
						U32 RegisterOffset32, U32 ReserveSize32 );
static CBOOL MES_GRP3D_BeginCommand_CommandQueue( MES_GRP3D_PCMD* ppCMD,
						U32 RegisterOffset32, U32 ReserveSize32 );
static void MES_GRP3D_EndCommand_Direct( void );
static void MES_GRP3D_EndCommand_CommandBuffer( void );
static void MES_GRP3D_EndCommand_CommandQueue( void );


CBOOL MES_GRP3D_RunRasterizer_UpdateLUT( void );

typedef enum 
{
	MES_GRP3D_COMMANDTYPE_CONTROL     =  0,
	MES_GRP3D_COMMANDTYPE_RENDERSTATE =  1,
	MES_GRP3D_COMMANDTYPE_ALPHABLEND  =  2,
	MES_GRP3D_COMMANDTYPE_TEXSEGMENT  =  3,
	MES_GRP3D_COMMANDTYPE_MAPPARAM    =  4,
	MES_GRP3D_COMMANDTYPE_LUTFILL     =  5,
	MES_GRP3D_COMMANDTYPE_TEXINFO0    =  6,
	MES_GRP3D_COMMANDTYPE_TEXINFO1    =  7,
	MES_GRP3D_COMMANDTYPE_TEXBLEND0   =  8,
	MES_GRP3D_COMMANDTYPE_TEXBLEND1   =  9,
	MES_GRP3D_COMMANDTYPE_PRIMITIVE   = 10,
	MES_GRP3D_COMMANDTYPE_REGFILL     = 11,
	MES_GRP3D_END_OF_COMMANDTYPE 	  = 12
} MES_GRP3D_COMMANDTYPE;	


CBOOL MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE CommandType, U32 Data );
CBOOL MES_GRP3D_CommandWrite2( MES_GRP3D_COMMANDTYPE CommandType,
						U32 Data0, U32 Data1 );
CBOOL MES_GRP3D_CommandWrite6( MES_GRP3D_COMMANDTYPE CommandType,
						U32 Data0, U32 Data1, U32 Data2,
						U32 Data3, U32 Data4, U32 Data5 );
CBOOL MES_GRP3D_CommandWrite(	U32	count,
						MES_GRP3D_COMMANDTYPE CommandType,
						U32 Data );





////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------------------------
// Module Interface
//------------------------------------------------------------------------------
/**
 *  @brief  Initialize of prototype enviroment & local variables.
 *  @return \b CTRUE   Initialize is successed.\n
 *          \b CFALSE  Initialize is failed.\n
 *  @see    MES_GRP3D_SelectModule,
 *          MES_GRP3D_GetCurrentModule,     MES_GRP3D_GetNumberOfModule
 */
CBOOL   MES_GRP3D_Initialize( void )
{
    U32 i;
    __g_CurModuleIndex= 0;
    for( i=0; i < NUMBER_OF_GRP3D_MODULE; i++ )
    {
        __g_ModuleVariables[i].pRegister = CNULL;
        //__m_MemberVariables[i].pValues   = CNULL;
    }
    return CTRUE;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Select module to control
 *  @param[in]  ModuleIndex     Module index to select.
 *  @return     None.
 *  @see    MES_GRP3D_Initialize,           
 *          MES_GRP3D_GetCurrentModule,     MES_GRP3D_GetNumberOfModule
 */
void    MES_GRP3D_SelectModule( U32 ModuleIndex )
{
    MES_ASSERT( NUMBER_OF_GRP3D_MODULE > ModuleIndex );

    __g_CurModuleIndex = ModuleIndex;
    __g_pRegister 	= __g_ModuleVariables[ModuleIndex].pRegister;
    __m_pValues 	= &(__m_MemberVariables[ModuleIndex]);
}

//------------------------------------------------------------------------------
/**
 *  @brief      Get index of current selected module.
 *  @return     Current module's index.
 *  @see    MES_GRP3D_Initialize,           MES_GRP3D_SelectModule,
 *          MES_GRP3D_GetNumberOfModule
 */
U32     MES_GRP3D_GetCurrentModule( void )
{
    return __g_CurModuleIndex;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Get number of modules in the chip.
 *  @return     Module's number.
 *  @see        MES_GRP3D_Initialize,           MES_GRP3D_SelectModule,
 *              MES_GRP3D_GetCurrentModule     
 */
U32     MES_GRP3D_GetNumberOfModule( void )
{
    return NUMBER_OF_GRP3D_MODULE;
}

//------------------------------------------------------------------------------
// Basic Interface
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/**
 *  @brief      Get module's physical address.
 *  @return     Module's physical address
 *  @see        MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
U32     MES_GRP3D_GetPhysicalAddress( void )
{
    MES_ASSERT( NUMBER_OF_GRP3D_MODULE > __g_CurModuleIndex );

    return  (U32)( PHY_BASEADDR_GRP3D_MODULE + (OFFSET_OF_GRP3D_MODULE * __g_CurModuleIndex) );
}

//------------------------------------------------------------------------------
/**
 *  @brief      Get a size, in byte, of register set.
 *  @return     Size of module's register set.
 *  @see        MES_GRP3D_GetPhysicalAddress,    
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
U32     MES_GRP3D_GetSizeOfRegisterSet( void )
{
    return sizeof( struct MES_GRP3D_RegisterSet );
}

//------------------------------------------------------------------------------
/**
 *  @brief      Set a base address of register set.
 *  @param[in]  BaseAddress Module's base address
 *  @return     None.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
void    MES_GRP3D_SetBaseAddress( U32 BaseAddress )
{
    MES_ASSERT( CNULL != BaseAddress );
    MES_ASSERT( NUMBER_OF_GRP3D_MODULE > __g_CurModuleIndex );

    __g_ModuleVariables[__g_CurModuleIndex].pRegister = (struct MES_GRP3D_RegisterSet *)BaseAddress;
    __g_pRegister = (struct MES_GRP3D_RegisterSet *)BaseAddress;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Get a base address of register set
 *  @return     Module's base address.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
U32     MES_GRP3D_GetBaseAddress( void )
{
    MES_ASSERT( NUMBER_OF_GRP3D_MODULE > __g_CurModuleIndex );

    return (U32)__g_ModuleVariables[__g_CurModuleIndex].pRegister;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Initialize selected modules with default value.
 *  @return     \b CTRUE   Initialize is successed. \n
 *              \b CFALSE  Initialize is failed.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
CBOOL   MES_GRP3D_OpenModule( void )
{
	const float maxZ = 65535.0f;
	const U32 fogColor = 0;
	
	MES_ASSERT( CNULL != __g_pRegister );
	
 	__m_pValues = &(__m_MemberVariables[__g_CurModuleIndex]);
 
	__m_pValues->m_VolumeCullingState			= MES_GRP3D_VOLUMECULLSTATE_NONE;
	__m_pValues->m_CullingEnable 				= 0;
	__m_pValues->m_CullingTestEnable			= 0;
	__m_pValues->m_GRP3DControlMode				= MES_GRP3D_CONTROLMODE_DIRECT;
	__m_pValues->m_TimeOutValue					= 0;	
	__m_pValues->m_CommandBufferPointer			= 0;
	__m_pValues->m_CommandBufferSize32			= 0;
	__m_pValues->m_CommandBufferPos32			= 0;
	__m_pValues->m_CommandQueueClosePoint		= 0;
	__m_pValues->m_CommandQueueSize32			= 0;
	__m_pValues->m_CommandQueue_VirtualOffset	= 0;

	__m_pValues->m_CommandQueueFrontPointer		= 0;
	
	__m_pValues->m_CurrentRenderState			= 0;
	__m_pValues->m_CurrentTransparencyColor		= 0;
	__m_pValues->m_CurrentMipmapBias			= 0;
	
	// ??? �ʱⰪ ������..?
	__m_pValues->m_CurrentPrimitiveParamDatas[0]= 0;
	__m_pValues->m_CurrentPrimitiveParamDatas[1]= 0;
	__m_pValues->m_CurrentPrimitiveParamDatas[2]= 0;
	__m_pValues->m_CurrentPrimitiveParamDatas[3]= 0;

	__m_pValues->m_LastError					= MES_GRP3D_ERR_NONE;


	MES_GRP3D_ResetCommandSystem();

	MES_GRP3D_SetPowerControl(MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN, 
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN, 
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN,
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN);
				
	MES_GRP3D_SetPowerControl(MES_GRP3D_POWERMODE_SLEEP, MES_GRP3D_POWERMODE_SLEEP, 
				MES_GRP3D_POWERMODE_SLEEP, MES_GRP3D_POWERMODE_SLEEP, 
				MES_GRP3D_POWERMODE_SLEEP, MES_GRP3D_POWERMODE_SLEEP,
				MES_GRP3D_POWERMODE_SLEEP, MES_GRP3D_POWERMODE_SLEEP);				

	MES_GRP3D_SetPowerControl(MES_GRP3D_POWERMODE_OPERATION, MES_GRP3D_POWERMODE_OPERATION, 
				MES_GRP3D_POWERMODE_OPERATION, MES_GRP3D_POWERMODE_OPERATION, 
				MES_GRP3D_POWERMODE_OPERATION, MES_GRP3D_POWERMODE_OPERATION,
				MES_GRP3D_POWERMODE_OPERATION, MES_GRP3D_POWERMODE_OPERATION);

	MES_GRP3D_SetInterruptEnableAll( CFALSE );		
	MES_GRP3D_ClearInterruptPendingAll();
	
	MES_GRP3D_SetVolumeCullingState( MES_GRP3D_VOLUMECULLSTATE_NONE );
	MES_GRP3D_ClearTextureCache();
	MES_GRP3D_SetRenderState( MES_GRP3D_RS_SHADE_ENB | MES_GRP3D_RS_DITHER );

	MES_GRP3D_SetBlendFactor( MES_GRP3D_BLEND_SRCALPHA, MES_GRP3D_BLEND_INVSRCALPHA );
	MES_GRP3D_SetTextureSegment( 0, 0 );
	MES_GRP3D_SetTextureSegment( 1, 0 );
	MES_GRP3D_SetTransparencyColor( 0 );
	
	//MES_GRP3D_SetMipmapBias( 0 );
	/*
	MES_GRP3D_SetTexture ( 0, MES_GRP3D_TEXTURETYPE_BITMAP,
						MES_GRP3D_PIXELFORMAT_4P, 0,
						CFALSE,
						MES_GRP3D_TEXTUREADDRESS_WRAP,
						0, 0, 16, 16 );
	MES_GRP3D_SetTexture ( 1, MES_GRP3D_TEXTURETYPE_BITMAP,
						MES_GRP3D_PIXELFORMAT_4P, 0,
						CFALSE,
						MES_GRP3D_TEXTUREADDRESS_WRAP,
						0, 0, 16, 16 );
	*/
	
	MES_GRP3D_SetTexture ( 0, 0, MES_GRP3D_COLORFORMAT_INDEXED4_R5G6B5, 
						CFALSE, CFALSE,
						MES_GRP3D_TEXTUREADDRESS_WRAP, MES_GRP3D_TEXTUREADDRESS_WRAP,
						0, 0, 16, 16 );
	MES_GRP3D_SetTexture ( 1, 0, MES_GRP3D_COLORFORMAT_INDEXED4_R5G6B5, 
						CFALSE, CFALSE,
						MES_GRP3D_TEXTUREADDRESS_WRAP, MES_GRP3D_TEXTUREADDRESS_WRAP,
						0, 0, 16, 16 );
						
	/*	// ??? �ʱⰪ ����??				
	MES_GRP3D_SetTextureBlend( 0, MES_GRP3D_TEXARG_TEXTURE, MES_GRP3D_TEXARG_DIFFUSE,
                         	  MES_GRP3D_TEXOP_MODULATE );
	MES_GRP3D_SetTextureBlend( 1, MES_GRP3D_TEXARG_TEXTURE, MES_GRP3D_TEXARG_CURRENT,
                         	  MES_GRP3D_TEXOP_ADD );
    */
    
    
	MES_GRP3D_SetFogColor( fogColor );
	MES_GRP3D_SetFogMaxZ( maxZ );

	MES_GRP3D_SetZValidBuffer( CFALSE, 0,0,0 );
	MES_GRP3D_SetZScale( maxZ );

	/*
	{
		U32 vf[4];
		vf[0] = vf[1] = vf[2] = vf[3] = 0xFFFFFFFF;
		MES_GRP3D_SetVertexFormat( 0,0,0,(MES_GRP3D_VertexFormat*)vf);
	}
	*/
	MES_GRP3D_SetViewport( 0,0,16,16 );

	MES_ASSERT(	! MES_GRP3D_CheckBusy() );	

	return CTRUE;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Deinitialize selected module to the proper stage.
 *  @return     \b CTRUE   Deinitialize is successed. \n
 *              \b CFALSE  Deinitialize is failed.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           
 *              MES_GRP3D_CheckBusy,            MES_GRP3D_CanPowerDown
 */
CBOOL   MES_GRP3D_CloseModule( void )
{
	MES_ASSERT(	MES_GRP3D_CanPowerDown() );
	MES_GRP3D_SetPowerControl( MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN, 
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN, 
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN,
				MES_GRP3D_POWERMODE_DOWN, MES_GRP3D_POWERMODE_DOWN );
	return CTRUE;
}

//------------------------------------------------------------------------------
/**
 *  @brief      Indicates whether the selected modules is busy or not.
 *  @return     \b CTRUE   Module is Busy. \n
 *              \b CFALSE  Module is NOT Busy.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CanPowerDown
 */
CBOOL   MES_GRP3D_CheckBusy( void )
{
	const U32 IDLE_MASK = 0x00BF0000;
	
	MES_ASSERT( CNULL != __g_pRegister );

	// 3d graphic processor�� idle�� ������ ���� ���ǵȴ�.
	// ��� sub-module�� idle�����̰�, rasterizer�� �Է� fifo�� empty�����̴�.
	// GRP3D_STATUS�� �����Ұ�.
	if( (__g_pRegister->STATUS & IDLE_MASK) == IDLE_MASK )
	{
		return CFALSE ;
	}
	else
	{
		return CTRUE;
	}	
}

//------------------------------------------------------------------------------
/**
 *  @brief      Indicaes whether the selected modules is ready to enter power-down stage
 *  @return     \b CTRUE   Ready to enter power-down stage. \n
 *              \b CFALSE  This module can't enter to power-down stage.
 */
CBOOL   MES_GRP3D_CanPowerDown( void )
{
    if( MES_GRP3D_CheckBusy() )
    {
        return CFALSE;   
    }
    
    return CTRUE;
}

// @Gamza 2008/07/31
void    MES_GRP3D_RestoreModule( void )
{
	int module_index;
	for( module_index = 0; module_index<NUMBER_OF_GRP3D_MODULE; module_index++ )
	{
		struct MES_GRP3D_RegisterSet*       phwregister = __g_ModuleVariables[module_index].pRegister;
		const struct MES_GRP3D_RegisterSet* pswregister = &__m_MemberVariables[module_index].m_BackupRegister;
		int i;

		phwregister->CLKENB	        = pswregister->CLKENB           ;

		//phwregister->CPCONTROL      = pswregister->CPCONTROL        ;
		//phwregister->CMDQSTART      = pswregister->CMDQSTART        ;
		//phwregister->CMDQEND        = pswregister->CMDQEND          ;
		//phwregister->CMDQFRONT      = pswregister->CMDQFRONT        ;
		//phwregister->CMDQREAR       = pswregister->CMDQREAR         ;
		//phwregister->STATUS         = pswregister->STATUS           ;
		phwregister->INTC           = pswregister->INTC             ;
		//phwregister->CONTROL        = pswregister->CONTROL          ;
		//phwregister->POWERCONTROL	= pswregister->POWERCONTROL	    ;
	    phwregister->POWERCONTROL = (((U32)MES_GRP3D_POWERMODE_DOWN	<<14) |
		                   			 ((U32)MES_GRP3D_POWERMODE_DOWN	<<12) |
  				                     ((U32)MES_GRP3D_POWERMODE_DOWN	<<10) |
                                     ((U32)MES_GRP3D_POWERMODE_DOWN	<< 8) |
                                     ((U32)MES_GRP3D_POWERMODE_DOWN	<< 6) |
                                     ((U32)MES_GRP3D_POWERMODE_DOWN	<< 4) |
                                     ((U32)MES_GRP3D_POWERMODE_DOWN	<< 2) |
                                     ((U32)MES_GRP3D_POWERMODE_DOWN << 0) );
	    phwregister->POWERCONTROL = (((U32)MES_GRP3D_POWERMODE_SLEEP<<14) |
		                   			 ((U32)MES_GRP3D_POWERMODE_SLEEP<<12) |
  				                     ((U32)MES_GRP3D_POWERMODE_SLEEP<<10) |
                                     ((U32)MES_GRP3D_POWERMODE_SLEEP<< 8) |
                                     ((U32)MES_GRP3D_POWERMODE_SLEEP<< 6) |
                                     ((U32)MES_GRP3D_POWERMODE_SLEEP<< 4) |
                                     ((U32)MES_GRP3D_POWERMODE_SLEEP<< 2) |
                                     ((U32)MES_GRP3D_POWERMODE_SLEEP<< 0) );
	    phwregister->POWERCONTROL = (((U32)MES_GRP3D_POWERMODE_OPERATION<<14) |
		                   			 ((U32)MES_GRP3D_POWERMODE_OPERATION<<12) |
  				                     ((U32)MES_GRP3D_POWERMODE_OPERATION<<10) |
                                     ((U32)MES_GRP3D_POWERMODE_OPERATION<< 8) |
                                     ((U32)MES_GRP3D_POWERMODE_OPERATION<< 6) |
                                     ((U32)MES_GRP3D_POWERMODE_OPERATION<< 4) |
                                     ((U32)MES_GRP3D_POWERMODE_OPERATION<< 2) |
                                     ((U32)MES_GRP3D_POWERMODE_OPERATION<< 0) );		
		phwregister->RENDERSTATE    = pswregister->RENDERSTATE      ;
		phwregister->ALPHABLEND     = pswregister->ALPHABLEND       ;
		phwregister->TEXSUBSEGMENT  = pswregister->TEXSUBSEGMENT    ;
		phwregister->TPCOLOR        = pswregister->TPCOLOR          ;
		phwregister->MIPMAPBIAS     = pswregister->MIPMAPBIAS       ;
		phwregister->LUTPARAM       = pswregister->LUTPARAM         ;
		phwregister->TEXINFO0_0     = pswregister->TEXINFO0_0       ;
		phwregister->TEXINFO0_1     = pswregister->TEXINFO0_1       ;
		phwregister->TEXINFO1_0     = pswregister->TEXINFO1_0       ;
		phwregister->TEXINFO1_1     = pswregister->TEXINFO1_1       ;
		phwregister->TEXBLEND0      = pswregister->TEXBLEND0        ;
		phwregister->TEXBLEND1      = pswregister->TEXBLEND1        ;
		phwregister->ALPHATEST		= pswregister->ALPHATEST		;
		phwregister->TEXCONST		= pswregister->TEXCONST		    ;
		phwregister->FOGCOLOR       = pswregister->FOGCOLOR         ;
		phwregister->FOGMAXZ        = pswregister->FOGMAXZ          ;
		phwregister->DISPINFO       = pswregister->DISPINFO         ;
		phwregister->MFILLPARAM0    = pswregister->MFILLPARAM0      ;
		phwregister->MFILLPARAM1    = pswregister->MFILLPARAM1      ;
		phwregister->MFILLPARAM2    = pswregister->MFILLPARAM2      ;
		phwregister->RENDTRG0       = pswregister->RENDTRG0         ;
		phwregister->RENDTRG1       = pswregister->RENDTRG1         ;
		phwregister->RENDTRG2       = pswregister->RENDTRG2         ;
		phwregister->ZBINFO         = pswregister->ZBINFO           ;
		phwregister->ZVBINFO        = pswregister->ZVBINFO          ;
		phwregister->ZSCALE         = pswregister->ZSCALE           ;
		phwregister->VPORTBOT       = pswregister->VPORTBOT         ;
		phwregister->VPORTH         = pswregister->VPORTH           ;
		phwregister->VPORTLEFT      = pswregister->VPORTLEFT        ;
		phwregister->VPORTW         = pswregister->VPORTW           ;
		phwregister->PRIMCON1		= pswregister->PRIMCON1		    ;
		phwregister->IDXSTART		= pswregister->IDXSTART		    ;
		phwregister->IDXEND			= pswregister->IDXEND			;
		phwregister->PRAMLOOPCTRL	= pswregister->PRAMLOOPCTRL	    ;

#define ARRAY_COPY( NAME )  \
        for( i=0; i<sizeof(phwregister->NAME)/sizeof(phwregister->NAME[0]); i++ )   \
            { phwregister->NAME[i] = pswregister->NAME[i]; }

		ARRAY_COPY( PPARAMS      );
		ARRAY_COPY( VERTEXSTREAM );
		ARRAY_COPY( FOGTBL       );
		ARRAY_COPY( TSEINPUT     );
		//volatile float	GTEOUT		[(0xA790-0xA700)/4]	;	///< 0xA700 ~ 0xA78F :
		ARRAY_COPY( GTECODE      );
		ARRAY_COPY( GTECONST     );
	}
}

//------------------------------------------------------------------------------
/**
 *  @brief      Indicaes whether the selected modules is ready to enter power-down stage
 *  @return     \b CTRUE   Ready to enter power-down stage. \n
 *              \b CFALSE  This module can't enter to power-down stage.
 *  @see        MES_GRP3D_GetPhysicalAddress,   MES_GRP3D_GetSizeOfRegisterSet, 
 *              MES_GRP3D_SetBaseAddress,       MES_GRP3D_GetBaseAddress,
 *              MES_GRP3D_OpenModule,           MES_GRP3D_CloseModule,
 *              MES_GRP3D_CheckBusy            
 */
//CBOOL   MES_GRP3D_CanPowerDown( void )
//{
//    return CTRUE;
//}

// 0: REGFILLINTR, 1: INVCMDINTR
void    MES_GRP3D_SetInterruptEnable( S32 IntNum, CBOOL Enable )
{
	MES_ASSERT( CNULL != __g_pRegister );
	MES_ASSERT( (Enable == 0) || (Enable == 1) ); 

	if( 0 == IntNum )		// REGFILLINTR
	{
		__g_pRegister->INTC = __m_pValues->m_BackupRegister.INTC = (Enable<<8);
	}
	else if( 1 == IntNum )	// INVCMDINTR
	{
		__g_pRegister->INTC = __m_pValues->m_BackupRegister.INTC = (Enable<<9);
	}
}

CBOOL   MES_GRP3D_GetInterruptEnable( S32 IntNum )
{
	MES_ASSERT( CNULL != __g_pRegister );
	
	if( 0 == IntNum )		// REGFILLINTR
		return (__g_pRegister->INTC>>8) & 1;
	else if( 1 == IntNum )	// INVCMDINTR
		return (__g_pRegister->INTC>>9) & 1;
	else
		return 0;
}

CBOOL   MES_GRP3D_GetInterruptPending( S32 IntNum )
{
	MES_ASSERT( CNULL != __g_pRegister );
	if( 0 == IntNum )		// REGFILLINTR
		return __g_pRegister->INTC & 1;
	else if( 1 == IntNum )	// INVCMDINTR	
		return (__g_pRegister->INTC>>1) & 1;
	else
		return CFALSE;
	
}

void    MES_GRP3D_ClearInterruptPending( S32 IntNum )
{
	U32 control = __g_pRegister->INTC;
	MES_ASSERT( CNULL != __g_pRegister );

	control &= 0x300;

	if( 0 == IntNum )		// REGFILLINTR
		control |= 1;

	else if( 1 == IntNum )	// INVCMDINTR
		control |= (1<<1);

	__g_pRegister->INTC = control;	
}

void    MES_GRP3D_SetInterruptEnableAll( CBOOL Enable )
{
	MES_ASSERT( CNULL != __g_pRegister );
	if( Enable )
		__g_pRegister->INTC = __m_pValues->m_BackupRegister.INTC = (3<<8);
	else
		__g_pRegister->INTC = __m_pValues->m_BackupRegister.INTC = 0;
}

CBOOL   MES_GRP3D_GetInterruptEnableAll( void )
{
	MES_ASSERT( CNULL != __g_pRegister );
	return (__g_pRegister->INTC>>8) & 3;
}

CBOOL   MES_GRP3D_GetInterruptPendingAll( void )
{
	MES_ASSERT( CNULL != __g_pRegister );
	return __g_pRegister->INTC & 3;		
}

void    MES_GRP3D_ClearInterruptPendingAll( void )
{
	U32 control = __g_pRegister->INTC;
	MES_ASSERT( CNULL != __g_pRegister );
		
	// enable bit�� �����ϰ� ��ġ�ʴ� pending bit�� clear���� �ʵ��� �Ѵ�.
	control &= 0x300;
	control |= 3;
	__g_pRegister->INTC = control;
}

S32     MES_GRP3D_GetInterruptPendingNumber( void )
{
	MES_ASSERT( CNULL != __g_pRegister );
	
	if( __g_pRegister->INTC & 2 )
		return 1;
	else if( __g_pRegister->INTC & 1 )
		return 0;
	else
		return -1;
}


void            MES_GRP3D_SetClockPClkMode( MES_PCLKMODE mode )
{
    const U32 PCLKMODE_POS = 3;
    U32 regvalue;

    MES_ASSERT( CNULL != __g_pRegister );
	
	//OUTPUT_DEBUG_STRING(" ** MES_GRP3D_SetClockPClkMode : before read value.\n");
	regvalue = __g_pRegister->CLKENB;
    regvalue &= ~(1UL<<PCLKMODE_POS);
    regvalue |= ((U32)mode << PCLKMODE_POS);
	
	//OUTPUT_DEBUG_STRING(" ** MES_GRP3D_SetClockPClkMode : before set value.\n");
    __g_pRegister->CLKENB = __m_pValues->m_BackupRegister.CLKENB = regvalue;

}

MES_PCLKMODE    MES_GRP3D_GetClockPClkMode( void )
{
    const U32 PCLKMODE_POS  = 3;

    MES_ASSERT( CNULL != __g_pRegister );
    return (MES_PCLKMODE)( (__g_pRegister->CLKENB >> PCLKMODE_POS) & 1 );
}


void            MES_GRP3D_SetClockBClkMode( MES_BCLKMODE mode )
{
    U32 regvalue;

    MES_ASSERT( CNULL != __g_pRegister );

    regvalue = __g_pRegister->CLKENB;
    regvalue &= ~(0x3);

    regvalue |= ((U32)mode );

    __g_pRegister->CLKENB = __m_pValues->m_BackupRegister.CLKENB = regvalue;	
}

MES_BCLKMODE    MES_GRP3D_GetClockBClkMode( void )
{
    MES_ASSERT( CNULL != __g_pRegister );
    return (MES_BCLKMODE)( __g_pRegister->CLKENB & 3 );
}


//------------------------------------------------------------------------------
/** 
 *  @brief   set time out counter value
 *  @remarks grp3d functions are check hardware state and wait.
 * 			 if wait loop counter is over time out value,
 * 			 set Last error to ERR_TIMEOUT. ( refer to GetLastError )
 */
void MES_GRP3D_SetTimeOutValue( U32 TimeOutValue )
{
 	__m_pValues->m_TimeOutValue = TimeOutValue;
}

//------------------------------------------------------------------------------
/**
 *  @brief   set Command queue memory region and
 * 			 change state to command queue mode.
 *  @remarks After this function call, all command are written/execute
 * 			 at command queue before GRP3D_CloseCommandQueue function call. \n
 * 			 Hardware status should be Idle.  \n
 * 			 When direct mode, possible to call  \n
 * 			 When Command buffer is open, impossible to call. \n
 * 			 When Command queue is open, impossible to call. \n
 */
void MES_GRP3D_OpenCommandQueue( U32* pCommand_Virtual, U32* pCommand_Physical, U32 Size64 )
{
	MES_ASSERT( pCommand_Virtual );
	MES_ASSERT( 0 == ((U32)pCommand_Virtual % 8 ) );
	MES_ASSERT( MES_GRP3D_MIN_COMMANDQUEUE_SIZE < Size64 );
	MES_ASSERT( ! MES_GRP3D_CheckBusy() );
	MES_ASSERT( MES_GRP3D_CONTROLMODE_DIRECT == __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_Direct == MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_Direct == MES_GRP3D_CurrentEndCommand );

	__m_pValues->m_CommandQueueClosePoint = CNULL;
	__m_pValues->m_CommandQueueSize32     = Size64*2;
	__m_pValues->m_CommandQueue_VirtualOffset = (U32)((U32)(pCommand_Virtual) - (U32)(pCommand_Physical));

	// FIFO setting : Start <= excute region <= End
	__g_pRegister->CMDQSTART = __m_pValues->m_BackupRegister.CMDQSTART = (U32)(pCommand_Physical);
	__g_pRegister->CMDQEND   = __m_pValues->m_BackupRegister.CMDQEND   = (U32)(pCommand_Physical+(Size64*2)-1);
	__g_pRegister->CMDQFRONT = __m_pValues->m_BackupRegister.CMDQFRONT = (U32)(pCommand_Physical);
	__g_pRegister->CPCONTROL = __m_pValues->m_BackupRegister.CPCONTROL = (MES_GRP3D_CONTROL_START);

	__m_pValues->m_GRP3DControlMode = MES_GRP3D_CONTROLMODE_QUEUE;
	MES_GRP3D_CurrentBeginCommand = &MES_GRP3D_BeginCommand_CommandQueue;
	MES_GRP3D_CurrentEndCommand   = &MES_GRP3D_EndCommand_CommandQueue;

	if( __m_pValues->m_CommandQueueFrontPointer==0 )
	{
		__m_pValues->m_CommandQueueFrontPointer = __g_pRegister->CMDQFRONT;	
	}
	else
	{
		__m_pValues->m_CommandQueueFrontPointer +=  7;	
		__m_pValues->m_CommandQueueFrontPointer &= ~7;
	}
}

//------------------------------------------------------------------------------
/**
 *  @brief   Stop Command queue operation and change state to direct mode.
 *  @remarks Hardware will operates continuously for finishing Command queue.
 * 			 Therefore, hardware may not idle for a moment right after the
 * 			 function finish.\n
 *			 It can be called when Command queue is opened.
 */
void MES_GRP3D_CloseCommandQueue( void )
{
	MES_ASSERT( MES_GRP3D_CheckBusy() );
	MES_ASSERT( MES_GRP3D_CONTROLMODE_QUEUE == __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_CommandQueue == MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_CommandQueue == MES_GRP3D_CurrentEndCommand );

	// command queue�� ���� 64bit ���ĵ��� �ʾҴٸ� NOP�� �����Ѵ�.
	if( 0 != (__g_pRegister->CMDQFRONT%8) )
	{
		// command queue�� ���� 64bit ���ĵ��� �ʾ����Ƿ�
		// NOP������ ���� �� �� ����.
		MES_CHECK( MES_GRP3D_Nop() );
	}
	// excute & stop command read
	__g_pRegister->CPCONTROL = (MES_GRP3D_CONTROL_START|MES_GRP3D_CONTROL_STOP);

	__m_pValues->m_GRP3DControlMode = MES_GRP3D_CONTROLMODE_DIRECT;
	MES_GRP3D_CurrentBeginCommand = &MES_GRP3D_BeginCommand_Direct;
	MES_GRP3D_CurrentEndCommand   = &MES_GRP3D_EndCommand_Direct;	
}

//------------------------------------------------------------------------------
/**
 *  @brief   Set Command buffer memory and change state to command buffer mode.
 *  @remarks After this function call, all command are written at
 * 			 command buffer before GRP3D_CloseCommandQueue function call.\n
 * 			 To execute command buffer written command,
 * 			 Command buffer should be closed before execution.\n
 * 			 It does not need hardware idle status.\n
 * 			 When direct mode, possible to call \n
 * 			 When Command buffer is open, impossible to call.\n
 *			 When Command queue is open, impossible to call.\n
 */
void MES_GRP3D_OpenCommandBuffer( U32* pCommand_Virtual, U32 Size64 )
{
	MES_ASSERT( pCommand_Virtual );
	MES_ASSERT( 0 == ((U32)pCommand_Virtual % 8 ) );
	MES_ASSERT( MES_GRP3D_MIN_COMMANDQUEUE_SIZE < Size64 );
	MES_ASSERT( MES_GRP3D_CONTROLMODE_DIRECT == __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_Direct == MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_Direct == MES_GRP3D_CurrentEndCommand );

	__m_pValues->m_CommandBufferPointer = pCommand_Virtual;
	__m_pValues->m_CommandBufferSize32  = Size64*2;
	__m_pValues->m_CommandBufferPos32   = 0;

	__m_pValues->m_GRP3DControlMode = MES_GRP3D_CONTROLMODE_BUFFER;
	MES_GRP3D_CurrentBeginCommand = &MES_GRP3D_BeginCommand_CommandBuffer;
	MES_GRP3D_CurrentEndCommand   = &MES_GRP3D_EndCommand_CommandBuffer;	
}

//------------------------------------------------------------------------------
/**
 *  @brief  Get of memory region filled with valid command.
 *  @return size of memory region filled with valid command.(unit:32bit)
 */ 
U32  MES_GRP3D_CheckCommandBuffer( void )
{
	MES_ASSERT( MES_GRP3D_CONTROLMODE_BUFFER == __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_CommandBuffer == MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_CommandBuffer == MES_GRP3D_CurrentEndCommand );
	return __m_pValues->m_CommandBufferPos32;	
}

//------------------------------------------------------------------------------
/**
 *  @brief   Close Command buffer and change state to direct mode
 *  @remarks Possible to call only when Command buffer is open.
 *  @return  size of memory region filled with valid command. (unit:32bit)
 */
U32  MES_GRP3D_CloseCommandBuffer( void )
{
	MES_ASSERT( MES_GRP3D_CONTROLMODE_BUFFER == __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_CommandBuffer == MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_CommandBuffer == MES_GRP3D_CurrentEndCommand );
	// command buffer�� ���� 64bit ���ĵ��� �ʾҴٸ� NOP�� �����Ѵ�.
	if( 0 != (__m_pValues->m_CommandBufferPos32%2) )
	{
		// command buffer�� ���� 64bit ���ĵ��� �ʾ����Ƿ�
		// NOP������ ���� �� �� ����.
		MES_CHECK( MES_GRP3D_Nop() );
	}
	__m_pValues->m_GRP3DControlMode = MES_GRP3D_CONTROLMODE_DIRECT;
	MES_GRP3D_CurrentBeginCommand = &MES_GRP3D_BeginCommand_Direct;
	MES_GRP3D_CurrentEndCommand   = &MES_GRP3D_EndCommand_Direct;
	return __m_pValues->m_CommandBufferPos32;	
}

//------------------------------------------------------------------------------
/**
 *  @brief   Execute Command buffer.
 * 	@remarks Hardware status should be Idle. \n
 * 			 When direct mode, possible to call \n
 *			 When Command buffer is open, impossible to call.\n
 *			 When Command queue is open, impossible to call.\n
 */
void MES_GRP3D_ExecuteCommandBuffer( U32* pCommand_Physical, U32 Size64 )
{
	U32 curFront;
	
	MES_ASSERT( pCommand_Physical );
	MES_ASSERT( 0 == ((U32)pCommand_Physical % 8 ) );
	MES_ASSERT( MES_GRP3D_MIN_COMMANDQUEUE_SIZE < Size64 );
	MES_ASSERT( ! MES_GRP3D_CheckBusy() );
	MES_ASSERT( MES_GRP3D_CONTROLMODE_QUEUE != __m_pValues->m_GRP3DControlMode );
	MES_ASSERT( MES_GRP3D_BeginCommand_CommandQueue != MES_GRP3D_CurrentBeginCommand );
	MES_ASSERT( MES_GRP3D_EndCommand_CommandQueue != MES_GRP3D_CurrentEndCommand );

	// FIFO setting : Start <= excute region <= End
	__g_pRegister->CMDQSTART = __m_pValues->m_BackupRegister.CMDQSTART = (U32)(pCommand_Physical);
	__g_pRegister->CMDQEND   = __m_pValues->m_BackupRegister.CMDQEND   = 0xFFFFFFFF;//(U32)(pCommand_Physical+(Size64*2));

	//m_pRegister->CMDQFRONT = (U32)(pCommand_Physical+(Size64*2));
	// �Ʒ� �ڵ�� ��ü.
	curFront = (U32)(pCommand_Physical+(Size64*2));
	//__m_pValues->m_CommandQueueFrontPointer += (curFront - __g_pRegister->CMDQFRONT)&0xFFFFFFFF;//������ �縸ŭ +		
	__m_pValues->m_CommandQueueFrontPointer += (( ((unsigned __int64)__m_pValues->m_CommandQueueSize32<<2) + curFront - __g_pRegister->CMDQFRONT)%(__m_pValues->m_CommandQueueSize32<<2));// ������ �縸ŭ +		
	__g_pRegister->CMDQFRONT = curFront;

	__g_pRegister->CPCONTROL = (MES_GRP3D_CONTROL_START|MES_GRP3D_CONTROL_STOP);	
}



//------------------------------------------------------------------------------
// Loacal constant definitions
//------------------------------------------------------------------------------
MES_DEBUG_CODE (
	static const float MES_GRP3D_MAX_ZVALUE = (65535.0f);
	static const float MES_GRP3D_MIN_ZVALUE = (1.0f/2048.0f);
)
static const U32 MES_GRP3D_ZV_SHIFT_X    = 6;
static const U32 MES_GRP3D_ZV_SHIFT_Y    = 7;


//------------------------------------------------------------------------------
/**
 *  @brief   interrupt command.\n
 * 			 if direct mode, it is just NOP (no-operation).
 *  @return	 if success, return CTURE. if failed, refer to GetLastError().
 */
CBOOL MES_GRP3D_Nop( void )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable );
}

CBOOL MES_GRP3D_Nops( U32 count )
{
	//return MES_GRP3D_CommandWrite( count, MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable );
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;
	U32 i;
	U32 value = MES_GRP3D_MODULEID_NOP;

	MES_ASSERT( MES_GRP3D_END_OF_COMMANDTYPE > MES_GRP3D_COMMANDTYPE_CONTROL );
	//MES_ASSERT( count == MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	MES_ASSERT( 0 == ((MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable) & MES_GRP3D_CMD_ID_MASK) );

	//MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(CONTROL), 1, (const U32*)&value, MES_GRP3D_WAIT_ALLIDLE, CFALSE );
	
	 //MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable 
	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   MES_GRP3D_CMD_PARAM_LIST[MES_GRP3D_COMMANDTYPE_CONTROL].uOffset32,
							   MES_GRP3D_CMD_PARAM_LIST[MES_GRP3D_COMMANDTYPE_CONTROL].uSize32 * count );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	//pCMD_BUFFER[0] = MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable;
	//pCMD_BUFFER[1] = Data1;
	//pCMD_BUFFER[2] = Data2;
	//pCMD_BUFFER[3] = Data3;
	//pCMD_BUFFER[4] = Data4;
	//pCMD_BUFFER[5] = Data5;
	//memset( (void*)pCMD_BUFFER, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable, sizeof(MES_GRP3D_PCMD) * count );

	U32 nopcommand = MES_GRP3D_CMD_PARAM_LIST[MES_GRP3D_COMMANDTYPE_CONTROL].uID | 
						MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable | 
						__m_pValues->m_CullingEnable;
	for( i = 0; i < count; i++ )
	{
		pCMD_BUFFER[i] = nopcommand;
	}
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}


CBOOL MES_GRP3D_SetPowerControl( MES_GRP3D_POWERMODE VertexCache, MES_GRP3D_POWERMODE GTEReg, 
						MES_GRP3D_POWERMODE GTEProg, MES_GRP3D_POWERMODE ClipReg, 
						MES_GRP3D_POWERMODE Perspective, 
						MES_GRP3D_POWERMODE TexCache0, MES_GRP3D_POWERMODE TexCache1, 
						MES_GRP3D_POWERMODE TexPalette )
{
	U32 commanddata[1];
	commanddata[0] = (((U32)VertexCache	<<14) |
					 ((U32)GTEReg		<<12) |
					 ((U32)GTEProg		<<10) |
					 ((U32)ClipReg		<< 8) |
					 ((U32)Perspective	<< 6) |
					 ((U32)TexCache0	<< 4) |
					 ((U32)TexCache1	<< 2) | (U32)TexPalette );
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(POWERCONTROL), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
}

//------------------------------------------------------------------------------
/**
 *  @brief   clear the Texture cache
 *  @return	 if success, return CTURE. if failed, refer to GetLastError().
 */  
CBOOL MES_GRP3D_ClearTextureCache( void )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
						  MES_GRP3D_MODULEID_RASTERIZER | MES_GRP3D_RASTMODE_CACHECLEAR | __m_pValues->m_CullingTestEnable );
}


CBOOL MES_GRP3D_RunGTE ( U32 Vnum, CBOOL Rendering, CBOOL InverseCullMode )
{
	U32 regVal;
	MES_ASSERT( Vnum<=2 );

	regVal = ( MES_GRP3D_MODULEID_GTE | (Vnum<<6)| ((U32)Rendering<<8)
					| ((U32)InverseCullMode<<9) | __m_pValues->m_CullingTestEnable );
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(CONTROL), 1,
							   (const U32*)&regVal, MES_GRP3D_WAIT_GTEIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_RunTSE_Triangle( CBOOL InverseCullMode )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
							MES_GRP3D_MODULEID_TSE |
					 		MES_GRP3D_TSEMODE_TRIANGLE |
					 		((U32)InverseCullMode<<9) | __m_pValues->m_CullingTestEnable);
}

CBOOL MES_GRP3D_RunTSE_Rectangle( void )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
							MES_GRP3D_MODULEID_TSE |
					 		MES_GRP3D_TSEMODE_RECTANGLE | __m_pValues->m_CullingTestEnable );
}

CBOOL MES_GRP3D_RunPrimitive( void )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
						  MES_GRP3D_MODULEID_PRIMITIVE | __m_pValues->m_CullingTestEnable );
}

CBOOL MES_GRP3D_SetRenderState( U32 RenderState )
{
	CBOOL mesresult;
	MES_ASSERT( 0 == ((~MES_GRP3D_RS_VALIDMASK) & RenderState) );
	mesresult = MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_RENDERSTATE, RenderState );
	if( ! mesresult ){ return CFALSE; }
	__m_pValues->m_CurrentRenderState = RenderState;
	//printf("RenderState: 0x%08x\n", RenderState);	
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );	
}

U32   MES_GRP3D_GetRenderState( void )
{
	return __m_pValues->m_CurrentRenderState;	
}

CBOOL MES_GRP3D_SetBlendFactor( MES_GRP3D_BLEND SrcBlend, MES_GRP3D_BLEND DstBlend )
{
	static const U32 BLEND[] = { 0x01,0x11,0x02,0x12,0x04,0x14,0x08,0x18 };
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_ALPHABLEND,
							(BLEND[DstBlend]<<5) |
							(BLEND[SrcBlend]) );	
}

CBOOL MES_GRP3D_SetTextureSegment( U32 TextureStage, U32 TextureSegment )
{
	CBOOL mesresult;
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > TextureStage );
	
	__m_pValues->m_TexSegment[ TextureStage ] = TextureSegment;

	TextureSegment = (__m_pValues->m_TexSegment[1] << 16) | __m_pValues->m_TexSegment[0];
	mesresult = MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_TEXSEGMENT, TextureSegment );
	if( ! mesresult ){ return CFALSE; }

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

CBOOL MES_GRP3D_SetTransparencyColor( U16 TransparencyColor )
{
	CBOOL mesresult;
	mesresult = MES_GRP3D_CommandWrite2( MES_GRP3D_COMMANDTYPE_MAPPARAM,
					TransparencyColor, __m_pValues->m_CurrentMipmapBias );
	if( ! mesresult ){ return CFALSE; }
	__m_pValues->m_CurrentTransparencyColor = (U32)TransparencyColor;
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

/*
CBOOL MES_GRP3D_SetMipmapBias( U16 MipmapBias )
{
	CBOOL mesresult;
	mesresult = MES_GRP3D_CommandWrite2( MES_GRP3D_COMMANDTYPE_MAPPARAM,
					__m_pValues->m_CurrentTransparencyColor, MipmapBias );
	if( ! mesresult ){ return CFALSE; }
	__m_pValues->m_CurrentMipmapBias = (U32)MipmapBias;
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}
*/

CBOOL MES_GRP3D_SetPalette16( U32 TextureStage, U32 Bank, U32 X, U32 Y )
{
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > TextureStage );
	//MES_ASSERT( MES_GRP3D_MAX_LUT4P_BANK > Bank );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_X > X );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_Y > Y );
	//MES_ASSERT( 0 == ( X % MES_GRP3D_MAX_LUTALIGN_X ) );
	//MES_ASSERT( 0 == ( Y % MES_GRP3D_MAX_LUT4PALIGN_Y ) );

	{
		U32 page  = MES_GRP3D_POS2PAGE( X, Y );
		U32 pagex = MES_GRP3D_POS2PAGEX( X );
		U32 pagey = MES_GRP3D_POS2PAGEY( Y );
		CBOOL mesresult;
		mesresult =  MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_LUTFILL,
					(Bank << 21)|
					(page << 25)|
					(pagey << 8)|
					(pagex << 0)|
					( 0 << 17 )|
					(TextureStage << 16)
					 );
		if( ! mesresult ){ return CFALSE; }
	}
	// command buffer/queue mode�� ��� �ڵ����� LUT�� upload���ش�.
	// direct mode��� �̰��� �䳻����.
	if( CTRUE == MES_GRP3D_IsDirectMode() )
	{
		return MES_GRP3D_RunRasterizer_UpdateLUT();
	}
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

CBOOL MES_GRP3D_SetPalette256( U32 TextureStage, U32 X, U32 Y )
{
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > TextureStage );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_X > X );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_Y > Y );
	//MES_ASSERT( 0 == ( X % MES_GRP3D_MAX_LUTALIGN_X ) );
	//MES_ASSERT( 0 == ( Y % MES_GRP3D_MAX_LUT8PALIGN_Y ) );

	{
		static const U32 FULL_UPDATE = (1 << 17);
		U32 page  = (( Y >> 9 )<<1) | ( X >> 9 );
		U32 pagex = ( X & 0x1ff ) >> 1;
		U32 pagey = ( Y & 0x1ff ) >> 1;
		CBOOL mesresult;
		mesresult = MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_LUTFILL,
					(page << 25)|
					(pagey << 8)|
					(pagex << 0)|
					FULL_UPDATE |
					(TextureStage << 16)
					 );
		if( ! mesresult ){ return CFALSE; }
	}
	// command buffer/queue mode�� ��� �ڵ����� LUT�� upload���ش�.
	// direct mode��� �̰��� �䳻����.
	if( CTRUE == MES_GRP3D_IsDirectMode() )
	{
		return MES_GRP3D_RunRasterizer_UpdateLUT();
	}
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );	
}

CBOOL MES_GRP3D_SetTexture ( U32 TextureStage,      
							U32 SegmentSelector, 
							 MES_GRP3D_COLORFORMAT ColorFormat, 
							 CBOOL MipmapEnb, CBOOL TileIndexEnb,
							 MES_GRP3D_TEXTUREADDRESS TextureAddressingModeU,
							 MES_GRP3D_TEXTUREADDRESS TextureAddressingModeV,
							 U32 X, U32 Y, U32 Width, U32 Height )						 
{

	// ??? MES_GRP3D_TEXTURETYPE�� ���� ó��?
/*
	MES_DEBUG_CODE(
		U32 align_x;
		switch( ColorFormat )
		{
			case MES_GRP3D_COLORFORMAT_INDEXED4_R5G6B5	:		
			case MES_GRP3D_COLORFORMAT_INDEXED4_R4G4B4A4:			
			case MES_GRP3D_COLORFORMAT_INDEXED4_R5G5B5A1:			
			case MES_GRP3D_COLORFORMAT_INDEXED4_A8L8	:			
			case MES_GRP3D_COLORFORMAT_INDEXED4_A4R4G4B4:			
			case MES_GRP3D_COLORFORMAT_INDEXED4_A1R5G5B5:			
			case MES_GRP3D_COLORFORMAT_INDEXED4_L8A8	:			
			case MES_GRP3D_COLORFORMAT_A4				:		
			case MES_GRP3D_COLORFORMAT_L4				:
				align_x = Width/4;	
				break;		
			case MES_GRP3D_COLORFORMAT_INDEXED8_R5G6B5	:		
			case MES_GRP3D_COLORFORMAT_INDEXED8_R4G4B4A4:			
			case MES_GRP3D_COLORFORMAT_INDEXED8_R5G5B5A1:			
			case MES_GRP3D_COLORFORMAT_INDEXED8_A8L8	:			
			case MES_GRP3D_COLORFORMAT_INDEXED8_A4R4G4B4:			
			case MES_GRP3D_COLORFORMAT_INDEXED8_A1R5G5B5:			
			case MES_GRP3D_COLORFORMAT_INDEXED8_L8A8	:			
			case MES_GRP3D_COLORFORMAT_L4A4				:		
			case MES_GRP3D_COLORFORMAT_L8				:		
			case MES_GRP3D_COLORFORMAT_A8				:		
			case MES_GRP3D_COLORFORMAT_A4L4				:		
				align_x = Width/2;	
				break;		
			case MES_GRP3D_COLORFORMAT_R5G6B5			:		
			case MES_GRP3D_COLORFORMAT_R4G4B4A4			:		
			case MES_GRP3D_COLORFORMAT_R5G5B5A1			:		
			case MES_GRP3D_COLORFORMAT_A8L8				:		
			case MES_GRP3D_COLORFORMAT_A4R4G4B4			:		
			case MES_GRP3D_COLORFORMAT_A1R5G5B5			:		
			case MES_GRP3D_COLORFORMAT_L8A8				:		
		    	align_x = Width;	
				break;		
			default:			
				break;
		}
	)
*/	
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > TextureStage );
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > SegmentSelector );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_X > X );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_Y > Y );
	//MES_ASSERT( MES_GRP3D_MAX_PAGE_X >= X+align_x );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_X >= X+Width );
	MES_ASSERT( MES_GRP3D_MAX_PAGE_Y >= Y+Height );
	//MES_ASSERT( MES_GRP3D_MIN_TEX_WIDTH <= align_x );
	MES_ASSERT( MES_GRP3D_MIN_TEX_WIDTH <= Width );
	MES_ASSERT( MES_GRP3D_MIN_TEX_HEIGHT <= Height );
	MES_ASSERT( 0 == ( (Width -1) & Width  ) );
	MES_ASSERT( 0 == ( (Height-1) & Height ) );
	//MES_ASSERT( 0 == ( X % align_x ) );
	MES_ASSERT( 0 == ( X % Width ) );
	MES_ASSERT( 0 == ( Y % Height ) );
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	{
		static const MES_GRP3D_COMMANDTYPE COMMAND_TEXINFO[] =
		{
			MES_GRP3D_COMMANDTYPE_TEXINFO0,
			MES_GRP3D_COMMANDTYPE_TEXINFO1
		};
		U32 page  = MES_GRP3D_POS2PAGE( X, Y );
		U32 pagex = MES_GRP3D_POS2PAGEX( X );
		U32 pagey = MES_GRP3D_POS2PAGEY( Y );
		U32 maskx = (Width/2) - 1;
		U32 masky = (Height/2) - 1;
		/*
		printf( "** %dth Texture **\n", TextureStage );
		printf( "- Segment:0x%x, Colorformat:%d \n", SegmentSelector, ColorFormat );
		printf( "- X:%d, Y:%d, Width:%d, Height:%d\n", X, Y, Width, Height );
		*/
		return MES_GRP3D_CommandWrite2( COMMAND_TEXINFO[TextureStage],
						(SegmentSelector << 27)			|
						(page << 25)					|
						(ColorFormat << 19) 			|
						((U32)MipmapEnb << 18) 			|
						((U32)TileIndexEnb << 16) 		|
						(TextureAddressingModeU << 1) 	|
						TextureAddressingModeV,
						(masky << 24) | (maskx << 16) | (pagey << 8) | pagex
						);
	}
}

CBOOL MES_GRP3D_SetTextureBlend( U32 TextureStage, 
								MES_GRP3D_RGBARG RGBArg0, MES_GRP3D_RGBARG RGBArg1, MES_GRP3D_RGBARG RGBArg2,
								MES_GRP3D_RGBOP	RGBOp,
								MES_GRP3D_AARG AlphaArg0, MES_GRP3D_AARG AlphaArg1, MES_GRP3D_AARG AlphaArg2,
								MES_GRP3D_AOP	AlphaOp )
{
	static const MES_GRP3D_COMMANDTYPE COMMAND_TEXBLEND[] =
	{
		MES_GRP3D_COMMANDTYPE_TEXBLEND0,
		MES_GRP3D_COMMANDTYPE_TEXBLEND1
	};
	MES_ASSERT( MES_GRP3D_MAX_TEXTURE_STAGE > TextureStage );
	/*
	{
		char pname_list[2][2][16][8] = 
		{
			{
				{ "Cs", "(1-Cs)", "As", "(1-As)", "Cc", "(1-Cc)", "Ac", "(1-Ac)", "Cf", "(1-Cf)", "Af", "(1-Af)", "Cs", "(1-Cs)", "As", "(1-As)" },
				{ "As", "(1-As)", "Ac", "(1-Ac)", "Af", "(1-Af)", "As", "(1-As)",                                                                }
			},
			{
				{ "Cs", "(1-Cs)", "As", "(1-As)", "Cc", "(1-Cc)", "Ac", "(1-Ac)", "Cf", "(1-Cf)", "Af", "(1-Af)", "Cp", "(1-Cp)", "Ap", "(1-Ap)" },
				{ "As", "(1-As)", "Ac", "(1-Ac)", "Af", "(1-Af)", "Ap", "(1-Ap)",                                                                }
			}
		};
		char opname_list[][16] = { "arg0", "mul", "add", "add_signed", "intp", "sub", "dp3", "dp4" };
		printf("%dth TexBlend Mode RGB  : %s, %s, %s  (%s)\n", TextureStage, pname_list[TextureStage][0][RGBArg0  ], pname_list[TextureStage][0][RGBArg1  ], pname_list[TextureStage][0][RGBArg2  ], opname_list[RGBOp  ] );
		printf("%dth TexBlend Mode Alpha: %s, %s, %s  (%s)\n", TextureStage, pname_list[TextureStage][1][AlphaArg0], pname_list[TextureStage][1][AlphaArg1], pname_list[TextureStage][1][AlphaArg2], opname_list[AlphaOp] );	
	}
	*/
	return MES_GRP3D_CommandWrite1( COMMAND_TEXBLEND[TextureStage],
					((U32)RGBArg0<<24) |
					((U32)RGBArg1<<20) |
					((U32)RGBArg2<<16) |
					((U32)RGBOp<<12 ) |
					((U32)AlphaArg0<<9) |
					((U32)AlphaArg1<<6) |
					((U32)AlphaArg2<<3) |
					(U32)AlphaOp  );
}

CBOOL MES_GRP3D_SetAlphaFunction( U32 RefValue, MES_GRP3D_ALPHAFUNC AlphaFunction )
{
	U32 commanddata[1];
	commanddata[0] = ((U32)RefValue<<8) |
					 ((U32)AlphaFunction);
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(ALPHATEST), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
}

/*
CBOOL MES_GRP3D_SetTextureConstColor( U32 ConstColor )
{
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(TEXCONST), 1,
							   (const U32*)(&ConstColor), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
	
}
*/
CBOOL MES_GRP3D_SetTextureConstColor( U8 A, U8 R, U8 G, U8 B )
{
	U32 commanddata[1];
	commanddata[0] = ((U32)A<<24) | ((U32)R<<16) | ((U32)G<<8) | (U32)B;
	
	//printf("Const color : (%d,%d,%d,%d)\n", R, G, B, A);

	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(TEXCONST), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetPrimitiveControl( MES_GRP3D_MEMBUST LockIndex, MES_GRP3D_MEMBUST LockVertex, 
							U32 StreamValid, MES_GRP3D_INDEXTYPE IndexType, 
							CBOOL ClearCache, CBOOL LoopEnb, 
							CBOOL UseIndexEnb, CBOOL UseMatrixPaletteEnb,
							CBOOL UseGTEEnb )
{
	U32 commanddata[1];
	commanddata[0] =((U32)LockIndex<<18) |
					 ((U32)LockVertex<<16) |
					 ((U32)StreamValid<<8) |
					 ((U32)IndexType<<6) |
					 ((U32)ClearCache<<4) |
					 ((U32)LoopEnb<<3) |
					 ((U32)UseIndexEnb<<2) |
					 ((U32)UseMatrixPaletteEnb<<1) |
					 ((U32)UseGTEEnb);
					 
	if( MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(PRIMCON1), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE ) )
	{
		return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
	}
	else
		return CFALSE;
}

CBOOL MES_GRP3D_SetPrimitiveControlWithIndexPointer( MES_GRP3D_MEMBUST LockIndex, MES_GRP3D_MEMBUST LockVertex, 
							U32 StreamValid, MES_GRP3D_INDEXTYPE IndexType, 
							CBOOL ClearCache, CBOOL LoopEnb, 
							CBOOL UseIndexEnb, CBOOL UseMatrixPaletteEnb,
							CBOOL UseGTEEnb,
							unsigned int StartIndex, 
							unsigned int EndIndex )
{
	U32 commanddata[3];
	commanddata[0] =((U32)LockIndex<<18) |
					 ((U32)LockVertex<<16) |
					 ((U32)StreamValid<<8) |
					 ((U32)IndexType<<6) |
					 ((U32)ClearCache<<4) |
					 ((U32)LoopEnb<<3) |
					 ((U32)UseIndexEnb<<2) |
					 ((U32)UseMatrixPaletteEnb<<1) |
					 ((U32)UseGTEEnb);
	commanddata[1] = StartIndex;
	commanddata[2] = EndIndex;
					 
	if( MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(PRIMCON1), 3,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE ) )
	{
		return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
	}
	else
		return CFALSE;
}

CBOOL MES_GRP3D_SetVertexStream( U32 StreamIndex, const void* Addr, U32 Stride, 
						U32 DstOffset, U32 Size, MES_GRP3D_VSTYPE Type )
{
	U32 commanddata[3];
	MES_ASSERT( StreamIndex < 8 );
	//MES_ASSERT( 0 == ((U32)Addr%8) );		// ??? bit align
	
	commanddata[0] = (U32)Addr;
	commanddata[1] = Stride;
	commanddata[2] = (DstOffset<<20) | (Size<<8) | (U32)Type;
	
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(VERTEXSTREAM[StreamIndex*3]), 3,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetVertexStreams( const U32* Data, unsigned int StreamValid )
{
	//MES_ASSERT( g_Open_GRP3D );
	int offset = 0; 
	int size   = 3*8;  
	if( (StreamValid & 1   )==0 ){ offset = 3; size -= 3; }
	if( (StreamValid & 0xF8)==0      ){ size -= 15; }
	else if( (StreamValid & 0xF0)==0 ){ size -= 12; } 
	else if( (StreamValid & 0xE0)==0 ){ size -= 9; }
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(VERTEXSTREAM[0])+offset, size,
							   Data+offset, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetIndexStart( U32 Start )
{
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(IDXSTART), 1,
							   (const U32*)(&Start), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
}

CBOOL MES_GRP3D_SetIndexEnd( U32 End )
{
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(IDXEND), 1,
							   (const U32*)(&End), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );		
}

CBOOL MES_GRP3D_SetPrimitiveParamLoopControl( U32 ParamLoop, U32 ParamEnd )
{
	U32 commanddata[1];
	
	MES_ASSERT( 16 > ParamLoop );
	MES_ASSERT( 16 > ParamEnd );
	
	commanddata[0] =((U32)ParamLoop<<8) | ParamEnd;
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(PRAMLOOPCTRL), 1,
							   (const U32*)(commanddata), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
}

CBOOL MES_GRP3D_SetParamData( U32 Index, U8 Param0, U8 Param1, U8 Param2, U8 Param3 )
{
	U32 commanddata[1];
	
	MES_ASSERT( 4 > Index );	
	
	
	commanddata[0] = ((U32)Param3<<24) | ((U32)Param2<<16) | ((U32)Param1<<8) | Param0;
	
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(PPARAMS[Index]), 1,
							   (const U32*)(commanddata), MES_GRP3D_WAIT_ALLIDLE, 
							   CFALSE );					
}

/*
CBOOL MES_GRP3D_SetParamData( U32 PrimitiveIndex, CBOOL RectanbleEnb, CBOOL InverseCullingEnb, U32 VertexNum )
{
	U32 row, col;
	U32 data;
	
	MES_ASSERT( 16 > PrimitiveIndex );	
	MES_ASSERT( 4 > VertexNum );
	
	row = PrimitiveIndex/4;
	col = PrimitiveIndex%4;
	
	data = ((U32)RectanbleEnb<<3) | ((U32)InverseCullingEnb<<2) | VertexNum;
	
	__m_pValues->m_CurrentPrimitiveParamDatas[row] &= ~(0xFF<<(col*8));
	__m_pValues->m_CurrentPrimitiveParamDatas[row] |= (data<<(col*8));
	
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(PPARAMS[row]), 1,
							   (const U32*)(&(__m_pValues->m_CurrentPrimitiveParamDatas[row])), 
							   MES_GRP3D_WAIT_ALLIDLE, CFALSE );					
}
*/


CBOOL MES_GRP3D_RegisterFill ( U32 RegisterOffset32, U32 NumberOfData32,
							   const U32* pData32, U32 WaitFalg,
							   CBOOL InterruptRequest )
{
	static const U32 WAIT_XOR_MASK  = 0xE000;
	MES_DEBUG_CODE (
		static const U32 WAIT_VALID_MASK= 0xFFFF0FFF;
		static const U32 REGFILL_MINADDR	 = (0x0020/4);
		static const U32 REGFILL_MAXADDR	 = (0x2000/4)-1;
		static const U32 REGFILL_MINDATA	 = 1;
		static const U32 REGFILL_MAXDATA	 = ((0x2000/4)-(0x0020/4));
	)
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;

	MES_ASSERT( REGFILL_MINADDR <= RegisterOffset32 );
	MES_ASSERT( REGFILL_MAXADDR >= RegisterOffset32 );
	MES_ASSERT( REGFILL_MINDATA <= NumberOfData32 );
	MES_ASSERT( REGFILL_MAXDATA >= NumberOfData32 );
	MES_ASSERT( pData32 );
	MES_ASSERT( 0 == ( WaitFalg & WAIT_VALID_MASK ) );

	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   RegisterOffset32,
							   NumberOfData32+1 );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	// command buffer/queue mode��� regfill command�� header��
	// ����� �־�� �Ѵ�.
	if( CFALSE == MES_GRP3D_IsDirectMode() )
	{
		pCMD_BUFFER[0] = MES_GRP3D_CMD_PARAM_LIST[MES_GRP3D_COMMANDTYPE_REGFILL].uID |
						((NumberOfData32-1)<<16) |
						(WaitFalg^WAIT_XOR_MASK) |
						RegisterOffset32 |
						((U32)InterruptRequest<<11) |
						__m_pValues->m_CullingEnable;
		pCMD_BUFFER++;
	}
	
	{
		U32 i;
		U32* pbackupregister = ((U32*)(&__m_pValues->m_BackupRegister)) + RegisterOffset32;
		for( i=0; i<NumberOfData32; i++ )
		{
			pCMD_BUFFER[i] = pbackupregister[i] = pData32[i];
		}
	}
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}
								                            	 
                            	 							 
CBOOL MES_GRP3D_InterruptNop( void )
{
	const U32 NOP_CODE = ( 4UL<<28)|4;
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(CONTROL), 1,
							   (const U32*)(&NOP_CODE), MES_GRP3D_WAIT_ALLIDLE,
							   CTRUE );
}

CBOOL MES_GRP3D_SetFogColor( U32 FogColor )
{
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(FOGCOLOR), 1,
							   (const U32*)(&FogColor), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetFogMaxZ( float Zmax )
{
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(FOGMAXZ), 1,
							   (const U32*)(&Zmax), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetFogTable( const U16* pFogTable )
{
	MES_ASSERT( pFogTable );
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(FOGTBL[0]), 32,
							   (const U32*)pFogTable, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

void MES_GRP3D_SetLinearFog ( float Zmin, float Zmax )
{
	MES_DEBUG_CODE( const float MAX_ZVALUE = 65535.0f; )
	U16 fogtable[64];
	long index;
	float t, dt;

	MES_ASSERT( 0.0f <= Zmin );
	MES_ASSERT( Zmin < Zmax );
	MES_ASSERT( MAX_ZVALUE > Zmax );

	t = 0;
	dt = Zmax/63.0f;
	for( index = 0; index<64; index++ )
	{
		if( t<=Zmin )		fogtable[index] = 0;
		else if( t>=Zmax )	fogtable[index] = 255;
		else
		{
			fogtable[index] = (U16)(255*(t-Zmin)/(Zmax-Zmin));
			MES_ASSERT( (1<<8) > fogtable[index] );
		}
		t += dt;
	}

	for( index = 0; index<63; index++ )
	{
		int f0	= fogtable[index];
		int f1	= fogtable[index+1];
		int df	= (f1-f0)>>2;
		MES_ASSERT( (1<<8) > df );
		fogtable[index] = (U16)(fogtable[index] | (df<<8) );
	}

	MES_GRP3D_SetFogTable( fogtable );
	MES_GRP3D_SetFogMaxZ( Zmax );
}

CBOOL MES_GRP3D_Flip( U32 Segment, U8 TableX, U8 TableY,
                    CBOOL WaitSync, CBOOL IgnoreField, CBOOL FSAAEnb )
{
	U32 commanddata[1];
	U32 WaitFlag = MES_GRP3D_WAIT_ALLIDLE;

	commanddata[0] = ((U32)FSAAEnb << 27) |
					 ((U32)Segment << 16) |
					 (((U32)TableY) << 8) | (U32)TableX;
	if( WaitSync )
	{
		WaitFlag |= MES_GRP3D_WAIT_VSYNC;
	}
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(DISPINFO), 1,
							   (const U32*)commanddata, WaitFlag,
							   CFALSE );
}
                    
CBOOL MES_GRP3D_FillRectangle( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                    U32 Segment, U32 X, U32 Y, U32 Width, U32 Height,
                    U16 R5G6B5 )
{
	U32 commanddata[3];
	MES_ASSERT( MES_GRP3D_SEGMENT_WIDTH > X );
	MES_ASSERT( MES_GRP3D_SEGMENT_HEIGHT > Y );
	MES_ASSERT( 0 < Width );
	MES_ASSERT( 0 < Height );
	MES_ASSERT( MES_GRP3D_SEGMENT_WIDTH > X + Width - 1 );
	MES_ASSERT( MES_GRP3D_SEGMENT_HEIGHT > Y + Height - 1 );

	commanddata[0] = ((U32)BlockAddressMode << 27) |
					 (Segment << 16) | R5G6B5;
	commanddata[1] = (Y << 16) | X;
	commanddata[2] = ((Y + Height - 1) << 16) |
					 (X + Width - 1);

	{
		CBOOL mesresult;
		mesresult = MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(MFILLPARAM0), 3,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
		if( ! mesresult ){ return mesresult; }
	}
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
						  MES_GRP3D_MODULEID_RASTERIZER | MES_GRP3D_RASTMODE_MEMFILL | __m_pValues->m_CullingTestEnable );
}

CBOOL MES_GRP3D_SetRenderTarget( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                            U32 Segment, U8 TableX, U8 TableY,
                            U32 ScissorRect_X, U32 ScissorRect_Y,
                            U32 ScissorRect_Width, U32 ScissorRect_Height,
                            CBOOL FSAAEnb )
{
	U32 commanddata[3];

	MES_ASSERT( MES_GRP3D_SEGMENT_WIDTH > ScissorRect_X );
	MES_ASSERT( MES_GRP3D_SEGMENT_HEIGHT > ScissorRect_Y );
	//MES_ASSERT( 0 <= ScissorRect_Width );
	//MES_ASSERT( 0 <= ScissorRect_Height );
	MES_ASSERT( MES_GRP3D_SEGMENT_WIDTH > ScissorRect_X + ScissorRect_Width - 1 );
	MES_ASSERT( MES_GRP3D_SEGMENT_HEIGHT > ScissorRect_Y + ScissorRect_Height - 1 );

	if( FSAAEnb )
	{
		ScissorRect_X <<= 1;
		ScissorRect_Y <<= 1;
		ScissorRect_Height <<= 1;
		ScissorRect_Width <<= 1;
	}

	commanddata[0] = ((U32)FSAAEnb << 28) |
					 ((U32)BlockAddressMode << 27) |
					 ((U32)Segment << 16) |
					 ((U32)TableY << 8) | (U32)TableX;
	commanddata[1] = (ScissorRect_Y << 16) | ScissorRect_X;
	commanddata[2] = ((ScissorRect_Y + ScissorRect_Height - 1) << 16) |
					 (ScissorRect_X + ScissorRect_Width - 1);
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(RENDTRG0), 3,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}
                    
 
 CBOOL MES_GRP3D_SetZBuffer( MES_GRP3D_BLOCKADDRESSMODE BlockAddressMode,
                       U32 Segment, U8 TableX, U8 TableY,
                       MES_GRP3D_CMPFUNC ZFunc )
{
	U32 commanddata[1];
	commanddata[0] = ((U32)ZFunc<<28) |
					 ((U32)BlockAddressMode<<27) |
					 ((U32)Segment<<16) |
					 ((U32)TableY<<8) | (U32)TableX;
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(ZBINFO), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}
 
CBOOL MES_GRP3D_SetZValidBuffer( CBOOL ZV_Enb,
								 U32 ZV_X, U32 ZV_Y, U16 ZV_Value )
{
	U32 commanddata[1];
	MES_ASSERT( MES_GRP3D_SEGMENT_WIDTH > ZV_X );
	MES_ASSERT( MES_GRP3D_SEGMENT_HEIGHT > ZV_Y );
	MES_ASSERT( 0 == ( ZV_X % (1UL << MES_GRP3D_ZV_SHIFT_X) ) );
	MES_ASSERT( 0 == ( ZV_Y % (1UL << MES_GRP3D_ZV_SHIFT_Y) ) );

	commanddata[0] = ((U32)ZV_Enb << 24) |
					 (((U32)ZV_Y >> MES_GRP3D_ZV_SHIFT_Y) << 21) |
					 (((U32)ZV_X >> MES_GRP3D_ZV_SHIFT_X) << 16) |
					 ((U32)ZV_Value);
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(ZVBINFO), 1,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );	
}
								 
CBOOL MES_GRP3D_SetZScale( float Z_Max )
{
	MES_ASSERT( Z_Max <= MES_GRP3D_MAX_ZVALUE );
	MES_ASSERT( Z_Max >= MES_GRP3D_MIN_ZVALUE );
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(ZSCALE), 1,
							   (const U32*)(&Z_Max), MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

/*
CBOOL MES_GRP3D_SetVertexFormat( U32 Fixed32_Resolution,
                            	 U32 Fixed16_Resolution,
	                             U32 Fixed8_Resolution,
	                             MES_GRP3D_VertexFormat* pVertexFormat )
{
	U32 commanddata[5];
	MES_ASSERT( Fixed32_Resolution<=0x1f );
	MES_ASSERT( Fixed16_Resolution<=0x1f );
	MES_ASSERT( Fixed8_Resolution<=0x1f );

	commanddata[0] = (Fixed32_Resolution << 10) |
					 (Fixed16_Resolution << 5) |
					 (Fixed8_Resolution);
	commanddata[1] = ((U32*)pVertexFormat)[0];
	commanddata[2] = ((U32*)pVertexFormat)[1];
	commanddata[3] = ((U32*)pVertexFormat)[2];
	commanddata[4] = ((U32*)pVertexFormat)[3];

	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(VBFIXED), 5,
							   (const U32*)commanddata, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}
*/

CBOOL MES_GRP3D_SetViewport( float X, float Y, float Width, float Height )
{
	float viewport[4];
	//MES_ASSERT( 0 <= X );
	//MES_ASSERT( 0 <= Y );
	MES_ASSERT( 0 <= Width );
	MES_ASSERT( 0 <= Height );
	viewport[0] = (float)( Y+Height-0.5f );
	viewport[1] = (float)( Height );
	viewport[2] = (float)( X-0.5f );
	viewport[3] = (float)( Width );

	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(VPORTBOT), 4,
							   (const U32*)viewport, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}
/*
CBOOL MES_GRP3D_SetGTECode( const U32* pCodeList, U32 CodeSize32 )
{
	return MES_GRP3D_SetGTECode ( pCodeList, 0, CodeSize32 );
}
*/

CBOOL MES_GRP3D_SetGTECode( const U32* pCodeList, U32 CodeBase32, U32 CodeSize32 )
{
	MES_DEBUG_CODE( const U32 MAX_GTE_CODESIZE = 512; )
	MES_ASSERT( pCodeList );
	MES_ASSERT( 0 < CodeSize32 );
	MES_ASSERT( MAX_GTE_CODESIZE >= CodeBase32+CodeSize32 );
	/*
	{
		unsigned int i;	
		printf( "CodeBase : 0x%x, CodeSize : 0x%x \n", CodeBase32, CodeSize32 );	
		for( i = 0; i < CodeSize32; i++ )
			printf( "0x%x  \n", pCodeList[i]);		
	}
	*/
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(GTECODE[0])+CodeBase32, CodeSize32,
							   (const U32*)pCodeList, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetGTEConst( U32 Index, U32 NumberOfValue,
							 const float* pValueList )
{
	MES_DEBUG_CODE( const U32 MAX_GTE_CONST = 252*4; )
	MES_ASSERT( MAX_GTE_CONST > Index );
	MES_ASSERT( 0 < NumberOfValue );
	MES_ASSERT( MAX_GTE_CONST >= Index + NumberOfValue );
	MES_ASSERT( pValueList );
	/*
	{
		int i;	
		printf( "Index : 0x%x, NumberOfValue : %d \n", Index, NumberOfValue );	
		for( i = 0; i < NumberOfValue; i++ )
		{
			printf( "%f\t", pValueList[i]);
			if( i%4 == 3)
				printf("\n");
		}	
	}
	*/	
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(GTECONST[0])+Index, NumberOfValue,
							   (const U32*)pValueList, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}

CBOOL MES_GRP3D_SetGTEConsts( U32 Count, U32* pData )
{
	U32
		i;
	CBOOL result = CTRUE;
	//MES_DEBUG_CODE( const U32 MAX_GTE_CONST = 252*4; )
	//MES_ASSERT( MAX_GTE_CONST > Index );
	//MES_ASSERT( 0 < NumberOfValue );
	//MES_ASSERT( MAX_GTE_CONST >= Index + NumberOfValue );
	//MES_ASSERT( pValueList );

	for( i = 0; i < Count; i++ )
	{
		result &= MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(GTECONST[0])+pData[i*3+0], pData[i*3+1],
								   (const U32*)(pData[i*3+2]), MES_GRP3D_WAIT_ALLIDLE,
								   CFALSE );
	}
	return result;
}

CBOOL MES_GRP3D_SetTSEInput ( U32 Index, U32 NumberOfValue,
							  const float* pValueList )
{
	MES_DEBUG_CODE( const U32 MAX_TSE_INPUT = 32+12; )
	MES_ASSERT( MAX_TSE_INPUT > Index );
	MES_ASSERT( 0 < NumberOfValue );
	MES_ASSERT( MAX_TSE_INPUT >= Index + NumberOfValue );
	MES_ASSERT( pValueList );
	return MES_GRP3D_RegisterFill ( MES_GRP3D_REGOFFSET(TSEINPUT[0])+Index, NumberOfValue,
							   (const U32*)pValueList, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE );
}
							                  
unsigned __int64 MES_GRP3D_GetFrontOfCommandQueue( void )
{
	switch(__m_pValues->m_GRP3DControlMode)
	{
	case MES_GRP3D_CONTROLMODE_DIRECT:
	case MES_GRP3D_CONTROLMODE_BUFFER:
		return 0;
	case MES_GRP3D_CONTROLMODE_QUEUE:
		return __m_pValues->m_CommandQueueFrontPointer;
	default:
		return 0;
	}
}

unsigned __int64 MES_GRP3D_GetRearOfCommandQueue( void )
{
	const U32 IDLE_MASK = 0x00BF0000;
	
	switch(__m_pValues->m_GRP3DControlMode)
	{
	case MES_GRP3D_CONTROLMODE_DIRECT:
		while( (__g_pRegister->STATUS & IDLE_MASK) != IDLE_MASK ) {}
		return 1;

	case MES_GRP3D_CONTROLMODE_BUFFER:
		return 1;

	case MES_GRP3D_CONTROLMODE_QUEUE:
		return ((unsigned __int64)(__m_pValues->m_CommandQueueFrontPointer - 
			(( ((unsigned __int64)__m_pValues->m_CommandQueueSize32<<2) + __g_pRegister->CMDQFRONT - __g_pRegister->CMDQREAR)%(__m_pValues->m_CommandQueueSize32<<2))));
	default:
		return 0;
	}
}

void MES_GRP3D_SetVolumeCullingState ( MES_GRP3D_VOLUMECULLSTATE State )
{
	__m_pValues->m_VolumeCullingState = State;
	switch( State )
	{
	case MES_GRP3D_VOLUMECULLSTATE_NONE    :
		__m_pValues->m_CullingEnable = 0;
		__m_pValues->m_CullingTestEnable=0;
		MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP );
		break;
	case MES_GRP3D_VOLUMECULLSTATE_TEST    :
		__m_pValues->m_CullingEnable = 0;
		__m_pValues->m_CullingTestEnable = (1<<11);
		MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP | (3<<11) );
		break;
	case MES_GRP3D_VOLUMECULLSTATE_CULLING :
		__m_pValues->m_CullingEnable = (1UL<<27);
		__m_pValues->m_CullingTestEnable = 0;
		break;
	default:
		//MES_ASSERT();
		break;
	}
}

CBOOL MES_GRP3D_SetLastError( MES_GRP3D_ERR Error )
{
	__m_pValues->m_LastError = Error;
	return ( MES_GRP3D_ERR_NONE == __m_pValues->m_LastError );
}

/*
void MES_GRP3D_Render_TLVERTEX( const MES_GRP3D_SimpleRenderVertex *pv0,
					  const MES_GRP3D_SimpleRenderVertex *pv1,
					  const MES_GRP3D_SimpleRenderVertex *pv2 )
{
	
}
					  
void MES_GRP3D_Render_VERTEX( const MES_GRP3D_SimpleRenderVertex *pv0,
					const MES_GRP3D_SimpleRenderVertex *pv1,
					const MES_GRP3D_SimpleRenderVertex *pv2 )
{
	
}
					
void MES_GRP3D_Render_RECT( const MES_GRP3D_SimpleRenderVertex *pv0,
				  const MES_GRP3D_SimpleRenderVertex *pv1 )
{
	
}
				  
*/

//------------------------------------------------------------------------------
// brief   command�� ����� �������� �ּҸ� ���´�.
// remarks direct mode������ ȣ�Ⱑ��.
//			 BeginCommand_Direct/EndCommand_Direct�� ������ ȣ��Ǿ�� �ϸ�,
//			 ��ø�Ǿ� ȣ��� �� ����.
//------------------------------------------------------------------------------
CBOOL /// @return ����/���и� ��ȯ. ���н� GetLastError ����.
MES_GRP3D_BeginCommand_Direct
(
	MES_GRP3D_PCMD* ppCMD,			///< [out] �������� �ּҸ� ���� ������ ������.
	U32 RegisterOffset32,	///< [in] ������ϴ� ���������� offset. 32bit ����.
	U32 ReserveSize32		///< [in] ������ ����.
)
{
	MES_ASSERT( ppCMD );
	MES_ASSERT( MES_GRP3D_REGFILL_MINADDR <= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXADDR >= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MINDATA <= ReserveSize32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXDATA >= ReserveSize32 );

	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( ! __m_pValues->m_CommandOpenFlag );

	{
		U32 utimeoutcounter = 0;
		while( MES_GRP3D_CheckBusy() )
		{
			MES_GRP3D_CHECK_TIMEOUT( utimeoutcounter );
		}
	}
	(*ppCMD) = ((MES_GRP3D_PCMD)(__g_pRegister))+RegisterOffset32;
	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CTRUE );
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}
//------------------------------------------------------------------------------
// brief   command�� �� ��������� �˸���.
// remarks BeginCommand_Direct/EndCommand_Direct�� ������ ȣ��Ǿ�� �ϸ�,
//			 ��ø�Ǿ� ȣ��� �� ����.
//------------------------------------------------------------------------------
void
MES_GRP3D_EndCommand_Direct(void)
{
	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( __m_pValues->m_CommandOpenFlag );
	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CFALSE );
}



//------------------------------------------------------------------------------
// brief   command�� ����� �޸𸮸� command buffer���� �Ҵ��Ѵ�.
// remarks command buffer mode������ ȣ�Ⱑ��.
//			 BeginCommand_CommandBuffer/EndCommand_CommandBuffer�� ������
//			 ȣ��Ǿ�� �ϸ�, ��ø�Ǿ� ȣ��� �� ����.
//------------------------------------------------------------------------------
CBOOL /// @return ����/���и� ��ȯ. ���н� GetLastError ����.
MES_GRP3D_BeginCommand_CommandBuffer
(
	MES_GRP3D_PCMD* ppCMD,			///< [out] �Ҵ�� �޸� �ּҸ� ���� ������ ������.
	U32 RegisterOffset32,	///< [in] ������ ����.
	U32 ReserveSize32 		///< [in] �Ҵ��� �޸� ������ ũ��. 32bit ����.
)
{
	MES_ASSERT( ppCMD );
	MES_ASSERT( MES_GRP3D_REGFILL_MINADDR <= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXADDR >= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MINDATA <= ReserveSize32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXDATA >= ReserveSize32 );

	MES_ASSERT( __m_pValues->m_CommandBufferPointer );
	MES_ASSERT( MES_GRP3D_MIN_COMMANDQUEUE_SIZE*2 < __m_pValues->m_CommandBufferSize32 );
	MES_ASSERT( __m_pValues->m_CommandBufferPos32 <= __m_pValues->m_CommandBufferSize32 );

	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( ! __m_pValues->m_CommandOpenFlag );

	{
		U32 newbufferpos32 = __m_pValues->m_CommandBufferPos32 + ReserveSize32;
		if( newbufferpos32 > __m_pValues->m_CommandBufferSize32 )
		{
			MES_ASSERT( ! "ERROR in GRP3D : ERR_BUFFEROVERFLOW" );
			return MES_GRP3D_SetLastError( MES_GRP3D_ERR_BUFFEROVERFLOW );
		}
		(*ppCMD) = __m_pValues->m_CommandBufferPointer + __m_pValues->m_CommandBufferPos32;
		__m_pValues->m_CommandBufferPos32 = newbufferpos32;
	}
	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CTRUE );
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

//------------------------------------------------------------------------------
// brief   command�� �� ��������� �˸���.
// remarks command buffer mode������ ȣ�Ⱑ��.\n
//			 BeginCommand_CommandBuffer/EndCommand_CommandBuffer�� ������
//			 ȣ��Ǿ�� �ϸ�, ��ø�Ǿ� ȣ��� �� ����.
//------------------------------------------------------------------------------
void
MES_GRP3D_EndCommand_CommandBuffer(void)
{
	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( __m_pValues->m_CommandOpenFlag );
	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CFALSE );
}

//------------------------------------------------------------------------------
// brief   command�� ����� �޸𸮸� command queue���� �Ҵ��Ѵ�.
// remarks command queue mode������ ȣ�Ⱑ��.\n
//			 BeginCommand_CommandQueue/EndCommand_CommandQueue�� ������
//			 ȣ��Ǿ�� �ϸ�, ��ø�Ǿ� ȣ��� �� ����.\n
//			 ��ȯ�Ǵ� �޸𸮴� ������ ���� Ư¡�� ���´�.\n
//				���� ����(random access) ����	\n
//				linear address					\n
//			 	ReserveSize32 * 4 bytes
//------------------------------------------------------------------------------
CBOOL /// @return ����/���и� ��ȯ. ���н� GetLastError ����.
MES_GRP3D_BeginCommand_CommandQueue
(
	MES_GRP3D_PCMD* ppCMD,			///< [out] �Ҵ�� �޸� �ּҸ� ���� ������ ������.
	U32  RegisterOffset32,	///< [in] ������ ����.
	U32 ReserveSize32 		///< [in] �Ҵ��� �޸� ������ ũ��. 32bit ����.
)
{

	// NOP_CODE = (CMDID_CONTROL|MODULEID_NOP)
	static const U32 NOP_CODE = ( 4UL<<28)|4;
	U32 utimeoutcounter=0;
	MES_ASSERT( ppCMD );
	MES_ASSERT( MES_GRP3D_REGFILL_MINADDR <= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXADDR >= RegisterOffset32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MINDATA <= ReserveSize32 );
	MES_ASSERT( MES_GRP3D_REGFILL_MAXDATA >= ReserveSize32 );

	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( ! __m_pValues->m_CommandOpenFlag );

	// ReserveCommandQueue( ppCMD, ReserveSize32 );
	{
		U32 CurFront = __g_pRegister->CMDQFRONT;
		U32 NewFront;

		MES_ASSERT( ReserveSize32 + 2 < __m_pValues->m_CommandQueueSize32 );

		NewFront = CurFront + (ReserveSize32 * 4);
		// �����ּ� ���������� ����ϱ����ؼ� queue�� ���κ���
		// Ȯ���� ������ ���Ե��� �ʵ��� �ؾ���.
		// ���� Queue�� Front���� End���� ������ ���ġ �ʴٸ� nop�� ä��������,
		// Start���� �ٽ� ����Ȯ���� �õ��Ѵ�.
		//                            Front   NewFront
		//                              |         |
		//	  x-------------------------+----x----+
		//	Start                           End
		if( __g_pRegister->CMDQEND < NewFront )
		{
			//  [Wait]
			// front�� rear���̿� end�� �����ִ� ���,
			// rear�� end�� ����ĥ������ ���.
			//                 Front Rear->
			//                   |    |
			//	  x--------------+----+----------x
			//	Start                           End
			while( __g_pRegister->CMDQREAR > CurFront )
			{
				MES_GRP3D_CHECK_TIMEOUT( utimeoutcounter );
			}

			//  [Fill nop]
			//       Rear      Front
			//        |          |------nop------|
			//	  x---+----------+---------------x
			//	Start                           End
			while( __g_pRegister->CMDQREAR ==
					__g_pRegister->CMDQSTART )
			{
				MES_ASSERT( __g_pRegister->CMDQREAR <= CurFront );
				MES_GRP3D_CHECK_TIMEOUT( utimeoutcounter );
			}
			//while( m_pRegister->CMDQEND >= CurFront )
			while( CTRUE )
			{
				MES_GRP3D_PCMD nextFront;
				MES_ASSERT( (CurFront & 3) == 0 );
				((MES_GRP3D_PCMD)(CurFront + __m_pValues->m_CommandQueue_VirtualOffset))[0] = NOP_CODE;
				nextFront = ((MES_GRP3D_PCMD)CurFront) + 1;
				MES_ASSERT( ((MES_GRP3D_PCMD)(CurFront + __m_pValues->m_CommandQueue_VirtualOffset))[0] == NOP_CODE );
				MES_ASSERT( __g_pRegister->CMDQREAR <= CurFront );
				MES_ASSERT( __g_pRegister->CMDQREAR >
							__g_pRegister->CMDQSTART );
				if( __g_pRegister->CMDQEND < (U32)nextFront )
				{
					//  [Set Front]
					// Front Rear
					//    |   |          |------nop------|
					//	  x---+----------+---------------x
					//	Start                           End
					CurFront = __g_pRegister->CMDQSTART;
					break;
				}
				else
				{
					CurFront = (U32)nextFront;
				}
				MES_GRP3D_CHECK_TIMEOUT( utimeoutcounter );
			}
			MES_ASSERT( __g_pRegister->CMDQSTART == CurFront );

			// CPU�� command queue�� ����� ���� ������ memory�� ��ϵ� ��
			// front pointer�� ������ �־�� �Ѵ�.
			// MCU�� �ִ� CPU request FIFO�� Flush�ϱ�����
			// command buffer�� read�� �����Ѵ�.
			// command buffer�� cache������ ������ �����ϴ� �����̴�.
			{
				volatile U32 flush_read =
						((MES_GRP3D_PCMD)(__g_pRegister->CMDQSTART + __m_pValues->m_CommandQueue_VirtualOffset))[0];
				flush_read = flush_read; // 2004/10/07 Gamza �������
			 }
			//pThis->m_pRegister->CMDQFRONT = CurFront; // �Ʒ����� ��ü.
			//__m_pValues->m_CommandQueueFrontPointer += ((unsigned int)(CurFront - __g_pRegister->CMDQFRONT)&0xFFFFFFFF);	// ������ �縸ŭ +
			__m_pValues->m_CommandQueueFrontPointer += (( ((unsigned __int64)__m_pValues->m_CommandQueueSize32<<2) + CurFront - __g_pRegister->CMDQFRONT)%(__m_pValues->m_CommandQueueSize32<<2));// ������ �縸ŭ +
			__g_pRegister->CMDQFRONT = CurFront;

			NewFront = CurFront + (ReserveSize32 * 4);
		}
		MES_ASSERT( __g_pRegister->CMDQFRONT == CurFront );
		MES_ASSERT( (CurFront & 3) == 0 );
		MES_ASSERT( (NewFront & 3) == 0 );
		MES_ASSERT( __g_pRegister->CMDQEND >= NewFront );
		MES_ASSERT( __g_pRegister->CMDQSTART <= NewFront );

		// ����Ȯ���� �õ��Ѵ�.
		// queue�� �ʿ��� ������ ���涧���� ���.
		//            Front Rear NewFront
		//              |    |       |
		//	  x---------+----+-------+-------x
		//	Start                           End
		// ���ǹ��� �Է��� �Ǵ� CMDQREAR�� ���� �ٸ��� �ִ�
		//while( m_pRegister->CMDQREAR > CurFront && m_pRegister->CMDQREAR <= NewFront )
		while( CTRUE )
		{
			volatile U32 currear = __g_pRegister->CMDQREAR;
			if( currear <= CurFront ){ break; }
			if( currear  > NewFront ){ break; }
			MES_GRP3D_CHECK_TIMEOUT( utimeoutcounter );
		}

		__m_pValues->m_CommandQueueClosePoint	=(MES_GRP3D_PCMD)NewFront;
		(*ppCMD) = (MES_GRP3D_PCMD)(CurFront + __m_pValues->m_CommandQueue_VirtualOffset);
	}

	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CTRUE );
	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}
//------------------------------------------------------------------------------
// brief   command�� �� ��������� �˸���.
// remarks command queue mode������ ȣ�Ⱑ��.\n
//			 BeginCommand_CommandQueue/EndCommand_CommandQueue�� ������
//			 ȣ��Ǿ�� �ϸ�, ��ø�Ǿ� ȣ��� �� ����.
//-----------------------------------------------------------------------------
void
MES_GRP3D_EndCommand_CommandQueue(void)
{
	U32 curFront;
	MES_ASSERT( MES_GRP3D_CHECK_INVALID_COMMAND );
	MES_ASSERT( __m_pValues->m_CommandOpenFlag );

	MES_ASSERT( __g_pRegister->CMDQFRONT <
					((U32)__m_pValues->m_CommandQueueClosePoint) );
	MES_ASSERT( __g_pRegister->CMDQEND >=
					((U32)__m_pValues->m_CommandQueueClosePoint) );
	// ù��°�� ������ �����ѵ� rear�� start point�� ���ư���
	// �ι�° ������ �����ϴ� ��찡 �ִ�.
	// ������ rear�� �ѹ� �о assertion�� �ϴ� �ڵ�� �������.
	//MES_ASSERT( pThis->m_pRegister->CMDQREAR <= pThis->m_pRegister->CMDQFRONT
	//			|| pThis->m_pRegister->CMDQREAR >
	//				((U32)pThis->m_CommandQueueClosePoint) );
	MES_DEBUG_CODE({
		volatile U32 rear  = __g_pRegister->CMDQREAR;
		volatile U32 front = __g_pRegister->CMDQFRONT;
		volatile U32 newfront = ((U32)__m_pValues->m_CommandQueueClosePoint);
		MES_ASSERT( rear <= front || rear > newfront );
	});
	MES_ASSERT( 0 == ((U32)(__m_pValues->m_CommandQueueClosePoint)&3) );

	// CPU�� command queue�� ����� ���� ������ memory�� ��ϵ� ��
	// front pointer�� ������ �־�� �Ѵ�.
	// MCU�� �ִ� CPU request FIFO�� Flush�ϱ�����
	// command buffer�� read�� �����Ѵ�.
	// command buffer�� cache������ ������ �����ϴ� �����̴�.
	{
		volatile U32 flush_read =
				((MES_GRP3D_PCMD)(__g_pRegister->CMDQSTART + __m_pValues->m_CommandQueue_VirtualOffset))[0];
		flush_read = flush_read; // 2004/10/07 Gamza �������
	 }

	//pThis->m_pRegister->CMDQFRONT = (U32)(pThis->m_CommandQueueClosePoint);
	curFront = (U32)(__m_pValues->m_CommandQueueClosePoint);
	//__m_pValues->m_CommandQueueFrontPointer += ((unsigned int)(curFront - __g_pRegister->CMDQFRONT )&0xFFFFFFFF);	// ������ �縸ŭ +
	__m_pValues->m_CommandQueueFrontPointer += (( ((unsigned __int64)__m_pValues->m_CommandQueueSize32<<2) + curFront - __g_pRegister->CMDQFRONT)%(__m_pValues->m_CommandQueueSize32<<2));// ������ �縸ŭ +
	__g_pRegister->CMDQFRONT = curFront;

	MES_DEBUG_CODE( __m_pValues->m_CommandOpenFlag = CFALSE );
}


// ???
void MES_GRP3D_ResetCommandSystem( void )
{
	__m_pValues->m_GRP3DControlMode = MES_GRP3D_CONTROLMODE_DIRECT;
	__m_pValues->m_TimeOutValue = 0xFFFFFFFF;

	__m_pValues->m_CommandBufferPointer = CNULL;
	__m_pValues->m_CommandBufferSize32  = 0;
	__m_pValues->m_CommandBufferPos32   = 0;

	__m_pValues->m_CommandQueueClosePoint = CNULL;
	__m_pValues->m_CommandQueueSize32     = 0;
	__m_pValues->m_CommandQueue_VirtualOffset = 0;

	MES_DEBUG_CODE (
		__m_pValues->m_CommandOpenFlag = CFALSE;
	)
	MES_GRP3D_CurrentBeginCommand = &MES_GRP3D_BeginCommand_Direct;
	MES_GRP3D_CurrentEndCommand   = &MES_GRP3D_EndCommand_Direct;
}

CBOOL MES_GRP3D_IsDirectMode( void )
{
	if( MES_GRP3D_CONTROLMODE_DIRECT == __m_pValues->m_GRP3DControlMode ){ return CTRUE; }
	return CFALSE;	
}

CBOOL MES_GRP3D_BeginCommand( MES_GRP3D_PCMD* ppCMD,
					U32 RegisterOffset32, U32 ReserveSize32 )
{
	return MES_GRP3D_CurrentBeginCommand( ppCMD, RegisterOffset32, ReserveSize32 );
	//return CFALSE;
}

void MES_GRP3D_EndCommand( void )
{
	MES_GRP3D_CurrentEndCommand();
}

CBOOL
MES_GRP3D_RunRasterizer_UpdateLUT( void )
{
	return MES_GRP3D_CommandWrite1( MES_GRP3D_COMMANDTYPE_CONTROL,
						  MES_GRP3D_MODULEID_RASTERIZER | MES_GRP3D_RASTMODE_LUTFILL | __m_pValues->m_CullingTestEnable );
}


//------------------------------------------------------------------------------
/// @brief   send command that it's size is 1 x 32bit
/// @return	 if success, return CTURE. if failed, refer to GetLastError().
//------------------------------------------------------------------------------
CBOOL
MES_GRP3D_CommandWrite1
(
	MES_GRP3D_COMMANDTYPE CommandType,	///< [in] command type
	U32 Data					///< [in] command data
)
{
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;
	U32* pbackupregister = ((U32*)(&__m_pValues->m_BackupRegister)) + MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32;

	MES_ASSERT( MES_GRP3D_END_OF_COMMANDTYPE > CommandType );
	MES_ASSERT( 1 == MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	MES_ASSERT( 0 == (Data & MES_GRP3D_CMD_ID_MASK) );

	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	pCMD_BUFFER[0] = pbackupregister[0] = MES_GRP3D_CMD_PARAM_LIST[CommandType].uID | Data | __m_pValues->m_CullingEnable;
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

//------------------------------------------------------------------------------
/// @brief   send command that it's size is 2 x 32bit
/// @return	 if success, return CTURE. if failed, refer to GetLastError().
//------------------------------------------------------------------------------
CBOOL
MES_GRP3D_CommandWrite2
(
	MES_GRP3D_COMMANDTYPE CommandType,	///< [in] command type
	U32 Data0,					///< [in] command data0
	U32 Data1					///< [in] command data1
)
{
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;
	U32* pbackupregister = ((U32*)(&__m_pValues->m_BackupRegister)) + MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32;

	MES_ASSERT( MES_GRP3D_END_OF_COMMANDTYPE > CommandType );
	MES_ASSERT( 2 == MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	MES_ASSERT( 0 == (Data0 & MES_GRP3D_CMD_ID_MASK) );

	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	pCMD_BUFFER[0] = pbackupregister[0] = MES_GRP3D_CMD_PARAM_LIST[CommandType].uID | Data0 | __m_pValues->m_CullingEnable;
	pCMD_BUFFER[1] = pbackupregister[0] = Data1;
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}


//------------------------------------------------------------------------------
/// @brief   send command that it's size is 6 x 32bit
/// @return	 if success, return CTURE. if failed, refer to GetLastError().
//------------------------------------------------------------------------------
CBOOL
MES_GRP3D_CommandWrite6
(
	MES_GRP3D_COMMANDTYPE CommandType,	///< [in] command type
	U32 Data0,					///< [in] command data0
	U32 Data1,					///< [in] command data1
	U32 Data2,					///< [in] command data2
	U32 Data3,					///< [in] command data3
	U32 Data4,					///< [in] command data4
	U32 Data5					///< [in] command data5
)
{
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;
	U32* pbackupregister = ((U32*)(&__m_pValues->m_BackupRegister)) + MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32;

	MES_ASSERT( MES_GRP3D_END_OF_COMMANDTYPE > CommandType );
	MES_ASSERT( 6 == MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	MES_ASSERT( 0 == (Data0 & MES_GRP3D_CMD_ID_MASK) );

	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	pCMD_BUFFER[0] = pbackupregister[0] = MES_GRP3D_CMD_PARAM_LIST[CommandType].uID | Data0  | __m_pValues->m_CullingEnable;
	pCMD_BUFFER[1] = pbackupregister[1] = Data1;
	pCMD_BUFFER[2] = pbackupregister[2] = Data2;
	pCMD_BUFFER[3] = pbackupregister[3] = Data3;
	pCMD_BUFFER[4] = pbackupregister[4] = Data4;
	pCMD_BUFFER[5] = pbackupregister[5] = Data5;
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}

//------------------------------------------------------------------------------
/// @brief   send command that it's size is n x 32bit
/// @return	 if success, return CTURE. if failed, refer to GetLastError().
//------------------------------------------------------------------------------
CBOOL
MES_GRP3D_CommandWrite
(
	U32	count,
	MES_GRP3D_COMMANDTYPE CommandType,	///< [in] command type
	U32 Data
)
{
	MES_GRP3D_PCMD pCMD_BUFFER;
	CBOOL mesresult;
	U32 i;
	U32* pbackupregister = ((U32*)(&__m_pValues->m_BackupRegister)) + MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32;

	MES_ASSERT( MES_GRP3D_END_OF_COMMANDTYPE > CommandType );
	//MES_ASSERT( count == MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 );
	MES_ASSERT( 0 == (Data & MES_GRP3D_CMD_ID_MASK) );

	 //MES_GRP3D_COMMANDTYPE_CONTROL, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable 
	mesresult = MES_GRP3D_BeginCommand( &pCMD_BUFFER,
							   MES_GRP3D_CMD_PARAM_LIST[CommandType].uOffset32,
							   /*MES_GRP3D_CMD_PARAM_LIST[CommandType].uSize32 * */count );
	if( ! mesresult ){ return CFALSE; }

	if( MES_GRP3D_IsDirectMode() && __m_pValues->m_CullingEnable && 0 == (__g_pRegister->STATUS & (1<<27)) )
		{ MES_GRP3D_EndCommand(); return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE ); }

	//pCMD_BUFFER[0] = MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable;
	//pCMD_BUFFER[1] = Data1;
	//pCMD_BUFFER[2] = Data2;
	//pCMD_BUFFER[3] = Data3;
	//pCMD_BUFFER[4] = Data4;
	//pCMD_BUFFER[5] = Data5;
	//memset( pCMD_BUFFER, MES_GRP3D_MODULEID_NOP | __m_pValues->m_CullingTestEnable, sizeof(MES_GRP3D_PCMD) * count );
	for( i = 0; i < count; i++ )
	{
		pCMD_BUFFER[i] = pbackupregister[i] = MES_GRP3D_CMD_PARAM_LIST[CommandType].uID | Data | __m_pValues->m_CullingEnable;
	}
	MES_GRP3D_EndCommand();

	return MES_GRP3D_SetLastError( MES_GRP3D_ERR_NONE );
}
