//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDrawTexfOES.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glDrawTex.html
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/18 Gamza Current Color�� R,B�� �ڹٲ�� ����Ǵ� ���� ����.
//	   2007/08/27 Gamza Current Color�� �ݿ��ϵ��� ����.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
#include "../source/renderprimitives.h"

#if		defined(ROTATE_0)
#elif	defined(ROTATE_90)
#elif	defined(ROTATE_180)
#elif	defined(ROTATE_270)
#else
    #define DISPLAY__00 0
    #define DISPLAY__90 1
    #define DISPLAY_180 2
    #define DISPLAY_270 3
    int GLESOAL_GetDisplayDirection( void );
#endif

//	openGL|ES only

// x and y are given directly in window (viewport) coordinates.
// z is mapped to window depth Zw as follows:
//	If z �� 0 then Zw = n
//	If z �� 1 then Zw = f
//	Otherwise Zw = n + z * (f - n)

// s = (Ucr + (X - x) * (Wcr / width)) / Wt
// t = (Vcr + (Y - y) * (Hcr / height)) / Ht
// r = 0
// q = 1
//		X and Y be the screen x and y coordinates of each sample point associated with the fragment
//		Wt and Ht be the width and height in texels of the texture currently bound to the texture unit
//			If the texture is a mipmap, let Wt and Ht be the dimensions of the level specified by GL_TEXTURE_BASE_LEVEL
//		Ucr, Vcr, Wcr and Hcr be (respectively) the four integers that make up the texture crop rectangle parameter for the currently bound texture

void glDrawTexfOES (GLfloat x, GLfloat y, GLfloat z, GLfloat width, GLfloat height)
{
	CALL_LOG;
	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);

	if( !ptexture )
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	int Ww, Hw;
	//GLESOAL_GetNativeWindowSize( &Ww, &Hw );
	Hw = __GLSTATE__.m_pSurface->GetHeight();
	Ww = __GLSTATE__.m_pSurface->GetWidth();

	float Xw = 0.0f; 
	float Yw = 0.0f;
	//float Ws, Hs;

	float Ucr = (float)(ptexture->m_TEXTURE_CROP_RECT_U)+0.5f;
	float Vcr = (float)(ptexture->m_TEXTURE_CROP_RECT_V)+0.5f;
	float Wcr = (float)(ptexture->m_TEXTURE_CROP_RECT_WIDTH);
	float Hcr = (float)(ptexture->m_TEXTURE_CROP_RECT_HEIGHT);

#if		defined(ROTATE_0)
	Xw = x;
	Yw = (float)(Hw)-(y); 
	//Ws = width;
	//Hs = height;

#elif	defined(ROTATE_90)
	Xw = (float)(Ww) - y;
	Yw = (float)(Hw) - x;
	//Ws = height;
	//Hs = width;

#elif	defined(ROTATE_180)
	Xw = (float)(Ww) - x;
	Yw = y; //(float)(Hw) - y - height + 1.0f;
	//Ws = width;
	//Hs = height;

#elif	defined(ROTATE_270)
	Xw = y;
	Yw = x; 
	//Ws = height;
	//Hs = width;

#else
    switch( GLESOAL_GetDisplayDirection() )
    {
    case DISPLAY__00 : 
		Xw = x;
		Yw = (float)(Hw)-(y); 
		break;
    case DISPLAY__90 : 
		Xw = (float)(Ww) - y;
		Yw = (float)(Hw) - x;
		break;
    case DISPLAY_180 : 
		Xw = (float)(Ww) - x;
		Yw = y; 
		break;
    case DISPLAY_270 :
		Xw = y;
		Yw = x; 
		break;
	}
#endif

	float Zw = 1.0f;
	if( __GLSTATE__.m_DepthMask || __GLSTATE__.m_Enable_DEPTH_TEST )
	{
		float fZ = z; //VF2F(z);
		Zw = ( fZ<=0.0f ? VF2F(__GLSTATE__.m_DepthRangeNear) : 
				   ( (fZ>=1.0f) ? VF2F(__GLSTATE__.m_DepthRangeFar) : 
					 ( VF2F(__GLSTATE__.m_DepthRangeNear)+fZ*( VF2F(__GLSTATE__.m_DepthRangeFar)-VF2F(__GLSTATE__.m_DepthRangeNear) ) ) ) );
	}

	if( width<=0.0f || height<=0.0f )
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	// Texture ����.
	UpdateTexture();
	
	float a = 255.0f*VF2F(__GLSTATE__.m_CurrentColor[3]); // a
	float r = 255.0f*VF2F(__GLSTATE__.m_CurrentColor[0]); // r
	float g = 255.0f*VF2F(__GLSTATE__.m_CurrentColor[1]); // g
	float b = 255.0f*VF2F(__GLSTATE__.m_CurrentColor[2]); // b

//	float v0[4*3] = { Xw, Yw, Zw, 1.0f, 
//					  a,r,g,b,
//					  Ucr, Vcr, };
//	float v1[4*3] = { Xw+Ws, Yw, Zw, 1.0f, 
//					  a,r,g,b,
//					  Ucr+Wcr, Vcr, };
//	float v2[4*3] = { Xw, Yw-Hs, Zw, 1.0f, 
//					  a,r,g,b,
//					  Ucr, Vcr+Hcr, };
//	float v3[4*3] = { Xw+Ws, Yw-Hs, Zw, 1.0f, 
//					  a,r,g,b,
//					  Ucr+Wcr, Vcr+Hcr, };
//
//	GLESHAL_SetTSEInput( 0, 10, v0 );
//	GLESHAL_SetTSEInput( 16, 10, v1 );
//	GLESHAL_SetTSEInput( 32, 10, v2 );
//	GLESHAL_RunTSE_Triangle( GL_FALSE );
//	GLESHAL_SetTSEInput( 0, 10, v3 );
//	GLESHAL_RunTSE_Triangle( GL_TRUE );
	/*
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };
	GLESHAL_SetTSEInput( 0, 10, v );
	v[0] = Xw+Ws; 
	v[8] = Ucr+Wcr;
	GLESHAL_SetTSEInput( 16, 10, v );
	v[1] = Yw-Hs; 
	v[9] = Vcr+Hcr;
	GLESHAL_SetTSEInput( 32, 10, v );
	GLESHAL_RunTSE_Triangle( GL_FALSE );
	v[0] = Xw; 
	v[8] = Ucr;
	GLESHAL_SetTSEInput( 16, 10, v );
	GLESHAL_RunTSE_Triangle( GL_TRUE );
	*/

#if		defined(ROTATE_0)
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };
	GLESHAL_SetTSEInput( 0, 10, v );
	v[0] = Xw + width; 
	v[8] = Ucr + Wcr;
	GLESHAL_SetTSEInput( 16, 10, v );
	v[1] = Yw - height; 
	v[9] = Vcr + Hcr;
	GLESHAL_SetTSEInput( 32, 10, v );
	GLESHAL_RunTSE_Triangle( GL_FALSE );
	v[0] = Xw; 
	v[8] = Ucr;
	GLESHAL_SetTSEInput( 16, 10, v );
	GLESHAL_RunTSE_Triangle( GL_TRUE );

#elif	defined(ROTATE_90)
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };
	GLESHAL_SetTSEInput( 0, 10, v );
	v[1] = Yw - width; 
	v[8] = Ucr + Wcr;
	GLESHAL_SetTSEInput( 16, 10, v );
	v[0] = Xw - height; 
	v[9] = Vcr + Hcr;
	GLESHAL_SetTSEInput( 32, 10, v );
	GLESHAL_RunTSE_Triangle( GL_FALSE );
	v[1] = Yw; 
	v[8] = Ucr;
	GLESHAL_SetTSEInput( 16, 10, v );
	GLESHAL_RunTSE_Triangle( GL_TRUE );

#elif	defined(ROTATE_180)
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };
	GLESHAL_SetTSEInput( 0, 10, v );
	v[0] = Xw - width; 
	v[8] = Ucr + Wcr;
	GLESHAL_SetTSEInput( 16, 10, v );
	v[1] = Yw + height; 
	v[9] = Vcr + Hcr;
	GLESHAL_SetTSEInput( 32, 10, v );
	GLESHAL_RunTSE_Triangle( GL_FALSE );
	v[0] = Xw; 
	v[8] = Ucr;
	GLESHAL_SetTSEInput( 16, 10, v );
	GLESHAL_RunTSE_Triangle( GL_TRUE );

#elif	defined(ROTATE_270)
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };
	GLESHAL_SetTSEInput( 0, 10, v );
	v[1] = Yw + width; 
	v[8] = Ucr + Wcr;
	GLESHAL_SetTSEInput( 16, 10, v );
	v[0] = Xw + height; 
	v[9] = Vcr + Hcr;
	GLESHAL_SetTSEInput( 32, 10, v );
	GLESHAL_RunTSE_Triangle( GL_FALSE );
	v[1] = Yw; 
	v[8] = Ucr;
	GLESHAL_SetTSEInput( 16, 10, v );
	GLESHAL_RunTSE_Triangle( GL_TRUE );

#else
	float v[4*3] = { Xw, Yw, Zw, 1.0f, a,r,g,b, Ucr, Vcr, };

    switch( GLESOAL_GetDisplayDirection() )
    {
    case DISPLAY__00 : 
		GLESHAL_SetTSEInput( 0, 10, v );
		v[0] = Xw + width; 
		v[8] = Ucr + Wcr;
		GLESHAL_SetTSEInput( 16, 10, v );
		v[1] = Yw - height; 
		v[9] = Vcr + Hcr;
		GLESHAL_SetTSEInput( 32, 10, v );
		GLESHAL_RunTSE_Triangle( GL_FALSE );
		v[0] = Xw; 
		v[8] = Ucr;
		GLESHAL_SetTSEInput( 16, 10, v );
		GLESHAL_RunTSE_Triangle( GL_TRUE );
	break;

	case DISPLAY__90 :	
		GLESHAL_SetTSEInput( 0, 10, v );
		v[1] = Yw - width; 
		v[8] = Ucr + Wcr;
		GLESHAL_SetTSEInput( 16, 10, v );
		v[0] = Xw - height; 
		v[9] = Vcr + Hcr;
		GLESHAL_SetTSEInput( 32, 10, v );
		GLESHAL_RunTSE_Triangle( GL_FALSE );
		v[1] = Yw; 
		v[8] = Ucr;
		GLESHAL_SetTSEInput( 16, 10, v );
		GLESHAL_RunTSE_Triangle( GL_TRUE );
	break;

	case DISPLAY_180 :
		GLESHAL_SetTSEInput( 0, 10, v );
		v[0] = Xw - width; 
		v[8] = Ucr + Wcr;
		GLESHAL_SetTSEInput( 16, 10, v );
		v[1] = Yw + height; 
		v[9] = Vcr + Hcr;
		GLESHAL_SetTSEInput( 32, 10, v );
		GLESHAL_RunTSE_Triangle( GL_FALSE );
		v[0] = Xw; 
		v[8] = Ucr;
		GLESHAL_SetTSEInput( 16, 10, v );
		GLESHAL_RunTSE_Triangle( GL_TRUE );
	break;

	case DISPLAY_270 :
		GLESHAL_SetTSEInput( 0, 10, v );
		v[1] = Yw + width; 
		v[8] = Ucr + Wcr;
		GLESHAL_SetTSEInput( 16, 10, v );
		v[0] = Xw + height; 
		v[9] = Vcr + Hcr;
		GLESHAL_SetTSEInput( 32, 10, v );
		GLESHAL_RunTSE_Triangle( GL_FALSE );
		v[1] = Yw; 
		v[8] = Ucr;
		GLESHAL_SetTSEInput( 16, 10, v );
		GLESHAL_RunTSE_Triangle( GL_TRUE );
     break;
	}
#endif

}
