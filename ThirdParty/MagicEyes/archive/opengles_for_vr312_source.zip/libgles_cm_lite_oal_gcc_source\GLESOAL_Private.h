//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#ifndef _GLESOAL_PRIVATE_H
#define _GLESOAL_PRIVATE_H

#include <libgles_cm_lite_oal.h>
//#include <GLESOAL_config.h>
//#include <Fake_OS.h>

//#define CHIPID_VR3511F		// !!! ���� ��������.

namespace __GLESOAL__
{

//------------------------------------------------------------------------------
// global variables
//------------------------------------------------------------------------------
extern int					g_WindowWidth;
extern int					g_WindowHeight;

} // namespace __GLESOAL__

using namespace __GLESOAL__;

//------------------------------------------------------------------------------
// memory initialization functions
//------------------------------------------------------------------------------
typedef struct
{
	unsigned int	VirtualAddress ;
	unsigned int    PhysicalAddress;
	unsigned int	SizeInMbyte;// size (Mbyte)
} ___OEM_CUSTOMHEAP;

void ___MES_1D_Manager_Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps );
void ___MES_2D_Manager_Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps );
unsigned int ___MES_2D_Manager_GetPhysicalAddress( const GLESOAL_MEMORY2D* pMemory2D );


#endif // _GLESOAL_PRIVATE_H
