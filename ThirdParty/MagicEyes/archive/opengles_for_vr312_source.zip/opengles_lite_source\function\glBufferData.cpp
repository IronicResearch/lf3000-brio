//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBufferData.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glBufferData.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
#ifdef __CC_ARM
//#include <string.h>
#include <cstring>
#else
#include <memory.h>
#endif

//	openGL|ES only


void glBufferData (GLenum target, GLsizeiptr size, const GLvoid *data, GLenum usage)
{
	CALL_LOG;
	int bindedbuffer;
	
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[0];		
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[1];		
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return; 
	}
	
	if ((usage != GL_STATIC_DRAW) && (usage != GL_DYNAMIC_DRAW))
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
	
	if ( size < 0 )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}	

	//	reference���� ������ vicent�� �ִ� �˻�	
	__BUFFER__* pcurrentbuffer;
	pcurrentbuffer = __BUFFER_POOL__.GetObject(bindedbuffer);
	
	if ( !bindedbuffer || !pcurrentbuffer )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if ( pcurrentbuffer->m_DataMemory1D.MemoryHandle )
	{
		while( pcurrentbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &pcurrentbuffer->m_DataMemory1D );
	}
	
	if( size )
	{
		if( !GLESOAL_Malloc1D( size, 8, &pcurrentbuffer->m_DataMemory1D ) )
		{
			GLSETERROR(GL_OUT_OF_MEMORY);
			return;
		}
		if ( data )
		{
			while( pcurrentbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			memcpy( (void*)(pcurrentbuffer->m_DataMemory1D.VirtualAddress), data, size );
		}		
	}

	pcurrentbuffer->m_Size  = size;
	pcurrentbuffer->m_Usage = usage;
	
	__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
}

