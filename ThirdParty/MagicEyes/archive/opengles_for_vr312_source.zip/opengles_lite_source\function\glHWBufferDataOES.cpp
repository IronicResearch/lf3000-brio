//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glHWBufferDataOES.cpp
//	Description: 
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/27 Yuni first implementation
//------------------------------------------------------------------------------
//#include "../source/glstate.h"
#include "../source/hwbufferobject.h"

#ifdef __CC_ARM
#include <cstring>
#else
#include <memory.h>
#endif


// OpenGL|ES extension

void glHWBufferDataOES(GLenum target, GLsizeiptr n, const GLvoid *data, GLenum format)
{
	CALL_LOG;
	int bindedbuffer;
	
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedHWBuffer[0];		
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedHWBuffer[1];		
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return; 
	}
	
	//	reference���� ������ vicent�� �ִ� �˻�	
	__HWBUFFER__* pcurrentbuffer;
	pcurrentbuffer = __HWBUFFER_POOL__.GetObject(bindedbuffer);
	if ( !bindedbuffer || !pcurrentbuffer )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
/*	
	if ( pcurrentbuffer->m_DataMemory1D.MemoryHandle )
	{
		GLESHAL_WaitToIdleState();	// buffer�� �а� �ִ� ���� �� �����Ƿ� idle ���¸� ��ٸ���.
		GLESOAL_Free1D( &(pcurrentbuffer->m_DataMemory1D) );
	}
*/
	if (n < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
		
	if (n > 0)
	{
		if( GL_ARRAY_BUFFER == target )
		{
			switch( format )
			{
			case GL_HWBUFFER_FV_OES:
				pcurrentbuffer->m_Stride = 4*sizeof(GLfloat);
				break;
			case GL_HWBUFFER_XV_OES:
				pcurrentbuffer->m_Stride = 4*sizeof(GLfixed);
				break;
			case GL_HWBUFFER_FVC_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfloat);
				break;
			case GL_HWBUFFER_XVC_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfixed);
				break;
			case GL_HWBUFFER_FVN_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfloat);
				break;
			case GL_HWBUFFER_XVN_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfixed);
				break;
			case GL_HWBUFFER_FVT_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfloat);
				break;
			case GL_HWBUFFER_XVT_OES:
				pcurrentbuffer->m_Stride = 8*sizeof(GLfixed);
				break;
			case GL_HWBUFFER_FVCTN_OES:
				pcurrentbuffer->m_Stride = 16*sizeof(GLfloat);
				break;
			case GL_HWBUFFER_XVCTN_OES:
				pcurrentbuffer->m_Stride = 16*sizeof(GLfixed);
				break;
			default:
				GLSETERROR(GL_INVALID_ENUM);
				return;
			}
			//if( pcurrentbuffer->m_Buffer )
			//	glDeleteBuffers( 1, &pcurrentbuffer->m_Buffer )
			
			// ���� binding�� buffer ����.
			GLint bindArrayBuffer;
			glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &bindArrayBuffer );
			
			//glGenBuffers( 1, &pcurrentbuffer->m_Buffer );
			glBindBuffer( GL_ARRAY_BUFFER, pcurrentbuffer->m_Buffer );
			glBufferData( GL_ARRAY_BUFFER, n * pcurrentbuffer->m_Stride, data, GL_STATIC_DRAW );
			
			// ���� ���·� �ǵ�����.
			glBindBuffer( GL_ARRAY_BUFFER, bindArrayBuffer );			
		}

		if( GL_ELEMENT_ARRAY_BUFFER == target )
		{
			switch( format )
			{
			case GL_UNSIGNED_BYTE:
				pcurrentbuffer->m_Stride = sizeof(GLubyte);
				break;
			case GL_UNSIGNED_SHORT:
				pcurrentbuffer->m_Stride = sizeof(GLushort);
				break;
			default:
				GLSETERROR(GL_INVALID_ENUM);
				return;
			}
			
			// ���� binding�� buffer ����.
			GLint bindElementBuffer;
			glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &bindElementBuffer );
			
			//glGenBuffers( 1, &pcurrentbuffer->m_Buffer );
			glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, pcurrentbuffer->m_Buffer );
			glBufferData( GL_ELEMENT_ARRAY_BUFFER, n * pcurrentbuffer->m_Stride, data, GL_STATIC_DRAW );
			
			// ���� ���·� �ǵ�����.
			glBindBuffer( GL_ELEMENT_ARRAY_BUFFER, bindElementBuffer );			
		}

/*
		if( !GLESOAL_Malloc1D( pcurrentbuffer->m_Stride*n, 8, &(pcurrentbuffer->m_DataMemory1D) ) )
		{
			GLSETERROR(GL_OUT_OF_MEMORY);
			return;
		}
		if ( data )
		{
			memcpy( (void*)(pcurrentbuffer->m_DataMemory1D.VirtualAddress), data, pcurrentbuffer->m_Stride*n );
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}
*/
	}
	
	pcurrentbuffer->m_Size  = n;
	pcurrentbuffer->m_Format = format;
}
