//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glMatrixMode.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glMatrixMode (GLenum mode)
{
	CALL_LOG;
	switch (mode)
	{
	case GL_MODELVIEW:
		__GLSTATE__.m_pCurrentMatrixMode = &__GLSTATE__.m_ModelViewMatrix;
		break;

	case GL_PROJECTION:
		__GLSTATE__.m_pCurrentMatrixMode = &__GLSTATE__.m_ProjectionMatrix;
		break;

	case GL_TEXTURE:
		__GLSTATE__.m_pCurrentMatrixMode = &__GLSTATE__.m_TextureMatrix[__GLSTATE__.m_ActiveTexture];
		break;

#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
	case GL_MATRIX_PALETTE_OES:
		__GLSTATE__.m_pCurrentMatrixMode = &__GLSTATE__.m_MatrixPalette[__GLSTATE__.m_CurrentPaletteMatrix];
		break;
#endif

	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__GLSTATE__.m_MatrixMode = mode;
}
