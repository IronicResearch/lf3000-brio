//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glHWBufferSubDataOES.cpp
//	Description: 
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza (n + offset_n) �� pcurhwbuffer->m_Size�� ���Ƶ� ��.
//	   2006/11/27 Yuni first implementation
//------------------------------------------------------------------------------
//#include "../source/glstate.h"
#include "../source/hwbufferobject.h"

#ifdef __CC_ARM
#include <cstring>
#else
#include <memory.h>
#endif

// OpenGL|ES extension

void glHWBufferSubDataOES(GLenum target, GLintptr offset_n, GLsizeiptr n, const GLvoid *data)
{
	CALL_LOG;
	int bindedbuffer;
	
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedHWBuffer[0];		
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedHWBuffer[1];		
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return; 
	}
	
	//	reference���� ������ vicent�� �ִ� �˻�	
	__HWBUFFER__* pcurhwbuffer;
	pcurhwbuffer = __HWBUFFER_POOL__.GetObject(bindedbuffer);
	if ( !bindedbuffer || !pcurhwbuffer )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if ( n < 0 || offset_n < 0 || (n + offset_n) > pcurhwbuffer->m_Size )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	
	if( data )
	{
		/*
		char* phwbufferData = reinterpret_cast<char*>(pcurhwbuffer->m_DataMemory1D.VirtualAddress) + pcurhwbuffer->m_Stride*offset_n;

		GLESHAL_WaitToIdleState();	// buffer�� �а� �ִ� ���� �� �����Ƿ� idle ���¸� ��ٸ���.
		memcpy(phwbufferData, data, pcurhwbuffer->m_Stride*n);

		__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		*/
		glBindBuffer( target, pcurhwbuffer->m_Buffer );
		glBufferSubData( target, (offset_n * pcurhwbuffer->m_Size), (n * pcurhwbuffer->m_Size), data );
	}

}
