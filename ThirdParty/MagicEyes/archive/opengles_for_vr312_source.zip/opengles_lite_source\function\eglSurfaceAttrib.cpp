//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglSurfaceAttrib.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : ��Ʈ
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglSurfaceAttrib (EGLDisplay dpy, EGLSurface surface, EGLint attribute, EGLint value)
{
	CALL_LOG;
	// The specified attribute of surface is set to value. Currently only the
	// EGL_MIPMAP_LEVEL attribute can be set.
	// For mipmap textures, the EGL_MIPMAP_LEVEL attribute indicates which level
	// of the mipmap should be rendered. If the value of this attribute is outside the
	// range of supported mipmap levels, the closest valid mipmap level is selected for
	// rendering. The default value of this attribute is 0.
	// If the value of pbuffer attribute EGL_TEXTURE_FORMAT is EGL_NO_TEXTURE, if
	// the value of attribute EGL_TEXTURE_TYPE is EGL_NO_TEXTURE, or if surface is not
	// a pbuffer, then attribute EGL_MIPMAP_LEVEL may be set, but has no effect.
	return EGL_FALSE;
}
