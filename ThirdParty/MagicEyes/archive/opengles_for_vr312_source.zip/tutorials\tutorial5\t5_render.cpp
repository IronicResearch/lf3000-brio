#include <math.h>
#include <stdio.h>
#include "t5_render.h"

namespace __TUTORIAL5__
{

EGLDisplay glesDisplay;
EGLSurface glesSurface;
EGLContext glesContext;

extern NativeWindowType hNativeWnd; // A handle to the window we will create

GLuint fontTexture = 0; 

int WindowWidth = 0;
int WindowHeight = 0;

BitmappedFont *font = NULL;


bool InitOGLES()
{  
  EGLConfig configs[10];
  EGLint matchingConfigs;	

  const EGLint configAttribs[] =
  {
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
  
  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 
  
  if(!eglInitialize(glesDisplay, NULL, NULL)) 
    return false;
  
  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
    return false;
  
	
  if(matchingConfigs < 1)  return false;	  

  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
  if(!glesSurface) 
    return false;
  
  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

  if(!glesContext) 
    return false;
  
  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
    
  glClearColorx(FixedFromFloat(0.5f), FixedFromFloat(0.5f), FixedFromFloat(0.5f), ONE);
  glShadeModel(GL_SMOOTH);  
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  OS_GetWindowSize(hNativeWnd, &WindowWidth, &WindowHeight);
  SetOrtho2D();  
  bool result = LoadTexture("./resources/font.tga",&fontTexture);  
  font = new BitmappedFont(fontTexture);
  return result;
}
//----------------------------------------------------------------------------
void Render()
{
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  

  glLoadIdentity();
    
  glColor4x(0, ONE,0,ONE);  
  BitmappedFont::EnableStates();
  font->Print(0,200,"Hello");
  font->Print(0,185,"At last we have");
  font->Print(0,170,"Text on screen");
  BitmappedFont::DisableStates();
  eglSwapBuffers(glesDisplay, glesSurface);
}
//----------------------------------------------------------------------------
void Clean()
{
  /*it is not mandatory free textures when you are goint to destroy the ogl context
    because the conext itself should destroy it's own objects, and textures is an
    context object*/
  delete font;
  if(glesDisplay)
  {
  	glDeleteTextures(1, &fontTexture);
    eglMakeCurrent(glesDisplay, NULL, NULL, NULL);  
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }  
}
//----------------------------------------------------------------------------
bool LoadTexture(const char *fileName, GLuint *id)
{
  OS_FILE f = OS_fopen(fileName, "rb");
  GLubyte *pixels = NULL;
  if(!f) return false;
			
	WORD width = 0, height = 0;			
	byte headerLength = 0;					
	byte imageType = 0;				
	byte bits = 0;						
	int format= 0;					
	int lineWidth = 0;							
			
	OS_fread(&headerLength, sizeof(byte), 1, f);		  
	OS_fseek(f,1,OS_SEEK_CUR); 	
	OS_fread(&imageType, sizeof(byte), 1, f);		
	OS_fseek(f, 9, OS_SEEK_CUR); 
	OS_fread(&width,  sizeof(WORD), 1, f);
	OS_fread(&height, sizeof(WORD), 1, f);
	OS_fread(&bits,   sizeof(byte), 1, f);

	OS_fseek(f, headerLength + 1, OS_SEEK_CUR); 
	
	if(imageType != 10)
	{		
		if((bits == 8)||(bits == 24)||(bits == 32)) //added to support for LUMINANCE or RGBA textures
		{		
			format = bits >> 3; 
			lineWidth = format * width;
			pixels = new GLubyte[lineWidth * height];
		
			for(int y = 0; y < height; y++)
			{
		  		GLubyte *line = &(pixels[lineWidth * y]);				
					OS_fread(line, lineWidth, 1, f);
				
		        if(format!= 1)
		        {
					for(int i=0;i<lineWidth ; i+=format)
					{
						int temp  = line[i];
						line[i]   = line[i+2];
						line[i+2] = temp;
					}
		        }
			}
		}		
		else
	    {      
	      OS_fclose(f);
	      *id = 0;
	      return false;	
	    }
	}	
	OS_fclose(f);
				
  glGenTextures(1, id);
  glBindTexture(GL_TEXTURE_2D, *id);
  glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
  glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
  glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  GLenum tformat;
  if(format==1) tformat = GL_LUMINANCE;
  else if(format==3) tformat = GL_RGB;
  else tformat = GL_RGBA;

  glTexImage2D(GL_TEXTURE_2D, 0, tformat, width, height, 0, tformat, GL_UNSIGNED_BYTE, pixels);  
  delete [] pixels;
  
  return true;
}
//----------------------------------------------------------------------------
void SetOrtho2D()
{  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(0), FixedFromInt(WindowWidth), 
           FixedFromInt(0), FixedFromInt(WindowHeight), 
           FixedFromInt(-1) , FixedFromInt(1));
  glMatrixMode(GL_MODELVIEW);
  
}
//----------------------------------------------------------------------------

}//namespace
