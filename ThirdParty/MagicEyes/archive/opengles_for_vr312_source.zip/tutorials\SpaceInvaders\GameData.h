// GameData.h: interface for the GameData class.
//
//////////////////////////////////////////////////////////////////////

#ifndef GAMEDATA_H
#define GAMEDATA_H
#include "global.h"
#include "font.h"
#include "timer.h"
#include "Actor.h"
#include "mesh.h"
#include "AliensGroup.h"


class GameData  
{
public:
  GameData();
  ~GameData();
  void RestartGame();

  //function to manage the thank's shots  
  void TankShotManagement(unsigned long elapsedtime);
  //function to manage the aliens' shots
  int AlienShotsManagement(unsigned long elapsedtime);
  
  //main function. contains all game logic
  void GameLoop(bool *done);

  //actives and updates the current camera
  void SetActiveCamera();

	int m_score;
  bool m_leftPushed;
  bool m_rightPushed;
  bool m_enterPushed;
  bool m_upPushed;
  bool m_downPushed;

  //cameras data
  int m_cameraActive;
  GLfixed m_cameraPosition[4][3];
  GLfixed m_cameraEye[4][3];

  //drawable objects
  BitmappedFont *m_font;  
  Actor *m_tank;
  Actor *m_bunker[4];  
  Actor *m_tankShot;
  bool m_tankShotActive;
  int m_tankAlive;
  Actor *m_alienShots[ALIEN_FIRE_RATE];
  bool m_alienShotsActive[ALIEN_FIRE_RATE];
  AliensGroup *m_enemies;
  Mesh *m_floor;  
  Mesh *m_bunkerMesh;
  Mesh *m_bala; //tank shot 
  Mesh *m_espina; //alien shot
  
  Texture *m_presentation;
  Texture *m_keyMap;
  Texture *m_credits;

private:
  void DrawScreenAlignedAndTexturedQuad();
  void Game(bool *done);
  int m_gameState;
  void InitCameras();
  void InitAlienShot(Actor *alien,int shot);
  bool CheckTankShotAgainstBunkers(); 
  bool CheckAlienShotsAgainstBunkers(int shot);
  bool CheckCollisionWithTank(int shot);
};

#endif 
