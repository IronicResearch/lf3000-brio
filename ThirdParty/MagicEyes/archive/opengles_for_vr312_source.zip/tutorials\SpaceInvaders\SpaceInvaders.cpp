#include <Fake_OS.h>
#include <stdlib.h>
#include "main.h" //We need the defines and prototypes from in.
#include "resource.h"
#include "render.h"
#include "GameData.h"
#include "camera.h"
//HACK: Arreglar FullScreen
//HACK: Resetear los disparos cuando matan al tanque

//Some useful global handles
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.

Timer *timer = NULL;
bool done = false;
extern GameData *game;

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int SpaceInvadersMain() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();

  srand(OS_GetTickCount());
  	  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;
  
  //Create our timer
  timer = new Timer();
  
  if(!InitOGLES()) //OpenGL ES Initialization
  {
    printf("OpenGL ES init error.");
    return false; 
  }

  //unsigned int frames = 1000;

  //Message Loop
  while(!done)
  //while(frames--)  
  {
    game->GameLoop(&done);            
  }

  Clean();
  delete timer;
  return 0;
}
/*
//----------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message) 
  {		
    
  //keyboard management
  case WM_KEYDOWN:
    if(wParam==VK_RETURN)
    {      
      game->m_enterPushed = true;        
      return 0;
    }
    if(wParam==VK_LEFT)
    {
      game->m_leftPushed = true;   
      return 0;
    }
    if(wParam==VK_RIGHT)
    {
      game->m_rightPushed = true;   
      return 0;
    }
    if(wParam==VK_UP)
    {              
      game->m_upPushed = true;
      return 0;
    }
    if(wParam==VK_DOWN)
    {   
      game->m_downPushed = true;      
      return 0;
    }
    break;

  case WM_KEYUP:
    if(wParam==VK_RETURN)
    {      
     // game->m_enterPushed = false;         
      return 0;
    }
    if(wParam==VK_LEFT)
    {      
      game->m_leftPushed = false;   
      return 0;
    }
    if(wParam==VK_RIGHT)
    {
      game->m_rightPushed = false;   
      return 0;
    }
    if(wParam==VK_UP)
    {      
      game->m_upPushed = false;
      game->m_cameraActive++;
      if(game->m_cameraActive>3) game->m_cameraActive = 0;
      return 0;
    }
    if(wParam==VK_DOWN)
    {            
      game->m_cameraActive--;
      if(game->m_cameraActive<0) game->m_cameraActive = 3;      
      game->m_downPushed = false;
      return 0;
    }
    break;


  case WM_DESTROY: 
    PostQuitMessage(0);
    return 0;  
  };
  return DefWindowProc(hWnd, message, wParam, lParam);   
}
*/
