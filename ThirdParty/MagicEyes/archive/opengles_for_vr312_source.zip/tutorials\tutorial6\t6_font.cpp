#include "t6_font.h"
//#include <cstring>
#include <string.h>

namespace __TUTORIAL6__
{

GLfixed BitmappedFont::m_textureCoordinates[];
bool BitmappedFont::m_instanced(false);

BitmappedFont::BitmappedFont(const char *textureFont, int fontWidth , int fontHeight):m_fontWidth(fontWidth),m_fontHeight(fontHeight)
{
  m_texture = NULL;
  m_state = true;
  //first, we need create the font texture
  m_texture = new Texture(textureFont,GL_NEAREST, GL_NEAREST, GL_CLAMP_TO_EDGE,GL_CLAMP_TO_EDGE, 256, 128, 8);
  
  //check if the texture is well created
  if(!m_texture->GetState()) 
  {
    delete m_texture;
    m_texture = NULL;
    m_state = false;
    return;
  }
  
  //next we will create the texture coordinates table, but this time using full fixed point math
  //This is exactly the same code than last tutorials, but uses the fixed point math. Nothing more has changed
  if(m_instanced) return;
  m_instanced = true;  

  const GLfixed rows = FixedFromInt(8);
  const GLfixed columns = FixedFromInt(16);
  const GLfixed xoffset = DivideFixed(ONE, columns); // the font texture has 16 columns
  const GLfixed yoffset = DivideFixed(ONE, rows); //the font texture has 8 rows   
          
  //prebuild the texture coordinates array for all characters
  for(int i=0;i<128;i++)
  {
    int aux = i % 16;
    const GLfixed cx = MultiplyFixed(FixedFromInt(aux), xoffset); 
    aux = i / 16;
    const GLfixed cy = MultiplyFixed(FixedFromInt(aux), yoffset);   
    const int index = i * 8;
    m_textureCoordinates[  index  ] = cx;
    m_textureCoordinates[index + 1] = ONE - cy - yoffset;

    m_textureCoordinates[index + 2] = cx + xoffset;
    m_textureCoordinates[index + 3] = ONE - cy - yoffset;         

    m_textureCoordinates[index + 4] = cx + xoffset;
    m_textureCoordinates[index + 5] = ONE - cy;

    m_textureCoordinates[index + 6] = cx;
    m_textureCoordinates[index + 7] = ONE - cy;    
  }
}
//----------------------------------------------------------------------------
BitmappedFont::~BitmappedFont()
{
  if(m_texture) delete m_texture;
}
//----------------------------------------------------------------------------
void BitmappedFont::EnableStates()
{
  /*This function exists because we can use it to enable all needed states to display the text
    for many Print calls, instead of call this states on every Print call*/
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glEnable(GL_TEXTURE_2D);
  glEnable(GL_BLEND);
  glBlendFunc(GL_ONE, GL_ONE);    
}
//----------------------------------------------------------------------------
void BitmappedFont::DisableStates()
{
  glDisable(GL_TEXTURE_2D);
  glDisableClientState(GL_VERTEX_ARRAY);  
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
  glDisable(GL_BLEND);  
}
//----------------------------------------------------------------------------  
void BitmappedFont::Print(int x, int y, const char *fmt, ...)
{
  //Convert the variable argument list, to a single char[] array
  //be careful, the final string length must fit into this array
  char text[256]; 
  va_list ap;
  if (fmt == NULL) 
    return;

  va_start(ap, fmt);
    vsprintf(text, fmt, ap);
  va_end(ap);
  if(text[0]=='\0')
    return;

  int length = (int)strlen(text);

  //Set up our arrays
  const GLushort indices[]= {1, 2, 0, 3};  //triangle strip
  GLfixed vertices[12];
  m_texture->BindTexture();  
  glVertexPointer(3, GL_FIXED, 0, vertices);  
  
  const GLfixed fy = FixedFromInt(y);  
  const GLfixed fheight = FixedFromInt(m_fontHeight);  
  
  //go throught all chars int the array
  //Code translated to use fixed point math
  for(int i = 0;i < length;i++)
  {
    /*We have to substract 32 units, because the characters stored in our font texture starts in the
      ASCII code 32 (the first 32 ASCII code, are control codes, usually non-displayables(*/
    const int c = text[i]-32;        
    const GLfixed originX = FixedFromInt(x + (i * m_fontWidth));
    const GLfixed offsetX = originX + FixedFromInt(m_fontWidth);
        
    //Compute the dimensions and position of the 'quad' (in reality is a triangle strip with two triangles)
    vertices[0] = originX;    vertices[1] = fy;            vertices[2] = 0;
    vertices[3] = offsetX;    vertices[4] = fy;            vertices[5] = 0;
    vertices[6] = offsetX;    vertices[7] = fy + fheight;  vertices[8] = 0;
    vertices[9] = originX;    vertices[10]= fy + fheight;  vertices[11]= 0;
    
    //we access to the corresponding texture coordinates in the precomputed texture coordinates array
    glTexCoordPointer(2, GL_FIXED, 0, &m_textureCoordinates[c*8]);  
    
    //draw the character
    glDrawElements(GL_TRIANGLE_STRIP,4,GL_UNSIGNED_SHORT,indices);
  }

  return;
}

}//namespace 
