//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glMaterialfv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_0rhu.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glMaterialfv (GLenum face, GLenum pname, const GLfloat *params)
{
	CALL_LOG;
	if (face != GL_FRONT_AND_BACK)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__MATERIAL__ * material = &__GLSTATE__.m_FrontMaterial;

	//GLclampf red  ;
	//GLclampf green;
	//GLclampf blue ;
	//GLclampf alpha;

	switch (pname)
	{
/*
	case GL_AMBIENT:
		red   = CLAMPF( params[0] );
		green = CLAMPF( params[1] );
		blue  = CLAMPF( params[2] );
		alpha = CLAMPF( params[3] );
		material->m_AmbientColor.argb[2] =  (unsigned char)(red  * 255) ;
		material->m_AmbientColor.argb[1] =  (unsigned char)(green* 255) ;
		material->m_AmbientColor.argb[0] =  (unsigned char)(blue * 255) ;
		material->m_AmbientColor.argb[3] =  (unsigned char)(alpha* 255) ;
		break;

	case GL_DIFFUSE:
		red   = CLAMPF( params[0] );
		green = CLAMPF( params[1] );
		blue  = CLAMPF( params[2] );
		alpha = CLAMPF( params[3] );
		material->m_DiffuseColor.argb[2] =  (unsigned char)(red  * 255) ;
		material->m_DiffuseColor.argb[1] =  (unsigned char)(green* 255) ;
		material->m_DiffuseColor.argb[0] =  (unsigned char)(blue * 255) ;
		material->m_DiffuseColor.argb[3] =  (unsigned char)(alpha* 255) ;
		break;

	case GL_AMBIENT_AND_DIFFUSE:
		red   = CLAMPF( params[0] );
		green = CLAMPF( params[1] );
		blue  = CLAMPF( params[2] );
		alpha = CLAMPF( params[3] );
		material->m_AmbientColor.argb[2] =  (unsigned char)(red  * 255) ;
		material->m_AmbientColor.argb[1] =  (unsigned char)(green* 255) ;
		material->m_AmbientColor.argb[0] =  (unsigned char)(blue * 255) ;
		material->m_AmbientColor.argb[3] =  (unsigned char)(alpha* 255) ;
		material->m_DiffuseColor = material->m_AmbientColor;
		break;

	case GL_SPECULAR:
		red   = CLAMPF( params[0] );
		green = CLAMPF( params[1] );
		blue  = CLAMPF( params[2] );
		alpha = CLAMPF( params[3] );
		material->m_SpecularColor.argb[2] =  (unsigned char)(red  * 255) ;
		material->m_SpecularColor.argb[1] =  (unsigned char)(green* 255) ;
		material->m_SpecularColor.argb[0] =  (unsigned char)(blue * 255) ;
		material->m_SpecularColor.argb[3] =  (unsigned char)(alpha* 255) ;
		break;

	case GL_EMISSION:
		red   = CLAMPF( params[0] );
		green = CLAMPF( params[1] );
		blue  = CLAMPF( params[2] );
		alpha = CLAMPF( params[3] );
		material->m_EmissionColor.argb[2] =  (unsigned char)(red  * 255) ;
		material->m_EmissionColor.argb[1] =  (unsigned char)(green* 255) ;
		material->m_EmissionColor.argb[0] =  (unsigned char)(blue * 255) ;
		material->m_EmissionColor.argb[3] =  (unsigned char)(alpha* 255) ;
		break;
*/
	case GL_AMBIENT:
		material->m_AmbientColor[0] =  F2VF( CLAMPF(params[0]) );
		material->m_AmbientColor[1] =  F2VF( CLAMPF(params[1]) );
		material->m_AmbientColor[2] =  F2VF( CLAMPF(params[2]) );
		material->m_AmbientColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_DIFFUSE:
		material->m_DiffuseColor[0] =  F2VF( CLAMPF(params[0]) );
		material->m_DiffuseColor[1] =  F2VF( CLAMPF(params[1]) );
		material->m_DiffuseColor[2] =  F2VF( CLAMPF(params[2]) );
		material->m_DiffuseColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_AMBIENT_AND_DIFFUSE:
		material->m_DiffuseColor[0] =  material->m_AmbientColor[0] =  F2VF( CLAMPF(params[0]) );
		material->m_DiffuseColor[1] =  material->m_AmbientColor[1] =  F2VF( CLAMPF(params[1]) );
		material->m_DiffuseColor[2] =  material->m_AmbientColor[2] =  F2VF( CLAMPF(params[2]) );
		material->m_DiffuseColor[3] =  material->m_AmbientColor[3] =  F2VF( CLAMPF(params[3]) );
		//material->m_DiffuseColor = material->m_AmbientColor;
		break;

	case GL_SPECULAR:
		material->m_SpecularColor[0] =  F2VF( CLAMPF(params[0]) );
		material->m_SpecularColor[1] =  F2VF( CLAMPF(params[1]) );
		material->m_SpecularColor[2] =  F2VF( CLAMPF(params[2]) );
		material->m_SpecularColor[3] =  F2VF( CLAMPF(params[3]) );
		break;

	case GL_EMISSION:
		material->m_EmissionColor[0] =  F2VF( CLAMPF(params[0]) );
		material->m_EmissionColor[1] =  F2VF( CLAMPF(params[1]) );
		material->m_EmissionColor[2] =  F2VF( CLAMPF(params[2]) );
		material->m_EmissionColor[3] =  F2VF( CLAMPF(params[3]) );
		break;
	default:
		glMaterialf(face, pname, *params);
		break;
	}

	__GLSTATE__.m_BackMaterial = __GLSTATE__.m_FrontMaterial;
	__GLSTATE__.m_IsGlobalLightingUpdated = GL_TRUE;
}


