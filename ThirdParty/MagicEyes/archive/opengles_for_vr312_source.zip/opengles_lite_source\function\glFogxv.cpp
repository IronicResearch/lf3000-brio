//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glFogxv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_5rmv.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// These functions specify fog parameters.

//	for GL
//	glFogi, glFogiv

//	for GL-ES
//	glFogf, glFogfv

// GL_FOG_MODE    The params parameter is a single value that specifies the equation to be used to compute the fog blend factor, f. Three symbolic constants are accepted: GL_LINEAR, GL_EXP, and GL_EXP2. The equations corresponding to these symbolic constants are defined in the following Remarks section. The default fog mode is GL_EXP.  
// GL_FOG_DENSITY The params parameter is a single value that specifies density, the fog density used in both exponential fog equations. Only nonnegative densities are accepted. The default fog density is 1.0.  
// GL_FOG_START   The params parameter is a single value that specifies start, the near distance used in the linear fog equation. The default near distance is 0.0.  
// GL_FOG_END     The params parameter is a single value that specifies end, the far distance used in the linear fog equation. The default far distance is 1.0.  
// GL_FOG_INDEX   The params parameter is a single value that specifies if, the fog color index. The default fog index is 0.0.  
// GL_FOG_COLOR   The glFogfv and glFogiv functions also accept GL_FOG_COLOR: 
//                The params parameter contains four values that specify Cf, the fog color.
//				  Integer values are mapped linearly such that the most positive representable value maps to 1.0, and the most negative representable value maps to 1.0. Floating-point values are mapped directly. After conversion, all color components are clamped to the range [0,1]. The default fog color is (0,0,0,0).
//
// glGet with argument GL_FOG_COLOR
// glGet with argument GL_FOG_INDEX
// glGet with argument GL_FOG_DENSITY
// glGet with argument GL_FOG_START
// glGet with argument GL_FOG_END
// glGet with argument GL_FOG_MODE
// glIsEnabled with argument GL_FOG
//
// GL_INVALID_ENUM  pname was not an accepted value. 
// GL_INVALID_OPERATION  glFinish was called between a call to glBegin and the corresponding call to glEnd. 

#define	_PARAMS_
#define _I( i )		int(i)
#define _B( b )		((b)!=0 ? GL_TRUE : GL_FALSE )
#define _VF( v )	X2VF(v)
#define _VCF( v )	X2VCF(v)

void glFogxv (GLenum pname, const GLfixed *params)
{
	CALL_LOG;
#	include "glFog.inl"
}
