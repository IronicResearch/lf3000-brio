//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLineWidthx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_75k8.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// The glLineWidth function specifies the width of rasterized lines

// The width of rasterized lines. The default is 1.0. 

//	
//	glGet with argument GL_LINE_WIDTH
//	glGet with argument GL_LINE_WIDTH_RANGE
//	glGet with argument GL_LINE_WIDTH_GRANULARITY
//	glIsEnabled with argument GL_LINE_SMOOTH

//	GL_INVALID_VALUE  width was less than or equal to zero. 
//	GL_INVALID_OPERATION  glLineWidth was called between a call to glBegin and the corresponding call to glEnd. 


void glLineWidthx (GLfixed width)
{
	CALL_LOG;
	if (width <= 0) { GLSETERROR(GL_INVALID_VALUE); return; }
	
	__GLSTATE__.m_LineWidth = X2VF(width);
}
