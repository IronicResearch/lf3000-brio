#include <math.h>
#include <Fake_OS.h>
#include <stdio.h>
#include "tutorial1.h" //We need the defines and prototypes of there

namespace __TUTORIAL1__
{

	//Some useful global handles
	NativeWindowType hNativeWnd = 0; // A handle to the window we will create


	// OpenGL variables
	EGLDisplay glesDisplay;  // EGL display
	EGLSurface glesSurface;	 // EGL rendering surface
	EGLContext glesContext;	 // EGL rendering context

    int texWidth = 32;
    int texHeight = 64;
    unsigned char* pPixels = NULL;

	GLboolean InitOGLES()
	{  
	  EGLConfig configs[10];
	  EGLint matchingConfigs;	

	  /*configAttribs is a integers list that holds the desired format of 
	   our framebuffer. We will ask for a framebuffer with 24 bits of 
	   color and 16 bits of z-buffer. We also ask for a window buffer, not 
	   a pbuffer or pixmap buffer*/	
	  const EGLint configAttribs[] =
	  {
	      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
	      EGL_NONE,           EGL_NONE
	  };
	  
	  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 //Ask for an default display

	  //Display initialization (we don't care about the OGLES version numbers)
	  if(!eglInitialize(glesDisplay, 0, 0)) 
	    return GL_FALSE;
		
	  /*Ask for the framebuffer confiburation that best fits our 
	  parameters. At most, we want 10 configurations*/
	  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
	   return GL_FALSE;
		
	  //If there isn't any configuration enough good
	  if (matchingConfigs < 1)  return GL_FALSE;	  

	  /*eglCreateWindowSurface creates an onscreen EGLSurface and returns 
	  a handle  to it. Any EGL rendering context created with a 
	  compatible EGLConfig can be used to render into this surface.*/
	  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
	  if(!glesSurface) return GL_FALSE;
	  
	  // Let's create our rendering context
	  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

	  if(!glesContext) return GL_FALSE;

	  //Now we will activate the context for rendering	
	  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
	    
      pPixels = new unsigned char[ 320*240 * 4];

	    
	  /*Remember: because we are programming for a mobile device, we cant 
	  use any of the OpenGL ES functions that finish in 'f', we must use 
	  the fixed point version (they finish in 'x'*/
	  glClearColor(0.5f, 0.5f, 1.0f, 1.0f);
	  glShadeModel(GL_SMOOTH);  
		
	  /*Setup of the projection matrix. We will use an ortho cube centered 
	  at (0,0,0) with 100 units of edge*/
	  glMatrixMode(GL_PROJECTION);
	  glLoadIdentity();   
	  
	  glOrthox(FixedFromInt(-50), FixedFromInt(50), 
	           FixedFromInt(-50), FixedFromInt(50), 
	           FixedFromInt(-50), FixedFromInt(50));
	  
	  glMatrixMode(GL_MODELVIEW);
	  glLoadIdentity();
	  
	  glDisable( GL_DEPTH_TEST);
	  glDisable( GL_CULL_FACE );
	  
	  return GL_TRUE;
	}
	//----------------------------------------------------------------------------
	void Render()
	{
		
	  static int rotation = 0;
	  				       
	  GLshort vertexArray[9] = {-25,-25,0,   25,-25,0,     0,25,0 };
	  /*
	  GLfloat vertexArray[] = { 
	  	0.1f, 0.1f, 0.5f, 1.0f,  
	  	0.9f, 0.1f, 0.5f, 1.0f,	
	  	0.5f, 0.9f, 0.5f, 1.0f
	  };
	  */
	  GLubyte colorArray[12] = {255,0,0,0,   0,255,0,0,    0,0,255,0};
	  
	  /*
	  int test = rotation%3;
	  switch( test )
	  {
	  	case 0:
	  		glClearColor(0.0f, 1.0f, 0.0f, 1.0f);
	  		break;
	  	case 1:
	  		glClearColor(1.0f, 0.0f, 0.0f, 1.0f);
	  		break;
	  	case 2:
	  		glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
	  		break;
	  	default:
	  		break;
	  }
	  //rotation++;
	  */

//    if( rotation < 45 )
        {
	  
	 // glClearColor(0.5f, 0.5f, 1.0f, 1.0f);
	 glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
	  glLoadIdentity();  

	  glTranslatex(0, 0, FixedFromInt(-10));
	  glRotatex(FixedFromInt(rotation++), 0, ONE,0);  
	  //glRotatex(FixedFromInt(0), 0, ONE,0); 

	  //Enable the vertices array  
	  glEnableClientState(GL_VERTEX_ARRAY);
	  glVertexPointer(3, GL_SHORT, 0, vertexArray);
	  //3 = XYZ coordinates, GL_SHORT = data type, 0 = 0 stride bytes
		
	  //Enable the vertex color array
	  glEnableClientState(GL_COLOR_ARRAY);
	  glColorPointer(4,GL_UNSIGNED_BYTE, 0, colorArray);
	  //4 = RGBA format, GL_UNSIGNED_BYTE = data type,0=0 stide    bytes

	  glDrawArrays(GL_TRIANGLES, 0, 3);

	  glDisableClientState(GL_VERTEX_ARRAY);
	  glDisableClientState(GL_COLOR_ARRAY);
}
	  //printf("%d\n", rotation );
    //glReadPixels(100, 30, texWidth, texHeight, GL_RGBA, GL_UNSIGNED_BYTE, pPixels);
    glReadPixels(160-16, 50, texWidth, texHeight, GL_RGBA, GL_UNSIGNED_BYTE, pPixels);
  /*
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  
    {
        int x,y;
        for( y=0; y<; y++ )
        for( x=0; x<32; x++ )
        {
            pPixels[ y*32*4 + x*4 + 0] = x*8;
            pPixels[ y*32*4 + x*4 + 1] = y*4;
            pPixels[ y*32*4 + x*4 + 2] = 0 ;
            pPixels[ y*32*4 + x*4 + 3] = 255;
        }
    }
  */
 // glDrawPixels( 10, 30, texWidth, texHeight, GL_RGBA, GL_UNSIGNED_BYTE, pPixels);
  glDrawPixels( 160-16, 50, texWidth, texHeight, GL_RGBA, GL_UNSIGNED_BYTE, pPixels);
	 	
	  eglSwapBuffers(glesDisplay, glesSurface);
	}
	//----------------------------------------------------------------------------
	void Clean()
	{
	  if(glesDisplay)
	  {
	    eglMakeCurrent(glesDisplay, 0, 0, 0);  
	    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
	    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
	    eglTerminate(glesDisplay);
	  }
      if(pPixels)
    	  delete [] pPixels;
	}

}

using namespace __TUTORIAL1__;
 
/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial1Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;

  if(!InitOGLES()) return GL_FALSE; //OpenGL ES Initialization
 
  // test
  Render();

  unsigned int frames = 1800;
  //Message Loop
  //while(!done)
  while(frames--)  
  {
	  Render();
  }
  //Clean up all
  Clean();
  return GL_TRUE;
}










