//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glmatrixstack.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/10/16 Yuni	finalize �߰�.
//	   2006/04/18 Gamza append inverse matrix
//	   2006/03/17 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLMATRIXSTACK_H
#define _GLMATRIXSTACK_H

#include "gllinalg.h"

#if defined(WIN32) || defined(UNDER_CE)
#pragma warning(disable:4514)
#endif

#ifdef UNDER_CE
	#include <mes_memory_debug.h>
#else
	#include <module/mes_memory_debug.h>
#endif

class MatrixStack
{
public:
	bool			m_IsUpdated;	// GTE Const reg�� update �Ǿ������� ���θ� �˷��ִ� flag.
									// private���� �ΰ� flag set/get �Լ��� ������ΰ�??

	MatrixStack(void);
	~MatrixStack(void);
	bool Initialize( int Depth );
	void Finalize(void);
	

	bool PushMatrix( void );
	bool PopMatrix( void );

	void LoadIdentity( void );
	void LoadMatrix( const Matrix4x4 &matrix );
	void MultMatrix( const Matrix4x4 &matrix );
	
	void Rotate    ( Vfloat angle, Vfloat x, Vfloat y, Vfloat z );
	void Scale     ( Vfloat x, Vfloat y, Vfloat z );
	void Translate ( Vfloat x, Vfloat y, Vfloat z );
	void Frustum   ( Vfloat left, Vfloat right, Vfloat bottom, Vfloat top, Vfloat zNear, Vfloat zFar );
	void Ortho     ( Vfloat left, Vfloat right, Vfloat bottom, Vfloat top, Vfloat zNear, Vfloat zFar );

	const Matrix4x4 & CurrentMatrix( void ) const ;
	const Matrix4x4 & CurrentInverseMatrix( void ) ;

	bool IsIdentity( void );

	int GetCurrentDepth( void );
	
private:
	struct StackItem
	{
		Matrix4x4	m_Matrix;
		Matrix4x4	m_Inverse;
		bool		m_ValidInverse;
		bool        m_Identity;
		void MakeInverse( void );
		int IsSimpleMatrix( void );
	};
	
	StackItem*	m_Stack;
	int			m_StackPointer;
	int			m_StackDepth;	
};

//------------------------------------------------------------------------------
//
//	inline implementation
//
//------------------------------------------------------------------------------
inline
MatrixStack::
MatrixStack(void) :
	m_IsUpdated(true),
	m_Stack(0),
	m_StackPointer(0),
	m_StackDepth(0)
{
}

inline
MatrixStack::
~MatrixStack(void)
{
	if( m_Stack )
	{
		MES_DELETE_ARRAY( m_Stack );
		m_IsUpdated = true;
		m_Stack = 0;
		m_StackPointer = 0;
		m_StackDepth = 0;
	}
}

inline
bool
MatrixStack::
Initialize( int Depth ) 
{
	if( m_Stack )
	{
		MES_DELETE_ARRAY( m_Stack );
		m_IsUpdated = true;
		m_Stack = 0;
		m_StackPointer = 0;
		m_StackDepth = 0;
	}
	m_Stack       = MES_NEW_ARRAY( StackItem, Depth );
	m_StackPointer= 0;
	m_StackDepth  = Depth;
	if( ! m_Stack ){ return false; }

	m_Stack[m_StackPointer].m_Identity = false;
	LoadIdentity();		// <- 	m_IsUpdated = true;
	return true;
}

inline
void
MatrixStack::
Finalize( void ) 
{
	if( m_Stack )
	{
		MES_DELETE_ARRAY( m_Stack );
		m_IsUpdated = true;
		m_Stack = 0;
		m_StackPointer = 0;
		m_StackDepth = 0;
	}
}

inline
bool
MatrixStack::
PushMatrix( void ) {
	if ( ( (m_StackDepth-1) <= m_StackPointer ) ){ return false; }
	m_Stack[m_StackPointer + 1] = m_Stack[m_StackPointer];
	++m_StackPointer;	
	return true;
}

inline
bool
MatrixStack::
PopMatrix( void ) {
	if ( 0 >= m_StackPointer ){ return false; }
	--m_StackPointer;
	return true;
}

inline
const Matrix4x4& 
MatrixStack::
CurrentMatrix( void ) const {
	return m_Stack[m_StackPointer].m_Matrix;
}

inline
bool
MatrixStack::
IsIdentity( void )
{
	return m_Stack[m_StackPointer].m_Identity;
}

inline
const Matrix4x4& 
MatrixStack::
CurrentInverseMatrix( void ) {
	if( !m_Stack[m_StackPointer].m_ValidInverse )
	{
		m_Stack[m_StackPointer].MakeInverse();
	}
	return m_Stack[m_StackPointer].m_Inverse;
}

inline
void 
MatrixStack::
LoadIdentity( void )
{
	bool old_identity = m_Stack[m_StackPointer].m_Identity;	

	Matrix4x4& curmat = m_Stack[m_StackPointer].m_Matrix;
	Matrix4x4& invmat = m_Stack[m_StackPointer].m_Inverse;
	m_Stack[m_StackPointer].m_ValidInverse = true;
	m_Stack[m_StackPointer].m_Identity   = true;
	M4_IDENTITY( curmat );
	M4_IDENTITY( invmat );

	if( (!old_identity) || (!m_Stack[m_StackPointer].m_Identity) ){ m_IsUpdated = true; }
}

inline
void 
MatrixStack::
LoadMatrix( const Matrix4x4 &matrix ) {
	bool old_identity = m_Stack[m_StackPointer].m_Identity;
	m_Stack[m_StackPointer].m_Matrix = matrix;
	m_Stack[m_StackPointer].m_ValidInverse = false;
	m_Stack[m_StackPointer].m_Identity   = 		
		VFONE == matrix.m[0][0] && VFONE == matrix.m[1][1] && VFONE == matrix.m[2][2] && VFONE == matrix.m[3][3] &&
		0     == matrix.m[0][1] && 0     == matrix.m[1][0] && 0     == matrix.m[2][0] && 0     == matrix.m[3][0] &&
		0     == matrix.m[0][2] && 0     == matrix.m[1][2] && 0     == matrix.m[2][1] && 0     == matrix.m[3][1] &&
		0     == matrix.m[0][3] && 0     == matrix.m[1][3] && 0     == matrix.m[2][3] && 0     == matrix.m[3][2];
	if( (!old_identity) || (!m_Stack[m_StackPointer].m_Identity) ){ m_IsUpdated = true; }
}

inline
void 
MatrixStack::
MultMatrix(const Matrix4x4 &matrix) {
	bool cur_identity = 
		VFONE == matrix.m[0][0] && VFONE == matrix.m[1][1] && VFONE == matrix.m[2][2] && VFONE == matrix.m[3][3] &&
		0     == matrix.m[0][1] && 0     == matrix.m[1][0] && 0     == matrix.m[2][0] && 0     == matrix.m[3][0] &&
		0     == matrix.m[0][2] && 0     == matrix.m[1][2] && 0     == matrix.m[2][1] && 0     == matrix.m[3][1] &&
		0     == matrix.m[0][3] && 0     == matrix.m[1][3] && 0     == matrix.m[2][3] && 0     == matrix.m[3][2];
	if( cur_identity ){ return; }
	//bool old_identity = m_Stack[m_StackPointer].m_Identity;
	Matrix4x4& newmat = m_Stack[m_StackPointer].m_Matrix;
	Matrix4x4  curmat = newmat;
	M4_MUL_M4( newmat, curmat, matrix );
	m_Stack[m_StackPointer].m_ValidInverse = false;	
	m_Stack[m_StackPointer].m_Identity   = 	
		VFONE == newmat.m[0][0] && VFONE == newmat.m[1][1] && VFONE == newmat.m[2][2] && VFONE == newmat.m[3][3] &&
		0     == newmat.m[0][1] && 0     == newmat.m[1][0] && 0     == newmat.m[2][0] && 0     == newmat.m[3][0] &&
		0     == newmat.m[0][2] && 0     == newmat.m[1][2] && 0     == newmat.m[2][1] && 0     == newmat.m[3][1] &&
		0     == newmat.m[0][3] && 0     == newmat.m[1][3] && 0     == newmat.m[2][3] && 0     == newmat.m[3][2];
	//if( (!old_identity) || (!m_Stack[m_StackPointer].m_Identity) ){ m_IsUpdated = true; }
	m_IsUpdated = true;
}

inline
int
MatrixStack::
GetCurrentDepth( void )
{
	return m_StackPointer+1;
}

// added by Yuni
inline
int
MatrixStack::
StackItem::
IsSimpleMatrix( void )
{
	if(	(m_Matrix.m[3][0] == 0) && (m_Matrix.m[3][1] == 0) 
		&& (m_Matrix.m[3][2] == 0 ) && ( m_Matrix.m[3][3] == VFONE ) )
		return 1;
	else 
		return 0;
}

#endif // _GLMATRIXSTACK_H

