#ifndef FONT_H
#define FONT_H

#include <stdarg.h>
#include <stdio.h>
#include <GLES/gl.h>
#include <GLES/egl.h>
#include "t5_fixed.h"

namespace __TUTORIAL5__
{

class BitmappedFont
{
public:
  BitmappedFont(GLuint textureFontID, int fontWidth = 15, int fontHeight = 15);
  ~BitmappedFont();
  static void EnableStates(); //Begin Print
  void Print(int x, int y, const char *fmt, ...);
  static void DisableStates(); //EndPrint
  

private:
  GLuint m_textureFontID;
  int m_fontWidth,m_fontHeight;
  
  //I've decided make this array static because will be exactly the same data for all fonts we will use
  static GLfixed m_textureCoordinates[2 * 4 * 8 * 16]; //2 = st, 4 = vertices per character, 8 = rows, 16 = columns
  static bool m_instanced;
};

}//namespace

#endif
