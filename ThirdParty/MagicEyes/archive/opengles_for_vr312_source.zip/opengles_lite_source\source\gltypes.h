//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gltypes.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/02 Yuni	change Color8888 type to float array that has 4 elements.
//	   2006/03/15 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLTYPES_H
#define _GLTYPES_H

#ifdef _WIN32
	#include <stdio.h>
	#define MES_TRACE( exp ) printf exp
#elif defined(__arm)
	#include <stdio.h>
	#define MES_TRACE( exp ) printf exp
#elif defined(__GNUC__)
	#define MES_TRACE( exp )
#else
	#error "Unknown platform"
#endif

namespace __MES_OPENGL_ES__
{

/*
union Color8888
{
	unsigned char argb[4]; // 0:b 1:g 2:r 3:a
	unsigned int  color32;	
};
*/

//struct Color9999
//{
//	unsigned short argb[4]; // 0:b 1:g 2:r 3:a
//};

#include <float.h>
#include "glfixed.h"

#define NULL	0

//#define INTERNAL_FLOAT 
#ifdef INTERNAL_FLOAT
	// internal float type
	typedef float Vfloat;
	#define VFONE	F2VF(1.0f)
	#define VFPINFINITY	( FLT_MAX)  // +infinity
	#define VFNINFINITY	(-FLT_MAX) // -infinity
	#define F2VF(f)	(Vfloat)(f)
	#define I2VF(f)	(Vfloat)(f)
	#define X2VF(f)	(Vfloat)Fixed2Float(f)
	#define VF2F(f)	(float)(f)
	#define VF2I(f)	(int)(f)
	#define VF2X(f)	Float2Fixed(f)
	#define VFABS(f) ( ((f)<0) ? (-(f)) : (+(f)) )

	// internal clamped float type [0.0f~1.0f]
	typedef float Vclampf;
	#define VCFONE		F2VCF(1.0f)
	#define F2VCF(f)	(Vclampf)(f)
	#define I2VCF(f)	(Vclampf)(f)
	#define X2VCF(f)	(Vclampf)Fixed2Float(f)
	#define VCF2F(f)	(float)(f)
	#define VCF2I(f)	(int)(f)
	#define VCF2X(f)	Float2Fixed(f)
	#define VCFABS(f)   ( ((f)<0) ? (-(f)) : (+(f)) )

	#define VFMUL( f1,f2 )	(Vfloat)((f1)*(f2))
	#define VFDIV( f1,f2 )	(Vfloat)((f1)/(f2))
	#define VFINV( f )		((0!=(f)) ? VFDIV( F2VF(1),f ) : VFPINFINITY )
	#define VFSQRT( f )		F2VF(sqrt(VF2F(f)))
	#define VFINVSQRT( f )	VFINV(F2VF(sqrt(VF2F(f))))
#else // #ifdef INTERNAL_FLOAT

//#define INTERNAL_FIXED_32
#ifdef INTERNAL_FIXED_32
	#define INTERNAL_FIXED				int
	#define INTERNAL_FIXED_BITS			32										// number of total bits
	#define INTERNAL_FIXED_PRECISION	16										// number of fractional bits
	#define INTERNAL_FIXED_MUL( f1,f2 )	(INTERNAL_FIXED)(((__int64)(f1)*(f2))>>INTERNAL_FIXED_PRECISION)
	#define INTERNAL_FIXED_DIV( f1,f2 )	(INTERNAL_FIXED)(((__int64)(f1)<<INTERNAL_FIXED_PRECISION)/(f2))
	#define INTERNAL_FIXED_INV( f )		((0!=(f)) ? INTERNAL_FIXED_DIV( INTERNAL_FIXED_ONE,f ) : INTERNAL_FIXED_PINF )
#else
	#define INTERNAL_FIXED				__int64
	#define INTERNAL_FIXED_BITS			64		// number of total bits
	#define INTERNAL_FIXED_PRECISION	32		// number of fractional bits (0~32)
	inline __int64 INTERNAL_FIXED_MUL( __int64 a, __int64 b )
	{
		bool sign = false;
		if (0>a){ sign = !sign; a = -a; }
		if (0>b){ sign = !sign; b = -b; }    
		__int64 a1 = a >> 32;
		__int64 a0 = a & 0xFFFFFFFF;        
		__int64 b1 = b >> 32;
		__int64 b0 = b & 0xFFFFFFFF;        
		__int64 sum = ((a1*b1)<<(64-(INTERNAL_FIXED_PRECISION))) + ((a1*b0 + a0*b1)<<(32-(INTERNAL_FIXED_PRECISION))) + ((a0*b0)>>(INTERNAL_FIXED_PRECISION));
		return sign ? (-sum) : sum;
	}
	#define INTERNAL_FIXED_DIV( f1,f2 )	(INTERNAL_FIXED)( (((double)(f1))/(f2)) * INTERNAL_FIXED_ONE )
	#define INTERNAL_FIXED_INV( f )		((0!=(f)) ? (INTERNAL_FIXED)( (((double)(INTERNAL_FIXED_ONE))/(f)) * INTERNAL_FIXED_ONE ) : INTERNAL_FIXED_PINF )
#endif

	#define INTERNAL_FIXED_ONE		(((INTERNAL_FIXED)1) << (INTERNAL_FIXED_PRECISION))	// representation of 1
	#define INTERNAL_FIXED_ZERO	    0													// representation of 0
	#define INTERNAL_FIXED_HALF	    (((INTERNAL_FIXED)1) << ((INTERNAL_FIXED_PRECISION)-1)) // 0.5 
	#define INTERNAL_FIXED_PINF	    ((((((INTERNAL_FIXED)1) << ((INTERNAL_FIXED_BITS)-2))-1)<<1)|1)	// +inf 
	#define INTERNAL_FIXED_MINF	    (((INTERNAL_FIXED)1) << ((INTERNAL_FIXED_BITS)-1))				// -inf 

	// internal float type
	typedef INTERNAL_FIXED Vfloat;
	#define VFONE		INTERNAL_FIXED_ONE
	#define VFPINFINITY	(INTERNAL_FIXED_PINF) // +infinity
	#define VFNINFINITY	(INTERNAL_FIXED_MINF) // -infinity
	#define F2VF(f)		static_cast<INTERNAL_FIXED>((f) * static_cast<float>(INTERNAL_FIXED_ONE))
	#define I2VF(f)		((static_cast<INTERNAL_FIXED>(f)) << (INTERNAL_FIXED_PRECISION))
	#define X2VF(f)		((static_cast<INTERNAL_FIXED>(f)) << ((INTERNAL_FIXED_PRECISION)-(GLFIXED_PRECISION)) )
	#define VF2F(f)		((f) * (1.0f/static_cast<float>(INTERNAL_FIXED_ONE)))
	#define VF2I(f)		((int)((f) >> (INTERNAL_FIXED_PRECISION)))
	#define VF2X(f)		((static_cast<GLfixed>(f))>>((INTERNAL_FIXED_PRECISION)-(GLFIXED_PRECISION)))
	#define VFABS(f)	( ((f)<0) ? (-(f)) : (+(f)) )

	// internal clamped float type [0.0f~1.0f]
	typedef INTERNAL_FIXED Vclampf;
	#define VCFONE		F2VCF(1.0f)
	#define F2VCF(f)	F2VF(f)
	#define I2VCF(f)	I2VF(f)
	#define X2VCF(f)	X2VF(f)
	#define VCF2F(f)	VF2F(f)
	#define VCF2I(f)	VF2I(f)
	#define VCF2X(f)	VF2X(f)
	#define VCFABS(f)   ( ((f)<0) ? (-(f)) : (+(f)) )

	#define VFMUL( f1,f2 )	INTERNAL_FIXED_MUL(f1,f2)
	#define VFDIV( f1,f2 )	INTERNAL_FIXED_DIV(f1,f2)
	#define VFINV( f )		INTERNAL_FIXED_INV(f)
	#define VFSQRT( f )		F2VF(sqrt(VF2F(f)))
	#define VFINVSQRT( f )	F2VF(1.0f/sqrt(VF2F(f)))
#endif

} // namespace __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;

#endif // _GLTYPES_H

