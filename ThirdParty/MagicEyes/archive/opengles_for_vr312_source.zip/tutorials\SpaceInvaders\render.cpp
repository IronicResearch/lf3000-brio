#include <stdlib.h>
#include <stdio.h>
#include "render.h"
#include "fixed.h"
#include "GameData.h"
#include "FrustumCuller.h"
#include "camera.h"

EGLDisplay glesDisplay;
EGLSurface glesSurface;
EGLContext glesContext;

extern NativeWindowType hNativeWnd; // A handle to the window we will create
extern Timer *timer;

int WindowWidth = 0;
int WindowHeight = 0;

GameData *game = NULL;
extern float angle;
extern int zoom;

GLfixed points[2*60];

bool InitOGLES()
{  
  EGLConfig configs[10];
  EGLint matchingConfigs;	

  const EGLint configAttribs[] =
  {
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
  
  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 
  
  if(!eglInitialize(glesDisplay, NULL, NULL)) 
    return false;
	
  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
   return false;
	
  if(matchingConfigs < 1)  return false;	  

  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
  if(!glesSurface) return false;
  
  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

  if(!glesContext) return false;

  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
    
  glClearColorx(0,0,0,0);
  glShadeModel(GL_SMOOTH);  
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  OS_GetWindowSize(hNativeWnd, &WindowWidth, &WindowHeight);
   
  //create or game logic class
  game = new GameData();
  
  //init our stars background
  for(int i=0;i<60;i+=2)
  {
    points[i] = FixedFromInt(rand()%WindowWidth);
    points[i+1] = FixedFromInt(rand()%WindowHeight);
  } 
  
  // we need the fastest rendering as possible
  glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);

  return true;
}
//----------------------------------------------------------------------------
void Render()
{  
  glClear(GL_COLOR_BUFFER_BIT);
  static char par = 0;
  
  //depth buffer hack. By this way we only have to clear the depth buffer on odd frames, 
  //losing some precision in the way
  if(par^= 1) 
  { 
    glClear(GL_DEPTH_BUFFER_BIT);
    glDepthRangex(FixedFromFloat(0.5f),ONE);
  }
  else 
    glDepthRangex(ZERO, FixedFromFloat(0.5f));        
  
  //Draw all our stars
  Camera::SetOrtho2D(WindowWidth, WindowHeight);
  glLoadIdentity();       
  glDepthMask(GL_FALSE);
  glColor4x(ONE,ONE,ONE,ONE);
  glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2,GL_FIXED,0,points);
    glDrawArrays(GL_POINTS,0,60);
  glDisableClientState(GL_VERTEX_ARRAY);
  glDepthMask(GL_TRUE);

  //active current camera
  game->SetActiveCamera();
      
  //draw tank and alien shots, if the y have to be rendered
  GLfixed color[3];
  color[0] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  color[1] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  color[2] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  glColor4x(color[0], color[1], color[2],ONE);
  if(game->m_tankShotActive)
    game->m_tankShot->Draw(timer->GetTimeBetweenTwoFrames());

  color[0] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  color[1] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  color[2] = DivideFixed(FixedFromInt(rand()%1000), FixedFromInt(1000));
  glColor4x(color[0], color[1], color[2],ONE);
  
  int i;
  for(i=0;i<ALIEN_FIRE_RATE;++i)
  {
    if(game->m_alienShotsActive[i])
      game->m_alienShots[i]->Draw(timer->GetTimeBetweenTwoFrames());
  }
  glColor4x(ONE,ONE,ONE,ONE);

  //draw road, tank, bunkers, and enemies
  glEnable(GL_TEXTURE_2D); 
  game->m_floor->Draw(timer->GetTimeBetweenTwoFrames());    
  game->m_tank->Draw(timer->GetTimeBetweenTwoFrames());
  game->m_enemies->Draw(timer->GetTimeBetweenTwoFrames());
       
  for(i=0;i<4;++i)
    game->m_bunker[i]->Draw(timer->GetTimeBetweenTwoFrames());

  glDisable(GL_TEXTURE_2D);         
  
}
//----------------------------------------------------------------------------
void Clean()
{
  delete game;
  FrustumCuller *f = FrustumCuller::Instance();
  if(f) delete f;
  if(glesDisplay)
  {
    eglMakeCurrent(glesDisplay, NULL, NULL, NULL);  
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }  
}

