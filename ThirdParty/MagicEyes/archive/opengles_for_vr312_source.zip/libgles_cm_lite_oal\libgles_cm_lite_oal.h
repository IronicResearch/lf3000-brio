//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_oal.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2008/03/26 Gamza append GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE
//	   2007/09/06 Gamza 2�� �¼����� �ƴ� �ؽ����� ����ó���� ���� �Լ� �߰�.
//						GLESOAL_MakeEdgeForNonPowerOf2_8BPP
//						GLESOAL_MakeEdgeForNonPowerOf2_16BPP
//	   2007/09/06 Gamza GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE �߰�
//	   2007/02/01 Yuni Remove Show3D(), Hide3D(), and add BufferSwapCallback()
//	   2007/01/04 Yuni add width and height information in memory structure
//	   2006/10/25 Yuni Memory1D/2D�� structure�� ����. 
//	   2006/09/27 Yuni first implementation
//------------------------------------------------------------------------------

#ifndef _LIBGLES_CM_LITE_OAL_H
#define _LIBGLES_CM_LITE_OAL_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef GLESOALAPI
#	ifndef UNDER_CE
#		define GLESOALAPI
#	else // UNDER_CE
#		ifdef LIBGLES_CM_LITE_OAL_EXPORTS
#			define GLESOALAPI __declspec(dllexport)
#		else // libgles_cm_lite_oal_EXPORTS
#			define GLESOALAPI __declspec(dllimport)
#		endif // libgles_cm_lite_oal_EXPORTS
#	endif // UNDER_CE
#endif // GLESOALAPI

typedef int GLESOALbool;


typedef struct
{
	unsigned long MemoryHandle;		///< memory handle for internal (do not modified it)
	unsigned long VirtualAddress;	///< virtual address of memory block (16byte aligned)
	unsigned long PhysicalAddress;	///< physical address of memory block (16byte aligned)
	unsigned long Size;
} GLESOAL_MEMORY1D;

GLESOALAPI enum GLESOAL_MEMORY2D_TYPE
{
	GLESOAL_MEMORY2D_TYPE_FRAMEBUFFER	  = 0,
	GLESOAL_MEMORY2D_TYPE_DEPTHBUFFER	  = 1,
	GLESOAL_MEMORY2D_TYPE_TEXTURE		  = 2,
	GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE    = 3,
	GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE = 4,
	GLESOAL_MEMORY2D_TYPE_FORCEU32		  = 0x7FFFFFFF
};

typedef struct
{
	unsigned long			MemoryHandle;		///< memory handle for internal (do not modified it)
	GLESOAL_MEMORY2D_TYPE	Type;				/// memory2D type
	unsigned long			VirtualSegment;		///< virtual address of memory block (16byte aligned)
	unsigned long			VirtualSegX;
	unsigned long			VirtualSegY;
	unsigned long			PhysicalSegment;	///< physical address of memory block (16byte aligned)
	unsigned long			PhysicalSegX;
	unsigned long			PhysicalSegY;
	unsigned long			Width;
	unsigned long			Height;
} GLESOAL_MEMORY2D;


GLESOALAPI enum GLESOAL_COLORFORMAT
{
	GLESOAL_COLORFORMAT_RGB565		= 0,
	GLESOAL_COLORFORMAT_RGBA8		= 1,
	GLESOAL_COLORFORMAT_LUMINANCE	= 2,
	GLESOAL_COLORFORMAT_FORCEU32	= 0x7FFFFFFF
};



//------------------------------------------------------------------------------
//	set EGL native window & native display
//------------------------------------------------------------------------------
GLESOALAPI 
void GLESOAL_SetNativeWindow( void* pNativeWindow );

GLESOALAPI 
void GLESOAL_SetNativeDisplay( void* pNativeDisplay );

GLESOALAPI 
void GLESOAL_GetNativeWindowSize( int* pWidth, int* pHeight );

GLESOALAPI 
GLESOALbool GLESOAL_Initialize_Internal( GLESOALbool FSAAEnb );

GLESOALAPI 
void GLESOAL_Finalize( void );

GLESOALAPI 
unsigned int GLESOAL_GetVirtualAddressOf3DCore( void );

GLESOALAPI 
void GLESOAL_WaitForDisplayAddressPatched( void );

GLESOALAPI 
void GLESOAL_PushDisplayAddressPatch( const GLESOAL_MEMORY2D* pDisplayBuffer );

GLESOALAPI 
GLESOALbool GLESOAL_IsSoftwareSyncNeeded( void );

GLESOALAPI 
GLESOALbool GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE Type,
							 unsigned int  Width, unsigned int  Height, 
							 unsigned int  AlignX, unsigned int  AlignY, 
							 GLESOAL_MEMORY2D* pMemory2D );
GLESOALAPI 
void GLESOAL_Free2D( GLESOAL_MEMORY2D* pMemory2D );

GLESOALAPI 
GLESOALbool GLESOAL_Malloc1D( unsigned int  Size, unsigned int  Align,
							GLESOAL_MEMORY1D* pMemory1D );
GLESOALAPI 
void GLESOAL_Free1D( GLESOAL_MEMORY1D* pMemory1D );



// Upload Texture - glTexImage2D
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_index4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );

GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_index8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );

GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_L8( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D,
									   unsigned int X, unsigned int Y,
									   unsigned int Width, unsigned int Height, 
									   const void* pSrc, unsigned int SrcStride );


// Create Mipmap Texture - glTexImage2D
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride );


// Upload Texture - glCopyTexImage2D
GLESOALAPI 
GLESOALbool GLESOAL_CopyDisplayToMemory_RGB565( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA );
GLESOALAPI 
GLESOALbool GLESOAL_CopyDisplayToMemory_RGBA8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA );
GLESOALAPI 
GLESOALbool GLESOAL_CopyDisplayToTexture_R5G6B5( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA );
GLESOALAPI 
GLESOALbool GLESOAL_CopyDisplayToTexture_L8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA );

// glDrawPixels
GLESOALAPI 
GLESOALbool GLESOAL_CopyMemoryToDisplay_RGB565( const void* pSrc, unsigned int SrcStride,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										int FSAA );
GLESOALAPI 
GLESOALbool GLESOAL_CopyMemoryToDisplay_RGBA8( const void* pSrc, unsigned int SrcStride,
										unsigned int X, unsigned int Y,
										unsigned int Width, unsigned int Height,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										int FSAA );

// Create Mipmap Texture - glCopyTexImage2D
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapCopyTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height );
GLESOALAPI 
GLESOALbool GLESOAL_CreateMipmapCopyTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height );


// for texture mipmap
GLESOALAPI 
GLESOALbool GLESOAL_CopyTexture_U8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height );
GLESOALAPI 
GLESOALbool GLESOAL_CopyTexture_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height );
GLESOALAPI 
GLESOALbool GLESOAL_GetMipmapPosition_U16(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y );
GLESOALAPI 
GLESOALbool GLESOAL_GetMipmapPosition_U8(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y );
GLESOALAPI 
GLESOALbool GLESOAL_UploadMipmap_U8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadMipmap_U16( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadMipmap_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadMipmap_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride );
GLESOALAPI 
GLESOALbool GLESOAL_UploadCopyTextureMipmap_L8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height );
GLESOALAPI 
GLESOALbool GLESOAL_UploadCopyTextureMipmap_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height );


// for FSAA
GLESOALAPI 
void GLESOAL_MakeEdgeForNonPowerOf2_8BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height );

GLESOALAPI 
void GLESOAL_MakeEdgeForNonPowerOf2_16BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height );

GLESOALAPI 
void GLESOAL_SwapBufferCallback( void );

GLESOALAPI 
GLESOALbool GLESOAL_ConvertColorSpace420( const void *pY,const void *pCb,const void *pCr,
										  int clipx, int clipy, int clipwidth, int clipheight,
									      GLESOAL_MEMORY2D* pDest );


GLESOALAPI 
void GLESOAL_Sleep( unsigned long Milliseconds );

GLESOALAPI 
int GLESOAL_GetDisplayDirection( void );

GLESOALAPI 
void GLESOAL_SetDither( GLESOALbool Enable );

#ifdef __cplusplus
}
#endif

#endif // _LIBGLES_CM_LITE_HAL_H
