#ifndef RENDER_H
#define RENDER_H

#include <Fake_OS.h>

#include <GLES/gl.h>
#include <GLES/egl.h>


bool InitOGLES();
void Render();  
void Clean();   
//void GameLoop(bool *done);

#endif
