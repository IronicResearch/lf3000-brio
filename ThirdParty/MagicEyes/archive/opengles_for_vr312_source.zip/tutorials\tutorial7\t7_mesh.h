#ifndef MESH_H
#define MESH_H

#include <GLES/gl.h>
#include "t7_fixed.h"

namespace __TUTORIAL7__
{

//Structure to hold the optimized mesh data for rendering
struct FixedMesh
{
  GLushort indexCounter;
  GLushort vertexCounter;  
  GLushort *Indices;
  GLfixed *Geometry;
  GLfixed *Normals;
  GLfixed *TexCoord;  
};

//Structure to hold the data readed from the file
struct GenericObjectData
{
  char Name[128];
  char ParentName[128];
  unsigned int *Indices;
  float *Geometry;
  float *Normals;
  float *TexCoord;
  unsigned long iC;
  unsigned long vC;  
};

//GSD file header 
struct GSDHeader
{
  char id[32];
  char version[16];
  int numberOfSubObjects;
};
 
class Mesh
{
public:
  Mesh(const char *filename, bool useVBO = false);
  ~Mesh();
  void Draw();
  bool GetState () {return m_state;};

private:
 FixedMesh m_mesh;
 bool m_state;
 //new VBO variables
 bool m_useVBO; //to know if this mesh will use VBO or not
 //VBO handlers
 GLuint m_indexBuffer;
 GLuint m_vertexBuffer;
 GLuint m_normalBuffer;
 GLuint m_texCoordBuffer;
};

}//namespace

#endif









