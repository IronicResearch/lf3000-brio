//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglDestroySurface.cpp
//	Description: �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/11/09 Yuni	Surface�� NULL���� �˻��� �޸� �����ϵ��� ����. 
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglDestroySurface (EGLDisplay dpy, EGLSurface surface)
{
	CALL_LOG;
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_SURFACE is generated if surface is not an EGL surface.
/*
	__SURFACE__* psurface = (__SURFACE__*)surface;
	if( ! psurface || EGLSURFACE_FLAG != psurface->m_Config.m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_SURFACE );
		return EGL_FALSE;
	}
*/
	GLES_Surface*  pSurface = (GLES_Surface*)surface;

	if( __GLSTATE__.m_pSurface == pSurface ) { __GLSTATE__.m_pSurface = NULL; }
	if( __EGLSTATE__.m_pCurDrawSurface == pSurface ) { __EGLSTATE__.m_pCurDrawSurface = NULL; }
	if( __EGLSTATE__.m_pCurReadSurface == pSurface ) { __EGLSTATE__.m_pCurReadSurface = NULL; }

	if( pSurface && ( (unsigned int)pSurface == __EGL_SURFACE__ ) )
	{
		pSurface->DestroySurface();
		MES_DELETE( pSurface );
		__EGL_SURFACE__ = 0;
	}

	return EGL_TRUE;
}


