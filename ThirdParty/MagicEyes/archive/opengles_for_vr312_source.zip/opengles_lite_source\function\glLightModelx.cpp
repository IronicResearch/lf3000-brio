//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLightModelx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_3y5o.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// These functions set the lighting model parameters.

//	for GL
//	glLightModeli, glLightModeliv

//	for GL-ES
//	glLightModelf, glLightModelfv
//	glLightModelx, glLightModelxv

//	glLightModelfv,glLightModeliv,glLightModelxv
//	GL_LIGHT_MODEL_LOCAL_VIEWER	
//	GL_LIGHT_MODEL_TWO_SIDE

//	glLightModelf,glLightModeli,glLightModelx
//	GL_LIGHT_MODEL_AMBIENT
//	GL_LIGHT_MODEL_LOCAL_VIEWER
//	GL_LIGHT_MODEL_TWO_SIDE

//	glGet with argument GL_LIGHT_MODEL_AMBIENT
//	glGet with argument GL_LIGHT_MODEL_LOCAL_VIEWER
//	glGet with argument GL_LIGHT_MODEL_TWO_SIDE
//	glIsEnabled with argument GL_LIGHTING

//	GL_INVALID_ENUM  pname was not an accepted value. 
//	GL_INVALID_OPERATION  glLightModel was called between a call to glBegin and the corresponding call to glEnd. 


void glLightModelx (GLenum pname, GLfixed param)
{
	CALL_LOG;
	switch (pname)
	{
	// case GL_LIGHT_MODEL_LOCAL_VIEWER: // GL only
	case GL_LIGHT_MODEL_TWO_SIDE:
		__GLSTATE__.m_TwoSidedLightning = (param != 0);
		break;
	default:
		GLSETERROR( GL_INVALID_ENUM );
	}
	//__GLSTATE__.m_IsLightingUpdated = GL_TRUE;
}
