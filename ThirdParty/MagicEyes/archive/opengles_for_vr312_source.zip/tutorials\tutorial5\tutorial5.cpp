#include "t5_render.h"
#include <stdio.h>

namespace __TUTORIAL5__
{

//Some useful global handles
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.

}// namespace
using namespace __TUTORIAL5__;

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial5Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;
  
  if(!InitOGLES()) //OpenGL ES Initialization
  {
    printf("OpenGL ES init error.");
    return false; 
  }
  
  unsigned int frames = 360;
  //Message Loop
  //while(!done)
  while(frames--)  
  {
    Render();
  }
  
  //Clean up all
  Clean();
  
  return 0;
}

