//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetClipPlanex.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_8ndx.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// The glGetClipPlane function returns the coefficients of the specified clipping plane.

//	for GL
//	glGetClipPlane

//	for GL-ES
//	glGetClipPlanef

//	GL_INVALID_ENUM  plane was not an accepted value. 
//	GL_INVALID_OPERATION  glGetClipPlane was called between a call to glBegin and the corresponding call to glEnd. 


void glGetClipPlanex (GLenum pname, GLfixed eqn[4])
{
	CALL_LOG;
	if( GL_CLIP_PLANE0 > pname || GL_CLIP_PLANE0+GLPARAM_MAX_CLIP_PLANES <= pname ){ GLSETERROR( GL_INVALID_ENUM );	return; }
#if GLPARAM_MAX_CLIP_PLANES > 0
	Vec4D& clipplane = __GLSTATE__.m_ClipPlane[pname-GL_CLIP_PLANE0];
	eqn[0] = VF2X(clipplane.x);
	eqn[1] = VF2X(clipplane.y);
	eqn[2] = VF2X(clipplane.z);
	eqn[3] = VF2X(clipplane.w);
#endif
}
