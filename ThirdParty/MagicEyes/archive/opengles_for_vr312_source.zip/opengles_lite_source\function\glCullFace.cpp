//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glCullFace.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_9yxx.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/25 Yuni	Change using HAL function 
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glCullFace (GLenum mode)
{
	CALL_LOG;
	switch( mode )
	{
	case GL_FRONT:
		GLESHAL_SetCullFace( GLESHAL_CULLFACE_FRONT );
		break;
	case GL_BACK:
		GLESHAL_SetCullFace( GLESHAL_CULLFACE_BACK );
		break;
	case GL_FRONT_AND_BACK:		
		GLESHAL_SetCullFace( GLESHAL_CULLFACE_FRONTANDBACK );
		break;
	default:
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}
	
	__GLSTATE__.m_CullFace = mode;

}
