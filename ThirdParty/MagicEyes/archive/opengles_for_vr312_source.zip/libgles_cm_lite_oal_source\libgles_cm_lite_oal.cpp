//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_oal.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2008/08/05 Gamza POLLUX������ MLC�� ���� flipping ������ �ذ�Ǿ���.
//						GLESOAL_IsSoftwareSyncNeeded �Լ� return g_GLESOAL_FSAA ���� ����.
//	   2007/10/22 Yuni first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#include <GLESOAL_Private.h>
#include "mes_memory_debug.h"
#include "OEM/MESGPS_OEM.h"
#include <stdio.h>
#define TRACE(exp)	printf exp

#define SUPPORT_MIPMAP

#if		defined(ROTATE_0)
#elif	defined(ROTATE_90)
#elif	defined(ROTATE_180)
#elif	defined(ROTATE_270)
#else
    #define DISPLAY__00 0
    #define DISPLAY__90 1
    #define DISPLAY_180 2
    #define DISPLAY_270 3
    int GLESOAL_GetDisplayDirection( void );
#endif

namespace __GLESOAL__ {

GLESOALbool	g_IsOpened	= 0;
HDC			g_NativeDisplay = NULL;
HWND		g_NativeWindow	= NULL;
int			g_WindowWidth	= 0;
int			g_WindowHeight	= 0;
GLESOALbool	g_GLESOAL_FSAA;

} // namespace __GLESOAL__

using namespace __GLESOAL__;

namespace {

	DWORD GetColorKeyFromRegistry( unsigned char* pColorKey )
	{
		LONG lRet;
		HKEY hkey;
		DWORD dwType;
		DWORD dwSize;
		WCHAR c_szShellOnTop[] = L"Software\\Microsoft\\DirectShow\\VideoRenderer";

		lRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE, c_szShellOnTop, 0, KEY_ALL_ACCESS, &hkey);
		if (lRet != ERROR_SUCCESS)
		{
			pColorKey[0] = 9;
			pColorKey[1] = 9;
			pColorKey[2] = 9;
			RETAILMSG(1,( L"GetColorKeyFromRegistry() R 0x%X / G 0x%X / B 0x%X\r\n", pColorKey[0], pColorKey[1], pColorKey[2] ));
			return RGB(9,9,9);
		}

		dwType = NULL;
		dwSize = 4;
		RegQueryValueEx(hkey, L"KeyColor", NULL, &dwType, (LPBYTE)pColorKey, &dwSize);

		RegCloseKey(hkey);

		RETAILMSG(1,( L"GetColorKeyFromRegistry() R 0x%X / G 0x%X / B 0x%X\r\n", pColorKey[0], pColorKey[1], pColorKey[2] ));

		return RGB( pColorKey[0], pColorKey[1], pColorKey[2] );
	}

	GLESOALbool GLESOAL_Show3D( int X, int Y, 
							   int Width, int Height )
	{
#if		defined(ROTATE_0)
		int isEnable = MESGPSOEM_Show3D(X, Y, Width, Height);
#elif	defined(ROTATE_90)
		int isEnable = MESGPSOEM_Show3D(Y, GetSystemMetrics(SM_CXSCREEN) - (X+Height), Width, Height);
#elif	defined(ROTATE_180)
		int isEnable = MESGPSOEM_Show3D(GetSystemMetrics(SM_CXSCREEN) - (X+Width),GetSystemMetrics(SM_CYSCREEN) - (Y+Height), Width, Height);
#elif	defined(ROTATE_270)
		int isEnable = MESGPSOEM_Show3D(GetSystemMetrics(SM_CYSCREEN) - (Y+Width), X, Width, Height);
#else
		int isEnable = 0;
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			isEnable = MESGPSOEM_Show3D(X, Y, Width, Height);
            break;
        case DISPLAY__90 : 
			isEnable = MESGPSOEM_Show3D(Y, GetSystemMetrics(SM_CXSCREEN) - (X+Height), Width, Height);
			//printf( "%d,%d,%d,%d (%d,%d)\n",
			//		Y, GetSystemMetrics(SM_CXSCREEN) - (X+Height), Width, Height,
			//		GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)
			//		);
            break;
        case DISPLAY_180 : 
			isEnable = MESGPSOEM_Show3D(GetSystemMetrics(SM_CXSCREEN) - (X+Width),GetSystemMetrics(SM_CYSCREEN) - (Y+Height), Width, Height);
        	break;
        case DISPLAY_270 :                    
			isEnable = MESGPSOEM_Show3D(GetSystemMetrics(SM_CYSCREEN) - (Y+Width), X, Width, Height);
            break;
        }
#endif
		//return MESGPSOEM_SetOverlay(isEnable, R, G, B);			
		//return MESGPSOEM_SetOverlay(isEnable, 255,0,255);

		unsigned char colorkey[4];
		GetColorKeyFromRegistry(colorkey);
		return MESGPSOEM_SetOverlay(isEnable, colorkey[0], colorkey[1], colorkey[2]);	
	}

	GLESOALbool GLESOAL_Hide3D( void )
	{
		MESGPSOEM_SetOverlay(0, 0, 0, 0);
		return MESGPSOEM_Hide3D();
	}

}

void GLESOAL_SetNativeWindow( void* pNativeWindow )
{
	g_NativeWindow = (HWND)pNativeWindow;

	if( g_NativeWindow )
	{
		RECT clientrect;

		GetClientRect( (HWND)g_NativeWindow, &clientrect );
#if		defined(ROTATE_0)
		g_WindowWidth = clientrect.right - clientrect.left;
		g_WindowHeight = clientrect.bottom - clientrect.top;
#elif	defined(ROTATE_90)
		g_WindowWidth = clientrect.bottom - clientrect.top;
		g_WindowHeight = clientrect.right - clientrect.left;
#elif	defined(ROTATE_180)
		g_WindowWidth = clientrect.right - clientrect.left;
		g_WindowHeight = clientrect.bottom - clientrect.top;
#elif	defined(ROTATE_270)
		g_WindowWidth = clientrect.bottom - clientrect.top;
		g_WindowHeight = clientrect.right - clientrect.left;
#else
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			g_WindowWidth = clientrect.right - clientrect.left;
			g_WindowHeight = clientrect.bottom - clientrect.top;
            break;
        case DISPLAY__90 : 
			g_WindowWidth = clientrect.bottom - clientrect.top;
			g_WindowHeight = clientrect.right - clientrect.left;
            break;
        case DISPLAY_180 : 
			g_WindowWidth = clientrect.right - clientrect.left;
			g_WindowHeight = clientrect.bottom - clientrect.top;
        	break;
        case DISPLAY_270 :                    
			g_WindowWidth = clientrect.bottom - clientrect.top;
			g_WindowHeight = clientrect.right - clientrect.left;
            break;
        }
#endif
	}
}

void GLESOAL_SetNativeDisplay( void* pNativeDisplay )
{
	g_NativeDisplay = (HDC)pNativeDisplay;
}

void GLESOAL_GetNativeWindowSize( int* pWidth, int* pHeight )
{
	*pWidth = g_WindowWidth;
	*pHeight = g_WindowHeight;
}

unsigned int GLESOAL_GetVirtualAddressOf3DCore( void )
{
	return MESGPSOEM_GetVirtualAddress();
}

void GLESOAL_SwapBufferCallback( void )//( int Width, int Height )
{
	static POINT old_point ={0,0};
	static int   old_width =0;
	static int   old_height=0;
	if( ! g_NativeWindow )
	{
		old_width = -1;
		MESGPSOEM_Hide3D();
	}

	// �ʿ��ұ�?
	if( g_WindowWidth <= 0 || g_WindowHeight<=0 )
	{
		old_width = -1;
		MESGPSOEM_Hide3D();
	}
	else
	{
		POINT point;
		point.x = 0;
		point.y = 0;
		ClientToScreen( g_NativeWindow, &point );

		if( old_point.x != point.x ||
			old_point.y != point.y ||
			old_width   != g_WindowWidth ||
			old_height  != g_WindowHeight )
		{
			static bool isshow = false;
			if( ! isshow )
			{
				GLESOAL_Show3D( point.x, point.y,
								g_WindowWidth, g_WindowHeight );
				isshow = true;
			}
			old_point.x = point.x ;
			old_point.y = point.y ;
			old_width   = g_WindowWidth ;
			old_height  = g_WindowHeight;
		}
	}
}

void GLESOAL_Sleep( unsigned long Milliseconds )
{
	Sleep( Milliseconds );
}
 
GLESOALbool GLESOAL_Malloc1D( unsigned int  Size, unsigned int  Align,
                                         GLESOAL_MEMORY1D* pMemory1D )
{
	if( (Align!=1) && (Align!=2) && (Align!=4) && (Align!=8) )
		return 0;

	MESGPSOEM_Memory1D* pmem = MES_NEW( MESGPSOEM_Memory1D );

	unsigned int alignedSize = ( (Size+Align-1) / Align ) * Align;

	if( MESGPSOEM_Malloc1D(alignedSize, pmem) )
	{
		pMemory1D->MemoryHandle		= (unsigned long)pmem;
		pMemory1D->PhysicalAddress	= pmem->PhysicalAddress;
		pMemory1D->VirtualAddress	= pmem->VirtualAddress;
		pMemory1D->Size				= pmem->Size;

		//printf("2D Mem Alloc: %08x \n", pMemory1D->MemoryHandle );
		return 1;
	}
	else
	{
		if( pmem )
			MES_DELETE( pmem );
		return 0;
	}
}

void GLESOAL_Free1D( GLESOAL_MEMORY1D* pMemory1D )
{
	if( !pMemory1D )
	{	return;	}	

	if( !pMemory1D->MemoryHandle )
	{	return;	}
	MESGPSOEM_Memory1D* pmem = (MESGPSOEM_Memory1D*)(pMemory1D->MemoryHandle);
	//printf("2D Mem Free: %08x \n", pMemory1D->MemoryHandle );

	MESGPSOEM_Free1D(pmem);
	MES_DELETE( pmem );

	// ��� ������� �ʱ�ȭ
	pMemory1D->PhysicalAddress	= 0;
	pMemory1D->VirtualAddress	= 0;
	pMemory1D->MemoryHandle		= 0;
	pMemory1D->Size				= 0;
}

int __GLESOAL_Malloc2D(  unsigned int  Width, unsigned int  Height, 
									unsigned int  AlignX, unsigned int  AlignY, 
									MESGPSOEM_Memory2D* pMemory2D );
void __GLESOAL_Free2D         ( MESGPSOEM_Memory2D* pMemory2D );

GLESOALbool GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE Type, 
							unsigned int  Width, unsigned int  Height, 
                            unsigned int  AlignX, unsigned int  AlignY, 
                            GLESOAL_MEMORY2D* pMemory2D )
{
	MESGPSOEM_Memory2D* pmem = MES_NEW( MESGPSOEM_Memory2D );

	if( ! pmem ){ return 0; }

	pmem->MemoryHandle = 0;

	if( Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
	{
#ifdef SUPPORT_MIPMAP
		if( ! __GLESOAL_Malloc2D(Width, Height, AlignX, AlignY,  pmem ) )
		{
			MES_DELETE(pmem);
			return 0;
		}
#else
		MES_DELETE(pmem);
		return 0;
#endif
	}
	else
	{
		if( ! MESGPSOEM_Malloc2D(Width, Height, AlignX, AlignY, pmem) )
		{
			MES_DELETE(pmem);
			return 0;
		}
	}

	pMemory2D->MemoryHandle = (unsigned long)pmem;
	pMemory2D->Width        	= pmem->Width;
	pMemory2D->Height       	= pmem->Height;
	pMemory2D->PhysicalSegment	= Segment(pmem->PhysicalAddress);
	pMemory2D->PhysicalSegX		= SegmentX(pmem->PhysicalAddress);
	pMemory2D->PhysicalSegY		= SegmentY(pmem->PhysicalAddress);
	pMemory2D->VirtualSegment	= Segment(pmem->VirtualAddress);
	pMemory2D->VirtualSegX		= SegmentX(pmem->VirtualAddress);
	pMemory2D->VirtualSegY		= SegmentY(pmem->VirtualAddress);
	pMemory2D->Type				= Type;

	//printf("2D Mem Alloc: %08x (%08x)\n", pMemory2D->MemoryHandle, pmem->MemoryHandle );
	return 1;
}

void GLESOAL_Free2D( GLESOAL_MEMORY2D* pMemory2D )
{
	if( !pMemory2D )
	{	return;	}
	
	if( !pMemory2D->MemoryHandle )
	{	return;	}

	MESGPSOEM_Memory2D* pmem = (MESGPSOEM_Memory2D*)(pMemory2D->MemoryHandle);
	//printf("2D Mem Free: %08x (%08x)\n", pMemory2D->MemoryHandle, pmem->MemoryHandle );

	if( pmem->MemoryHandle & 1 )
		__GLESOAL_Free2D(pmem);
	else
		MESGPSOEM_Free2D(pmem);
	MES_DELETE( pmem );
	
	// ��� ������� �ʱ�ȭ
	pMemory2D->PhysicalSegment	= 0;
	pMemory2D->PhysicalSegX		= 0;
	pMemory2D->PhysicalSegY		= 0;
	pMemory2D->VirtualSegment	= 0;
	pMemory2D->VirtualSegX		= 0;
	pMemory2D->VirtualSegY		= 0;
	pMemory2D->Type				= (GLESOAL_MEMORY2D_TYPE)0;
	pMemory2D->MemoryHandle		= 0;
}
//*/
void GLESOAL_PushDisplayAddressPatch( const GLESOAL_MEMORY2D* pDisplayBuffer )
{
	MESGPSOEM_SetDisplayAddress( (const MESGPSOEM_Memory2D*)pDisplayBuffer->MemoryHandle );
}

void GLESOAL_WaitForDisplayAddressPatched( void )
{
	MESGPSOEM_WaitForDirtyFlagCleared();
}

GLESOALbool GLESOAL_IsSoftwareSyncNeeded( void )
{
	return 1;
	//return g_GLESOAL_FSAA;
}

GLESOALbool GLESOAL_Initialize_Internal( GLESOALbool FSAAEnb )
{
	if(g_IsOpened){ return 0; }

	//OUTPUT_DEBUG_STRING(" - GLESOAL_Initialize_Internal.\n");
	g_GLESOAL_FSAA = FSAAEnb;

	MESGPSOEM_Config config;
	config.m_Size = sizeof(config);
	config.m_FSAA = FSAAEnb ? 1 : 0;
	if( MESGPSOEM_Initialize( &config ) )
	{
		if( MESGPSOEM_ClockEnable() )
		{
			if( (GLESOALbool)MESGPSOEM_OpenMalloc() )
			{
				//__Open_GLESOAL_ConvertColorSpace420();	// @Yuni �̵� ó���ҷ���.
				g_IsOpened = 1;
				return 1;
			}
			else 
			{
				MESGPSOEM_ClockDisable();
				MESGPSOEM_Finalize();
				return 0;
			}
		}
		else
		{
			MESGPSOEM_Finalize();
			return 0;
		}
	}
	else
	{
		return 0;
	}
}

void GLESOAL_Finalize( void )
{
	if( g_IsOpened )
	{
		MESGPSOEM_Hide3D();
		MESGPSOEM_ClockDisable();
		MESGPSOEM_CloseMalloc();
		MESGPSOEM_Finalize();
		//__Close_GLESOAL_ConvertColorSpace420();
		g_IsOpened = 0;

		MES_MEMORY_DEBUG_ReportMemoryLeak();
	}
}

int GLESOAL_GetDisplayDirection( void )
{
   static int s_DisplayDirection = -1;
   if( s_DisplayDirection < 0 )
   {
	   DEVMODE dm;
	   ZeroMemory(&dm, sizeof(dm));
	   dm.dmSize = sizeof(dm);
	   dm.dmFields = DM_DISPLAYORIENTATION;
	   if(DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettingsEx(NULL, &dm, NULL, CDS_TEST, NULL))
	   {
			switch( dm.dmDisplayOrientation )
			{
			case DMDO_0  : s_DisplayDirection = 0; break;
			case DMDO_90 : s_DisplayDirection = 1; break;
			case DMDO_180: s_DisplayDirection = 2; break;
			case DMDO_270: s_DisplayDirection = 3; break;
			default:       s_DisplayDirection = 0; break;
			}
			//switch( dm.dmDisplayOrientation )
			//{
			//case DMDO_0  : printf("DMDO_0\n"); break;
			//case DMDO_90 : printf("DMDO_90\n"); break;
			//case DMDO_180: printf("DMDO_180\n"); break;
			//case DMDO_270: printf("DMDO_270\n"); break;
			//}
	   }
	   else
	   { 
		  s_DisplayDirection = 0;
	   }
   }
   return s_DisplayDirection;
}

