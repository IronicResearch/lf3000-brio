#ifndef TIMER_H
#define TIMER_H

namespace __TUTORIAL7__
{

//Timer class, to control the FPS and the animations speed
class Timer
{
public:
  Timer();
  void UpdateTimer();  //This method updates the timer. May be called once in all frames
  unsigned long GetTimeBetweenTwoFrames()   {return m_diffTime;}; //returns the elapsed time between the current frame and the last frame
  unsigned long GetTotalTime()              {return m_accumTime;}; // return the time elapsed since the creation of the timer
  int GetFPS()                              {return m_fps;}; // returns the frames per second

private:        
  unsigned long m_diffTime;
  unsigned long m_accumTime;      
  unsigned long m_lastTime;		
	unsigned long m_frameTime;
  int m_fps;    
};

}//namespace

#endif
