//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glVertexPointer.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glVertexPointer (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
	CALL_LOG;
	if (type != GL_BYTE && type != GL_SHORT && type != GL_FIXED && type != GL_FLOAT)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (size < 2 || size > 4)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (stride < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (stride == 0)
	{
		switch (type)
		{
		case GL_BYTE:
			stride = sizeof (GLbyte) * size;
			break;

		case GL_SHORT:
			stride = sizeof (GLshort) * size;
			break;

		case GL_FIXED:
			stride = sizeof (GLfixed) * size;
			break;

		case GL_FLOAT:
			stride = sizeof (GLfloat) * size;
			break;

		}
	}
	
	__GLSTATE__.m_VertexPointer.m_Pointer = pointer;
	__GLSTATE__.m_VertexPointer.m_Stride = stride;
	__GLSTATE__.m_VertexPointer.m_Type = type;
	__GLSTATE__.m_VertexPointer.m_Size = size;
	__GLSTATE__.m_VertexPointer.m_Buffer = __GLSTATE__.m_BindedBuffer[0];
	__GLSTATE__.m_VertexPointer.SetSetStreamInfo(0);
}
