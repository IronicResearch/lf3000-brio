//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexSubImage2D.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
/*
GL_INVALID_ENUM is generated if target is not GL_TEXTURE_2D.
GL_INVALID_OPERATION is generated if the texture array has not been defined by a previous glTexImage2D or glCopyTexImage2D operation.
GL_INVALID_VALUE is generated if level is less than 0.
GL_INVALID_VALUE may be generated if level is greater than log2max, where max is the returned value of GL_MAX_TEXTURE_SIZE.
GL_INVALID_VALUE is generated if xoffset < - b, xoffset + width > (w - b) , yoffset < - b, or yoffset + height > (h - b) , where w is the texture width, h is the texture height, and b is the border of the texture image being modified. Note that w and h include twice the border width.
GL_INVALID_VALUE is generated if width or height is less than 0.
GL_INVALID_ENUM is generated if format is not an accepted constant.
GL_INVALID_ENUM is generated if type is not a type constant.
GL_INVALID_OPERATION is generated if type is GL_UNSIGNED_SHORT_5_6_5 and format is not GL_RGB.
GL_INVALID_OPERATION is generated if type is one of GL_UNSIGNED_SHORT_4_4_4_4, or GL_UNSIGNED_SHORT_5_5_5_1 and format is not GL_RGBA.
 */
namespace {
	GLint (* UploadTexture)( const GLESOAL_MEMORY2D* pMemory2D, 
								  unsigned int X, unsigned int Y,
								  unsigned int Width, unsigned int Height, 
								  const void* pSrc, unsigned int SrcStride );

	GLint (* UploadMipmap)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* GetMipmapPosition)(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
								  unsigned int *X, unsigned int *Y );

	GLboolean GetInfomation( GLenum format,	GLenum type, int &MemBitCount )
	{
		{
			switch( format )
			{
			case GL_ALPHA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						MemBitCount = 1;
						UploadTexture		= GLESOAL_UploadTexture_A8;
						UploadMipmap		= GLESOAL_UploadMipmap_U8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U8;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_RGB:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						MemBitCount = 3;
						UploadTexture		= GLESOAL_UploadTexture_RGB8;
						UploadMipmap		= GLESOAL_UploadMipmap_RGB8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_5_6_5 )
					{
						MemBitCount = 2;
						UploadTexture		= GLESOAL_UploadTexture_R5G6B5;
						UploadMipmap		= GLESOAL_UploadMipmap_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_RGBA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						MemBitCount = 4;
						UploadTexture		= GLESOAL_UploadTexture_RGBA8;
						UploadMipmap		= GLESOAL_UploadMipmap_RGBA8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_4_4_4_4 )
					{
						MemBitCount = 2;
						UploadTexture		= GLESOAL_UploadTexture_RGBA4;
						UploadMipmap		= GLESOAL_UploadMipmap_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_5_5_5_1 )
					{
						MemBitCount = 2;
						UploadTexture		= GLESOAL_UploadTexture_RGB5A1;
						UploadMipmap		= GLESOAL_UploadMipmap_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_LUMINANCE:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						MemBitCount = 1;
						UploadTexture		= GLESOAL_UploadTexture_L8;
						UploadMipmap		= GLESOAL_UploadMipmap_U8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U8;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_LUMINANCE_ALPHA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						MemBitCount = 2;
						UploadTexture = GLESOAL_UploadTexture_LA8;
						UploadMipmap = GLESOAL_UploadMipmap_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			default:
				GLSETERROR(GL_INVALID_VALUE);
				return GL_FALSE;;
			}
		}	
		return GL_TRUE;
	}
}

void glTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels)
{	
	CALL_LOG;

	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( (width < 0 || width > GL_MAX_TEXTURE_SIZE ) ||
		 (height < 0 || height > GL_MAX_TEXTURE_SIZE ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( type	!= GL_UNSIGNED_BYTE &&
		 type	!= GL_UNSIGNED_SHORT_5_6_5 &&
		 type	!= GL_UNSIGNED_SHORT_4_4_4_4 &&
		 type	!= GL_UNSIGNED_SHORT_5_5_5_1 )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject( __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] );
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( ! IsValidTextureFormat( ptexture->m_Format, format, type ) )
	{
		// GLSETERROR()�� IsValidTextureFormat �Լ� �ȿ��� �� ����.
		// ��쿡 ���� error ������ �޶� �ε����ϰ�.. -_-
		return;
	}

	if( ! ptexture->m_TextureDataMemory2D.MemoryHandle )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( (xoffset < -(ptexture->m_Border) ) || 
		(xoffset+width) > (ptexture->m_Width)-(ptexture->m_Border)	||
		(yoffset+height) > (ptexture->m_Height)-(ptexture->m_Border) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if( pixels == NULL )
		return;
	
	unsigned char* pNewSrc = NULL;
	const GLvoid* pSrc = NULL;
	
	GLint bytePerPixel_mem;
	if( !GetInfomation( format, type, bytePerPixel_mem ) )
		return;

	if( ( level == 0 ) && ( (1 !=ptexture->m_ScaleX) || (1 !=ptexture->m_ScaleY) ) )
	{
		int size = (int)( ( ( width * ptexture->m_ScaleX ) * ( height * ptexture->m_ScaleY ) ) * bytePerPixel_mem );
		pNewSrc = MES_NEW_ARRAY( unsigned char, size );
		
		//MakeValidMinTexture( pNewSrc, pixels, ptexture );
		MakeValidMinTexture( pNewSrc, pixels, bytePerPixel_mem * 8, width, height, ptexture->m_ScaleX, ptexture->m_ScaleY );
		pSrc = (GLvoid*)pNewSrc;
	}
	else
		pSrc = pixels;	

	while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
	
	//if( pixels )
	{
		if( level == 0 )	// level 0�̸� �׳� update
		{
			UploadTexture( &ptexture->m_TextureDataMemory2D, 
						xoffset * ptexture->m_ScaleX, yoffset * ptexture->m_ScaleY, 
						width * ptexture->m_ScaleX, height * ptexture->m_ScaleY, 
						pSrc, bytePerPixel_mem * width * ptexture->m_ScaleX );
		}
		else
		{
			// mipmap�� ���µ� subtex�� �����Ϸ� �ϸ� �����?
			if( ptexture->m_TextureDataMemory2D.Type != GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
			{
				goto error;
			}

			unsigned int x, y;
			if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			if( !UploadMipmap( &ptexture->m_TextureDataMemory2D, x + xoffset, y + yoffset, width, height, pSrc, bytePerPixel_mem*width ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
	}
	
	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );

	ptexture->m_IsUpdated = GL_TRUE;
	ptexture->m_ContentsIsUpdated = GL_TRUE;
	return;
	
error:
	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );
		
	return;
}
