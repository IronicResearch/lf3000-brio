//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : renderprimitives.cpp
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2008/09/11 Yuni	 Matrix palette�� vertex stream�� data format�� matrix index�� ���˿� ������ �޴� ���� ����.
//	    2008/03/20 Yuni	 Two side lighting ����.
//		2007/09/07 Yuni	 UpdateTexture ����. -> size�� 0�� texture�� ��� disable ���·� ����.
//		2007/09/07 Yuni	 GTEconst�� weight�� 0���� �ʱ�ȭ.
//		2007/09/07 Yuni	 m_CurrentPrimitive�� �ʱ�ȭ�� �� matrix palette�� null�� ����� ���� ����.
//						 matrix palette�� ���ο��� ������ �ִ� ���̹Ƿ� ������ �ʿ� ����.
//		2007/06/01 Yuni  first implementation
//------------------------------------------------------------------------------
//#include <cstring>
#include <string.h>
#include "glstate.h"
#include "renderprimitives.h"
#include "gtecode.h"

#include <stdio.h>
// internal funcitons
namespace {

#define INV_S8		( 2.0f/(float)( (1<<8)-1 ) )
#define INV_S16		( 2.0f/(float)( (1<<16)-1 ) )

#define	GTE_CONST_DEST			(0x1000/4)

typedef enum 
{
	VERTEXSTREAM_MATRIXINDEX	= 0,
	VERTEXSTREAM_POSITION		= 1,
	VERTEXSTREAM_COLOR			= 2,
	VERTEXSTREAM_TEXCOORD0		= 3,
	VERTEXSTREAM_TEXCOORD1		= 4,
	VERTEXSTREAM_NORMAL			= 5,
	VERTEXSTREAM_POINTSIZE		= 6,
	VERTEXSTREAM_WEIGHT			= 6,
	VERTEXSTREAM_MATRIXPALETTE	= 7,
	VERTEXSTREAM_FORCES32		= 0x7FFFFFFF
}VERTEXSTREAM;

	const void* GetEffectiveAddress( const __POINTER__& Pointer, __BUFFER__* pBuffer, GLint first, GLsizei count )
	{
		if ( !pBuffer ){ return 0; }
		unsigned int offset = static_cast<const char *>(Pointer.m_Pointer) - static_cast<const char *>(0);
		const void* psrc = (const char*)pBuffer->m_DataMemory1D.PhysicalAddress 
							+ offset + (Pointer.m_Stride * first);
		return psrc;
	}

	const void* GetEffectiveAddress_DefaultBuffer( const __POINTER__& Pointer, __BUFFER__* pBuffer, GLint first, GLsizei count )
	{
		unsigned int pointerSize = Pointer.m_Stride * count;
		const void* psrc = (const char*)(Pointer.m_Pointer) + (Pointer.m_Stride * first);
		if( pBuffer->m_DataMemory1D.MemoryHandle )
		{
			// buffer�� ������̶�� ��ٸ���.
			while( pBuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() ){}
			if( pBuffer->m_DataMemory1D.Size < pointerSize )
			{
				GLESOAL_Free1D( &pBuffer->m_DataMemory1D );
				GLESOAL_Malloc1D( pointerSize, 8, &pBuffer->m_DataMemory1D );
			}
		}
		else 
		{
			GLESOAL_Malloc1D( pointerSize, 8, &pBuffer->m_DataMemory1D );
		}
		memcpy( (void*)(pBuffer->m_DataMemory1D.VirtualAddress), psrc, pointerSize );
		return (const char*)pBuffer->m_DataMemory1D.PhysicalAddress;
	}

	const void* GetIndexAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_IndexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = __BUFFER_POOL__.GetObject(__GLSTATE__.m_IndexPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_IndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pIndex, first, count );
		}
		else
		{
			if( __GLSTATE__.m_IndexPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultIndexBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = &__GLSTATE__.m_DefaultIndexBuffer[__GLSTATE__.m_DefaultIndexBuffer_Index];
			__GLSTATE__.m_DefaultIndexBuffer_Index = (__GLSTATE__.m_DefaultIndexBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultIndexBuffer)/sizeof(__GLSTATE__.m_DefaultIndexBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_IndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pIndex, first, count );
		}
	}

	const void* GetPositionAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_VertexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = __BUFFER_POOL__.GetObject(__GLSTATE__.m_VertexPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_VertexPointer, __GLSTATE__.m_CurrentPrimitive.m_pPosition, first, count );
		}
		else
		{
			if( __GLSTATE__.m_VertexPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				//printf( "__GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE: %d, %d\n", __GLSTATE__.m_VertexPointer.m_Stride, count );
				__GLSTATE__.m_DefaultPositionBuffer_Index = __GLSTATE__.m_DefaultPositionBuffer_Index % __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = &__GLSTATE__.m_DefaultPositionBuffer[__GLSTATE__.m_DefaultPositionBuffer_Index];
			__GLSTATE__.m_DefaultPositionBuffer_Index = (__GLSTATE__.m_DefaultPositionBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultPositionBuffer)/sizeof(__GLSTATE__.m_DefaultPositionBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
/*
			unsigned __int64 currear = GLESHAL_GetRearOfCommandQueue();
			static int maxwaitcount=0;
			int waitcount=0;
			for( int i=0; i<(sizeof(__GLSTATE__.m_DefaultPositionBuffer)/sizeof(__GLSTATE__.m_DefaultPositionBuffer[0])); i++ )
			{
				if( __GLSTATE__.m_DefaultPositionBuffer[i].m_UsedPoint )
				{
					if( __GLSTATE__.m_DefaultPositionBuffer[i].m_UsedPoint > currear )
					{
						waitcount++;
					}
				}
			}
			if( maxwaitcount < waitcount )
			{
				maxwaitcount = waitcount;
				printf( "maxwaitcount : %d\n", maxwaitcount );
			}
//*/
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_VertexPointer, __GLSTATE__.m_CurrentPrimitive.m_pPosition, first, count );
		}
	}

	const void* GetColorAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_ColorPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pColor = __BUFFER_POOL__.GetObject(__GLSTATE__.m_ColorPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_ColorPointer, __GLSTATE__.m_CurrentPrimitive.m_pColor, first, count );
		}
		else
		{
			if( __GLSTATE__.m_ColorPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultColorBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pColor = &__GLSTATE__.m_DefaultColorBuffer[__GLSTATE__.m_DefaultColorBuffer_Index];
			__GLSTATE__.m_DefaultColorBuffer_Index = (__GLSTATE__.m_DefaultColorBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultColorBuffer)/sizeof(__GLSTATE__.m_DefaultColorBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_ColorPointer, __GLSTATE__.m_CurrentPrimitive.m_pColor, first, count );
		}		
	}

	const void* GetNormalAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_NormalPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = __BUFFER_POOL__.GetObject(__GLSTATE__.m_NormalPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_NormalPointer, __GLSTATE__.m_CurrentPrimitive.m_pNormal, first, count );
		}
		else
		{
			if( __GLSTATE__.m_NormalPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultNormalBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = &__GLSTATE__.m_DefaultNormalBuffer[__GLSTATE__.m_DefaultNormalBuffer_Index];
			__GLSTATE__.m_DefaultNormalBuffer_Index = (__GLSTATE__.m_DefaultNormalBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultNormalBuffer)/sizeof(__GLSTATE__.m_DefaultNormalBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_NormalPointer, __GLSTATE__.m_CurrentPrimitive.m_pNormal, first, count );
		}		
	}

	const void* GetPointSizeAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_PointSizePointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = __BUFFER_POOL__.GetObject(__GLSTATE__.m_PointSizePointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_PointSizePointer, __GLSTATE__.m_CurrentPrimitive.m_pPointSize, first, count );
		}
		else
		{
			if( __GLSTATE__.m_PointSizePointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultPointSizeBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = &__GLSTATE__.m_DefaultPointSizeBuffer[__GLSTATE__.m_DefaultPointSizeBuffer_Index];
			__GLSTATE__.m_DefaultPointSizeBuffer_Index = (__GLSTATE__.m_DefaultPointSizeBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultPointSizeBuffer)/sizeof(__GLSTATE__.m_DefaultPointSizeBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_PointSizePointer, __GLSTATE__.m_CurrentPrimitive.m_pPointSize, first, count );
		}		
	}

	const void* GetWeightAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_WeightPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = __BUFFER_POOL__.GetObject(__GLSTATE__.m_WeightPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_WeightPointer, __GLSTATE__.m_CurrentPrimitive.m_pWeight, first, count );
		}
		else
		{
			if( __GLSTATE__.m_WeightPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultWeightBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = &__GLSTATE__.m_DefaultWeightBuffer[__GLSTATE__.m_DefaultWeightBuffer_Index];
			__GLSTATE__.m_DefaultWeightBuffer_Index = (__GLSTATE__.m_DefaultWeightBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultWeightBuffer)/sizeof(__GLSTATE__.m_DefaultWeightBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_WeightPointer, __GLSTATE__.m_CurrentPrimitive.m_pWeight, first, count );
		}
	}

	const void* GetTexCoordAddress( GLint index, GLint first, GLsizei count )
	{
		if( index >=  GLPARAM_MAX_TEXTURE_UNITS )
			return NULL;

		if( __GLSTATE__.m_TexturePointer[index].m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index] = __BUFFER_POOL__.GetObject(__GLSTATE__.m_TexturePointer[index].m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_TexturePointer[index], __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index], first, count );
		}
		else
		{
			if( __GLSTATE__.m_TexturePointer[index].m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultTexCoordBuffer_Index %= (__GLSTATESET__::DEFAULT_BUFFERS_BIG*GLPARAM_MAX_TEXTURE_UNITS);
			}
			__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index] = &__GLSTATE__.m_DefaultTexCoordBuffer[__GLSTATE__.m_DefaultTexCoordBuffer_Index];
			__GLSTATE__.m_DefaultTexCoordBuffer_Index = (__GLSTATE__.m_DefaultTexCoordBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultTexCoordBuffer)/sizeof(__GLSTATE__.m_DefaultTexCoordBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_TexturePointer[index], __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index], first, count );
		}
	}

	const void* GetMatrixIndexAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_MatrixIndexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = __BUFFER_POOL__.GetObject(__GLSTATE__.m_MatrixIndexPointer.m_Buffer);
			return GetEffectiveAddress( __GLSTATE__.m_MatrixIndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex, first, count );
		}
		else
		{
			if( __GLSTATE__.m_MatrixIndexPointer.m_Stride * count > __GLSTATESET__::DEFAULT_BUFFERS_MAXSIZE )
			{
				__GLSTATE__.m_DefaultMatrixIndexBuffer_Index %= __GLSTATESET__::DEFAULT_BUFFERS_BIG;
			}
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = &__GLSTATE__.m_DefaultMatrixIndexBuffer[__GLSTATE__.m_DefaultMatrixIndexBuffer_Index];
			__GLSTATE__.m_DefaultMatrixIndexBuffer_Index = (__GLSTATE__.m_DefaultMatrixIndexBuffer_Index+1)%(sizeof(__GLSTATE__.m_DefaultMatrixIndexBuffer)/sizeof(__GLSTATE__.m_DefaultMatrixIndexBuffer[0]));
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			return GetEffectiveAddress_DefaultBuffer( __GLSTATE__.m_MatrixIndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex, first, count );
		}
	}


	GLboolean GetHALVertexType( GLenum type, GLESHAL_VSTYPE& HALType )
	{
		switch( type )
		{
		case GL_UNSIGNED_BYTE:
			HALType = GLESHAL_VSTYPE_U8;
			break;
		case GL_BYTE:
			HALType = GLESHAL_VSTYPE_S8;
			break;
		case GL_SHORT:
			HALType = GLESHAL_VSTYPE_S16;
			break;
		case GL_FIXED:
			HALType = GLESHAL_VSTYPE_FIXED;
			break;
		case GL_FLOAT:
			HALType = GLESHAL_VSTYPE_FLOAT;
			break;
		
		default:
			return GL_FALSE;
		}
		return GL_TRUE;
	}

	GLboolean UpdateMatrixPaletteState( void )
	{
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0		
		__BUFFER__* pbuffer = __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette;
		if( !pbuffer || !pbuffer->m_DataMemory1D.MemoryHandle )
			return GL_FALSE;

		while( pbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.


		Matrix4x4 curMatrix;
		Matrix4x4 curInvMatrix;
		Matrix4x4 curInvTransMatrix;

		if( __GLSTATE__.m_IsLightTurnON )	// matrix palette�� ��ü inverse matrix�� ���ض�.
		{
			float mat[32];
			for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
			{
				// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
				unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];

				for( int j=0; j<8; j++ )
				{
					curInvMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentInverseMatrix();
					M4_TRANSPOSE( curInvTransMatrix, curInvMatrix );
					MatrixToFloat( &mat[16], curInvTransMatrix );
					if( curIndex & (1<<j) )
					{
						// update
						curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
						MatrixToFloat( mat, curMatrix );

						char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
						memcpy( pData, mat, sizeof(float) * 32 );
					}
					else
					{
						char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float)*((i*8+j) * 32 + 16) );
						memcpy( pData, mat, sizeof(float) * 16 );
					}
				}
				__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
				__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			}
			__GLSTATE__.m_IsLightTurnON = GL_FALSE;
		}
		else
		{
			if( __GLSTATE__.m_Enable_LIGHTING )	// transform & inverse transform �� �� copy.
			{
				float mat[32];

				for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
				{
					// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
					unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];
					if( curIndex )
					{
						for( int j=0; j<8; j++ )
						{
							if( curIndex & (1<<j) )
							{
								// update
								curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
								curInvMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentInverseMatrix();
								M4_TRANSPOSE( curInvTransMatrix, curInvMatrix )
								MatrixToFloat( mat, curMatrix );
								MatrixToFloat( &mat[16], curInvTransMatrix );

								char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
								memcpy( pData, mat, sizeof(float) * 32 );
							}
						}
						__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
						__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
					}
				}
			}
			else	// transform�� copy.
			{
				float mat[16];

				for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
				{
					// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
					unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];
					if( curIndex )
					{
						for( int j=0; j<8; j++ )
						{
							if( curIndex & (1<<j) )
							{
								// update
								curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
								MatrixToFloat( mat, curMatrix );
								char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
								memcpy( pData, mat, sizeof(float) * 16 );
							}
						}
						__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
						__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
					}
				}
			}
		}
#endif // GLPARAM_MAX_PALETTE_MATRICES_OES > 0		
		return GL_TRUE;
	}


	void SetTextureBlendMode( unsigned int textureStage, GLenum TextureFormat )
	{
		if( !(__GLSTATE__.m_TexEnv[textureStage].m_IsEnable) )
		{
			if( 0 == textureStage )
				GLESHAL_SetTextureBlend( 0, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C,
										GLESHAL_RGBOP_REPLACE, 
										GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A,
										GLESHAL_AOP_REPLACE );
											
			else if( 1 == textureStage )
				GLESHAL_SetTextureBlend( 1, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C,
										GLESHAL_RGBOP_REPLACE, 
										GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A,
										GLESHAL_AOP_REPLACE );				
			
		}
		else
		{
			GLESHAL_RGBARG	rgbArg[3] = { 
					GLESHAL_RGBARG_FRAGMENT_C, 
					GLESHAL_RGBARG_FRAGMENT_C, 
					GLESHAL_RGBARG_FRAGMENT_C 
			};
			GLESHAL_RGBOP	rgbOp = GLESHAL_RGBOP_REPLACE;
			GLESHAL_AARG	aArg[3] = {
					GLESHAL_AARG_FRAGMENT_A,
					GLESHAL_AARG_FRAGMENT_A, 
					GLESHAL_AARG_FRAGMENT_A
			};
			GLESHAL_AOP		aOp = GLESHAL_AOP_REPLACE;
			GLESHAL_RGBARG	rgbPreArg;
			GLESHAL_AARG	aPreArg;

			// 1. Stage level check
			// 2. Internal format check
			if( 0 == textureStage )
			{
				rgbPreArg		= GLESHAL_RGBARG_FRAGMENT_C;
				aPreArg			= GLESHAL_AARG_FRAGMENT_A;
			}
			else	
			{
				rgbPreArg		= GLESHAL_RGBARG_PREVIOUS_C;
				aPreArg			= GLESHAL_AARG_PREVIOUS_A;			
			}

			__TEXENV__* ptexenv = &__GLSTATE__.m_TexEnv[textureStage];

			switch( ptexenv->m_TEXTURE_ENV_MODE )
			{
				case GL_REPLACE:
				{
					if( GL_ALPHA == TextureFormat )
					{
						rgbArg[0] = rgbPreArg;
						aArg[0]	= GLESHAL_AARG_SOURCE_A;
					}
					else if(( GL_LUMINANCE_ALPHA == TextureFormat ) || ( GL_RGBA == TextureFormat ))
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						aArg[0]	= GLESHAL_AARG_SOURCE_A;
					}
					else
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						aArg[0]	= aPreArg;
					}
					rgbOp	= GLESHAL_RGBOP_REPLACE;
					aOp		= GLESHAL_AOP_REPLACE;
				}
				break;

				case GL_MODULATE:
				{ 
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_SOURCE_C;
					
					if( GL_ALPHA == TextureFormat )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else
						rgbOp	= GLESHAL_RGBOP_MODULATE;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;
				
				case GL_DECAL:
				{
					if(( GL_RGB == TextureFormat ) || ( GL_RGBA == TextureFormat ))
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						rgbArg[1] = rgbPreArg;		
						rgbArg[2] = GLESHAL_RGBARG_SOURCE_A;
						rgbOp	= GLESHAL_RGBOP_INTERPOLATE;

						aArg[0]	= aPreArg;
						aOp		= GLESHAL_AOP_REPLACE;
					}
					else
					{
						//GLSETERROR(GL_INVALID_VALUE);
						return;
					}
				}
				break;

				case GL_ADD:
				{
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_SOURCE_C;
					
					if( GL_ALPHA == TextureFormat )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else				
						rgbOp	= GLESHAL_RGBOP_ADD;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;

				case GL_BLEND:
				{
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_CONST_C;
					rgbArg[2] = GLESHAL_RGBARG_SOURCE_1_C;
					
					if( GL_ALPHA == TextureFormat )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else				
						rgbOp	= GLESHAL_RGBOP_INTERPOLATE;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;

				case GL_COMBINE:
				{
					int previousSrcNum = 3;
					if( 0 == textureStage )
						previousSrcNum = 2;
					
					for( int i=0; i<3; i++ )
					{
						int srcNum = 0;
						int opNum = 0;
						
						// RGB args
						if( GL_TEXTURE == ptexenv->m_SRC_RGB[i] )				srcNum = 0;
						else if(  GL_CONSTANT == ptexenv->m_SRC_RGB[i] )		srcNum = 1;
						else if(  GL_PRIMARY_COLOR == ptexenv->m_SRC_RGB[i] )	srcNum = 2;
						else if( GL_PREVIOUS == ptexenv->m_SRC_RGB[i] )			srcNum = previousSrcNum;
						/*
						{
							if( 0 == __GLSTATE__.m_ActiveTexture )	srcNum = 2;
							else									srcNum = 3;
						}
						*/

						if( GL_SRC_COLOR == ptexenv->m_OPERAND_RGB[i] )					opNum = 0;
						else if( GL_ONE_MINUS_SRC_COLOR == ptexenv->m_OPERAND_RGB[i] )	opNum = 1;
						else if( GL_SRC_ALPHA == ptexenv->m_OPERAND_RGB[i] )			opNum = 2;
						else if( GL_ONE_MINUS_SRC_ALPHA == ptexenv->m_OPERAND_RGB[i] )	opNum = 3;

						rgbArg[i] = (GLESHAL_RGBARG)( srcNum*4 + opNum );

						// ALPHA args
						if( GL_TEXTURE == ptexenv->m_SRC_ALPHA[i] )				srcNum = 0;
						else if(  GL_CONSTANT == ptexenv->m_SRC_ALPHA[i] )		srcNum = 1;
						else if(  GL_PRIMARY_COLOR == ptexenv->m_SRC_ALPHA[i] )	srcNum = 2;
						else if( GL_PREVIOUS == ptexenv->m_SRC_ALPHA[i] )		srcNum = previousSrcNum;
						/*
						{
							if( 0 == __GLSTATE__.m_ActiveTexture )	srcNum = 2;
							else									srcNum = 3;
						}
						*/

						if( GL_SRC_ALPHA == ptexenv->m_OPERAND_ALPHA[i] )					opNum = 0;
						else if( GL_ONE_MINUS_SRC_ALPHA == ptexenv->m_OPERAND_ALPHA[i] )	opNum = 1;

						aArg[i] = (GLESHAL_AARG)( srcNum*2 + opNum );
					}

					// RGB Operand
					if( GL_REPLACE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_REPLACE;
					else if( GL_MODULATE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_MODULATE;
					else if( GL_ADD == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_ADD;
					else if( GL_ADD_SIGNED == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_ADD_SIGNED;
					else if( GL_INTERPOLATE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_INTERPOLATE;
					else if( GL_SUBTRACT == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_SUBTRACT;
					else if( GL_DOT3_RGB == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_DOT3_RGB;
					else if( GL_DOT3_RGBA == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_DOT3_RGBA;

					// ALPHA Operand
					if( GL_REPLACE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_REPLACE;
					else if( GL_MODULATE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_MODULATE;
					else if( GL_ADD == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_ADD;
					else if( GL_ADD_SIGNED == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_ADD_SIGNED;
					else if( GL_INTERPOLATE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_INTERPOLATE;
					else if( GL_SUBTRACT == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_SUBTRACT;

				}
				break;
			default:
				return;
			}

			GLESHAL_SetTextureBlend( textureStage, 
									rgbArg[0], rgbArg[1], rgbArg[2], rgbOp, 
									aArg[0], aArg[1], aArg[2], aOp );		
		}
	}	

	// Set fog to HAL
	void SetFog( void )
	{
		GLESHAL_FOGMODE fogMode;
		
		if( GL_LINEAR == __GLSTATE__.m_FogMode )
		{
			GLESHAL_SetLinearFog( VF2F(__GLSTATE__.m_FogStart), VF2F(__GLSTATE__.m_FogEnd) );
		}
		else
		{
			if( GL_EXP == __GLSTATE__.m_FogMode )
				fogMode = GLESHAL_FOGMODE_EXP;
			else
				fogMode = GLESHAL_FOGMODE_EXP2;
			
			GLESHAL_SetFog( fogMode, VF2F(__GLSTATE__.m_FogDensity) );
		}
		
		GLESHAL_SetFogColor( VF2F(__GLSTATE__.m_FogColor[0]),
						     VF2F(__GLSTATE__.m_FogColor[1]),
						     VF2F(__GLSTATE__.m_FogColor[2]),
						     VF2F(__GLSTATE__.m_FogColor[3]) );
						     
		__GLSTATE__.m_IsFogUpdated = GL_FALSE;
	}

	unsigned int __GetStreamInfo( int StreamType, int Type, int Size )
	{
		GLESHAL_VSTYPE HALType;
		if( !GetHALVertexType( Type, HALType ) ){ return 0; }
		if ( GLESHAL_VSTYPE_U8 == HALType && StreamType==1 ){ HALType = GLESHAL_VSTYPE_NORMALIZED_U8; }
		const static unsigned int destaddr[] = 
		{
			((GTE_CONST_DEST + __Position_dest     )<<20),// 0
			((GTE_CONST_DEST + __Color_dest        )<<20),// 1
			((GTE_CONST_DEST + __Normal_dest       )<<20),// 2
			((GTE_CONST_DEST + 15*4                )<<20),// 3
			((GTE_CONST_DEST + __Weight_dest       )<<20),// 4
			((GTE_CONST_DEST + __MatrixPalette_dest)<<20),// 5
			((GTE_CONST_DEST + __PointSize_dest    )<<20),// 6
			((GTE_CONST_DEST + __Tex0_dest + 0*4   )<<20),// 7
			((GTE_CONST_DEST + __Tex0_dest + 1*4   )<<20) // 8
		};
		return destaddr[StreamType] | ((Size - 1)<<8) | (unsigned int)HALType;
	}

}	// namespace

namespace __MES_OPENGL_ES__ {

void __POINTER__::SetSetStreamInfo( int StreamType )
{
	m_HALInfo = __GetStreamInfo( StreamType, m_Type, m_Size );
}

namespace
{
	float gteConst[4*7];
	bool updatedefaultinput=false;
	unsigned int vertexStream[3*8];
	unsigned int bufferenableflag;

	GLint   __first;
	GLsizei __count;

	float __ConstForNormalize__;	

	void __SetDefault_Pos( void )
	{
		gteConst[__Position_dest + 0] = 0.0f;
		gteConst[__Position_dest + 1] = 0.0f;
		gteConst[__Position_dest + 2] = 0.0f;
		gteConst[__Position_dest + 3] = 1.0f;
		updatedefaultinput = true;
	}
	void __SetDefault_Color( bool updatedefaultinput_color )
	{
		if( __GLSTATE__.m_ClientState_COLOR_ARRAY )
		{ 
			bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_COLOR); 
			static int LastPointerSize_Color = 100;
			int        CurPointerSize_Color  = __GLSTATE__.m_ColorPointer.m_Size;
			if( LastPointerSize_Color > CurPointerSize_Color || updatedefaultinput_color )
			{
				gteConst[__Color_dest + 0] = 0.0f;
				gteConst[__Color_dest + 1] = 0.0f;
				gteConst[__Color_dest + 2] = 0.0f;
				gteConst[__Color_dest + 3] = 1.0f;
				updatedefaultinput = true;
			}
			LastPointerSize_Color = CurPointerSize_Color;

			vertexStream[ VERTEXSTREAM_COLOR * 3 + 0 ] = (unsigned int)(GetColorAddress( __first, __count ));
			vertexStream[ VERTEXSTREAM_COLOR * 3 + 1 ] = __GLSTATE__.m_ColorPointer.m_Stride;
			vertexStream[ VERTEXSTREAM_COLOR * 3 + 2 ] = __GLSTATE__.m_ColorPointer.m_HALInfo;
		}
		else if( updatedefaultinput_color || __GLSTATE__.m_UpdateCurrentColor )
		{
			gteConst[__Color_dest + 0] = VF2F(__GLSTATE__.m_CurrentColor[0]);
			gteConst[__Color_dest + 1] = VF2F(__GLSTATE__.m_CurrentColor[1]);
			gteConst[__Color_dest + 2] = VF2F(__GLSTATE__.m_CurrentColor[2]);
			gteConst[__Color_dest + 3] = VF2F(__GLSTATE__.m_CurrentColor[3]);
			__GLSTATE__.m_UpdateCurrentColor = false;
			updatedefaultinput = true;
		}
	}
	void __SetDefault_Normal( bool updatedefaultinput_normal )
	{
		if( (__GLSTATE__.m_ClientState_NORMAL_ARRAY) && (__GLSTATE__.m_Enable_LIGHTING) ) 
		{
			bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_NORMAL); 
			//float normalized;
			switch( __GLSTATE__.m_NormalPointer.m_Type )
			{
			case GL_BYTE:
				__ConstForNormalize__ = INV_S8;
				break;
			case GL_SHORT:
				__ConstForNormalize__ = INV_S16;
				break;
			default:
				__ConstForNormalize__ = 1.0f;
				break;
			}
			gteConst[__Normalize_const_dest + 0] = __ConstForNormalize__;
			gteConst[__Normalize_const_dest + 1] = __ConstForNormalize__;
			gteConst[__Normalize_const_dest + 2] = __ConstForNormalize__;
			gteConst[__Normalize_const_dest + 3] = 1.0f;
			gteConst[__Normal_dest + 0] = 0.0f;
			gteConst[__Normal_dest + 1] = 0.0f;
			gteConst[__Normal_dest + 2] = 1.0f;
			updatedefaultinput = true;

			vertexStream[ VERTEXSTREAM_NORMAL * 3 + 0 ] = (unsigned int)(GetNormalAddress( __first, __count ));
			vertexStream[ VERTEXSTREAM_NORMAL * 3 + 1 ] = __GLSTATE__.m_NormalPointer.m_Stride;
			vertexStream[ VERTEXSTREAM_NORMAL * 3 + 2 ] = __GLSTATE__.m_NormalPointer.m_HALInfo;
		}
		else if( updatedefaultinput_normal || __GLSTATE__.m_UpdateDefaultNormal )
		{
			__ConstForNormalize__ = 1.0f;
			gteConst[__Normalize_const_dest + 0] = 1.0f;
			gteConst[__Normalize_const_dest + 1] = 1.0f;
			gteConst[__Normalize_const_dest + 2] = 1.0f;
			gteConst[__Normalize_const_dest + 3] = 1.0f;

			gteConst[__Normal_dest + 0] = VF2F(__GLSTATE__.m_DefaultNormal.x);
			gteConst[__Normal_dest + 1] = VF2F(__GLSTATE__.m_DefaultNormal.y);
			gteConst[__Normal_dest + 2] = VF2F(__GLSTATE__.m_DefaultNormal.z);
			__GLSTATE__.m_UpdateDefaultNormal = false;
			updatedefaultinput = true;
		}

	}
	bool __SetDefault_MatrixPalette( void )
	{
		updatedefaultinput = true;
		bufferenableflag |= ( (1<<GLESHAL_VERTEXSTREAM_MATRIXINDEX) |
							( 1<<GLESHAL_VERTEXSTREAM_WEIGHT )		|
							( 1<<GLESHAL_VERTEXSTREAM_MATRIXPALETTE) );

		gteConst[__PointSize_dest] = (float)(__GLSTATE__.m_PointSize);
		//gteConst[__PointSize_dest] = 0.0f;

		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 0 ] = (unsigned int)(GetMatrixIndexAddress( __first, __count ));
		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 1 ] = __GLSTATE__.m_MatrixIndexPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 2 ] = __GLSTATE__.m_MatrixIndexPointer.m_HALInfo;

		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 0 ] = (unsigned int)(GetWeightAddress( __first, __count ));
		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 1 ] = __GLSTATE__.m_WeightPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 2 ] = __GLSTATE__.m_WeightPointer.m_HALInfo;

		gteConst[__Weight_dest + 0] = 0.0f;
		gteConst[__Weight_dest + 1] = 0.0f;
		gteConst[__Weight_dest + 2] = 0.0f;
		gteConst[__Weight_dest + 3] = 0.0f;	

		if( !UpdateMatrixPaletteState() )	// ����� matrix palette update
			return false;

		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 0 ] = (unsigned int)(__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_DataMemory1D.PhysicalAddress);
		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 1 ] = __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_Size * sizeof(GLfloat);
		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 2 ] = __GetStreamInfo( 5, GL_FLOAT, __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_Size );
		return true;
	}
	void __SetDefault_PointSize( bool updatedefaultinput_pointsize )
	{
		if( __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES )
		{ 
			bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_POINTSIZE);
			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 0 ] = (unsigned int)(GetPointSizeAddress( __first, __count ));
			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 1 ] = __GLSTATE__.m_PointSizePointer.m_Stride;
			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 2 ] = __GLSTATE__.m_PointSizePointer.m_HALInfo;
		}
		else if( updatedefaultinput_pointsize || __GLSTATE__.m_UpdataPointSize )
		{
			gteConst[__PointSize_dest] = VF2F(__GLSTATE__.m_PointSize);
			__GLSTATE__.m_UpdataPointSize = false;
			updatedefaultinput = true;
		}
	}

	void __SetDefault_Texture( int i, bool updatedefaultinput_texture )
	{
		if( __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[i] )
		{
			bufferenableflag |= (1<<(GLESHAL_VERTEXSTREAM_TEXCOORD0+i)); 

			static int LastPointerSize_Texture[GLPARAM_MAX_TEXTURE_UNITS] = {100,100};
			int        CurPointerSize_Texture = __GLSTATE__.m_TexturePointer[i].m_Size;
			if( LastPointerSize_Texture[i] > CurPointerSize_Texture || updatedefaultinput_texture )
			{
				gteConst[__Tex0_dest + 4*i + 0] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 1] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 2] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 3] = 1.0f;
				updatedefaultinput = true;
			}
			LastPointerSize_Texture[i] = CurPointerSize_Texture;

			vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 0 ] = (unsigned int)GetTexCoordAddress( i, __first, __count );
			vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 1 ] = __GLSTATE__.m_TexturePointer[i].m_Stride;
			vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 2 ] = __GLSTATE__.m_TexturePointer[i].m_HALInfo;
		}
		else if( updatedefaultinput_texture || __GLSTATE__.m_UpdateDefaultTexCoord[i] )
		{
			gteConst[__Tex0_dest + 4*i + 0] = VF2F(__GLSTATE__.m_DefaultTexCoord[i][0]);
			gteConst[__Tex0_dest + 4*i + 1] = VF2F(__GLSTATE__.m_DefaultTexCoord[i][1]);
			gteConst[__Tex0_dest + 4*i + 2] = 0.0f;//VF2F(__GLSTATE__.m_DefaultTexCoord[i][2]); // �����ϱ�� spec�� ���õǾ� ����.
			gteConst[__Tex0_dest + 4*i + 3] = 1.0f;//VF2F(__GLSTATE__.m_DefaultTexCoord[i][3]);
			__GLSTATE__.m_UpdateDefaultTexCoord[i] = false;
			updatedefaultinput = true;
		}
	}

	struct Auto_ClearTexEnvUpdate
	{
		~Auto_ClearTexEnvUpdate()
		{
			__GLSTATE__.m_TexEnv[0].m_IsUpdated = GL_FALSE;
			__GLSTATE__.m_TexEnv[1].m_IsUpdated = GL_FALSE;
		}
	};

	void UpdateTexEnv_Body( void )
	{
		Auto_ClearTexEnvUpdate _Auto_ClearTexEnvUpdate;

		GLboolean isValidTex[GLPARAM_MAX_TEXTURE_UNITS];
		__TEXTURE__* ptexture[GLPARAM_MAX_TEXTURE_UNITS];
		
		int i;
		// size�� 0�� ��� disable ���·� ���. (spec ����)
		// enable ���¶�� ptexture�� �ش� texture ���.
		for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_TexEnv[i].m_IsEnable )
			{
				ptexture[i] = __TEXTURE_POOL__.GetObject( __GLSTATE__.m_BindedTexture[i] );
				if( !ptexture[i] || !ptexture[i]->m_Width || !ptexture[i]->m_Height )	// width or height�� 0�̸�.
				{
					ptexture[i] = &__GLSTATE__.m_DefaultTexture;
					isValidTex[i] = GL_FALSE;
				}
				else
				{
					isValidTex[i] = GL_TRUE;
				}
			}
			else
			{
				ptexture[i] = &__GLSTATE__.m_DefaultTexture;
				isValidTex[i] = GL_FALSE;
			}
		}

		unsigned long curRenderState = GLESHAL_GetRenderState();
		// texture const color�� ���� enable �Ǿ� �ִ� texture�� env color�� ����.
		// render state ����.
		if( isValidTex[0] )
		{
			if( __GLSTATE__.m_TexEnv[0].m_IsUpdated )
			{
	//			printf( "__GLSTATE__.m_TexEnv[0].m_IsUpdated\n" );
				GLESHAL_SetTextureConstColor( VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[0]),
											VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[1]),
											VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[2]),
											VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[3]) );
			}

			// texture enable
			curRenderState |= GLESHAL_RS_TEXTURE_ENB;

			if( isValidTex[1] )		// multi-texture
				curRenderState |= GLESHAL_RS_MULTITEX_ENB;
			else
				curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
			
			// texture filtering
			if( GL_NEAREST == ptexture[0]->m_TEXTURE_MAG_FILTER )
			{
				curRenderState &= ~GLESHAL_RS_BILINEAR_FILTER_ENB;
				curRenderState &= ~GLESHAL_RS_ABILINEAR_FILTER_ENB;
			}
			else if( GL_LINEAR == ptexture[0]->m_TEXTURE_MAG_FILTER )
			{
				curRenderState |= GLESHAL_RS_BILINEAR_FILTER_ENB;
				curRenderState |= GLESHAL_RS_ABILINEAR_FILTER_ENB;
			}			
		}
		else
		{
			if( isValidTex[1] )
			{
				// texture enable, mult-texture
				curRenderState |= GLESHAL_RS_TEXTURE_ENB;
				curRenderState |= GLESHAL_RS_MULTITEX_ENB;

				//ptexture[0] = &__GLSTATE__.m_DefaultTexture;

				if( __GLSTATE__.m_TexEnv[1].m_IsUpdated )
				{
	//				printf( "__GLSTATE__.m_TexEnv[1].m_IsUpdated\n" );
					GLESHAL_SetTextureConstColor( VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[0]),
												VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[1]),
												VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[2]),
												VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[3]) );
				}
											
				if( GL_NEAREST == ptexture[1]->m_TEXTURE_MAG_FILTER )
				{
					curRenderState &= ~GLESHAL_RS_BILINEAR_FILTER_ENB;
					curRenderState &= ~GLESHAL_RS_ABILINEAR_FILTER_ENB;
				}
				else if( GL_LINEAR == ptexture[1]->m_TEXTURE_MAG_FILTER )
				{
					curRenderState |= GLESHAL_RS_BILINEAR_FILTER_ENB;
					curRenderState |= GLESHAL_RS_ABILINEAR_FILTER_ENB;
				}												
			}
			else
			{
				// texture disable
				curRenderState &= ~GLESHAL_RS_TEXTURE_ENB;
				curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
				GLESHAL_SetRenderState( curRenderState );
				return;
			}
		}
	//	printf( "GLESHAL_SetRenderState( curRenderState );\n" );
		GLESHAL_SetRenderState( curRenderState );

		// texture ���� ����.
		for( i=0; i<2/*GLPARAM_MAX_TEXTURE_UNITS*/; i++ )
		{
			static GLenum Last_Format[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};
			if( (0!=(__GLSTATE__.m_EventGLState&(1<<(GLSTATE_TEXTURE_2D_0+i)))) ||
				__GLSTATE__.m_TexEnv[i].m_IsUpdated ||
				Last_Format[i] != ptexture[i]->m_Format )
			{
	//			printf( "SetTextureBlendMode( i, ptexture[i]->m_Format );\n" );
				Last_Format[i] = ptexture[i]->m_Format;
				SetTextureBlendMode( i, ptexture[i]->m_Format );
			}
			//if( !ptexture[i] )
			//	break;

			static unsigned int Last_Texture_ID[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};
			static GLenum Last_TEXTURE_WRAP_S[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};
			static GLenum Last_TEXTURE_WRAP_T[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};
			static GLenum Last_TEXTURE_MIN_FILTER[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};		
			if( ((Last_Texture_ID[i]!=ptexture[i]->m_ID)
				 || ptexture[i]->m_ContentsIsUpdated 
				 || (ptexture[i]->m_TEXTURE_WRAP_S != Last_TEXTURE_WRAP_S[i])
				 || (ptexture[i]->m_TEXTURE_WRAP_T != Last_TEXTURE_WRAP_T[i])
				 || (ptexture[i]->m_TEXTURE_MIN_FILTER != Last_TEXTURE_MIN_FILTER[i] && ( ptexture[i]->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE ))
				) && ptexture[i]->m_TextureDataMemory2D.MemoryHandle )
			{
				Last_Texture_ID[i] = ptexture[i]->m_ID;
				Last_TEXTURE_WRAP_S[i] = ptexture[i]->m_TEXTURE_WRAP_S;
				Last_TEXTURE_WRAP_T[i] = ptexture[i]->m_TEXTURE_WRAP_T;
				Last_TEXTURE_MIN_FILTER[i] = ptexture[i]->m_TEXTURE_MIN_FILTER;

				GLESHAL_COLORFORMAT colorFormat;
				if( ptexture[i]->m_IsCompessed )
					colorFormat = GetHALCompressedTexColorFormat( ptexture[i]->m_Format );
				else
					colorFormat = GetHALTexColorFormat( ptexture[i]->m_Format, ptexture[i]->m_Type );
				
				GLESHAL_TEXTUREADDRESS wrapS = GLESHAL_TEXTUREADDRESS_CLAMP;
				GLESHAL_TEXTUREADDRESS wrapT = GLESHAL_TEXTUREADDRESS_CLAMP;
				if( GL_REPEAT == ptexture[i]->m_TEXTURE_WRAP_S )
					wrapS = GLESHAL_TEXTUREADDRESS_WRAP;
				if( GL_REPEAT == ptexture[i]->m_TEXTURE_WRAP_T )
					wrapT = GLESHAL_TEXTUREADDRESS_WRAP;
				
	//			printf( "GLESHAL_SetTextureWithSegment\n" );
				GLESHAL_SetTextureWithSegment( i, 
									ptexture[i]->m_ContentsIsUpdated,
									ptexture[i]->m_TextureDataMemory2D.PhysicalSegment, 
									colorFormat,
									( ptexture[i]->m_TEXTURE_MIN_FILTER == GL_NEAREST_MIPMAP_NEAREST ) && ( ptexture[i]->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE ),
									wrapS, //(GLESHAL_TEXTUREADDRESS)ptexture[i]->m_TEXTURE_WRAP_S,
									wrapT, //(GLESHAL_TEXTUREADDRESS)ptexture[i]->m_TEXTURE_WRAP_T,
									(ptexture[i]->m_TextureDataMemory2D.PhysicalSegX)/2, 
									ptexture[i]->m_TextureDataMemory2D.PhysicalSegY, 
									ptexture[i]->m_WidthPowerOf2 * ptexture[i]->m_Bpp / 16, 
									ptexture[i]->m_HeightPowerOf2 );
			}		

			// compressed texture�̸� palette ����
			static unsigned int Last_Compessed_Texture_ID[GLPARAM_MAX_TEXTURE_UNITS] = {0,0};
			if( (ptexture[i]->m_IsCompessed) && 			
				(Last_Compessed_Texture_ID[i]!=ptexture[i]->m_ID || ptexture[i]->m_ContentsIsUpdated) &&
				(ptexture[i]->m_PaletteMemory2D.MemoryHandle) )
			{
				Last_Compessed_Texture_ID[i] = ptexture[i]->m_ID;
				switch( ptexture[i]->m_PaletteSize )
				{
				case 16:
					if( !GLESHAL_SetPalette16( i,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegment,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegX/2,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegY ))
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					break;

				case 256:
					if( !GLESHAL_SetPalette256( i, 
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegment,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegX/2,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegY ))
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					break;

				default:
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
			}
			ptexture[i]->m_IsUpdated = GL_FALSE;
			ptexture[i]->m_ContentsIsUpdated = GL_FALSE;
		}
	}

	bool operator != ( const __TEXENV__& texenv1, const __TEXENV__& texenv2 )
	{
		return  (texenv1.m_IsEnable             != texenv2.m_IsEnable            ) ||
				(texenv1.m_TEXTURE_ENV_MODE     != texenv2.m_TEXTURE_ENV_MODE    ) ||
				(texenv1.m_LODBias              != texenv2.m_LODBias             ) ||
				(texenv1.m_RGB_SCALE            != texenv2.m_RGB_SCALE           ) ||
				(texenv1.m_ALPHA_SCALE          != texenv2.m_ALPHA_SCALE         ) ||
				(texenv1.m_TEXTURE_ENV_COLOR[0] != texenv2.m_TEXTURE_ENV_COLOR[0]) ||
				(texenv1.m_TEXTURE_ENV_COLOR[1] != texenv2.m_TEXTURE_ENV_COLOR[1]) ||
				(texenv1.m_TEXTURE_ENV_COLOR[2] != texenv2.m_TEXTURE_ENV_COLOR[2]) ||
				(texenv1.m_TEXTURE_ENV_COLOR[3] != texenv2.m_TEXTURE_ENV_COLOR[3]) ||
				(texenv1.m_COORD_REPLACE_OES    != texenv2.m_COORD_REPLACE_OES   ) ||
				( ( texenv1.m_TEXTURE_ENV_MODE == GL_COMBINE ) && 
				  ( (texenv1.m_COMBINE_RGB          != texenv2.m_COMBINE_RGB     ) ||
					(texenv1.m_COMBINE_ALPHA        != texenv2.m_COMBINE_ALPHA   ) ||
					(texenv1.m_SRC_RGB[0]           != texenv2.m_SRC_RGB[0]      ) ||
					(texenv1.m_SRC_RGB[1]           != texenv2.m_SRC_RGB[1]      ) ||
					(texenv1.m_SRC_RGB[2]           != texenv2.m_SRC_RGB[2]      ) ||
					(texenv1.m_SRC_ALPHA[0]         != texenv2.m_SRC_ALPHA[0]    ) ||
					(texenv1.m_SRC_ALPHA[1]         != texenv2.m_SRC_ALPHA[1]    ) ||
					(texenv1.m_SRC_ALPHA[2]         != texenv2.m_SRC_ALPHA[2]    ) ||
					(texenv1.m_OPERAND_RGB[0]       != texenv2.m_OPERAND_RGB[0]  ) ||
					(texenv1.m_OPERAND_RGB[1]       != texenv2.m_OPERAND_RGB[1]  ) ||
					(texenv1.m_OPERAND_RGB[2]       != texenv2.m_OPERAND_RGB[2]  ) ||
					(texenv1.m_OPERAND_ALPHA[0]     != texenv2.m_OPERAND_ALPHA[0]) ||
					(texenv1.m_OPERAND_ALPHA[1]     != texenv2.m_OPERAND_ALPHA[1]) ||
					(texenv1.m_OPERAND_ALPHA[2]     != texenv2.m_OPERAND_ALPHA[2]) ));
	};

	void SetBufferUseLog( void )
	{
		GLESHAL_Nops( 8 ); // H/W FIFO depth 32bitx8
		unsigned __int64 curPointer = GLESHAL_GetFrontOfCommandQueue();					
		if( 0 != (curPointer&7) ){ GLESHAL_Nop(); }
		else { GLESHAL_Nops( 2 ); }
		curPointer = GLESHAL_GetFrontOfCommandQueue();			

		if( __GLSTATE__.m_CurrentPrimitive.m_pIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pIndex->m_UsedPoint = curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pPosition )
			__GLSTATE__.m_CurrentPrimitive.m_pPosition->m_UsedPoint = curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pColor )
			__GLSTATE__.m_CurrentPrimitive.m_pColor->m_UsedPoint	= curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pNormal )
			__GLSTATE__.m_CurrentPrimitive.m_pNormal->m_UsedPoint = curPointer;

		for( int i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_BindedTexture[i] && __GLSTATE__.m_TexEnv[i].m_IsEnable )
			{
				__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[i]);
				ptexture->m_UsedPoint = curPointer;
			}

			if( __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] )
				__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i]->m_UsedPoint = curPointer;
		}

		if( ! __GLSTATE__.m_Enable_MATRIX_PALETTE_OES )
		{
			if( __GLSTATE__.m_CurrentPrimitive.m_pPointSize )
				__GLSTATE__.m_CurrentPrimitive.m_pPointSize->m_UsedPoint = curPointer;
			return;
		}
		else
		{
			if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex )
				__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex->m_UsedPoint	= curPointer;
			if( __GLSTATE__.m_CurrentPrimitive.m_pWeight )
				__GLSTATE__.m_CurrentPrimitive.m_pWeight->m_UsedPoint		= curPointer;
			if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette )
				__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_UsedPoint = curPointer;

			SetCurMatrixPaletteBufferIndex();	// matrix palette buffer change
			return;
		}
	}
	
	void InitCurrentPrimitive( void )
	{
		//if( __GLSTATE__.m_CurrentPrimitive.m_pPosition )
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pColor )	
			__GLSTATE__.m_CurrentPrimitive.m_pColor = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pNormal )
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pPointSize )
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pWeight )
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = NULL;
		
		int i;
		for( i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			//if( __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] )
				__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] = NULL;
		}
		
		//if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette )
		//	__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette = NULL;	// Matrix palette�� NULL�� ����� �ȵſ�~
		//if( __GLSTATE__.m_CurrentPrimitive.m_pIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = NULL;
	}
}

void UpdateTexture( void )
{
	static __TEXENV__ Last_TexEnv[GLPARAM_MAX_TEXTURE_UNITS];
	{
		int i;
		for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_TexEnv[i].m_IsUpdated )
			{
				if( __GLSTATE__.m_TexEnv[i] != Last_TexEnv[i] )
				{
					Last_TexEnv[i] = __GLSTATE__.m_TexEnv[i];
				}
				else
				{
					__GLSTATE__.m_TexEnv[i].m_IsUpdated = GL_FALSE;
				}
			}
		}
	}

	// Texture blending
	// Const color
	// Multi-texture, texture enable flag setting
	// Texture palette or texture segment, option setting
	// Texture filtering
	// **** filtering�� constant color ������ ���, multi-texturing�̸� tex[0]�� ������
	// �� �� �ϳ��� enable�̸� enable �� texture�� ������ ������. ****		
	
	if( !__GLSTATE__.m_TexEnv[0].m_IsEnable && !__GLSTATE__.m_TexEnv[1].m_IsEnable )
	{
		if( (0==(__GLSTATE__.m_EventGLState&(3<<GLSTATE_TEXTURE_2D_0))) ){ return; }

		unsigned long curRenderState = GLESHAL_GetRenderState();

		GLESHAL_SetTextureBlend( 0, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C,
								GLESHAL_RGBOP_REPLACE, 
								GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A,
								GLESHAL_AOP_REPLACE );
		/*	// multi-texture enable ���°� �ƴ϶�� tex1�� blending�� ������ �ʿ� ����.						
		GLESHAL_SetTextureBlend( 1, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C,
								GLESHAL_RGBOP_REPLACE, 
								GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A,
								GLESHAL_AOP_REPLACE );								
		*/
		curRenderState &= ~GLESHAL_RS_TEXTURE_ENB;
		curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
		GLESHAL_SetRenderState( curRenderState );		
		return;
	}
	
	if( (!__GLSTATE__.m_TexEnv[0].m_IsUpdated) && 
		(!__GLSTATE__.m_TexEnv[1].m_IsUpdated) && 
		(!__GLSTATE__.m_IsTextureUpdated) &&
		(0==(__GLSTATE__.m_EventGLState&(3<<GLSTATE_TEXTURE_2D_0))) ) { return; }

	UpdateTexEnv_Body();
}

unsigned int Preparerendering( GLint first, GLsizei count )
{
	updatedefaultinput=false;
	__first = first;
	__count = count;

	//--------------------------------------------------------------------------------------------
	bufferenableflag = 1<<GLESHAL_VERTEXSTREAM_POSITION;
	vertexStream[ VERTEXSTREAM_POSITION * 3 + 0 ] = (unsigned int)(GetPositionAddress( __first, __count ));
	vertexStream[ VERTEXSTREAM_POSITION * 3 + 1 ] = __GLSTATE__.m_VertexPointer.m_Stride;
	vertexStream[ VERTEXSTREAM_POSITION * 3 + 2 ] = __GLSTATE__.m_VertexPointer.m_HALInfo;
	static int LastPointerSize_Vertex = 100;
	int        CurPointerSize_Vertex  = __GLSTATE__.m_VertexPointer.m_Size;
	if( LastPointerSize_Vertex > CurPointerSize_Vertex )
	{
		__SetDefault_Pos();		
	}
	LastPointerSize_Vertex = CurPointerSize_Vertex;

	//--------------------------------------------------------------------------------------------
	static bool LastPointerEnable_Color = false;
	bool updatedefaultinput_color = (LastPointerEnable_Color != __GLSTATE__.m_ClientState_COLOR_ARRAY);
	LastPointerEnable_Color = __GLSTATE__.m_ClientState_COLOR_ARRAY;
	if( __GLSTATE__.m_ClientState_COLOR_ARRAY || updatedefaultinput_color || __GLSTATE__.m_UpdateCurrentColor )
	{ 
		__SetDefault_Color(updatedefaultinput_color);
	}

	//--------------------------------------------------------------------------------------------
	static bool LastPointerEnable_Normal = false;
	bool updatedefaultinput_normal = (LastPointerEnable_Normal != ( (__GLSTATE__.m_ClientState_NORMAL_ARRAY) && (__GLSTATE__.m_Enable_LIGHTING) ));
	LastPointerEnable_Normal = ( (__GLSTATE__.m_ClientState_NORMAL_ARRAY) && (__GLSTATE__.m_Enable_LIGHTING) );
	if( ((__GLSTATE__.m_ClientState_NORMAL_ARRAY) && (__GLSTATE__.m_Enable_LIGHTING)) ||
		updatedefaultinput_normal || __GLSTATE__.m_UpdateDefaultNormal ) 
	{
		__SetDefault_Normal( updatedefaultinput_normal );
	}

	//--------------------------------------------------------------------------------------------
	static bool LastPointerEnable_PointSize = false;
	bool updatedefaultinput_pointsize = (LastPointerEnable_PointSize != (__GLSTATE__.m_Enable_MATRIX_PALETTE_OES || __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES));
	LastPointerEnable_PointSize = (__GLSTATE__.m_Enable_MATRIX_PALETTE_OES || __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES);
	if( __GLSTATE__.m_Enable_MATRIX_PALETTE_OES )
	{
		if( ! __SetDefault_MatrixPalette() ){ return 0; }
	}
	else if( __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES || updatedefaultinput_pointsize || __GLSTATE__.m_UpdataPointSize )
	{
		__SetDefault_PointSize( updatedefaultinput_pointsize );
	}

	//--------------------------------------------------------------------------------------------
	for( int i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
	{
		if(__GLSTATE__.m_TexEnv[i].m_IsEnable )
		{
			static bool LastPointerEnable_Texture[GLPARAM_MAX_TEXTURE_UNITS] = {false,false};
			bool updatedefaultinput_texture = (LastPointerEnable_Texture[i] != __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[i] );
			LastPointerEnable_Texture[i] = __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[i];
			if( __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[i] || 
				updatedefaultinput_texture || 
				__GLSTATE__.m_UpdateDefaultTexCoord[i] )
			{
				__SetDefault_Texture( i, updatedefaultinput_texture );
			}
		}
	}

	if( updatedefaultinput ) GLESHAL_SetGTEConst( 0, 4*7, gteConst );	// GTE input register �ʱⰪ ����.
	
	//Fog setting
	if( __GLSTATE__.m_Enable_FOG && __GLSTATE__.m_IsFogUpdated ){ SetFog(); }

	GLESHAL_SetVertexStreams( vertexStream, bufferenableflag );

	// texture update
	UpdateTexture();

	return bufferenableflag;
}

GLboolean GLESHAL_RunPrimitive_TwoSideLighting( void );
GLboolean RenderPrimitiveArrays( unsigned int StreamValidFlag, GLenum mode, GLint first, GLsizei count )
{

	if(!count)
		return GL_FALSE;
	
	GLboolean result = (GLboolean)GLESHAL_SetPrimitiveControl( StreamValidFlag, (GLESHAL_INDEXTYPE)0, 
							__GLSTATE__.m_IsPrimitiveCacheClear, 
							( (GL_LINE_LOOP==mode) ? GL_TRUE : GL_FALSE ) , 
							GL_FALSE, 
							__GLSTATE__.m_Enable_MATRIX_PALETTE_OES,
							first, first + count - 1 );

	if( !result ) return GL_FALSE;

	if( ( !__GLSTATE__.m_Enable_LIGHTING ) || ( !__GLSTATE__.m_TwoSidedLightning ) ||
		( (mode != GL_TRIANGLE_STRIP) && ( mode != GL_TRIANGLE_FAN) && ( mode != GL_TRIANGLES) ) ) 
	{
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		if( !result ) return GL_FALSE;	
		SetBufferUseLog();		// ����� ���۵鿡 ���� use point ǥ��.
		InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.	
		return GL_TRUE;
	}
	else
	{
		result = GLESHAL_RunPrimitive_TwoSideLighting();
		if( !result ) return GL_FALSE;	
		SetBufferUseLog();		// ����� ���۵鿡 ���� use point ǥ��.
		InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.	
		return GL_TRUE;
	}
}

GLboolean RenderPrimitiveElements( unsigned int StreamValidFlag, GLenum mode, GLsizei count )
{
	if(!count)
		return GL_FALSE;
	
	unsigned int StartIndexAddr = (unsigned int)GetIndexAddress( 0, count );
	
	GLboolean result = (GLboolean)GLESHAL_SetPrimitiveControl( StreamValidFlag, 
							(GLESHAL_INDEXTYPE)(__GLSTATE__.m_IndexPointer.m_Type), 
							__GLSTATE__.m_IsPrimitiveCacheClear, 
							( (GL_LINE_LOOP==mode) ? GL_TRUE : GL_FALSE ),
							GL_TRUE, 
							__GLSTATE__.m_Enable_MATRIX_PALETTE_OES,
							StartIndexAddr, 
							StartIndexAddr + ( (count-1) * __GLSTATE__.m_IndexPointer.m_Stride ) );
							
	if( !result ) return GL_FALSE;
	
	if( ( !__GLSTATE__.m_Enable_LIGHTING ) || ( !__GLSTATE__.m_TwoSidedLightning ) ||
		( (mode != GL_TRIANGLE_STRIP) && ( mode != GL_TRIANGLE_FAN) && ( mode != GL_TRIANGLES) ) ) 
	{
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		if( !result ) return GL_FALSE;	
		SetBufferUseLog();	// ����� ���۵鿡 ���� use point ǥ��.
		InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.	
		return GL_TRUE;
	}
	else
	{
		result = GLESHAL_RunPrimitive_TwoSideLighting();
		if( !result ) return GL_FALSE;	
		SetBufferUseLog();		// ����� ���۵鿡 ���� use point ǥ��.
		InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.	
		return GL_TRUE;
	}
}


GLboolean SetPrimitiveControlParam( GLenum mode )
{
	if( __GLSTATE__.m_DrawMode == mode )
		return GL_TRUE;
		
	switch( mode )
	{
	case GL_POINTS:
		//GLESHAL_SetParamData( 0, 2, 0, 0, 0 );
		//GLESHAL_SetPrimitiveParamLoopControl( 0, 0 );
		break;
	case GL_LINE_STRIP:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );		
		GLESHAL_SetPrimitiveParamLoopControl( 1, 1 );
		break;
	case GL_LINE_LOOP:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );		
		GLESHAL_SetPrimitiveParamLoopControl( 1, 1 );
		break;
	case GL_LINES:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );	
		GLESHAL_SetPrimitiveParamLoopControl( 0, 1 );
		break;
	case GL_TRIANGLE_STRIP:
		GLESHAL_SetParamData( 0, 0, 1, 6, 12 );
		GLESHAL_SetParamData( 1, 5, 14, 4, 13 );
		GLESHAL_SetPrimitiveParamLoopControl( 2, 7 );
		break;
	case GL_TRIANGLE_FAN:
		GLESHAL_SetParamData( 0, 0, 1, 6, 13 );
		GLESHAL_SetPrimitiveParamLoopControl( 2, 3 );
		break;
	case GL_TRIANGLES:
		GLESHAL_SetParamData( 0, 0, 1, 6, 0 );
		GLESHAL_SetPrimitiveParamLoopControl( 0, 2 );
		break;
	default:
		return GL_FALSE; 
	}

	__GLSTATE__.m_DrawMode = mode;
	return GL_TRUE;
}

void DestroyDefaultBuffer( void )
{
	GLESHAL_Flush();
	int k;
	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultPositionBuffer)/sizeof(__GLSTATE__.m_DefaultPositionBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultPositionBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultPositionBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultPositionBuffer[k].m_DataMemory1D );
		}
	}

	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultColorBuffer)/sizeof(__GLSTATE__.m_DefaultColorBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultColorBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultColorBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultColorBuffer[k].m_DataMemory1D );
		}
	}

	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultTexCoordBuffer)/sizeof(__GLSTATE__.m_DefaultTexCoordBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultTexCoordBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultTexCoordBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultTexCoordBuffer[k].m_DataMemory1D );
		}
	}
	
	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultNormalBuffer)/sizeof(__GLSTATE__.m_DefaultNormalBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultNormalBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultNormalBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultNormalBuffer[k].m_DataMemory1D );
		}
	}

	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultPointSizeBuffer)/sizeof(__GLSTATE__.m_DefaultPointSizeBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultPointSizeBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultPointSizeBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultPointSizeBuffer[k].m_DataMemory1D );
		}
	}

	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultWeightBuffer)/sizeof(__GLSTATE__.m_DefaultWeightBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultWeightBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultWeightBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultWeightBuffer[k].m_DataMemory1D );
		}
	}

	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultMatrixIndexBuffer)/sizeof(__GLSTATE__.m_DefaultMatrixIndexBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultMatrixIndexBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultMatrixIndexBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultMatrixIndexBuffer[k].m_DataMemory1D );
		}
	}

	int i;
	for( i=0; i<GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES; i++ )
	{
		while( __GLSTATE__.m_DefaultMatrixPalette[i].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
	
		if( __GLSTATE__.m_DefaultMatrixPalette[i].m_DataMemory1D.MemoryHandle )
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultMatrixPalette[i].m_DataMemory1D );			
	}
	
	for( k=0; k<(sizeof(__GLSTATE__.m_DefaultIndexBuffer)/sizeof(__GLSTATE__.m_DefaultIndexBuffer[0])); k++ )
	{
		if( __GLSTATE__.m_DefaultIndexBuffer[k].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultIndexBuffer[k].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultIndexBuffer[k].m_DataMemory1D );
		}
	}
}

void SetCurMatrixPaletteBufferIndex( void )
{
	__GLSTATE__.m_CurMatrixPaletteBufferIndex = 
				( __GLSTATE__.m_CurMatrixPaletteBufferIndex + 1 ) % GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES;

	__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette = 
				&(__GLSTATE__.m_DefaultMatrixPalette[ __GLSTATE__.m_CurMatrixPaletteBufferIndex ]);
}

void EnableMatrixPaletteUpdate( GLint index ) 
{
	GLint row = index / 8;
	GLint col = index % 8;
	for( int i=0; i<GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES; i++ )
	{
		__GLSTATE__.m_MatrixPaletteUpdateFlag[i][row] |= (1<<col);
	}
}



GLboolean GLESHAL_RunPrimitive_TwoSideLighting( void )
{
	GLboolean result = GL_TRUE;
	float gteConst[4];
	gteConst[0] = gteConst[1] = gteConst[2] = -1.0f * __ConstForNormalize__;
	gteConst[3] = 1.0f;
	if( __GLSTATE__.m_Enable_CULL_FACE )
	{
		if( __GLSTATE__.m_CullFace == GL_FRONT )
		{
			GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
		}
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
	}
	else
	{
		unsigned long curRenderState = GLESHAL_GetRenderState();
		// back face culling and draw
		GLESHAL_SetRenderState( curRenderState | GLESHAL_RS_BACKFACECULL_ENB );
		GLESHAL_SetCullFace( GLESHAL_CULLFACE_BACK );
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

		// front face culling and draw
		GLESHAL_SetCullFace( GLESHAL_CULLFACE_FRONT );
		GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
		result |= (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

		GLESHAL_SetRenderState( curRenderState );	// culling disable ����.
		//glCullFace( __GLSTATE__.m_CullFace );		// culling mode ����.
		
		//result = (GLboolean)GLESHAL_RunPrimitive();	// test
	}

	return result;
}

}	// namespace __MES_OPENGL_ES__


