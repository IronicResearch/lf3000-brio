//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : memory management (1D)
//	File       : mes_memory1d.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/01/03 Yuni  modify for GLESOAL
//	   2004/10/07 Gamza first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	custom heap structure
//------------------------------------------------------------------------------
typedef struct
{
	unsigned int	VirtualAddress ;
	unsigned int    PhysicalAddress;
	unsigned int	SizeInMbyte;// size (Mbyte)
} ___OEM_CUSTOMHEAP;

//------------------------------------------------------------------------------
//	1D memory manager
//------------------------------------------------------------------------------
#define MCBFLAG_USED	1
#define MES_ASSERT(exp)
#define CNULL   0
#define CTRUE	1
#define CFALSE	0
typedef int		        CBOOL;
typedef char    		S8 ;
typedef short   		S16;
typedef long   			S32;
typedef unsigned char	U8 ;
typedef unsigned short	U16;
typedef unsigned long	U32;


struct __MES_MCB_1D
{
	U32 m_MemoryHandle;
	U32 m_HeapID;
	U32 m_VirtualAddress;
	U32 m_PhysicalAddress;	
	U32 m_Size;
	U32 m_MCBFlag;
	__MES_MCB_1D* m_pPrev;
	__MES_MCB_1D* m_pNext;

	__MES_MCB_1D( void )
	{
		m_MemoryHandle 		= 0xFFFFFFFF;
		m_HeapID       		= 0xFFFFFFFF;
		m_VirtualAddress	= 0;
		m_PhysicalAddress 	= 0;
		m_Size         		= 0;
		m_MCBFlag      		= 0;
		m_pPrev        		= CNULL;
		m_pNext        		= CNULL;
	}
};

class __MES_MCB_1D_Manager// : public MES_Singleton<__MES_MCB_1D_Manager>
{
public:
	CBOOL Malloc( U32 HeapID, U32 ByteSize, __MES_MCB_1D* &pMemory1D );
	static void  Free( __MES_MCB_1D* pMemory1D );
	__MES_MCB_1D* GetRootHeap( U32 HeapID );
	U32   GetNumberOfHeap( void ){ return m_NumberOfHeap; }

	void Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps );
	void Deinitialize();
	virtual ~__MES_MCB_1D_Manager();
private:
	U32			  m_NumberOfHeap;
	__MES_MCB_1D* m_ListOfHeapRoot;

	template< typename T >
	static void LinkNode( T* pPrev, T* pNext );
	template< typename T >
	static T* MergeLinkNode( T* pPrev, T* pNext );
	template< typename T >
	static T* DivideLinkNode( T* pNode, U32 Size );
};

template< typename T >
void __MES_MCB_1D_Manager::LinkNode( T* pPrev, T* pNext )
{
	if( pPrev ){ pPrev->m_pNext = pNext; }
	if( pNext ){ pNext->m_pPrev = pPrev; }
}

template< typename T >
T* __MES_MCB_1D_Manager::MergeLinkNode( T* pPrev, T* pNext )
{
	MES_ASSERT( pPrev->m_HeapID == pNext->m_HeapID );
	MES_ASSERT( pPrev->m_VirtualAddress + pPrev->m_Size == pNext->m_VirtualAddress );
	MES_ASSERT( pPrev->m_PhysicalAddress + pPrev->m_Size == pNext->m_PhysicalAddress );
	pPrev->m_Size += pNext->m_Size;

	// link node
	LinkNode( pPrev, pNext->m_pNext );

	// remove node
	delete pNext;

	// return new node
	return pPrev;
}

template< typename T >
T* __MES_MCB_1D_Manager::DivideLinkNode( T* pNode, U32 Size )
{
	MES_ASSERT( pNode->m_Size > Size );
	T* newnode = new T;
	*newnode = *pNode;
	newnode->m_VirtualAddress = pNode->m_VirtualAddress + Size;
	newnode->m_PhysicalAddress = pNode->m_PhysicalAddress + Size;
	newnode->m_Size    = pNode->m_Size - Size;
	pNode->m_Size = Size;

	// link node
	LinkNode( newnode, pNode->m_pNext );
	LinkNode( pNode, newnode );

	// return node
	return pNode;
}

void __MES_MCB_1D_Manager::Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps )
{
	m_NumberOfHeap=NumberOfHeaps;

	// alloc heap root
	m_ListOfHeapRoot = new __MES_MCB_1D[(unsigned int)m_NumberOfHeap];
	MES_ASSERT( CNULL != m_ListOfHeapRoot );

	// init heap root
	U32 i;
	for( i=0; i<m_NumberOfHeap; i++ )
	{
		m_ListOfHeapRoot[i].m_HeapID       = i;
		m_ListOfHeapRoot[i].m_VirtualAddress  = pHeapList[i].VirtualAddress;
		m_ListOfHeapRoot[i].m_PhysicalAddress = pHeapList[i].PhysicalAddress;
		m_ListOfHeapRoot[i].m_Size            = pHeapList[i].SizeInMbyte * 0x100000;
	}
}

void __MES_MCB_1D_Manager::Deinitialize()
{
    delete[] m_ListOfHeapRoot;
}

__MES_MCB_1D_Manager::~__MES_MCB_1D_Manager()
{
	Deinitialize();
}

__MES_MCB_1D* __MES_MCB_1D_Manager::GetRootHeap( U32 HeapID )
{
	MES_ASSERT( m_NumberOfHeap > HeapID );
	MES_ASSERT( CNULL != m_ListOfHeapRoot );
	return m_ListOfHeapRoot + HeapID;
}

void  __MES_MCB_1D_Manager::Free
(
	__MES_MCB_1D* pMemory1D
)
{
	MES_ASSERT( CNULL != pMemory1D );
	MES_ASSERT( pMemory1D->m_MCBFlag & MCBFLAG_USED );
	__MES_MCB_1D* pprev = pMemory1D->m_pPrev;
	if( pprev )
	{
		if( 0 == (pprev->m_MCBFlag & MCBFLAG_USED) )
		{
			pMemory1D = MergeLinkNode( pprev, pMemory1D );
		}
	}
	__MES_MCB_1D* pnext = pMemory1D->m_pNext;
	if( pnext )
	{
		if( 0 == (pnext->m_MCBFlag & MCBFLAG_USED) )
		{
			pMemory1D = MergeLinkNode( pMemory1D, pnext );
		}
	}
	pMemory1D->m_MCBFlag &= ~MCBFLAG_USED;
}

CBOOL __MES_MCB_1D_Manager::Malloc
(
	U32 HeapID,
	U32 ByteSize,
	__MES_MCB_1D* &pMemory1D
)
{
	// �ϴ� �ӽñ���!
	MES_ASSERT( m_NumberOfHeap > HeapID );
	U32 maxdiff=0xFFFFFFFF;
	U32 curdiff;
	__MES_MCB_1D* pbestfit = CNULL;
	__MES_MCB_1D* pmemnode = &m_ListOfHeapRoot[HeapID];
	while(	CNULL != pmemnode )
	{
		if( 0 == (pmemnode->m_MCBFlag & MCBFLAG_USED) &&
			pmemnode->m_Size >= ByteSize )
		{
			curdiff = pmemnode->m_Size - ByteSize;
			if( maxdiff > curdiff )
			{
				maxdiff = curdiff;
				pbestfit= pmemnode;
				if( maxdiff == 0 ){ break; }
			}
		}
		pmemnode = pmemnode->m_pNext;
	}
	if( pbestfit )
	{
		if( maxdiff != 0 )
		{
			pbestfit = DivideLinkNode( pbestfit, ByteSize );
		}
		pbestfit->m_MCBFlag |= MCBFLAG_USED;
	}
	pMemory1D = pbestfit;
	return (CNULL != pMemory1D);
}


//------------------------------------------------------------------------------
// singleton
//------------------------------------------------------------------------------
static __MES_MCB_1D_Manager s__MES_MCB_1D_Manager;

void ___MES_1D_Manager_Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps )
{
    s__MES_MCB_1D_Manager.Initialize( pHeapList, NumberOfHeaps );
}

//------------------------------------------------------------------------------
//	OAL interface
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
    typedef int GLESOALbool;
    typedef struct
    {
    	unsigned long MemoryHandle   ; ///< memory handle for internal
    	unsigned long VirtualAddress ; ///< virtual address of memory block
    	unsigned long PhysicalAddress; ///< physical address of memory block
		unsigned long Size;
    } GLESOAL_MEMORY1D;
    
    GLESOALbool GLESOAL_Malloc1D( unsigned int  Size, unsigned int  Align,
                                             GLESOAL_MEMORY1D* pMemory1D ); 
    void GLESOAL_Free1D         ( GLESOAL_MEMORY1D* pMemory1D );
#ifdef __cplusplus
}
#endif

//------------------------------------------------------------------------------
//	OAL implementation
//------------------------------------------------------------------------------
#define DEFAULT_HEAP_ID 0

#include <stdio.h>

GLESOALbool GLESOAL_Malloc1D( unsigned int  Size, unsigned int  Align,
							GLESOAL_MEMORY1D* pMemory1D )
{
	if( (Align!=1) && (Align!=2) && (Align!=4) && (Align!=8) )
		return CFALSE;
	
	unsigned int alignedSize = ( (Size+Align-1) / Align ) * Align;

	__MES_MCB_1D* pmemory1d;	
	for( int i=0; i<s__MES_MCB_1D_Manager.GetNumberOfHeap(); i++ )
	{
		if( s__MES_MCB_1D_Manager.Malloc( i, alignedSize, pmemory1d ) )
		{
			pMemory1D->MemoryHandle 	= (U32)pmemory1d;
			pMemory1D->VirtualAddress 	= pmemory1d->m_VirtualAddress;
			pMemory1D->PhysicalAddress 	= pmemory1d->m_PhysicalAddress;
			pMemory1D->Size             = Size;
			return CTRUE;
		}
	}
	printf( "*E: 1D Memory allocation is failed\n" );
	return CFALSE;
}
 
void GLESOAL_Free1D( GLESOAL_MEMORY1D* pMemory1D )
{
	if( pMemory1D->MemoryHandle )
	{
		__MES_MCB_1D* pmemnode = (__MES_MCB_1D*)pMemory1D->MemoryHandle;
		s__MES_MCB_1D_Manager.Free( pmemnode );

		// ��� ������� �ʱ�ȭ
		pMemory1D->PhysicalAddress 	= 0;
		pMemory1D->VirtualAddress 	= 0;
		pMemory1D->MemoryHandle 	= 0;
		pMemory1D->Size             = 0;
	}
}

