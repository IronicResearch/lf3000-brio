#include <stdlib.h>
#include <math.h>
#include "GameData.h"
#include "FrustumCuller.h"
#include "render.h"
#include "timer.h"
#include "camera.h"
//#include "Mmsystem.h"

extern Timer *timer;
extern int WindowWidth;
extern int WindowHeight;
extern EGLDisplay glesDisplay;
extern EGLSurface glesSurface;
//extern HWND hWnd;
extern NativeWindowType hNativeWnd; // A handle to the window we will create

//init all data...
GameData::GameData()
{   
  m_gameState = PRESENTATION_SCREEN;
  m_cameraActive = 0;
  m_tankAlive = CONTINUE_PLAYING;
  m_score = 0;
  m_leftPushed = false;
  m_rightPushed = false;
  m_enterPushed = false;
  m_upPushed = false;
  m_downPushed = false;
  m_cameraActive = 0;
  
  m_presentation = new Texture("./resources/portada.tga",GL_NEAREST,GL_NEAREST);
  m_keyMap = new Texture("./resources/keymap.tga",GL_NEAREST,GL_NEAREST);
  m_credits = new Texture("./resources/creditos.tga",GL_NEAREST,GL_NEAREST);
  
  m_floor = new Mesh("./resources/suelo.gsd","./resources/suelo.tga",GL_LINEAR,GL_CLAMP_TO_EDGE);
  m_font = new BitmappedFont("./resources/font.raw");  
  m_tank = new Actor("./resources/tank.gsd","./resources/tank.tga",3,1);  
  m_enemies = new AliensGroup(10,4,FixedFromFloat(20.0f));
  m_bunkerMesh = new Mesh("./resources/bunker.gsd","./resources/bunker.tga",GL_NEAREST,GL_CLAMP_TO_EDGE);  
  m_bala = new Mesh("./resources/bala.gsd",NULL,0,0);
  m_espina= new Mesh("./resources/espina.gsd",NULL,0,0);
  m_tankShot = new Actor(m_bala,1,1,true);
  m_tankShotActive = false;

  int i;
  for(i=0;i<ALIEN_FIRE_RATE;++i)
  {
    m_alienShots[i] = new Actor(m_espina,1,1,false);
    m_alienShotsActive[i] = false;
  }

  GLfixed pos[3] = {FixedFromFloat(-10.0f),FixedFromFloat(3.0f),FixedFromFloat(0.0f)};
  for(i=0;i<4;i++)
  {
    m_bunker[i] = new Actor(m_bunkerMesh,1,BUNKER_STRENGTH);
    m_bunker[i]->m_position[0] = pos[0];
    m_bunker[i]->m_position[1] = pos[1];
    m_bunker[i]->m_position[2] = pos[2];    
    pos[0] += FixedFromFloat(7.0f);
  }
  InitCameras();
}
//-----------------------------------------------------------------------------
GameData::~GameData()
{
  if(m_presentation) delete m_presentation;
  if(m_keyMap) delete m_keyMap;
  if(m_credits) delete m_credits;
  delete m_espina;
  delete m_bala;
  delete m_tank;
  delete m_enemies;
  delete m_floor;
  delete m_font;  
  delete m_tankShot;
  
  int i;
  for(i=0;i<ALIEN_FIRE_RATE;++i)
    delete m_alienShots[i];

  for(i=0;i<4;++i)
    delete m_bunker[i];
  
  delete m_bunkerMesh;
}
//-----------------------------------------------------------------------------
void GameData::InitCameras()
{

  //Camera 1: tranks the tank
  m_cameraPosition[0][0] = FixedFromFloat(-12.5f);
  m_cameraPosition[0][1] = FixedFromInt(40);
  m_cameraPosition[0][2] = FixedFromInt(12);
  m_cameraEye[0][0] = m_tank->m_position[0];
  m_cameraEye[0][1] = m_tank->m_position[1];
  m_cameraEye[0][2] = m_tank->m_position[2];

  //Camera 2: usual space invaders view
  m_cameraPosition[1][0] = FixedFromInt(0);
  m_cameraPosition[1][1] = FixedFromInt(10);
  m_cameraPosition[1][2] = FixedFromInt(40);
  m_cameraEye[1][0] = ZERO;
  m_cameraEye[1][1] = FixedFromInt(10);
  m_cameraEye[1][2] = ZERO;

  //Camera 3: first person camera
  m_cameraPosition[2][0] = m_tank->m_position[0];
  m_cameraPosition[2][1] = m_tank->m_position[1];
  m_cameraPosition[2][2] = m_tank->m_position[2];
  m_cameraEye[2][0] = m_tank->m_position[0];
  m_cameraEye[2][1] = m_tank->m_position[1] + ONE;
  m_cameraEye[2][2] = m_tank->m_position[2];

  //Camera 4: perspective camera
  m_cameraPosition[3][0] = FixedFromFloat(25.0f);
  m_cameraPosition[3][1] = FixedFromFloat(-4.0f);
  m_cameraPosition[3][2] = FixedFromFloat(25.0f);
  m_cameraEye[3][0] = FixedFromFloat(-15.0f);
  m_cameraEye[3][1] = FixedFromFloat(25.0f);
  m_cameraEye[3][2] = FixedFromFloat(-15.0f);


}
//-----------------------------------------------------------------------------
void GameData::SetActiveCamera()
{
  FrustumCuller *f = FrustumCuller::Instance();
  if(m_cameraActive==0)
  {  
    m_cameraEye[0][0] = m_tank->m_position[0];
    m_cameraEye[0][1] = m_tank->m_position[1];
    m_cameraEye[0][2] = m_tank->m_position[2];
  }
  else if(m_cameraActive==2)
  {
    m_cameraPosition[2][0] = m_tank->m_position[0];
    m_cameraPosition[2][1] = m_tank->m_position[1];
    m_cameraPosition[2][2] = m_tank->m_position[2]+ONE;
    m_cameraEye[2][0] = m_tank->m_position[0];
    m_cameraEye[2][1] = m_tank->m_position[1] + FixedFromInt(1000);
    m_cameraEye[2][2] = m_tank->m_position[2];     
  }
  Camera::SetPerspective(hNativeWnd, FixedFromInt(45), ONE, FixedFromInt(400));     
  glLoadIdentity();
  Camera::LookAt(m_cameraPosition[m_cameraActive][0],m_cameraPosition[m_cameraActive][1],m_cameraPosition[m_cameraActive][2],
                 m_cameraEye[m_cameraActive][0],m_cameraEye[m_cameraActive][1],m_cameraEye[m_cameraActive][2],
                 0,ONE,0);  
  f->ExtractFrustumPlanes();  
  
}
//-----------------------------------------------------------------------------
void GameData::TankShotManagement(unsigned long elapsedtime)
{
   //initialize the shot position if the used have pushed enter key
  if(m_enterPushed)
  {
    if(!m_tankShotActive)
    {
      //set the shot at tank position
      m_tankShot->m_position[0] = m_tank->m_position[0];
      m_tankShot->m_position[1] = ONE;
      m_tankShot->m_position[2] = m_tank->m_position[2];
    
      //update the hotpoint position
      m_tankShot->m_hotPoint[0] += m_tank->m_position[0];
      m_tankShot->m_hotPoint[1] += m_tank->m_position[1];
      m_tankShot->m_hotPoint[2] += m_tank->m_position[2];
      m_tankShotActive = true;

      //play a sound
      //PlaySound(L"/resources/tankshot.wav", NULL, SND_ASYNC);
    }
    m_enterPushed = false;        
  }
  
  //check if the shot have scaped to the athmosphere
  if(m_tankShot->m_position[1] >= FixedFromInt(20))
  {
    m_tankShot->m_position[0] = ZERO;
    m_tankShot->m_position[1] = ZERO;
    m_tankShot->m_position[2] = ZERO;
    m_tankShot->ComputeHotPoint(true);
    m_tankShotActive = false;
  }
  //check if the shot is "alive"
  else if(m_tankShot->m_position[1] >= ONE)
  {
    m_tankShot->m_position[1] += MultiplyFixed(TANK_SHOT_SPEED,FixedFromInt(elapsedtime));
    m_tankShot->m_hotPoint[1] += MultiplyFixed(TANK_SHOT_SPEED,FixedFromInt(elapsedtime));  
    m_tankShotActive = true;
    
    //check possible collisions
    bool collidedWithBunker = CheckTankShotAgainstBunkers();
    //we only want check against aliens if there wasn't a collision with a bunker
    if(!collidedWithBunker)
    {      
      //a = alien that have been impacted by the shot
      Actor *a = m_enemies->CheckShotAgainstAliens(m_tankShot->m_hotPoint);
      if(a)
      {
        m_tankShot->m_position[0] = ZERO;
        m_tankShot->m_position[1] = ZERO;
        m_tankShot->m_position[2] = ZERO;
        m_tankShot->ComputeHotPoint(true);
        m_tankShotActive = false;        
        a->UpdateDyingTime(elapsedtime); //start falling to red
        m_score += 10;
      }
    }
  }
}
//-----------------------------------------------------------------------------
int GameData::AlienShotsManagement(unsigned long elapsedtime)
{  
  Actor *a = NULL;
  int j=0,k=0;
  
  int i;
  //check if the aliens will shot 
  for(i=0;i<ALIEN_FIRE_RATE;++i)
  {
    if(!m_alienShotsActive[i])
    {
      j = rand()%m_enemies->GetNumberOfAliensPerRow();
      k = rand()%m_enemies->GetNumberOfRows();
      a = m_enemies->GetNextAliveActor(j,k);
      if(a)
      {          
        int prob = rand()%100;
        //aliens' shot fire possibilities
        if(prob<ALIEN_SHOT_FREQUENCY)
        {
          InitAlienShot(a,i);
          //PlaySound(L"/resources/alienshot.wav", NULL, SND_ASYNC);
        }
      }
    }
  }//end for

  
  for(i=0;i<ALIEN_FIRE_RATE;++i)
  {
    //if aliens' shot are in an invalid place, reset them
    if(m_alienShots[i]->m_position[1] <= 0)
    {
      m_alienShotsActive[i] = false;
      m_alienShots[i]->ComputeHotPoint(false);
    }
    else if(m_alienShotsActive[i])
    {
      //update alien shot
      m_alienShots[i]->m_position[1] -= MultiplyFixed(ALIEN_SHOT_SPEED,FixedFromInt(elapsedtime));
      m_alienShots[i]->m_hotPoint[1] -= MultiplyFixed(ALIEN_SHOT_SPEED,FixedFromInt(elapsedtime));  

      bool collidedWithBunker = CheckAlienShotsAgainstBunkers(i);
      if(!collidedWithBunker)
      {
        bool tankKilled = CheckCollisionWithTank(i);
        if(tankKilled)
        {
          if(m_tank->m_lives>0)
            m_tank->m_lives--;
          return TANK_KILLED;
        }
      }
    }
  }
  return CONTINUE_PLAYING;
}
//-----------------------------------------------------------------------------
bool GameData::CheckCollisionWithTank(int shot)
{
  GLfixed pos[3];//,point[3];
  //update sphere position
  pos[0] = m_tank->m_sphereCenter[0] + m_tank->m_position[0];
  pos[1] = m_tank->m_sphereCenter[1] + m_tank->m_position[1];
  pos[2] = m_tank->m_sphereCenter[2] + m_tank->m_position[2];

  if(m_tank->m_hitPoints>0)
  {
    FrustumCuller *fr = FrustumCuller::Instance();
    if(fr->PointVsSphere(pos, m_tank->m_sphereRadius, m_alienShots[shot]->m_hotPoint))    
    {         
      m_alienShots[shot]->ComputeHotPoint(true);
      m_alienShotsActive[shot] = false;      
      return true;
    }
  }
  return false;
}
//-----------------------------------------------------------------------------
bool GameData::CheckAlienShotsAgainstBunkers(int shot)
{
  FrustumCuller *fr = FrustumCuller::Instance();
  GLfixed pos[3];
  for(int j=0;j<4;++j)
  {
    //check the shot against the bunkers, updating the bounding sphere
    pos[0] = m_bunker[j]->m_sphereCenter[0] + m_bunker[j]->m_position[0];
    pos[1] = m_bunker[j]->m_sphereCenter[1] + m_bunker[j]->m_position[1];
    pos[2] = m_bunker[j]->m_sphereCenter[2] + m_bunker[j]->m_position[2];
    if(m_bunker[j]->m_hitPoints>0)
    {
      if(fr->PointVsSphere(pos, m_bunker[j]->m_sphereRadius, m_alienShots[shot]->m_hotPoint))
      {
        //reset alien shot
        //PlaySound(L"/resources/bunkerXplosion.wav", NULL, SND_ASYNC);
        m_alienShots[shot]->ComputeHotPoint(true);
        m_alienShotsActive[shot] = false;
        m_bunker[j]->m_hitPoints--;      
        return true;
      }
    }
  }  
  return false;
}
//-----------------------------------------------------------------------------
void GameData::InitAlienShot(Actor *alien, int shot)
{
  m_alienShotsActive[shot] = true;
  m_alienShots[shot]->m_position[0] = alien->m_position[0];
  m_alienShots[shot]->m_position[1] = alien->m_position[1];
  m_alienShots[shot]->m_position[2] = alien->m_position[2];

  m_alienShots[shot]->m_hotPoint[0] += alien->m_position[0];
  m_alienShots[shot]->m_hotPoint[1] += alien->m_position[1];
  m_alienShots[shot]->m_hotPoint[2] += alien->m_position[2];
}
//-----------------------------------------------------------------------------
bool GameData::CheckTankShotAgainstBunkers()
{
  FrustumCuller *fr = FrustumCuller::Instance();
  GLfixed pos[3];
  for(int j=0;j<4;++j)
  {
    //check the shot against the bunkers
    pos[0] = m_bunker[j]->m_sphereCenter[0] + m_bunker[j]->m_position[0];
    pos[1] = m_bunker[j]->m_sphereCenter[1] + m_bunker[j]->m_position[1];
    pos[2] = m_bunker[j]->m_sphereCenter[2] + m_bunker[j]->m_position[2];
    if(m_bunker[j]->m_hitPoints>0)
    {
      if(fr->PointVsSphere(pos, m_bunker[j]->m_sphereRadius, m_tankShot->m_hotPoint))
      {
        //PlaySound(L"/resources/bunkerXplosion.wav", NULL, SND_ASYNC);
        m_tankShot->m_position[0] = ZERO;
        m_tankShot->m_position[1] = ZERO;
        m_tankShot->m_position[2] = ZERO;
        m_tankShot->ComputeHotPoint(true);
        m_tankShotActive = false;
        m_bunker[j]->m_hitPoints--;      
        return true;
      }
    }
  }
  return false;
}
//-----------------------------------------------------------------------------
void GameData::RestartGame()
{
  m_score = 0;
  m_tank->Revive();
  
  int i;
  for(i=0;i<4;++i)
    m_bunker[i]->Revive();
  
  for(i=0;i<ALIEN_FIRE_RATE;++i) 
    m_alienShotsActive[i] = false;
  
  m_tankShotActive = false;
  m_enemies->ReviveAliens();
  m_tankAlive = true;
  
}
//----------------------------------------------------------------------------
void GameData::GameLoop(bool *done)
{
  if(m_gameState == PLAYING)
    Game(done);
  else if(m_gameState == PRESENTATION_SCREEN)
  {    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    Camera::SetOrtho2D(WindowWidth, WindowHeight);
    glLoadIdentity();     
    
    glEnable(GL_TEXTURE_2D);
    m_presentation->BindTexture();
    DrawScreenAlignedAndTexturedQuad();
    glDisable(GL_TEXTURE_2D);
    
    eglSwapBuffers(glesDisplay, glesSurface);    
    OS_Sleep(3000);
    delete m_presentation; m_presentation = NULL;
    m_gameState = KEYMAP_SCREEN;    
  }
  else if(m_gameState == KEYMAP_SCREEN)
  {    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    Camera::SetOrtho2D(WindowWidth, WindowHeight);
    glLoadIdentity();     
    
    glEnable(GL_TEXTURE_2D);
    m_keyMap->BindTexture();
    DrawScreenAlignedAndTexturedQuad();
    glDisable(GL_TEXTURE_2D);
    
    eglSwapBuffers(glesDisplay, glesSurface);    
    OS_Sleep(3000);
    delete m_keyMap; m_keyMap = NULL;
    m_gameState = PLAYING;    
  }
  else if(m_gameState == CREDITS_SCREEN)
  {    
    *done = true;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    Camera::SetOrtho2D(WindowWidth, WindowHeight);
    glLoadIdentity();         
    glEnable(GL_TEXTURE_2D);
    m_credits->BindTexture();
    DrawScreenAlignedAndTexturedQuad();
    glDisable(GL_TEXTURE_2D);    
    eglSwapBuffers(glesDisplay, glesSurface);    
    OS_Sleep(3000);
    delete m_credits; m_credits = NULL;      
  }
}
//----------------------------------------------------------------------------
void GameData::DrawScreenAlignedAndTexturedQuad()
{
  static GLushort indices[] = {1,2,0,3};
  static GLfixed vertices[] = {ZERO, ZERO, 
                               FixedFromInt(WindowWidth), ZERO,
                               FixedFromInt(WindowWidth), FixedFromInt(WindowHeight),  
                               ZERO, FixedFromInt(WindowHeight)};

  GLfixed W = DivideFixed(FixedFromInt(240), FixedFromInt(256));
  GLfixed H = DivideFixed(FixedFromInt(320), FixedFromInt(512));
  static GLfixed texCoords[] = {ZERO,ZERO,   W,ZERO,   W,H,   ZERO,H};

  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FIXED, 0, texCoords);
    glVertexPointer(2, GL_FIXED, 0, vertices);
    glDrawElements(GL_TRIANGLE_STRIP,4,GL_UNSIGNED_SHORT,indices);
  glDisableClientState(GL_VERTEX_ARRAY);  
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}
//----------------------------------------------------------------------------
void GameData::Game(bool *done)
{
  Render();
     
  int aliensCode = m_enemies->Update(timer->GetTimeBetweenTwoFrames());

  Camera::SetOrtho2D(WindowWidth, WindowHeight);
  glLoadIdentity();      
  BitmappedFont::EnableStates();  
   m_font->Print(0,WindowHeight - 15,"Score: %d",  m_score);
   m_font->Print(0,WindowHeight - 30,"Lives: %d",  m_tank->m_lives);
  BitmappedFont::DisableStates();  

  //check ending conditions
  if((aliensCode == ALIENS_HAS_CONQUERED_THE_WORLD)||( m_tank->m_lives<1))
  {    
    glClear(GL_COLOR_BUFFER_BIT);
    Camera::SetOrtho2D(WindowWidth, WindowHeight);
    glLoadIdentity();      
    BitmappedFont::EnableStates();  
     m_font->Print(0,WindowHeight / 2+15,"Score: %d",  m_score);
     m_font->Print(0,WindowHeight / 2,"You Lose.");
     m_font->Print(0,(WindowHeight / 2) - 15,"Play Again?");
     m_font->Print(0,(WindowHeight / 2) - 30,"Hit left if Yes");
     m_font->Print(0,(WindowHeight / 2) - 45,"Right to finish");
    BitmappedFont::DisableStates();

	m_rightPushed = true;
    if(m_rightPushed)
      m_gameState = CREDITS_SCREEN;
    else if(m_leftPushed)
       RestartGame();
  }
  else if(aliensCode == ALL_ALIENS_DEAD) 
  {
    glClear(GL_COLOR_BUFFER_BIT);
    Camera::SetOrtho2D(WindowWidth, WindowHeight);
    glLoadIdentity();      
    BitmappedFont::EnableStates();  
     m_font->Print(0,WindowHeight / 2 + 15,"Score: %d", m_score);
     m_font->Print(0,WindowHeight / 2,"You Won.");
     m_font->Print(0,(WindowHeight / 2) - 15,"Play Again?");
     m_font->Print(0,(WindowHeight / 2) - 30,"Hit left if Yes");
     m_font->Print(0,(WindowHeight / 2) - 45,"Right to finish");
    BitmappedFont::DisableStates();
    if(m_rightPushed)
      *done = true;
    else if(m_leftPushed)
       RestartGame();
  }
  else if(aliensCode == CONTINUE_PLAYING)
  {
    //move tank
    if(m_leftPushed)
    {      
      if(m_tank->m_position[0] > LIMIT_L)
         m_tank->m_position[0] -= MultiplyFixed(TANK_SPEED, FixedFromInt(timer->GetTimeBetweenTwoFrames()));
    }
    else if(m_rightPushed)
    { 
      if(m_tank->m_position[0] < LIMIT_R)
         m_tank->m_position[0] += MultiplyFixed(TANK_SPEED, FixedFromInt(timer->GetTimeBetweenTwoFrames()));
    }          
    //shots management
    TankShotManagement(timer->GetTimeBetweenTwoFrames());
    m_tankAlive = AlienShotsManagement(timer->GetTimeBetweenTwoFrames());
    
    //manage tank lives
    if(m_tankAlive == TANK_KILLED)
    {
      for(int i=0;i<ALIEN_FIRE_RATE;i++)
      {
        m_alienShots[i]->ComputeHotPoint(true);
        m_alienShotsActive[i] = false;
      }

      Camera::SetOrtho2D(WindowWidth, WindowHeight);
      glLoadIdentity();      
      BitmappedFont::EnableStates();  
      m_font->Print(0,(WindowHeight / 2) + 15,"You've been hit.");
      m_font->Print(0,WindowHeight / 2,"Lives: %d",  m_tank->m_lives);
      BitmappedFont::DisableStates();              
      eglSwapBuffers(glesDisplay, glesSurface);              
      timer->UpdateTimer();
      OS_Sleep(3000);      
      return;      
    }//end if tank killed
  }//end else continue playing
  
  //swap buffers
  eglSwapBuffers(glesDisplay, glesSurface);    
  //update timer
  timer->UpdateTimer();
}
