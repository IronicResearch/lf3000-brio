//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDepthRangex.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_9bxh.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza ���� �Լ� ȣ�⵵ ������Ŀ� ������ �ش�.
//						glDepthRangef/glDepthRangex/glPolygonOffset/glPolygonOffsetx
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// The glDepthRange function specifies the mapping of z values from
// normalized device coordinates to window coordinates

// znear 
// The mapping of the near clipping plane to window coordinates. The default value is 0. 
// zfar 
// The mapping of the far clipping plane to window coordinates. The default value is 1. 
//	Current color values are stored in floating-point format,
//	
//	glGet with argument GL_DEPTH_RANGE
//
//	GL_INVALID_OPERATION  glDepthRange was called between a call to glBegin and the corresponding call to glEnd. 

void glDepthRangex (GLclampx zNear, GLclampx zFar)
{
	CALL_LOG;
	zNear = CLAMPX(zNear);
	zFar  = CLAMPX(zFar );
	__GLSTATE__.m_DepthRangeNear =  X2VCF(zNear) ;
	__GLSTATE__.m_DepthRangeFar  =  X2VCF(zFar ) ;
	__GLSTATE__.m_ProjectionMatrix.m_IsUpdated = 1;
}
