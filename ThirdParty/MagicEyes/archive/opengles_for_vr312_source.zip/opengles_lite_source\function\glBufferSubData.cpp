//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBufferSubData.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glBufferSubData.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza (size + offset) �� pcurrentbuffer->m_Size�� ���Ƶ� ��.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
#ifdef __CC_ARM
#include <cstring>
#else
#include <memory.h>
#endif

//	openGL|ES only


void glBufferSubData (GLenum target, GLintptr offset, GLsizeiptr size, const GLvoid *data)
{
	CALL_LOG;
	int bindedbuffer;
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[0];		
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[1];		
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return; 
	}
	
	//	reference���� ������ vicent�� �ִ� �˻�	
	__BUFFER__* pcurrentbuffer;
	pcurrentbuffer = __BUFFER_POOL__.GetObject(bindedbuffer);
	if ( !bindedbuffer || !pcurrentbuffer || !(pcurrentbuffer->m_DataMemory1D.MemoryHandle) )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if ( size < 0 || offset < 0 || (size + offset) > pcurrentbuffer->m_Size )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	
	if( size && data && (pcurrentbuffer->m_DataMemory1D.MemoryHandle) )
	{
		char* pbufferData = reinterpret_cast<char*>(pcurrentbuffer->m_DataMemory1D.VirtualAddress) + offset;

		while( pcurrentbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		memcpy(pbufferData, data, size);

		__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
	}
}
