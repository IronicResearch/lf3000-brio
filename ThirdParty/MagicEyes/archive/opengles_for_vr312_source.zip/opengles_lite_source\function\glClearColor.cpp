//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glClearColor.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_0rhu.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//The glClearColor function specifies clear values for the color buffers.

//red, green, blue, alpha 
//	The red, green, blue, and alpha values that glClear uses to clear the color buffers. The default values are all zero. 
//	Values specified by glClearColor are clamped to the range [0,1].
//
//	glGet with argument GL_ACCUM_CLEAR_VALUE
//	glGet with argument GL_COLOR_CLEAR_VALUE
//
//	GL_INVALID_OPERATION  glClearColor was called between a call to glBegin and the corresponding call to glEnd. 
//

void glClearColor (GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha)
{
	CALL_LOG;
	__GLSTATE__.m_ClearColor[0] = F2VF( CLAMPF(red) );
	__GLSTATE__.m_ClearColor[1] = F2VF( CLAMPF(green) );
	__GLSTATE__.m_ClearColor[2] = F2VF( CLAMPF(blue) );
	__GLSTATE__.m_ClearColor[3] = F2VF( CLAMPF(alpha) );
}
