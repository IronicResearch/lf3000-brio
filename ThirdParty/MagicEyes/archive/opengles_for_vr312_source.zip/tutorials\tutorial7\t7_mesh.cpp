#include <Fake_OS.h>
#include "t7_mesh.h"

namespace __TUTORIAL7__
{

Mesh::Mesh(const char *filename,bool useVBO)
{
  m_state = true;
  m_useVBO = useVBO;
  m_mesh.Geometry = NULL;
  m_mesh.Indices = NULL;
  m_mesh.Normals = NULL;
  m_mesh.TexCoord = NULL;
  
  
  GSDHeader header;
  OS_FILE meshFile = OS_fopen(filename,"rb");
  if(!meshFile)
  {
    m_state = false;
    return;
  }

  /*The header holds a brief description of the file, the version number, and the number of meshes
    that are stored in the file. This type of files are thought for static meshes only*/
  OS_fread(&header,sizeof(GSDHeader),1,meshFile); 

  //Check if there is at least one object
  if(header.numberOfSubObjects < 1)
  {
    m_state = false;
    OS_fclose(meshFile);
    return;
  }

  GenericObjectData o;
  
  // we only will use the first object, so we won't iterate over the others, if they exist
  OS_fread(o.Name,sizeof(char)*128,1,meshFile); //read the object name
  OS_fread(o.ParentName,sizeof(char)*128,1,meshFile); //Read the name of the parent object (useful for hierarchies)
  OS_fread(&o.iC,sizeof(unsigned long),1,meshFile); //read the number of vertex indices
  OS_fread(&o.vC,sizeof(unsigned long),1,meshFile); //read the number of vertices

  
  //allocate enough space for the indices and the GLshort version of them
  o.Indices = new unsigned int[o.iC];
  m_mesh.Indices = new GLushort[o.iC];
  OS_fread(o.Indices,sizeof(unsigned int) * o.iC,1,meshFile); // read all indices

  //allocate enough space for the vertices and the GLfixed version of them
  o.Geometry = new float[o.vC * 3]; 
  m_mesh.Geometry = new GLfixed[o.vC * 3];
  OS_fread(o.Geometry,o.vC * 3 * sizeof(float),1,meshFile); //read all vertices (1 vertex = 3 floats)

  //allocate enough space for the texture coordinates and the GLfixed version of them
  o.TexCoord = new float[o.vC * 2];
  m_mesh.TexCoord = new GLfixed[o.vC * 2];
  OS_fread(o.TexCoord,o.vC * 2 * sizeof(float),1,meshFile);//read all texcoords (1 tex coord = 2 floats)
  
  //allocate enough space for the normals and the GLfixed version of them
  o.Normals= new float[o.vC * 3];
  m_mesh.Normals = new GLfixed[o.vC * 3];
  OS_fread(o.Normals,o.vC * 3* sizeof(float),1,meshFile);//read all normals (1 normal = 3 floats)
  
  unsigned int i;
  
  // Convert data to optimized data types for OpenGL ES (GLfixed and GLshort)
  for(i=0;i<o.vC * 3;i++)
  {
    m_mesh.Geometry[i]= FixedFromFloat(o.Geometry[i]);
    m_mesh.Normals[i] = FixedFromFloat(o.Normals[i]);
  }

  for(i=0;i<o.vC * 2;i++)
    m_mesh.TexCoord[i] = FixedFromFloat(o.TexCoord[i]);
  
  for(i=0;i<o.iC;i++)
    m_mesh.Indices[i] = (GLushort)o.Indices[i];

  m_mesh.indexCounter = (GLushort)o.iC;
  m_mesh.vertexCounter= (GLushort)o.vC;
  //delete original values, we will use only the optimized ones
  delete [] o.Indices;
  delete [] o.Geometry;
  delete [] o.Normals;
  delete [] o.TexCoord;
  OS_fclose(meshFile); //Do not need the file opened anymore 
  
  //if we will use the VBO features, then lets create them
  if(m_useVBO)
  {
    glGenBuffers(1, &m_indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_indexBuffer);  
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, m_mesh.indexCounter * sizeof(GLushort), m_mesh.Indices, GL_STATIC_DRAW);    
   
    //remember unbind the VBO if you wint use it in the future
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glGenBuffers(1, &m_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, m_mesh.vertexCounter * 3 * sizeof(GLfixed), m_mesh.Geometry, GL_STATIC_DRAW);
      
    glGenBuffers(1, &m_normalBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_normalBuffer);
    glBufferData(GL_ARRAY_BUFFER, m_mesh.vertexCounter * 3 * sizeof(GLfixed), m_mesh.Normals, GL_STATIC_DRAW);

    glGenBuffers(1, &m_texCoordBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_texCoordBuffer);
    glBufferData(GL_ARRAY_BUFFER, m_mesh.vertexCounter * 2 * sizeof(GLfixed), m_mesh.TexCoord, GL_STATIC_DRAW);
    
    //remember unbind the VBO if you wint use it in the future
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    //because VBO data is stored in client memory, we do not need in main memory for more time
    if(m_mesh.Geometry) delete [] m_mesh.Geometry;
    if(m_mesh.Indices) delete [] m_mesh.Indices;
    if(m_mesh.Normals) delete [] m_mesh.Normals;
    if(m_mesh.TexCoord) delete [] m_mesh.TexCoord;
  }    
}
//----------------------------------------------------------------------------
Mesh::~Mesh()
{

  if(m_useVBO)
  {
    glDeleteBuffers(1, &m_indexBuffer);
    glDeleteBuffers(1, &m_vertexBuffer);
    glDeleteBuffers(1, &m_normalBuffer);
    glDeleteBuffers(1, &m_texCoordBuffer);
  }
  else
  {
    if(m_mesh.Geometry) delete [] m_mesh.Geometry;
    if(m_mesh.Indices) delete [] m_mesh.Indices;
    if(m_mesh.Normals) delete [] m_mesh.Normals;
    if(m_mesh.TexCoord) delete [] m_mesh.TexCoord;
  }
}
//----------------------------------------------------------------------------
void Mesh::Draw()
{
  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_NORMAL_ARRAY);
  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  if(m_useVBO)
  {
    /*Binding the VBO and assigning NULL to the pointer, means that the next drawing call
    will use the previus uploaded data to the VBO*/
    glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);
    glVertexPointer(3, GL_FIXED, 0, NULL);
        
    glBindBuffer(GL_ARRAY_BUFFER, m_normalBuffer);
    glNormalPointer(GL_FIXED, 0, NULL);
    
    glBindBuffer(GL_ARRAY_BUFFER, m_texCoordBuffer);
    glTexCoordPointer(2,GL_FIXED, 0, NULL);
   
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_indexBuffer);
    glDrawElements(GL_TRIANGLES,m_mesh.indexCounter,GL_UNSIGNED_SHORT, NULL);

    //VBO unbinds
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
  }
  else
  {
    glVertexPointer(3, GL_FIXED, 0, m_mesh.Geometry);            
    glNormalPointer(GL_FIXED, 0, m_mesh.Normals);        
    glTexCoordPointer(2,GL_FIXED, 0, m_mesh.TexCoord);       
    glDrawElements(GL_TRIANGLES,m_mesh.indexCounter,GL_UNSIGNED_SHORT, m_mesh.Indices);  
  }
  glDisableClientState(GL_VERTEX_ARRAY);   	
  glDisableClientState(GL_NORMAL_ARRAY); 
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);   	
}

}//namespace

















