//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_oal.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//     2007/01/23 Gamza FW team���� �ۼ��� MP2530F platform�� virtual address��
//                      physical address�� ������ ����.
//	   2007/01/03 Yuni first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#include "libgles_cm_lite_oal.h"
#include <mes_memory.h>
#include <GLESOAL_Private.h>
#include "mes_memory_debug.h"

#define DEFAULT_HEAP_ID 0
#define Segment( Address )	((((Address)>>22)<<1) | (((Address)>>11)&1))
#define SegmentX( Address )	((Address)&((1<<11)-1))
#define SegmentY( Address )	(((Address)>>12)&((1<<10)-1))

int					__GLESOAL__::g_WindowWidth		= 0;
int					__GLESOAL__::g_WindowHeight		= 0;

static unsigned int	g_AddressOf3DCore = 0;


//  this function's implementation is in OS
#ifdef __cplusplus
extern "C" {
#endif
/*
	enum GLESOAL_MEMORY2D_TYPE
	{
		GLESOAL_MEMORY2D_TYPE_FRAMEBUFFER	= 0,
		GLESOAL_MEMORY2D_TYPE_DEPTHBUFFER	= 1,
		GLESOAL_MEMORY2D_TYPE_TEXTURE		= 2,
		GLESOAL_MEMORY2D_TYPE_FORCEU32		= 0x7FFFFFFF
	};

    typedef struct
    {
    	unsigned long MemoryHandle   ; ///< memory handle for internal
    	unsigned long VirtualAddress ; ///< virtual address of memory block
    	unsigned long PhysicalAddress; ///< physical address of memory block
    } GLESOAL_MEMORY1D;

	typedef struct
	{
		unsigned long			MemoryHandle;		///< memory handle for internal (do not modified it)
		GLESOAL_MEMORY2D_TYPE	Type;				/// memory2D type
		unsigned long			VirtualSegment;		///< virtual address of memory block (16byte aligned)
		unsigned long			VirtualSegX;
		unsigned long			VirtualSegY;
		unsigned long			PhysicalSegment;	///< physical address of memory block (16byte aligned)
		unsigned long			PhysicalSegX;
		unsigned long			PhysicalSegY;
		unsigned long			Width;
		unsigned long			Height;
	} GLESOAL_MEMORY2D;
*/    
/*
    typedef struct
    {
        unsigned int	VirtualAddressOf3DCore  ; // virtual addres of the 3D core register
        
    	unsigned int	Memory1D_VirtualAddress ; // must be 8byte aligned, non-cacheable
    	unsigned int    Memory1D_PhysicalAddress; // must be 8byte aligned, non-cacheable
    	unsigned int	Memory1D_SizeInMbyte    ; // size (Mbyte)
    
    	unsigned int	Memory2D_VirtualAddress ; // must be 4Mbyte aligned, non-cacheable
    	unsigned int    Memory2D_PhysicalAddress; // must be 4Mbyte aligned, non-cacheable
    	unsigned int	Memory2D_SizeInMbyte    ; // size (Mbyte), must be multiple of 4
    } ___OAL_MEMORY_INFORMATION__;
*/    
    //GLESOALbool GLESOAL_Initialize( ___OAL_MEMORY_INFORMATION__* pMemoryInfomation );
    void        GLESOAL_SetWindow    ( void* pNativeWindow  );
    void        GLESOAL_GetWindowSize( int* pWidth, int* pHeight );
	void		GLESOAL_SetDisplayAddress( const unsigned int DisplayBufferPhysicalAddress );

#ifdef __cplusplus
}
#endif
 
void GLESOAL_SetNativeWindow( void* pNativeWindow )
{
    GLESOAL_SetWindow    ( pNativeWindow );
	GLESOAL_GetWindowSize( &g_WindowWidth, &g_WindowHeight );
}
 
void GLESOAL_SetNativeDisplay( void* pNativeDisplay )
{
}

void GLESOAL_GetNativeWindowSize( int* pWidth, int* pHeight )
{
    GLESOAL_GetWindowSize( &g_WindowWidth, &g_WindowHeight );
	*pWidth 	= g_WindowWidth;
	*pHeight 	= g_WindowHeight;
}

bool g_GLESOAL_FSAA;

GLESOALbool GLESOAL_Initialize_Internal( GLESOALbool FSAAEnb )
{    
	g_GLESOAL_FSAA = FSAAEnb;
/*
	___OAL_MEMORY_INFORMATION__ memoryinformation;
	if( ! GLESOAL_Initialize( &memoryinformation ) ){ return 0; }
	
	if( 0 != ( memoryinformation.Memory1D_VirtualAddress  % 8) ){ return 0; }
	if( 0 != ( memoryinformation.Memory1D_PhysicalAddress % 8) ){ return 0; }
	if( 0 >=   memoryinformation.Memory1D_SizeInMbyte )         { return 0; }
	
	if( 0 != ( memoryinformation.Memory2D_VirtualAddress  % 0x400000) ){ return 0; }
	if( 0 != ( memoryinformation.Memory2D_PhysicalAddress % 0x400000) ){ return 0; }
	if( 0 != ( memoryinformation.Memory2D_SizeInMbyte     % 2       ) ){ return 0; }
	if( 0 >=   memoryinformation.Memory2D_SizeInMbyte )                { return 0; }
*/
/*		
    ___OEM_CUSTOMHEAP memory1d = { 
        memoryinformation.Memory1D_VirtualAddress,
        memoryinformation.Memory1D_PhysicalAddress,
        memoryinformation.Memory1D_SizeInMbyte
        };
    ___OEM_CUSTOMHEAP memory2d = { 
        memoryinformation.Memory2D_VirtualAddress,
        memoryinformation.Memory2D_PhysicalAddress,
        memoryinformation.Memory2D_SizeInMbyte
        };
       
    ___MES_1D_Manager_Initialize( &memory1d, 1 );
    ___MES_2D_Manager_Initialize( &memory2d, 1 );
	
*/
	
	g_AddressOf3DCore = 0xC001A000; // MES_GRP3D_GetPhysicalAddress();
	
    return 1;
}



unsigned int GLESOAL_GetVirtualAddressOf3DCore( void )
{
	//U32 coreAddr = MES_GRP3D_GetPhysicalAddress();
    //return MES_ConvertToVirtualAddress( coreAddr );
    
    return g_AddressOf3DCore;
}

void GLESOAL_Sleep( unsigned long Milliseconds )
{
	// what to do?
}

    
GLESOALbool GLESOAL_Malloc1D( unsigned int  Size, unsigned int  Align,
                                         GLESOAL_MEMORY1D* pMemory1D )
{
	if( (Align!=1) && (Align!=2) && (Align!=4) && (Align!=8) )
		return 0;

	MES_Memory1D* pmem = MES_NEW( MES_Memory1D );

	unsigned int alignedSize = ( (Size+Align-1) / Align ) * Align;

	if( MES_Malloc1D( DEFAULT_HEAP_ID, alignedSize, pmem ) )
	{
		pMemory1D->MemoryHandle 	= (unsigned long)pmem;
		pMemory1D->PhysicalAddress 	= pmem->Address; // MES_ConvertToPhysicalAddress( pmem->Address );
		pMemory1D->VirtualAddress 	= pmem->Address;
		pMemory1D->Size 			= pmem->Size;

		return CTRUE;
	}
	else
	{
		if( pmem )
			MES_DELETE( pmem );
		
		return CFALSE;		
	}
}

void GLESOAL_Free1D         ( GLESOAL_MEMORY1D* pMemory1D )
{
	if( !pMemory1D )
	{	return;	}	
	
	if( !pMemory1D->MemoryHandle )
	{	return;	}
	
	MES_Memory1D* pmem = (MES_Memory1D*)(pMemory1D->MemoryHandle);
	MES_Free1D(pmem);
	MES_DELETE( pmem );

	// ��� ������� �ʱ�ȭ
	pMemory1D->PhysicalAddress	= 0;
	pMemory1D->VirtualAddress	= 0;
	pMemory1D->Size				= 0;
	pMemory1D->MemoryHandle		= 0;
	pMemory1D 					= CNULL;
}

GLESOALbool GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE Type, 
							unsigned int  Width, unsigned int  Height, 
                            unsigned int  AlignX, unsigned int  AlignY, 
                            GLESOAL_MEMORY2D* pMemory2D )
{
	MES_Memory2D* pmem = MES_NEW( MES_Memory2D );
	
	if( MES_Malloc2D( DEFAULT_HEAP_ID, Width, Height, AlignX, AlignY, pmem ) )
	{
		pMemory2D->Type				= Type;
		pMemory2D->MemoryHandle 	= ( unsigned long )pmem;
		pMemory2D->Width 			= pmem->Width;
		pMemory2D->Height 			= pmem->Height;
		
		unsigned long physicalAddr 	= pmem->Address; // MES_ConvertToPhysicalAddress( pmem->Address );
		pMemory2D->PhysicalSegment	= Segment( physicalAddr );
		pMemory2D->PhysicalSegX		= SegmentX( physicalAddr );
		pMemory2D->PhysicalSegY		= SegmentY( physicalAddr );
		
		pMemory2D->VirtualSegment	= Segment( pmem->Address );
		pMemory2D->VirtualSegX		= SegmentX( pmem->Address );
		pMemory2D->VirtualSegY		= SegmentY( pmem->Address );
		
		return CTRUE;
	}
	else
	{
		if( pmem )
			MES_DELETE( pmem );
		return CFALSE;
	}
}
void GLESOAL_Free2D         ( GLESOAL_MEMORY2D* pMemory2D )
{
	if( !pMemory2D )
	{	return;	}

	if( !pMemory2D->MemoryHandle )
	{	return;	}
	
	MES_Memory2D* pmem = (MES_Memory2D*)(pMemory2D->MemoryHandle);
	MES_Free2D(pmem);
	MES_DELETE( pmem );
	
	// ��� ������� �ʱ�ȭ
	pMemory2D->PhysicalSegment	= 0;
	pMemory2D->PhysicalSegX		= 0;
	pMemory2D->PhysicalSegY		= 0;
	pMemory2D->VirtualSegment	= 0;
	pMemory2D->VirtualSegX		= 0;
	pMemory2D->VirtualSegY		= 0;
	pMemory2D->Type				= (GLESOAL_MEMORY2D_TYPE)0;
	pMemory2D->MemoryHandle		= 0;
	
	pMemory2D					= CNULL;
}

void GLESOAL_PushDisplayAddressPatch( const GLESOAL_MEMORY2D* pDisplayBuffer )
{
	MES_Memory2D* pmem = (MES_Memory2D*)(pDisplayBuffer->MemoryHandle);
	GLESOAL_SetDisplayAddress( pmem->Address + 0x20000000 );
}

