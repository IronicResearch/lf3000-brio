//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_hal.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2007/04/30 Yuni		first implementation
//------------------------------------------------------------------------------

#ifndef _LIBGLES_CM_LITE_HAL_H
#define _LIBGLES_CM_LITE_HAL_H

#ifdef __cplusplus
extern "C" {
#endif

#define	GLESHALAPI	extern

typedef	int	GLESHALbool;

#ifndef	CFALSE
	#define	CFALSE	0
#endif
#ifndef CTRUE
	#define	CTRUE	1
#endif		


GLESHALAPI 
void GLESHAL_Initialize();
GLESHALAPI 
void GLESHAL_InitializeWithAddress( unsigned int VirtualAddress );

// @Gamza 2008/07/31
GLESHALAPI void GLESHAL_RestoreModule( void );


GLESHALAPI void    GLESHAL_SelectModule( unsigned int ModuleIndex );
GLESHALAPI unsigned int     GLESHAL_GetCurrentModule( void );
GLESHALAPI unsigned int     GLESHAL_GetNumberOfModule( void );

GLESHALAPI unsigned int     GLESHAL_GetPhysicalAddress( void );
GLESHALAPI unsigned int     GLESHAL_GetSizeOfRegisterSet( void );
GLESHALAPI void    GLESHAL_SetBaseAddress( unsigned int BaseAddress );
GLESHALAPI unsigned int     GLESHAL_GetBaseAddress( void );
GLESHALAPI GLESHALbool   GLESHAL_OpenModule( void );
GLESHALAPI GLESHALbool   GLESHAL_CloseModule( void );
GLESHALAPI GLESHALbool   GLESHAL_CheckBusy( void );
GLESHALAPI GLESHALbool   GLESHAL_CanPowerDown( void );

//GLESHALAPI int     GLESHAL_GetInterruptNumber( void );
GLESHALAPI void    GLESHAL_SetInterruptEnable( int IntNum, GLESHALbool Enable );
GLESHALAPI GLESHALbool   GLESHAL_GetInterruptEnable( int IntNum );
GLESHALAPI GLESHALbool   GLESHAL_GetInterruptPending( int IntNum );
GLESHALAPI void    GLESHAL_ClearInterruptPending( int IntNum );
GLESHALAPI void    GLESHAL_SetInterruptEnableAll( GLESHALbool Enable );
GLESHALAPI GLESHALbool   GLESHAL_GetInterruptEnableAll( void );
GLESHALAPI GLESHALbool   GLESHAL_GetInterruptPendingAll( void );
GLESHALAPI void    GLESHAL_ClearInterruptPendingAll( void );
GLESHALAPI int     GLESHAL_GetInterruptPendingNumber( void );  // -1 if None

//GLESHALAPI void            GLESHAL_SetClockPClkMode( MES_PCLKMODE mode );
//GLESHALAPI MES_PCLKMODE    GLESHAL_GetClockPClkMode( void );
//GLESHALAPI void            GLESHAL_SetClockBClkMode( MES_BCLKMODE mode );
//GLESHALAPI MES_BCLKMODE    GLESHAL_GetClockBClkMode( void );

//--------------------------------------------------------------------------
// Register Address : REG_BASE + 0x00~0x18
//--------------------------------------------------------------------------
GLESHALAPI void GLESHAL_SetTimeOutValue( unsigned int TimeOutValue );


//--------------------------------------------------------------------------
// RENDERSTATE
// Register Address : REG_BASE + 0x28
//--------------------------------------------------------------------------
// @brief	renderstate flags

GLESHALAPI const unsigned int GLESHAL_RS_PERSPECTIVE_ENB      ;
GLESHALAPI const unsigned int GLESHAL_RS_TEXTURE_ENB          ;
GLESHALAPI const unsigned int GLESHAL_RS_MULTITEX_ENB         ;
GLESHALAPI const unsigned int GLESHAL_RS_TRANSPARENCY_ENB     ;
GLESHALAPI const unsigned int GLESHAL_RS_SHADE_ENB            ;
GLESHALAPI const unsigned int GLESHAL_RS_BILINEAR_FILTER_ENB  ;
GLESHALAPI const unsigned int GLESHAL_RS_ABILINEAR_FILTER_ENB ;
GLESHALAPI const unsigned int GLESHAL_RS_ALPHA_ENB            ;
GLESHALAPI const unsigned int GLESHAL_RS_ZBUFFER_ENB          ;
GLESHALAPI const unsigned int GLESHAL_RS_ZBUFFERWRITE_ENB     ;
GLESHALAPI const unsigned int GLESHAL_RS_FOG_ENB              ;
GLESHALAPI const unsigned int GLESHAL_RS_DITHER_ENB           ;
GLESHALAPI const unsigned int GLESHAL_RS_BACKFACECULL_ENB     ;
GLESHALAPI const unsigned int GLESHAL_RS_BACKFACECULL_CW      ;
GLESHALAPI const unsigned int GLESHAL_RS_BACKFACECULL_CCW     ;
GLESHALAPI const unsigned int GLESHAL_RS_ALPHATEST_ENB		  ;

GLESHALAPI GLESHALbool GLESHAL_SetRenderState( unsigned int RenderState );
GLESHALAPI unsigned int   GLESHAL_GetRenderState( void );

//--------------------------------------------------------------------------
// ALPHABLEND
// Register Address : REG_BASE + 0x30
//--------------------------------------------------------------------------
/// @brief	alpha blending parameter
enum GLESHAL_BLEND
{
	GLESHAL_BLEND_ZERO               = 0,
	GLESHAL_BLEND_ONE                = 1,
	GLESHAL_BLEND_SRCCOLOR           = 2,
	GLESHAL_BLEND_INVSRCCOLOR        = 3,
	GLESHAL_BLEND_SRCALPHA           = 4,
	GLESHAL_BLEND_INVSRCALPHA        = 5,
	GLESHAL_BLEND_DESTCOLOR          = 6,
	GLESHAL_BLEND_INVDESTCOLOR       = 7,
	GLESHAL_BLEND_FORCES32  = 0x7FFFFFFF
};

GLESHALAPI 
GLESHALbool GLESHAL_SetBlendFactor( GLESHAL_BLEND SrcBlend, 
								   GLESHAL_BLEND DstBlend );

//--------------------------------------------------------------------------
// TPCOLOR,MIPMAPBIAS
// Register Address : REG_BASE + 0x40
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetTransparencyColor( unsigned short TransparencyColor );

//GLESHALAPI 
//GLESHALbool GLESHAL_SetMipmapBias( unsigned short MipmapBias );

//--------------------------------------------------------------------------
// LUTPARAM
// Register Address : REG_BASE + 0x48
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetPalette16( unsigned int TextureStage, 
								 unsigned int TextureSegment, 
								 unsigned int X, unsigned int Y );

GLESHALAPI 
GLESHALbool GLESHAL_SetPalette256( unsigned int TextureStage, 
								  unsigned int TextureSegment,
								  unsigned int X, unsigned int Y );


//--------------------------------------------------------------------------
// TEXSEGMENT
// Register Address : REG_BASE + 0x38
//--------------------------------------------------------------------------
typedef enum 
{
    GLESHAL_COLORFORMAT_INDEXED4_R5G6B5		=  0, ///
    GLESHAL_COLORFORMAT_INDEXED4_R4G4B4A4	=  1, ///
    GLESHAL_COLORFORMAT_INDEXED4_R5G5B5A1	=  2, ///
    GLESHAL_COLORFORMAT_INDEXED4_A8L8		=  3, ///
    GLESHAL_COLORFORMAT_INDEXED4_A4R4G4B4	=  4, ///
    GLESHAL_COLORFORMAT_INDEXED4_A1R5G5B5	=  5, ///
    GLESHAL_COLORFORMAT_INDEXED4_L8A8		=  6, ///
    GLESHAL_COLORFORMAT_A4					=  9, ///
    GLESHAL_COLORFORMAT_L4					= 15, ///
    GLESHAL_COLORFORMAT_INDEXED8_R5G6B5		= 16, ///
    GLESHAL_COLORFORMAT_INDEXED8_R4G4B4A4	= 17, ///
    GLESHAL_COLORFORMAT_INDEXED8_R5G5B5A1	= 18, ///
    GLESHAL_COLORFORMAT_INDEXED8_A8L8		= 19, ///
    GLESHAL_COLORFORMAT_INDEXED8_A4R4G4B4	= 20, ///
    GLESHAL_COLORFORMAT_INDEXED8_A1R5G5B5	= 21, ///
    GLESHAL_COLORFORMAT_INDEXED8_L8A8		= 22, ///
    GLESHAL_COLORFORMAT_L4A4				= 25, ///
    GLESHAL_COLORFORMAT_L8					= 27, ///
    GLESHAL_COLORFORMAT_A8					= 30, ///
    GLESHAL_COLORFORMAT_A4L4				= 31, ///
    GLESHAL_COLORFORMAT_R5G6B5				= 40, ///
    GLESHAL_COLORFORMAT_R4G4B4A4			= 41, ///
    GLESHAL_COLORFORMAT_R5G5B5A1			= 42, ///
    GLESHAL_COLORFORMAT_A8L8				= 43, ///
    GLESHAL_COLORFORMAT_A4R4G4B4			= 44, ///
    GLESHAL_COLORFORMAT_A1R5G5B5			= 45, ///
    GLESHAL_COLORFORMAT_L8A8				= 46, ///
    GLESHAL_COLORFORMAT_FORCES32 			= 0x7FFFFFFF
} GLESHAL_COLORFORMAT;

/// @brief	texture addressing mode
enum GLESHAL_TEXTUREADDRESS
{
	GLESHAL_TEXTUREADDRESS_WRAP  = 0,
	GLESHAL_TEXTUREADDRESS_CLAMP = 1,
	GLESHAL_TEXTUREADDRESS_FORCES32  = 0x7FFFFFFF
};


GLESHALAPI 
GLESHALbool GLESHAL_ClearTextureCache( unsigned int TextureStage );
//GLESHALAPI 
//GLESHALbool GLESHAL_SetTextureSegment( unsigned int TextureStage, unsigned int TextureSegment );
GLESHALAPI 
GLESHALbool GLESHAL_SetTextureWithSegment( 
								unsigned int			TextureStage, 
								GLESHALbool	 			IsCacheClear,
								unsigned int 			TextureSegment,
								GLESHAL_COLORFORMAT 	ColorFormat, 
								GLESHALbool 			MipmapEnb,
								GLESHAL_TEXTUREADDRESS 	TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS 	TextureAddressingModeV,
							    unsigned int 	X, 		unsigned int 	Y, 
								unsigned int 	Width, 	unsigned int 	Height );
								
//--------------------------------------------------------------------------
// TEXINFO0_0,TEXINFO0_1,TEXINFO1_0,TEXINFO1_1
// Register Address : REG_BASE + 0x50,0x54,0x58,0x5C
//--------------------------------------------------------------------------
/*
GLESHALAPI 
GLESHALbool GLESHAL_SetTextureMipmapEnable(
								unsigned int TextureStage, 
								GLESHALbool MipmapEnb );
*/
GLESHALAPI 
GLESHALbool GLESHAL_SetTextureWrappingMode( unsigned int TextureStage, 
								GLESHAL_TEXTUREADDRESS TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeV );
/*
GLESHALAPI 
GLESHALbool GLESHAL_SetTexture( unsigned int TextureStage, 
								GLESHAL_COLORFORMAT ColorFormat, 
							    unsigned int X, unsigned int Y, 
								unsigned int Width, unsigned int Height );
*/
/*
GLESHALAPI 
GLESHALbool GLESHAL_SetTexture( unsigned int TextureStage, 
								GLESHAL_COLORFORMAT ColorFormat, 
								GLESHALbool MipmapEnb,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeV,
							    unsigned int X, unsigned int Y, 
								unsigned int Width, unsigned int Height );
*/
							   

typedef enum 
{
	GLESHAL_RGBARG_SOURCE_C		= 0,
	GLESHAL_RGBARG_SOURCE_1_C	= 1,
	GLESHAL_RGBARG_SOURCE_A		= 2,
	GLESHAL_RGBARG_SOURCE_1_A	= 3,
	GLESHAL_RGBARG_CONST_C		= 4,
	GLESHAL_RGBARG_CONST_1_C	= 5,
	GLESHAL_RGBARG_CONST_A		= 6,
	GLESHAL_RGBARG_CONST_1_A	= 7,	
	GLESHAL_RGBARG_FRAGMENT_C	= 8,
	GLESHAL_RGBARG_FRAGMENT_1_C	= 9,
	GLESHAL_RGBARG_FRAGMENT_A	= 10,
	GLESHAL_RGBARG_FRAGMENT_1_A	= 11,	
	GLESHAL_RGBARG_PREVIOUS_C	= 12,
	GLESHAL_RGBARG_PREVIOUS_1_C	= 13,
	GLESHAL_RGBARG_PREVIOUS_A	= 14,
	GLESHAL_RGBARG_PREVIOUS_1_A	= 15,	
	GLESHAL_RGBARG_FORCES32  = 0x7FFFFFFF
}GLESHAL_RGBARG;

typedef enum 
{
	GLESHAL_RGBOP_REPLACE		= 0,
	GLESHAL_RGBOP_MODULATE		= 1,
	GLESHAL_RGBOP_ADD			= 2,
	GLESHAL_RGBOP_ADD_SIGNED	= 3,
	GLESHAL_RGBOP_INTERPOLATE	= 4,
	GLESHAL_RGBOP_SUBTRACT		= 5,
	GLESHAL_RGBOP_DOT3_RGB		= 6,
	GLESHAL_RGBOP_DOT3_RGBA		= 7,
	GLESHAL_RGBOP_FORCES32		= 0x7FFFFFFF
}GLESHAL_RGBOP;

typedef enum 
{
	GLESHAL_AARG_SOURCE_A		= 0,
	GLESHAL_AARG_SOURCE_1_A		= 1,
	GLESHAL_AARG_CONST_A		= 2,
	GLESHAL_AARG_CONST_1_A		= 3,	
	GLESHAL_AARG_FRAGMENT_A		= 4,
	GLESHAL_AARG_FRAGMENT_1_A	= 5,	
	GLESHAL_AARG_PREVIOUS_A		= 6,
	GLESHAL_AARG_PREVIOUS_1_A	= 7,
	GLESHAL_AARG_FORCES32		= 0x7FFFFFFF
}GLESHAL_AARG;

typedef enum 
{
	GLESHAL_AOP_REPLACE		= 0,
	GLESHAL_AOP_MODULATE	= 1,
	GLESHAL_AOP_ADD			= 2,
	GLESHAL_AOP_ADD_SIGNED	= 3,
	GLESHAL_AOP_INTERPOLATE	= 4,
	GLESHAL_AOP_SUBTRACT	= 5,
	GLESHAL_AOP_FORCES32	= 0x7FFFFFFF
}GLESHAL_AOP;

GLESHALbool GLESHAL_SetTextureBlend( unsigned int TextureStage, 
								GLESHAL_RGBARG RGBArg0, GLESHAL_RGBARG RGBArg1, GLESHAL_RGBARG RGBArg2,
								GLESHAL_RGBOP	RGBOp,
								GLESHAL_AARG AlphaArg0, GLESHAL_AARG AlphaArg1, GLESHAL_AARG AlphaArg2,
								GLESHAL_AOP	AlphaOp );

typedef enum
{
	GLESHAL_ALPHAFUNC_NEVER 		= 0,
	GLESHAL_ALPHAFUNC_LESS 			= 1, 
	GLESHAL_ALPHAFUNC_EQUAL			= 2,
	GLESHAL_ALPHAFUNC_LESSEQUAL		= 3,
	GLESHAL_ALPHAFUNC_GREATER		= 4,
	GLESHAL_ALPHAFUNC_NOTEQUAL		= 5,
	GLESHAL_ALPHAFUNC_GREATEREQUAL	= 6,
	GLESHAL_ALPHAFUNC_ALWAYS		= 7,
	GLESHAL_ALPHAFUNC_FORCE32		= 0x7FFFFFFF
}GLESHAL_ALPHAFUNC;

GLESHALbool GLESHAL_SetAlphaFunction( float RefValue, GLESHAL_ALPHAFUNC AlphaFunction );
								
//GLESHALbool GLESHAL_SetTextureConstColor( unsigned int ConstColor );
GLESHALbool GLESHAL_SetTextureConstColor( float R, float G, float B, float A );


typedef enum
{
	GLESHAL_MEMBUST_4 			= 0,
	GLESHAL_MEMBUST_8 			= 1,
	GLESHAL_MEMBUST_16 			= 2,
	GLESHAL_MEMBUST_FORCES32	= 0x7FFFFFFF
}GLESHAL_MEMBUST;

typedef enum 
{
	GLESHAL_VSTYPE_NORMALIZED_U8 	= 0,
	GLESHAL_VSTYPE_U8				= 1,
	GLESHAL_VSTYPE_S8				= 2,
	GLESHAL_VSTYPE_S16				= 3,
	GLESHAL_VSTYPE_S32				= 4,
	GLESHAL_VSTYPE_FIXED			= 5,
	GLESHAL_VSTYPE_FLOAT			= 7,
	GLESHAL_VSTYPE_FORCES32			= 0x7FFFFFFF
}GLESHAL_VSTYPE;

typedef enum 
{
	GLESHAL_INDEXTYPE_8				= 0,
	GLESHAL_INDEXTYPE_16			= 1,
	GLESHAL_INDEXTYPE_FORCES32		= 0x7FFFFFFF
}GLESHAL_INDEXTYPE;
/*
GLESHALbool GLESHAL_SetPrimitiveControl( unsigned int StreamValid, GLESHAL_INDEXTYPE IndexType, 
							GLESHALbool ClearCache, GLESHALbool LoopEnb, 
							GLESHALbool UseIndexEnb, GLESHALbool UseMatrixPaletteEnb );
*/
GLESHALbool GLESHAL_SetPrimitiveControl( unsigned int StreamValid, 
							GLESHAL_INDEXTYPE IndexType, 
							GLESHALbool ClearCache, GLESHALbool LoopEnb, 
							GLESHALbool UseIndexEnb, GLESHALbool UseMatrixPaletteEnb,
							unsigned int StartIndex,
							unsigned int EndIndex );

//	0: Matrix index
//	1: Vertex position
//	2: Color
//	3: Texture Coords
//	4: Normal
//	5: Point size array
typedef enum 
{
	GLESHAL_VERTEXSTREAM_MATRIXINDEX	= 0,
	GLESHAL_VERTEXSTREAM_POSITION		= 1,
	GLESHAL_VERTEXSTREAM_COLOR			= 2,
	GLESHAL_VERTEXSTREAM_TEXCOORD0		= 3,
	GLESHAL_VERTEXSTREAM_TEXCOORD1		= 4,
	GLESHAL_VERTEXSTREAM_NORMAL			= 5,
	GLESHAL_VERTEXSTREAM_POINTSIZE		= 6,
	GLESHAL_VERTEXSTREAM_WEIGHT			= 6,
	GLESHAL_VERTEXSTREAM_MATRIXPALETTE	= 7,
	GLESHAL_VERTEXSTREAM_FORCES32		= 0x7FFFFFFF
}GLESHAL_VERTEXSTREAM;

GLESHALbool GLESHAL_SetMatrixIndexVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetPositionVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetColorVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetNormalVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetPointSizeVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetTexCoordVertexStream( unsigned int Index, 
						const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetWeightVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetPaletteMatrixVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type );

GLESHALbool GLESHAL_SetVertexStreams( const unsigned int* Data, unsigned int StreamValid );

GLESHALbool GLESHAL_SetIndexStart( unsigned int Start );

GLESHALbool GLESHAL_SetIndexEnd( unsigned int End );

GLESHALbool GLESHAL_SetPrimitiveParamLoopControl( unsigned int ParamLoop, unsigned int ParamEnd );

GLESHALbool GLESHAL_SetParamData( unsigned int Index, unsigned char Param0, unsigned char Param1, unsigned char Param2, unsigned char Param3 );



/*

GLESHALAPI 
GLESHALbool GLESHAL_RegisterFill ( unsigned int RegisterOffset32, 
								  unsigned int NumberOfData32,
								  const unsigned int* pData32, 
								  unsigned int WaitFlag,
								  GLESHALbool InterruptRequest );
*/

//--------------------------------------------------------------------------
// FOG MODE
//--------------------------------------------------------------------------
enum GLESHAL_FOGMODE
{
	GLESHAL_FOGMODE_LINEAR		= 0,
	GLESHAL_FOGMODE_EXP			= 1,
	GLESHAL_FOGMODE_EXP2		= 2,
	GLESHAL_FOGMODE_FORCEU32	= 0x7FFFFFFF
};

//--------------------------------------------------------------------------
// FOGCOLOR
// Register Address : REG_BASE + 0x90
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetFogColor( float R, float G, float B, float A );

GLESHALAPI 
GLESHALbool GLESHAL_SetLinearFog( float Start, float End );

GLESHALAPI 
GLESHALbool GLESHAL_SetFog( GLESHAL_FOGMODE Mode, float Density );

/*
GLESHALAPI 
GLESHALbool GLESHAL_SetFogMode( GLESHAL_FOGMODE Mode );

GLESHALAPI 
void GLESHAL_SetFogDensity( float Density );

GLESHALAPI 
void GLESHAL_SetFogStart( float Start );

GLESHALAPI 
void GLESHAL_SetFogEnd( float End );
*/

//--------------------------------------------------------------------------
// DISPINFO -> Display Flush ( Flip )
// Register Address : REG_BASE + 0x98
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_FlipDisplayBuffer( GLESHALbool WaitSync, 
						   GLESHALbool FSAAEnb );


// GL coordinate�� window coordinate�� ��ȯ�ϱ� ����..
GLESHALAPI 
void GLESHAL_SetWindowSize( unsigned int Width, unsigned int Height );

//--------------------------------------------------------------------------
// functions for glClear
//--------------------------------------------------------------------------
// Window size���� ������ ���� ��� �� Color�� ����� �ȿ���.. 
GLESHALAPI 
GLESHALbool GLESHAL_ClearColorBuffer( float R, float G, float B, float A );

GLESHALAPI 
GLESHALbool GLESHAL_ClearDepthBuffer( unsigned short Depth );


//--------------------------------------------------------------------------
// RENDTRG0,RENDTRG1,RENDTRG2
// Register Address : REG_BASE + 0xB0~0xB8
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetDisplayBuffer( unsigned int Segment, 
									  unsigned int SegmentX, unsigned int SegmentY,
									  GLESHALbool FSAAEnb );

// Display size ����. (�̸��� ��������.. SetDisplaySize?)
GLESHALAPI 
GLESHALbool GLESHAL_SetScissorSize( unsigned int ScissorRect_X, 
									unsigned int ScissorRect_Y,
									unsigned int ScissorRect_Width, 
									unsigned int ScissorRect_Height );

// glDisable(GL_SCISSOR_TEST)�� ���, scissor size�� full screen size�� �����Ѵ�.
GLESHALAPI 
GLESHALbool GLESHAL_ScissorDisable( void );

//--------------------------------------------------------------------------
// ZBINFO,ZVBINFO,ZSCALE
// Register Address : REG_BASE + 0xC0~0xC8
//--------------------------------------------------------------------------
/// @brief	z-buffer function
enum GLESHAL_CMPFUNC
{
	GLESHAL_CMPFUNC_NEVER         = 0,
	GLESHAL_CMPFUNC_LESS          = 1,
	GLESHAL_CMPFUNC_EQUAL         = 2,
	GLESHAL_CMPFUNC_LESSEQUAL     = 3,
	GLESHAL_CMPFUNC_GREATER       = 4,
	GLESHAL_CMPFUNC_NOTEQUAL      = 5,
	GLESHAL_CMPFUNC_GREATEREQUAL  = 6,
	GLESHAL_CMPFUNC_ALWAYS        = 7,
	GLESHAL_CMPFUNC_FORCES32		= 0x7FFFFFFF
};

// DepthBuffer ���� �Լ��� �ѷ� ������ �ɰ� ���ϴ�.
// depth buffer segment ����  ����.
GLESHALAPI 
GLESHALbool GLESHAL_SetDepthBuffer( unsigned int Segment, 
								    unsigned int SegmentX, unsigned int SegmentY );

// depth function�� ����.
GLESHALAPI 
GLESHALbool GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC ZFunc );


//--------------------------------------------------------------------------
// VPORTBOT,VPORTH,VPORTLEFT,VPORTW
// Register Address : REG_BASE + 0xF0~0xFC
//--------------------------------------------------------------------------

GLESHALAPI 
GLESHALbool GLESHAL_SetViewport( int X, int Y, 
								 int Width, int Height );

//--------------------------------------------------------------------------
// GTECODE
// Register Address : REG_BASE + 0x200~0x2FF
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetGTECode( const unsigned int* pCodeList, 
							   unsigned int CodeOffset,
							   unsigned int CodeSize32 );
//GLESHALbool GLESHAL_SetGTECode( const unsigned int* pCodeList, 
//							   unsigned int CodeSize32 );

GLESHALAPI 
GLESHALbool GLESHAL_SetGTECodeWithOffset( const unsigned int* pCodeList, 
										 unsigned int CodeBase32, 
										 unsigned int CodeSize32 );

//--------------------------------------------------------------------------
// GTECONST
// Register Address : REG_BASE + 0x300~0x3FF
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetGTEConst( unsigned int Index, 
								unsigned int NumberOfValue,
								const float* pValueList );

//--------------------------------------------------------------------------
// TSEINPUT
// Register Address : REG_BASE + 0x500~0x5FF
//--------------------------------------------------------------------------
GLESHALAPI 
GLESHALbool GLESHAL_SetTSEInput ( unsigned int Index, 
								 unsigned int NumberOfValue,
								 const float* pValueList );

GLESHALAPI 
GLESHALbool GLESHAL_RunGTE ( unsigned int Vnum,				
							 GLESHALbool Rendering,		
							 GLESHALbool InverseCullMode );

GLESHALAPI 
GLESHALbool GLESHAL_RunTSE_Triangle( GLESHALbool InverseCullMode );

GLESHALAPI 
GLESHALbool GLESHAL_RunPrimitive( void );

//--------------------------------------------------------------------------
// face culling interface
//--------------------------------------------------------------------------
enum GLESHAL_CULLFACE
{
	GLESHAL_CULLFACE_FRONT			= 0,
	GLESHAL_CULLFACE_BACK			= 1,
	GLESHAL_CULLFACE_FRONTANDBACK	= 2,	// �̰� ���� �ؾ��ϳ�..
	GLESHAL_CULLFACE_FORCEU32		= 0x7FFFFFFF
};

enum GLESHAL_FRONTFACE
{
	GLESHAL_FRONTFACE_CW		= 0,
	GLESHAL_FRONTFACE_CCW		= 1,
	GLESHAL_FRONTFACE_FORCEU32	= 0x7FFFFFFF
};

GLESHALAPI 
void GLESHAL_SetCullFace( GLESHAL_CULLFACE CullfaceState );

GLESHALAPI 
void GLESHAL_SetFrontFace( GLESHAL_FRONTFACE FrontfaceState );


//--------------------------------------------------------------------------
// volume culling interface
//--------------------------------------------------------------------------
/// @brief	volume culling state
enum GLESHAL_VOLUMECULLSTATE
{
	GLESHAL_VOLUMECULLSTATE_NONE     = 0,
	GLESHAL_VOLUMECULLSTATE_TEST     = 1,
	GLESHAL_VOLUMECULLSTATE_CULLING  = 2,
	GLESHAL_VOLUMECULLSTATE_FORCES32 = 0x7FFFFFFF
};

GLESHALAPI 
void GLESHAL_SetVolumeCullingState ( GLESHAL_VOLUMECULLSTATE State );

////--------------------------------------------------------------------------
////	simple rendering interface
////	mes_grp3d00_render.cpp
////--------------------------------------------------------------------------
GLESHALAPI 
void GLESHAL_OpenCommandQueue(
	unsigned int* pCommand_Virtual,	
	unsigned int* pCommand_Physical,
	unsigned int Size64
);

GLESHALAPI 
void GLESHAL_CloseCommandQueue();

GLESHALAPI 
unsigned __int64 GLESHAL_GetFrontOfCommandQueue( void );

GLESHALAPI 
unsigned __int64 GLESHAL_GetRearOfCommandQueue( void );

//GLESHALAPI 
//void GLESHAL_WaitToIdleState( void );
GLESHALAPI 
GLESHALbool GLESHAL_IsIdleState( void );

GLESHALAPI 
void GLESHAL_Flush( void );

GLESHALAPI 
GLESHALbool GLESHAL_IsDoneFlipCommand( void );

GLESHALAPI 
void GLESHAL_SetVirtualAddressOfRegisterSet( unsigned int RegisterSetIndex, unsigned int VirtualAddress );

GLESHALAPI 
void GLESHAL_Nop( void );
GLESHALAPI 
void GLESHAL_Nops( unsigned int count );
GLESHALAPI 
GLESHALbool GLESHAL_RegisterFill ( unsigned int RegisterOffset32, 
								  unsigned int NumberOfData32,
								  const unsigned int* pData32, 
								  unsigned int WaitFlag,
								  GLESHALbool InterruptRequest );

#ifdef __cplusplus
}
#endif

#endif // _LIBGLES_CM_LITE_HAL_H
