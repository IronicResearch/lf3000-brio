//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglCreatePixmapSurface.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : ��Ʈ
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLSurface eglCreatePixmapSurface (EGLDisplay dpy, EGLConfig config, NativePixmapType pixmap, const EGLint *attrib_list)
{
	CALL_LOG;
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_CONFIG is generated if config is not an EGL config.
	const __CONFIG__* pconfig = (const __CONFIG__*)config;
	if( ! pconfig || EGLCONFIG_FLAG != pconfig->m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_CONFIG );
		return EGL_NO_SURFACE;
	}

	//	EGL_BAD_NATIVE_PIXMAP may be generated if native_pixmap is not a valid native pixmap.
	{
		//	!!!
	}

	//	EGL_BAD_ATTRIBUTE is generated if attrib_list contains an invalid pixmap attribute or if an attribute value is not recognized or out of range.
	//	Must be NULL or empty (first attribute is EGL_NONE).
	if( attrib_list && EGL_NONE != attrib_list[0] )
	{
		EGLSETERROR( EGL_BAD_ATTRIBUTE );
		return EGL_NO_SURFACE;
	}

	//	EGL_BAD_MATCH is generated if the attributes of native_pixmap do not correspond to config or
	//	              if config does not support rendering to pixmaps
	//                (the EGL_SURFACE_TYPE attribute does not contain EGL_PIXMAP_BIT).
	if( // !!!
		0 == (pconfig->m_SURFACE_TYPE & EGL_PIXMAP_BIT) )
	{
		EGLSETERROR( EGL_BAD_MATCH );
		return EGL_NO_SURFACE;
	}

	//	EGL_BAD_ALLOC is generated if there are not enough resources to allocate the new surface.

	return EGL_NO_SURFACE;
}
