//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glQueryMatrixxOES.cpp
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/08/23 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

GLbitfield glQueryMatrixxOES(GLfixed *mantissa, GLint *exponent)
{
	CALL_LOG;
	const Matrix4x4* currentMatrix;
	
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
	if( GL_MATRIX_PALETTE_OES == __GLSTATE__.m_MatrixMode )
	{
		currentMatrix = &__GLSTATE__.m_MatrixPalette[__GLSTATE__.m_CurrentPaletteMatrix].CurrentMatrix();
	} else
#endif
	{
		currentMatrix = &__GLSTATE__.m_pCurrentMatrixMode->CurrentMatrix();
	}

	for ( int col = 0; col < 4; ++col )				
	for ( int row = 0; row < 4; ++row )
	{
		int index = row + col * 4;
		mantissa[index] = VF2X(currentMatrix->m[row][col]);
		exponent[index] = 0;
	}

	return 0;
}
