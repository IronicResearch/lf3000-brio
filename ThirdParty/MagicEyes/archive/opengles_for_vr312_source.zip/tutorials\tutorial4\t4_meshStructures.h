#ifndef MESH_DEFINITIONS_H
#define MESH_DEFINITIONS_H

namespace __TUTORIAL4__
{

//Structure to hold the optimized mesh data for rendering
struct FixedMesh
{
  GLshort indexCounter;
  GLshort vertexCounter;  
  GLshort *Indices;
  GLfixed *Geometry;
  GLfixed *Normals;
  GLfixed *TexCoord;  
};

//Structure to hold the data readed from the file
struct GenericObjectData
{
  char Name[128];
  char ParentName[128];
  unsigned int *Indices;
  float *Geometry;
  float *Normals;
  float *TexCoord;
  unsigned long iC;
  unsigned long vC;  
};

//GSD file header 
struct GSDHeader
{
  char id[32];
  char version[16];
  int numberOfSubObjects;
};
 
}//namespace

#endif
