//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glMatrixIndexPointerOES.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glMatrixIndexPointerOES (GLint size, GLenum type, GLsizei stride, const GLvoid *pointer)
{
	CALL_LOG;
	if (type != GL_UNSIGNED_BYTE)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (size < 1 || size > GLPARAM_MAX_VERTEX_UNITS_OES)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (stride < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (stride == 0)
	{
		stride = sizeof (GLubyte) * size;
	}

	__GLSTATE__.m_MatrixIndexPointer.m_Size = size;
	__GLSTATE__.m_MatrixIndexPointer.m_Type = type;
	__GLSTATE__.m_MatrixIndexPointer.m_Stride = stride;
	__GLSTATE__.m_MatrixIndexPointer.m_Pointer = pointer;
	__GLSTATE__.m_MatrixIndexPointer.m_Buffer = __GLSTATE__.m_BindedBuffer[0];
	__GLSTATE__.m_MatrixIndexPointer.SetSetStreamInfo(3);
}
