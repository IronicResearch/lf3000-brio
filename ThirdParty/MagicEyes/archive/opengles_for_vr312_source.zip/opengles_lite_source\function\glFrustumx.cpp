//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glFrustumx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_0oj1.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// The glFrustum function multiplies the current matrix by a perspective matrix.

//	for GL
//	glFrustum

//	for GL-ES
//	glFrustumf

// glGet with argument GL_MATRIX_MODE
// glGet with argument GL_MODELVIEW_MATRIX
// glGet with argument GL_PROJECTION_MATRIX
// glGet with argument GL_TEXTURE_MATRIX
//
// GL_INVALID_VALUE      znear or zfar was not positive. 
// GL_INVALID_OPERATION  glFrustum was called between a call to glBegin and the corresponding call to glEnd. 


void glFrustumx (GLfixed left, GLfixed right, GLfixed bottom, GLfixed top, GLfixed zNear, GLfixed zFar)
{
	CALL_LOG;
	Vfloat l = X2VF(left   );
	Vfloat r = X2VF(right  );
	Vfloat b = X2VF(bottom );
	Vfloat t = X2VF(top    );
	Vfloat n = X2VF(zNear  );
	Vfloat f = X2VF(zFar   );
	if ( l==r || t==b || n <= 0 || f <= 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	__GLSTATE__.m_pCurrentMatrixMode->Frustum( l, r, b, t, n, f );
	__GLSTATE__.m_pCurrentMatrixMode->m_IsUpdated = GL_TRUE;

	if( GL_MATRIX_PALETTE_OES == __GLSTATE__.m_MatrixMode )
		EnableMatrixPaletteUpdate( __GLSTATE__.m_CurrentPaletteMatrix );
}
