//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBlendFunc.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_4vs3.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glBlendFunc (GLenum sfactor, GLenum dfactor)
{
	CALL_LOG;
	GLESHAL_BLEND srcBlend;
	GLESHAL_BLEND dstBlend;

	switch (sfactor)
	{
		case GL_ZERO:
			srcBlend = GLESHAL_BLEND_ZERO;
			break;
		case GL_ONE:
			srcBlend = GLESHAL_BLEND_ONE;
			break;
		case GL_SRC_COLOR:
			srcBlend = GLESHAL_BLEND_SRCCOLOR;
			break;
		case GL_ONE_MINUS_SRC_COLOR:
			srcBlend = GLESHAL_BLEND_INVSRCCOLOR;
			break;
		case GL_DST_COLOR:
			srcBlend = GLESHAL_BLEND_DESTCOLOR;
			break;
		case GL_ONE_MINUS_DST_COLOR:
			srcBlend = GLESHAL_BLEND_INVDESTCOLOR;
			break;
		case GL_SRC_ALPHA:
			srcBlend = GLESHAL_BLEND_SRCALPHA;
			break;
		case GL_ONE_MINUS_SRC_ALPHA:
			srcBlend = GLESHAL_BLEND_INVSRCALPHA;
			break;
		case GL_DST_ALPHA:
			srcBlend = GLESHAL_BLEND_ONE;
			break;			
		case GL_ONE_MINUS_DST_ALPHA:
			srcBlend = GLESHAL_BLEND_ZERO;
			break;
		case GL_SRC_ALPHA_SATURATE:
			srcBlend = GLESHAL_BLEND_ZERO;
			break;
		default:						
			GLSETERROR(GL_INVALID_ENUM);
			return;
	}

	switch (dfactor)
	{
		case GL_ZERO:
			dstBlend = GLESHAL_BLEND_ZERO;
			break;
		case GL_SRC_COLOR:
			dstBlend = GLESHAL_BLEND_SRCCOLOR;
			break;
		case GL_ONE_MINUS_SRC_COLOR:
			dstBlend = GLESHAL_BLEND_INVSRCCOLOR;
			break;
		case GL_DST_COLOR:
			dstBlend = GLESHAL_BLEND_DESTCOLOR;
			break;
		case GL_ONE_MINUS_DST_COLOR:
			dstBlend = GLESHAL_BLEND_INVDESTCOLOR;
			break;
		case GL_SRC_ALPHA:
			dstBlend = GLESHAL_BLEND_SRCALPHA;
			break;
		case GL_ONE_MINUS_SRC_ALPHA:
			dstBlend = GLESHAL_BLEND_INVSRCALPHA;
			break;
		case GL_DST_ALPHA:	
			dstBlend = GLESHAL_BLEND_ONE;
			break;			
		case GL_ONE_MINUS_DST_ALPHA:
			dstBlend = GLESHAL_BLEND_ZERO;
			break;			
		case GL_ONE:
			dstBlend = GLESHAL_BLEND_ONE;
			break;
		default:						
			GLSETERROR(GL_INVALID_ENUM);
			return;
	}

	__GLSTATE__.m_BlendFunc_Src = sfactor; // GL_ONE
	__GLSTATE__.m_BlendFunc_Dst = dfactor; // GL_ZERO
	
	GLESHAL_SetBlendFactor( srcBlend, dstBlend );
}
