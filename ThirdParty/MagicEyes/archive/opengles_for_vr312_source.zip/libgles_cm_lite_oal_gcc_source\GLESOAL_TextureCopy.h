//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#ifndef _GLESOAL_TEXTURECOPY_H
#define _GLESOAL_TEXTURECOPY_H

//#include "libgles_cm_lite_oal.h"
#include "GLESOAL_Private.h"

#if		defined(ROTATE_0)
#elif	defined(ROTATE_90)
#elif	defined(ROTATE_180)
#elif	defined(ROTATE_270)
#else
    #define DISPLAY__00 0
    #define DISPLAY__90 1
    #define DISPLAY_180 2
    #define DISPLAY_270 3
    int GLESOAL_GetDisplayDirection( void );
#endif

namespace __GLESOAL__
{

template< typename WRITECLASS, typename READCLASS >
inline void TextureCopyWithObject( WRITECLASS Writer, READCLASS Reader, unsigned int Width, unsigned int Height )
{
	int i, j;
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( i, j, Reader.Read(i, j) );
}

template< typename WRITECLASS, typename READCLASS >
inline void ReadDisplayWriteTexture( WRITECLASS Writer, READCLASS Reader, 
										    unsigned int Width, unsigned int Height )
{
	int i, j;
/*
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
#if		defined(ROTATE_0)
			Writer.Write( i, j, Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_90)
			Writer.Write( j, (Width - i - 1), Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_180)
			Writer.Write( (Width - i - 1), (Height - j - 1), Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_270)
			Writer.Write( (Height - j - 1), i, Reader.Read(i, g_WindowHeight-j) );
#else
#		error "you must define ROTATE_XXX"
#endif
*/


#if		defined(ROTATE_0)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( i, j, Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_90)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( j, (Width - i - 1), Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_180)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( (Width - i - 1), (Height - j - 1), Reader.Read(i, g_WindowHeight-j) );
#elif	defined(ROTATE_270)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( (Height - j - 1), i, Reader.Read(i, g_WindowHeight-j) );
#else
//#		error "you must define ROTATE_XXX"
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( i, j, Reader.Read(i, g_WindowHeight-j) );
            break;
        case DISPLAY__90 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( j, (Width - i - 1), Reader.Read(i, g_WindowHeight-j) );
            break;
        case DISPLAY_180 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( (Width - i - 1), (Height - j - 1), Reader.Read(i, g_WindowHeight-j) );
        	break;
        case DISPLAY_270 :                    
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( (Height - j - 1), i, Reader.Read(i, g_WindowHeight-j) );
            break;
        }
#endif


}

template< typename WRITECLASS, typename READCLASS >
inline void ReadMemoryWriteDisplay( WRITECLASS Writer, READCLASS Reader, 
										    unsigned int Width, unsigned int Height )
{
	int i, j;
/*
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
#if		defined(ROTATE_0)
			Writer.Write( i, (-j - 1), Reader.Read(i, j) );
#elif	defined(ROTATE_90)
			Writer.Write( (-i - 1), (-j - 1), Reader.Read(j, i) );
#elif	defined(ROTATE_180)
			Writer.Write( i, (-j - 1), Reader.Read((Width - i - 1), (Height - j - 1)) );
#elif	defined(ROTATE_270)
			Writer.Write( i, j, Reader.Read(j, i) );
#else
#		error "you must define ROTATE_XXX"
#endif
*/
#if		defined(ROTATE_0)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( i, (-j - 1), Reader.Read(i, j) );
#elif	defined(ROTATE_90)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( (-i - 1), (-j - 1), Reader.Read(j, i) );
#elif	defined(ROTATE_180)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( i, (-j - 1), Reader.Read((Width - i - 1), (Height - j - 1)) );
#elif	defined(ROTATE_270)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
			Writer.Write( i, j, Reader.Read(j, i) );
#else
//#		error "you must define ROTATE_XXX"
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( i, (-j - 1), Reader.Read(i, j) );
            break;
        case DISPLAY__90 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( (-i - 1), (-j - 1), Reader.Read(j, i) );
            break;
        case DISPLAY_180 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( i, (-j - 1), Reader.Read((Width - i - 1), (Height - j - 1)) );
        	break;
        case DISPLAY_270 :                    
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
					Writer.Write( i, j, Reader.Read(j, i) );
            break;
        }
#endif
}

template< typename WRITECLASS, typename READCLASS >
inline void ReadMemoryWriteDisplay_FSAA( WRITECLASS Writer, READCLASS Reader, 
										    unsigned int Width, unsigned int Height )
{
	int i, j;
/*
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
		{
#if		defined(ROTATE_0)
			Writer.Write( i, j*2, Reader.Read(i, j) );
			Writer.Write( i, j*2+1, Reader.Read(i, j) );
#elif	defined(ROTATE_90)
			Writer.Write( (Width - i - 1), (Height - j - 1)*2, Reader.Read(j, i) );
			Writer.Write( (Width - i - 1), (Height - j - 1)*2+1, Reader.Read(j, i) );
#elif	defined(ROTATE_180)
			Writer.Write( (Width - i - 1), (Height - j - 1)*2, Reader.Read(i, j) );
			Writer.Write( (Width - i - 1), (Height - j - 1)*2+1, Reader.Read(i, j) );
#elif	defined(ROTATE_270)
			Writer.Write( i, j*2, Reader.Read(j, i) );
			Writer.Write( i, j*2+1, Reader.Read(j, i) );
#else
#		error "you must define ROTATE_XXX"
#endif
		}
*/
#if		defined(ROTATE_0)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
		{
			Writer.Write( i, (-j - 1)*2, Reader.Read(i, j) );
			Writer.Write( i, (-j - 1)*2-1, Reader.Read(i, j) );
		}
#elif	defined(ROTATE_90)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
		{
			Writer.Write( (-i - 1), (-j - 1)*2, Reader.Read(j, i) );
			Writer.Write( (-i - 1), (-j - 1)*2-1, Reader.Read(j, i) );
		}
#elif	defined(ROTATE_180)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
		{
			Writer.Write( i, (-j - 1)*2, Reader.Read((Width - i - 1), (Height - j - 1)) );
			Writer.Write( i, (-j - 1)*2-1, Reader.Read((Width - i - 1), (Height - j - 1)) );
		}
#elif	defined(ROTATE_270)
	for( j=0; j<(int)Height; j++)
		for( i=0; i<(int)Width; i++)
		{
			Writer.Write( i, j*2, Reader.Read(j, i) );
			Writer.Write( i, j*2+1, Reader.Read(j, i) );
		}
#else
//#		error "you must define ROTATE_XXX"
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
				{
					Writer.Write( i, (-j - 1)*2, Reader.Read(i, j) );
					Writer.Write( i, (-j - 1)*2-1, Reader.Read(i, j) );
				}
            break;
        case DISPLAY__90 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
				{
					Writer.Write( (-i - 1), (-j - 1)*2, Reader.Read(j, i) );
					Writer.Write( (-i - 1), (-j - 1)*2-1, Reader.Read(j, i) );
				}
            break;
        case DISPLAY_180 : 
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
				{
					Writer.Write( i, (-j - 1)*2, Reader.Read((Width - i - 1), (Height - j - 1)) );
					Writer.Write( i, (-j - 1)*2-1, Reader.Read((Width - i - 1), (Height - j - 1)) );
				}
        	break;
        case DISPLAY_270 :                    
			for( j=0; j<(int)Height; j++)
				for( i=0; i<(int)Width; i++)
				{
					Writer.Write( i, j*2, Reader.Read(j, i) );
					Writer.Write( i, j*2+1, Reader.Read(j, i) );
				}
            break;
        }
#endif
}

template< typename WRITECLASS, typename READCLASS >
inline void ReadDisplayWriteValidTexture( WRITECLASS Writer, READCLASS Reader, 
										unsigned int Width, unsigned int Height,
										unsigned int CountX, unsigned int CountY )
{
	unsigned int i, j;
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
		{
			unsigned int x, y;
			for( y=0; y<CountY; y++ )
				for( x=0; x<CountX; x++ )
				{
					unsigned short value = Reader.Read(i, g_WindowHeight-j);
					Writer.Write( i*CountX + x, j*CountY + y, value );
				}
		}
}

template< typename WRITECLASS, typename READCLASS >
inline GLESOALbool TextureCopy( const GLESOAL_MEMORY2D* pMemory2D, 
					 unsigned int X, unsigned int Y,
					 unsigned int Width, unsigned int Height, 
					 const void* pSrc, unsigned int SrcStride )
{
	//if( Memory2D )
	{
		if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
			return 0;
		
		READCLASS Reader( pSrc, SrcStride );
		WRITECLASS Writer( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+X, pMemory2D->VirtualSegY+Y );


		unsigned int curWidth = SrcStride / READCLASS::BYTE_PER_PIXEL;	// source�� ���� width ���.
		if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
			curWidth = Width;

		TextureCopyWithObject< WRITECLASS, READCLASS >( Writer, Reader, curWidth, Height );
		return 1;
	}
	//else
		//return 0;
}

} // namespace __GLESOAL__

using namespace __GLESOAL__;

#endif // _GLESOAL_TEXTURECOPY_H
