//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopyFromVideo.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/03/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "GLESOAL_Private.h"

namespace {
    #define Segment_VR3511F( Address )      ((Address)>>21)
    #define Segment_X_VR3511F( Address )    ((Address)&((1<<11)-1))
    #define Segment_Y_VR3511F( Address )    (((Address)>>11)&((1<<10)-1))
    #define Segment_MP2530F( Address )      ((((Address)>>22)<<1) | (((Address)>>11)&1))
    #define Segment_X_MP2530F( Address )    ((Address)&((1<<11)-1))
    #define Segment_Y_MP2530F( Address )    (((Address)>>12)&((1<<10)-1))

	inline void GetSegmentInfo
	(
		unsigned int  Address, /// [in] block memory address
		unsigned int& Segment, /// [out] segment number of block memory
		unsigned int& X,	   /// [out] horizontal position in segment (16bpp unit)
		unsigned int& Y		   /// [out] vertical position in segment
	)
	{

		Segment = Segment_MP2530F( Address );
		X       = Segment_X_MP2530F( Address );
		Y       = Segment_Y_MP2530F( Address );
	}

	typedef struct 
	{
		volatile unsigned int   CONTROL;                   ///< 0x00 [RW] : Control Register
		volatile unsigned int   SIZE   ;                   ///< 0x04 [ W] : Size Register
		volatile unsigned int   ADDRY  ;                   ///< 0x08 [ W] : Address Y Channel Register
		volatile unsigned int   ADDRCB ;                   ///< 0x0C [ W] : Address Cb Channel Register
		volatile unsigned int   ADDRCR ;                   ///< 0x10 [ W] : Address Cr Channel Register
		volatile unsigned int   ADDRTEX;                   ///< 0x14 [ W] : Address Texture Register
		volatile unsigned int   TPCTRL ;                   ///< 0x18 [ W] : Transparency Control Register
		volatile unsigned int   TPY    ;                   ///< 0x1C [ W] : Transparency Y Range Register
		volatile unsigned int   TPCB   ;                   ///< 0x20 [ W] : Transparency Cb Range Register
		volatile unsigned int   TPCR   ;                   ///< 0x24 [ W] : Transparency Cr Range Register
		volatile unsigned short RESERVED[(0x7C0-0x28)/2];  ///< 0x28 ~ 0x7BF : Reserved Region
		volatile unsigned int   CLKENB;                    ///< Clock Enable Register
	} MES_CSC03_RegisterStructure;
}


//------------------------------------------------------------------------------
//
//	
//
//------------------------------------------------------------------------------

GLESOALbool GLESOAL_ConvertColorSpace420( const void *pY,const void *pCb,const void *pCr,
										  int clipx, int clipy, int clipwidth, int clipheight,
									      GLESOAL_MEMORY2D* pDest )
{
	// you must set a virtual address of CSC
	volatile MES_CSC03_RegisterStructure* pcsc = 0;

	if( ! pcsc ){ return 0; }

	const unsigned int QMODE  = 1; // 0: 220     1: 256
	const unsigned int DITHER = 1; // 0: disable 1: enable
	const unsigned int INTENB = 0; // 0: disable 1: enable

	// check inputs
	if( 0 != (clipwidth&0xF) || 0 != (clipheight&0xF) ){ return 0; }
	if( clipx<0 || clipy<0 || clipwidth<=0 || clipheight<=0 ){ return 0; }
	if( clipwidth > (int)pDest->Width || clipheight > (int)pDest->Height ){ return 0; }
	{
		// ����/���̸� �����ϴ� ���� ���� 2�� �¼��� ã�´�.
		int width2n;
		int height2n;
		for( width2n = 1; width2n < clipwidth; width2n <<= 1 ){ ; }
		for( height2n = 1; height2n < clipheight; height2n <<= 1 ){ ; }		
		if( 0 != (clipx%width2n ) ){ return 0; }
		if( 0 != (clipy%height2n) ){ return 0; }
	}
	
	// get physical address info
	unsigned int Segment_Y , X_Y,  Y_Y;
	unsigned int Segment_Cb, X_Cb, Y_Cb;
	unsigned int Segment_Cr, X_Cr, Y_Cr;
	unsigned int Segment_Tex, X_Tex, Y_Tex;
	GetSegmentInfo( (unsigned int)pY , Segment_Y , X_Y , Y_Y  );
	GetSegmentInfo( (unsigned int)pCb, Segment_Cb, X_Cb, Y_Cb );
	GetSegmentInfo( (unsigned int)pCr, Segment_Cr, X_Cr, Y_Cr );
	Segment_Tex = pDest->PhysicalSegment;
	X_Tex       = pDest->PhysicalSegX;
	Y_Tex       = pDest->PhysicalSegY;

	// set offset
	X_Y += clipx ; X_Cb += (clipx/2); X_Cr += (clipx/2);
	Y_Y += clipy ; Y_Cb += (clipy/2); Y_Cr += (clipy/2);

	// 16bpp ��ǥ��� ��ȯ.
	X_Y   >>= 1; 
	X_Cb  >>= 1;
	X_Cr  >>= 1;
	X_Tex >>= 1;

	#if	defined(CHIPID_MP2530F)
	//	enable CSC clock (for MP2530F only)
	pcsc->CLKENB = (1<<3)|(3<<0);
	#endif

	// run CSC
	pcsc->SIZE    = ((clipheight - 1) << 16) | (clipwidth - 1);
	pcsc->ADDRY   = (Segment_Y   << 21) | (Y_Y   << 11) | (X_Y   << 1);
	pcsc->ADDRCB  = (Segment_Cb  << 21) | (Y_Cb  << 11) | (X_Cb  << 1);
	pcsc->ADDRCR  = (Segment_Cr  << 21) | (Y_Cr  << 11) | (X_Cr  << 1);
	pcsc->ADDRTEX = (Segment_Tex << 21) | (Y_Tex << 11) | (X_Tex << 1);
	pcsc->CONTROL = (DITHER << 5) | (QMODE << 4) | (INTENB << 1) | 1;

	//	wait for CSC idle.
	while( pcsc->CONTROL & (1UL << 0) ){ ; }

	#if	defined(CHIPID_MP2530F)
	//	disable CSC clock (for MP2530F only)
	pcsc->CLKENB = 0;
	#endif

	return 1;
}

