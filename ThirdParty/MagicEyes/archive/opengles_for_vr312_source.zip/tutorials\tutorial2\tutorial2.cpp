//#include "main.h" //We need the defines and prototypes from in.
#include "t2_render.h"

namespace __TUTORIAL2__
{

//Some useful global handles
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.
GLboolean drawInOrtho = GL_TRUE; //This variable will change with every click in the touch screen of the pda

}

using namespace __TUTORIAL2__;

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial2Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
	  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;
  
  if(!InitOGLES()) return GL_FALSE; //OpenGL ES Initialization
  
 
  unsigned int startTime = OS_GetTickCount();
  unsigned int frames = 1800;
  
  drawInOrtho = GL_TRUE;
  
  //Message Loop
  //while(!done)
  while(frames--)  
  {
     Render();
      
  	__int64 interval = (__int64)(OS_GetTickCount())-(__int64)startTime;
  	
  	if(interval < 0)
  		interval *= -1;
    
    if( interval > 5000 )
  	{
  		if( drawInOrtho )
  		{
  			SetOrtho();
  			drawInOrtho = GL_FALSE;
  		}
  		else
  		{
  			SetPerspective();
  			drawInOrtho = GL_TRUE;	
  		}
  		startTime = OS_GetTickCount();  		
  	}	 
  }
  
  //Clean up all
  Clean();
 
  return 0;
}
