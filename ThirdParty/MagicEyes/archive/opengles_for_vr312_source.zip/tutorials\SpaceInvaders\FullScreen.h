/*There are a unresolved bug in this functions. The fullscreen works fine, but, after closing the application
  WinCE windows are not restored correctly*/
int InitFullScreen	(void);
int DoFullScreen	(bool);
