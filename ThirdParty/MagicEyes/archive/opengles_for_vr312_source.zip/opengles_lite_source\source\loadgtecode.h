//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : loadgtecode.h
//	Description: 
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2008/03/20 Yuni GL_SPOT_EXPONENT, GL_SHINENESS ����
//	   2008/03/12 Yuni GL_NORMALIZE ����
//	   2007/10/18 Yuni Light 8�� ����.
//	   2007/09/07 Yuni �߸��� GTE code �о���̴� bug ����.
//	   2007/02/05 Yuni first implementation
//------------------------------------------------------------------------------
#ifndef _LOADGTECODE_H
#define _LOADGTECODE_H

// CODEARRY(A)
// -> g_gtecode_A
#define CODEARRY(code_name)	(g_ ## code_name)
#define GTECODEBODY(code_name)	{CODEARRY(code_name), (sizeof(CODEARRY(code_name))/sizeof(unsigned int))}

namespace
{

//------------------------------------------------------------------------------
// triangle
//------------------------------------------------------------------------------
	// position & normal
	const unsigned int CODEARRY(GTECode_pos)[] =
	#include "../gtecode/GTECode_pos.gtxt"
	;
	const unsigned int CODEARRY(GTECode_pos_norm)[] =
	#include "../gtecode/GTECode_pos_norm.gtxt"
	;
	const unsigned int CODEARRY(GTECode_pos_pm)[] =
	#include "../gtecode/GTECode_pos_pm.gtxt"
	;
	const unsigned int CODEARRY(GTECode_pos_norm_pm)[] =
	#include "../gtecode/GTECode_pos_norm_pm.gtxt"
	;

	// normal normalize
	const unsigned int CODEARRY(GTECode_norm_normalize)[] =
	#include "../gtecode/GTECode_norm_normalize.gtxt"
	;
	
	// light set page
	const unsigned int CODEARRY(GTECode_setpage_light0)[] =
	#include "../gtecode/GTECode_setpage_light0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light1)[] =
	#include "../gtecode/GTECode_setpage_light1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light2)[] =
	#include "../gtecode/GTECode_setpage_light2.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light3)[] =
	#include "../gtecode/GTECode_setpage_light3.gtxt"
	;	
	const unsigned int CODEARRY(GTECode_setpage_light4)[] =
	#include "../gtecode/GTECode_setpage_light4.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light5)[] =
	#include "../gtecode/GTECode_setpage_light5.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light6)[] =
	#include "../gtecode/GTECode_setpage_light6.gtxt"
	;
	const unsigned int CODEARRY(GTECode_setpage_light7)[] =
	#include "../gtecode/GTECode_setpage_light7.gtxt"
	;

	// light mode
	const unsigned int CODEARRY(GTECode_color_none)[] =
	#include "../gtecode/GTECode_color_none.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_amb)[] =
	#include "../gtecode/GTECode_color_amb.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_amb_cm)[] =
	#include "../gtecode/GTECode_color_amb_cm.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_dir_0)[] =
	#include "../gtecode/GTECode_color_dir_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_dir_1)[] =
	#include "../gtecode/GTECode_color_dir_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_dir_cm_0)[] =
	#include "../gtecode/GTECode_color_dir_cm_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_dir_cm_1)[] =
	#include "../gtecode/GTECode_color_dir_cm_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_pt_0)[] =
	#include "../gtecode/GTECode_color_pt_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_pt_1)[] =
	#include "../gtecode/GTECode_color_pt_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_pt_cm_0)[] =
	#include "../gtecode/GTECode_color_pt_cm_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_pt_cm_1)[] =
	#include "../gtecode/GTECode_color_pt_cm_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_spot_0)[] =
	#include "../gtecode/GTECode_color_spot_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_spot_1)[] =
	#include "../gtecode/GTECode_color_spot_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_spot_2)[] =
	#include "../gtecode/GTECode_color_spot_2.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_spot_cm_1)[] =
	#include "../gtecode/GTECode_color_spot_cm_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_color_spot_cm_2)[] =
	#include "../gtecode/GTECode_color_spot_cm_2.gtxt"
	;

    // texture
	const unsigned int CODEARRY(GTECode_tex_0)[] =
	#include "../gtecode/GTECode_tex_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_tex_1)[] =
	#include "../gtecode/GTECode_tex_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_tex_all)[] =
	#include "../gtecode/GTECode_tex_all.gtxt"
	;

	// render
	const unsigned int CODEARRY(GTECode_render_triangle)[] =
	#include "../gtecode/GTECode_render_triangle.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_triangle_flat)[] =
	#include "../gtecode/GTECode_render_triangle_flat.gtxt"
	;	
	const unsigned int CODEARRY(GTECode_render_point)[] =
	#include "../gtecode/GTECode_render_point.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_pointsprite_0)[] =
	#include "../gtecode/GTECode_render_pointsprite_0.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_pointsprite_1)[] =
	#include "../gtecode/GTECode_render_pointsprite_1.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_pointsprite_all)[] =
	#include "../gtecode/GTECode_render_pointsprite_all.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_line)[] =
	#include "../gtecode/GTECode_render_line.gtxt"
	;
	const unsigned int CODEARRY(GTECode_render_line_flat)[] =
	#include "../gtecode/GTECode_render_line_flat.gtxt"	
	;

} // namespace


#endif // #ifndef _LOADGTECODE_H
