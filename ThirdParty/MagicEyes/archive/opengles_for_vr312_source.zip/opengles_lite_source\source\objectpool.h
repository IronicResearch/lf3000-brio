//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : objectpool.h
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/10/16 Yuni	 ObjectPool destroy �߰�.
//	   2006/08/22 Gamza first implementation
//------------------------------------------------------------------------------
#ifndef _OBJECTPOOL_H
#define _OBJECTPOOL_H

namespace __MES_OPENGL_ES__
{

template< typename T, int INITIAL_SIZE, int INC_FACTOR = 2>
class ObjectPool
{
public:
	void	Destroy		( void );
	bool    Alloc		( unsigned int N, unsigned int* pItems );
	bool    Alloc		( unsigned int Index );
	bool	Free		( unsigned int N, const unsigned int* pItems );
	T*		GetObject	( unsigned int Index );	
	bool	IsObject	( unsigned int Index );

	void    Reset       ( void );

public:
	ObjectPool( void );
	virtual ~ObjectPool( void );
private:
	bool IncreaseBuffer( unsigned int NewSize );

	struct ObjectRecord
	{
		union
		{
			T* 			 m_pObject;
			unsigned int m_Index;
		};

		bool IsFree  ( void ) { return m_Index == 0xFFFFFFFFu; }
		void SetFree ( void ) { m_Index = 0xFFFFFFFFu; }

		void SetPointer(T * pObject) { m_pObject = pObject; }
		T * GetPointer ( void )
		{
			//assert(IsPointer());
			return m_pObject;
		}
	};

	ObjectRecord *	m_Objects;
	unsigned int	m_FreeObjects;
	unsigned int	m_AllocatedObjects;
};

//------------------------------------------------------------------------------
//
//	inline implementations
//
//------------------------------------------------------------------------------
template< typename T, int INITIAL_SIZE, int INC_FACTOR>
void
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
Destroy		( void )
{
	if (m_Objects != 0)
	{
		for (unsigned int index = 0; index < m_AllocatedObjects; ++index)
		{
			if ( !m_Objects[index].IsFree() && m_Objects[index].GetPointer() )
				MES_DELETE( m_Objects[index].GetPointer() );
		}	
		MES_DELETE_ARRAY( m_Objects );
		m_Objects = 0;
	}
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
bool
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
Alloc		( unsigned int N, unsigned int* pItems )
{
	// assert( 0 < N );
	if ( m_FreeObjects < N )
	{
		unsigned int newsize = m_AllocatedObjects;
		while( newsize < m_AllocatedObjects + N ){ newsize *= INC_FACTOR; }
		if( ! IncreaseBuffer( newsize ) ){ return false; }
	}

	for( unsigned int i=0; i<m_AllocatedObjects; i++ )
	{
		if( m_Objects[i].IsFree() )
		{
			m_Objects[i].SetPointer(0);
			m_FreeObjects--;
			*pItems++ = i;
			N--;
			if( 0 == N ){ break; }
		}
	}

	return true;
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
bool
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
Alloc		( unsigned int Index )
{
	if( Index >= m_AllocatedObjects )
	{
		unsigned int newsize = m_AllocatedObjects;
		while( newsize < Index ){ newsize *= INC_FACTOR; }
		if( ! IncreaseBuffer( newsize ) ){ return false; }
	}

	if( m_Objects[Index].IsFree() )
	{
		m_Objects[Index].SetPointer(0);
		m_FreeObjects--;
	}

	return true;
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
bool
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
Free		( unsigned int N, const unsigned int* pItems )
{
	for( unsigned int i=0; i<N; i++ )
	{
		if( *pItems < m_AllocatedObjects && 
			! m_Objects[*pItems].IsFree() )
		{
			if( m_Objects[*pItems].GetPointer() )
			{
				MES_DELETE( m_Objects[*pItems].GetPointer() );
			}
			m_Objects[*pItems].SetFree();
			pItems++;
			m_FreeObjects++;
		}
	}
	return true;
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
T*
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
GetObject	( unsigned int Index )
{
	if( ! IsObject( Index ) )
	{
		if( ! Alloc( Index ) )
			return 0;
	}
	
	if (!m_Objects[Index].GetPointer())
	{
		m_Objects[Index].SetPointer( MES_NEW( T ) );
	}
	
	return m_Objects[Index].GetPointer();
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
bool
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
IsObject	( unsigned int Index )
{
	return (Index < m_AllocatedObjects) && (!m_Objects[Index].IsFree());	
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
ObjectPool( void )
{
	m_Objects = MES_NEW_ARRAY( ObjectRecord, INITIAL_SIZE );	
	for (unsigned int index = 0; index < INITIAL_SIZE; ++index)
	{
		m_Objects[index].SetFree();
	}	
	m_FreeObjects = m_AllocatedObjects = INITIAL_SIZE;
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
~ObjectPool( void )
{
	if (m_Objects != 0)
	{
		for (unsigned int index = 0; index < m_AllocatedObjects; ++index)
		{
			if ( !m_Objects[index].IsFree() && m_Objects[index].GetPointer() )
				MES_DELETE( m_Objects[index].GetPointer() );
		}	
		MES_DELETE_ARRAY( m_Objects );
	}
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
void
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
Reset( void )
{
	if (m_Objects != 0)
	{
		for (unsigned int index = 0; index < m_AllocatedObjects; ++index)
		{
			if ( !m_Objects[index].IsFree() && m_Objects[index].GetPointer() )
				MES_DELETE( m_Objects[index].GetPointer() );
		}	
		MES_DELETE_ARRAY( m_Objects );
	}
	
	m_Objects = MES_NEW_ARRAY( ObjectRecord, INITIAL_SIZE );	
	for (unsigned int index = 0; index < INITIAL_SIZE; ++index)
	{
		m_Objects[index].SetFree();
	}	
	m_FreeObjects = m_AllocatedObjects = INITIAL_SIZE;
}

template< typename T, int INITIAL_SIZE, int INC_FACTOR>
bool
ObjectPool<T,INITIAL_SIZE,INC_FACTOR>::
IncreaseBuffer( unsigned int NewSize )
{
	//assert(NewSize > m_AllocatedObjects);
	//assert(m_FreeListHead == 0xffffffffu);
	if( NewSize <= m_AllocatedObjects ){ return true; }
	
	ObjectRecord * newObjects = MES_NEW_ARRAY( ObjectRecord, NewSize );
	if( !newObjects ){ return false; }
	unsigned int index;
	
	for (index = 0; index < m_AllocatedObjects; ++index)
	{
		newObjects[index] = m_Objects[index];
	}
	
	for (index = m_AllocatedObjects; index < NewSize; ++index)
	{
		newObjects[index].SetFree();
	}

	MES_DELETE_ARRAY( m_Objects );
	m_Objects = newObjects;
	m_FreeObjects = NewSize - m_AllocatedObjects;
	m_AllocatedObjects = NewSize;
	return true;
}

} // namespace __MES_OPENGL_ES__

#endif // #ifndef _OBJECTPOOL_H












