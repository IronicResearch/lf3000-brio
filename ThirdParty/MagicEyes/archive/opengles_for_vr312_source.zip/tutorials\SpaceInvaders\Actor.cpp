#include "Actor.h"
#include "FrustumCuller.h"

Actor::Actor(const char *filename, const char *texture,int lives, int hitpoints, bool hotOnTop)
{
  m_maxLives = m_lives = lives;
  m_hitPoints = m_maxHitPoints = hitpoints;  
  m_ownedMesh = true;
  m_dying = ZERO; 
  m_mesh = new Mesh(filename, texture,GL_NEAREST,GL_CLAMP_TO_EDGE);
  m_position[0] = 0;  m_position[1] = 0;  m_position[2] = 0;
  m_rotation[0] = 0;  m_rotation[1] = 0;  m_rotation[2] = ONE;  m_rotation[3] = 0;
  
  ComputeAABB();
  ComputeBSphere();
  ComputeHotPoint(hotOnTop);
}
//-------------------------------------------------------------------------------
Actor::Actor(Mesh *mesh,int lives, int hitpoints,bool hotOnTop)
{
  m_maxLives = m_lives = lives;
  m_hitPoints = m_maxHitPoints = hitpoints;  
  m_ownedMesh = false;
  m_mesh = mesh;
  m_dying = ZERO; 
  m_position[0] = 0;  m_position[1] = 0;  m_position[2] = 0;
  m_rotation[0] = 0;  m_rotation[1] = 0;  m_rotation[2] = ONE;  m_rotation[3] = 0;
  ComputeAABB();
  ComputeBSphere();
  ComputeHotPoint(hotOnTop);
}
//-------------------------------------------------------------------------------
void Actor::ComputeHotPoint(bool hotOnTop)
{
  /*This will compute the hotpoint, used with collisions point against sphere.
    The hot point will be on the top face of the AABB (in its middle) if hotTop = true,
    or in the bottom face if false*/

  m_hotPoint[0] = DivideFixed(m_maxAABBCorner[0] + m_minorAABBCorner[0],FixedFromInt(2));    
  m_hotPoint[2] = DivideFixed(m_maxAABBCorner[2] + m_minorAABBCorner[2],FixedFromInt(2));
  if(hotOnTop)
    m_hotPoint[1] = m_maxAABBCorner[1];
  else
    m_hotPoint[1] = m_minorAABBCorner[1];    
}
//-------------------------------------------------------------------------------
Actor::~Actor()
{
  //only destroy the mesh if is not shared
  if(m_ownedMesh) delete m_mesh;
}
//-------------------------------------------------------------------------------
int Actor::Draw(unsigned long elapsedtime,bool showBB)
{
  //perform frustum culling
  if(!IsInFrustum())
    return 0;

  //only draw it is alive
  if(!m_hitPoints)
    return 0;

  GLfixed color = DivideFixed(FixedFromInt(m_hitPoints), FixedFromInt(m_maxHitPoints));
  color = ONE - color;
  
  if(color > ZERO)
  {
    glColor4x(ONE, ONE - color,ONE - color,ONE - color);    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  }
  glPushMatrix();              
    glTranslatex(m_position[0],m_position[1],m_position[2]);    
    if(m_rotation[0]) 
      glRotatex(m_rotation[0],m_rotation[1],m_rotation[2],m_rotation[3]);
    m_mesh->Draw(elapsedtime,showBB);    
  glPopMatrix();
  
  
  if(color > ZERO)
  {
    glColor4x(ONE,ONE,ONE,ONE);    
    glDisable(GL_BLEND);
  } 

  return 1;
}
//-------------------------------------------------------------------------------
bool Actor::IsInFrustum()
{ 
  FrustumCuller *f = FrustumCuller::Instance();

  //translate the spherecenter to the current position for perform the frustum culling correctly
  GLfixed aux[3];
  aux[0] = m_sphereCenter[0] + m_position[0];
  aux[1] = m_sphereCenter[1] + m_position[1];
  aux[2] = m_sphereCenter[2] + m_position[2];
  return f->IsSphereInFrustum(aux,m_sphereRadius);    
}
//-------------------------------------------------------------------------------
void Actor::ComputeAABB()
{
  int i;
  //copies the mesh's AABB
  for(i=0;i<3;i++)
  {
    m_minorAABBCorner[i] = m_mesh->m_minorAABBCorner[i];
    m_maxAABBCorner[i] = m_mesh->m_maxAABBCorner[i];
    m_sphereCenter[i] = m_mesh->m_sphereCenter[i];
  }
  
  for(i=0;i<24;i++)
    m_boundingBoxVertices[i] = m_mesh->m_boundingBoxVertices[i];
  
  m_sphereRadius = m_mesh->m_sphereRadius;
}
//-------------------------------------------------------------------------------
void Actor::Revive()
{
   m_hitPoints = m_maxHitPoints;
   m_lives = m_maxLives;
   m_dying = 0;
}
