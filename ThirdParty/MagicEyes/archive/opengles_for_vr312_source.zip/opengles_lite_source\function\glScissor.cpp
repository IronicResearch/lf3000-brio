//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glScissor.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/20 Gamza hardware setting
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#if		defined(ROTATE_0)
#elif	defined(ROTATE_90)
#elif	defined(ROTATE_180)
#elif	defined(ROTATE_270)
#else
    #define DISPLAY__00 0
    #define DISPLAY__90 1
    #define DISPLAY_180 2
    #define DISPLAY_270 3
    int GLESOAL_GetDisplayDirection( void );
#endif


void glScissor (GLint x, GLint y, GLsizei width, GLsizei height)
{
	CALL_LOG;
	if (width < 0 || height < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__GLSTATE__.m_Scissor_X      = x;
	__GLSTATE__.m_Scissor_Y      = y;
	__GLSTATE__.m_Scissor_Width  = width;
	__GLSTATE__.m_Scissor_Height = height;

	if( ! __GLSTATE__.m_pSurface ){ GLESHAL_SetScissorSize( x, y, width, height ); return; }

#if		defined(ROTATE_0)
		GLESHAL_SetScissorSize( x, __GLSTATE__.m_pSurface->GetHeight() - (y+height), width, height );
#elif	defined(ROTATE_90)
		GLESHAL_SetScissorSize( __GLSTATE__.m_pSurface->GetWidth() - (y+height), __GLSTATE__.m_pSurface->GetHeight()-(x+width), height, width );
#elif	defined(ROTATE_180)
		GLESHAL_SetScissorSize( __GLSTATE__.m_pSurface->GetWidth() - (x+width),y, width, height );
#elif	defined(ROTATE_270)
		GLESHAL_SetScissorSize( y, x, height, width );
#else
    switch( GLESOAL_GetDisplayDirection() )
	{
	case DISPLAY__00:
		GLESHAL_SetScissorSize( x, __GLSTATE__.m_pSurface->GetHeight() - (y+height), width, height );
		break;
	case DISPLAY__90:		
		GLESHAL_SetScissorSize( __GLSTATE__.m_pSurface->GetWidth() - (y+height), __GLSTATE__.m_pSurface->GetHeight()-(x+width), height, width );
		break;
	case DISPLAY_180:
		GLESHAL_SetScissorSize( __GLSTATE__.m_pSurface->GetWidth() - (x+width),y, width, height );
		break;
	case DISPLAY_270:
		GLESHAL_SetScissorSize( y, x, height, width );
		break;
	}
#endif

}

