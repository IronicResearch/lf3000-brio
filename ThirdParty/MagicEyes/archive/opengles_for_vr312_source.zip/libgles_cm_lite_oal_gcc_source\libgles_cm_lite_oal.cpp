//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_oal.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//     2007/01/23 Gamza FW team���� �ۼ��� MP2530F platform�� virtual address��
//                      physical address�� ������ ����.
//	   2007/01/03 Yuni first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#include "libgles_cm_lite_oal.h"
#include <GLESOAL_Private.h>

int					__GLESOAL__::g_WindowWidth		= 0;
int					__GLESOAL__::g_WindowHeight		= 0;

static unsigned int	g_AddressOf3DCore = 0;
static unsigned int	g_FSAA = 0;

//  this function's implementation is in OS
#ifdef __cplusplus
extern "C" {
#endif
    typedef struct
    {
        unsigned int	VirtualAddressOf3DCore; // virtual addres of the 3D core register
        
        unsigned int    Memory1D_NumberOfHeaps; 
        struct
        {
        	unsigned int	VirtualAddress ; // must be 8byte aligned, non-cacheable
        	unsigned int    PhysicalAddress; // must be 8byte aligned, non-cacheable
        	unsigned int	SizeInMbyte    ; // size (Mbyte)
        } Memory1D_Heaps[32];
    
        unsigned int	Memory2D_NumberOfHeaps; 
        struct
        {
        	unsigned int	VirtualAddress ; // must be 4Mbyte aligned, non-cacheable
        	unsigned int    PhysicalAddress; // must be 4Mbyte aligned, non-cacheable
        	unsigned int	SizeInMbyte    ; // size (Mbyte), must be multiple of 4
        } Memory2D_Heaps[32];
    } ___OAL_MEMORY_INFORMATION__;
    GLESOALbool GLESOAL_Initalize( ___OAL_MEMORY_INFORMATION__* pMemoryInfomation, int FSAAEnb );
    void        GLESOAL_SetWindow    ( void* pNativeWindow  );
    void        GLESOAL_GetWindowSize( int* pWidth, int* pHeight );

	void         GLESOAL_WaitForDisplayAddressPatched( void );
	void		 GLESOAL_SetDisplayAddress( const unsigned int DisplayBufferPhysicalAddress );
	GLESOALbool  GLESOAL_IsSoftwareSyncNeeded( void );
#ifdef __cplusplus
}
#endif

#if		defined(ROTATE_0)
#elif	defined(ROTATE_90)
#elif	defined(ROTATE_180)
#elif	defined(ROTATE_270)
#else
    #define DISPLAY__00 0
    #define DISPLAY__90 1
    #define DISPLAY_180 2
    #define DISPLAY_270 3
    int GLESOAL_GetDisplayDirection( void );
#endif
 
void GLESOAL_SetNativeWindow( void* pNativeWindow )
{
    GLESOAL_SetWindow    ( pNativeWindow );
	
	//if( pNativeWindow )
	{
		int w,h;
        GLESOAL_GetWindowSize( &w, &h );
#if		defined(ROTATE_0)
		g_WindowWidth = w;
		g_WindowHeight = h;
#elif	defined(ROTATE_90)
		g_WindowWidth = h;
		g_WindowHeight = w;
#elif	defined(ROTATE_180)
		g_WindowWidth = w;
		g_WindowHeight = h;
#elif	defined(ROTATE_270)
		g_WindowWidth = h;
		g_WindowHeight = w;
#else
        switch( GLESOAL_GetDisplayDirection() )
        {
        case DISPLAY__00 :
			g_WindowWidth = w;
			g_WindowHeight = h;
            break;
        case DISPLAY__90 : 
			g_WindowWidth = h;
			g_WindowHeight = w;
            break;
        case DISPLAY_180 : 
			g_WindowWidth = w;
			g_WindowHeight = h;
        	break;
        case DISPLAY_270 :                    
			g_WindowWidth = h;
			g_WindowHeight = w;
            break;
        }
#endif
	}
}
 
void GLESOAL_SetNativeDisplay( void* pNativeDisplay )
{
}

void GLESOAL_GetNativeWindowSize( int* pWidth, int* pHeight )
{
	*pWidth = g_WindowWidth;
	*pHeight = g_WindowHeight;
}
#include <stdio.h>
GLESOALbool GLESOAL_Initialize_Internal( GLESOALbool FSAAEnb )
{    
	___OAL_MEMORY_INFORMATION__ memoryinformation;
	if( ! GLESOAL_Initalize( &memoryinformation, FSAAEnb ) ){ return 0; }

    // for old style OAL	
	if( memoryinformation.Memory1D_NumberOfHeaps >= sizeof(memoryinformation.Memory1D_Heaps)/sizeof(memoryinformation.Memory1D_Heaps[0]) )
	{
        printf( "OAL is old styel...\n" );
        unsigned int* pmeminfo = (unsigned int*)(&memoryinformation) + 1;
        int mem1d_vir = *pmeminfo++;
        int mem1d_phy = *pmeminfo++;
        int mem1d_size= *pmeminfo++;
        int mem2d_vir = *pmeminfo++;
        int mem2d_phy = *pmeminfo++;
        int mem2d_size= *pmeminfo++;
        memoryinformation.Memory1D_NumberOfHeaps = 1;
        memoryinformation.Memory1D_Heaps[0].VirtualAddress  = mem1d_vir;
        memoryinformation.Memory1D_Heaps[0].PhysicalAddress = mem1d_phy;
        memoryinformation.Memory1D_Heaps[0].SizeInMbyte     = mem1d_size;
        memoryinformation.Memory2D_NumberOfHeaps = 1;
        memoryinformation.Memory2D_Heaps[0].VirtualAddress  = mem2d_vir;
        memoryinformation.Memory2D_Heaps[0].PhysicalAddress = mem2d_phy;
        memoryinformation.Memory2D_Heaps[0].SizeInMbyte     = mem2d_size;
    }
    
	int heapsize_1d=0;
	int heapsize_2d=0;
    int i;
    for( i=0; i< memoryinformation.Memory1D_NumberOfHeaps; i++ )
    {
    	if( 0 != ( memoryinformation.Memory1D_Heaps[i].VirtualAddress  % 8) ){ return 0; }
    	if( 0 != ( memoryinformation.Memory1D_Heaps[i].PhysicalAddress % 8) ){ return 0; }
    	if( 0 >=   memoryinformation.Memory1D_Heaps[i].SizeInMbyte )         { return 0; }
    	heapsize_1d += memoryinformation.Memory1D_Heaps[i].SizeInMbyte;
    	printf( "Memory1D[%d]: Virtual : %08x / Physical : %08x / %d Mbytes\n",  
    	            i,
    	            memoryinformation.Memory1D_Heaps[i].VirtualAddress,
    	            memoryinformation.Memory1D_Heaps[i].PhysicalAddress,
    	            memoryinformation.Memory1D_Heaps[i].SizeInMbyte ) ;
    }
    if( 0>=heapsize_1d ){ return 0; }
    
    for( i=0; i< memoryinformation.Memory2D_NumberOfHeaps; i++ )
    {
    	if( 0 != ( memoryinformation.Memory2D_Heaps[i].VirtualAddress  % 0x400000) ){ return 0; }
    	if( 0 != ( memoryinformation.Memory2D_Heaps[i].PhysicalAddress % 0x400000) ){ return 0; }
    	if( 0 != ( memoryinformation.Memory2D_Heaps[i].SizeInMbyte     % 2       ) ){ return 0; }
    	if( 0 >=   memoryinformation.Memory2D_Heaps[i].SizeInMbyte )                { return 0; }
    	heapsize_2d += memoryinformation.Memory2D_Heaps[i].SizeInMbyte;
    	printf( "Memory2D[%d]: Virtual : %08x / Physical : %08x / %d Mbytes\n",  
    	            i,
    	            memoryinformation.Memory2D_Heaps[i].VirtualAddress,
    	            memoryinformation.Memory2D_Heaps[i].PhysicalAddress,
    	            memoryinformation.Memory2D_Heaps[i].SizeInMbyte ) ;
    }
    if( 0>=heapsize_2d ){ return 0; }
    
    ___MES_1D_Manager_Initialize( (___OEM_CUSTOMHEAP*)memoryinformation.Memory1D_Heaps, memoryinformation.Memory1D_NumberOfHeaps );
    ___MES_2D_Manager_Initialize( (___OEM_CUSTOMHEAP*)memoryinformation.Memory2D_Heaps, memoryinformation.Memory2D_NumberOfHeaps );
	
	g_AddressOf3DCore = memoryinformation.VirtualAddressOf3DCore;
	g_FSAA = FSAAEnb ? 1 : 0;
	
    return 1;
}

unsigned int GLESOAL_GetVirtualAddressOf3DCore( void )
{
    return g_AddressOf3DCore;
}


//------------------------------------------------------------------------------
void GLESOAL_PushDisplayAddressPatch( const GLESOAL_MEMORY2D* pDisplayBuffer )
{
	GLESOAL_SetDisplayAddress( ___MES_2D_Manager_GetPhysicalAddress( pDisplayBuffer ) );
}

//------------------------------------------------------------------------------
GLESOALbool  GLESOAL_IsSoftwareSyncNeeded( void )
{
	// if you used dual display in MP2530F, this function must return 1
	return g_FSAA;
}


