#ifndef RENDER_H
#define RENDER_H

#include <Fake_OS.h>

#include <GLES/gl.h>
#include <GLES/egl.h>
#include "t5_fixed.h"
#include "t5_font.h"

namespace __TUTORIAL5__
{

bool InitOGLES();
void Render();  
void SetOrtho2D();
void Clean();   
bool LoadTexture(const char *fileName, GLuint *id);

} //namespace

#endif
