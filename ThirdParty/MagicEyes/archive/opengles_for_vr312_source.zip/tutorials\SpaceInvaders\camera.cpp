#include <Fake_OS.h>
#include "camera.h"

void Camera::SetOrtho2D(int width, int height)
{  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(0), FixedFromInt(width), 
           FixedFromInt(0), FixedFromInt(height), 
           FixedFromInt(-1), FixedFromInt(1));
  glMatrixMode(GL_MODELVIEW);  
}
//----------------------------------------------------------------------------
//compute the aspect ration and call the true perspective function
void Camera::SetPerspective(NativeWindowType hNativeWnd, GLfixed fov, GLfixed znear, GLfixed zfar)
{  
  int width, height;
  OS_GetWindowSize(hNativeWnd, &width, &height);
  GLfixed ratio = DivideFixed(FixedFromInt(width),FixedFromInt(height));

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();        
  Perspective(fov, ratio, znear, zfar);
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void Camera::Perspective (GLfixed fovy, GLfixed aspect, GLfixed zNear,  GLfixed zFar)
{
  GLfixed xmin, xmax, ymin, ymax;     
    
  //we do not have trigonometric functions that works with fixed point, so we must use floats
  ymax = MultiplyFixed(zNear, FixedFromFloat((float)tan(FloatFromFixed(fovy) * 3.1415962f / 360.0f)));  
  ymin = -ymax;

  xmin = MultiplyFixed(ymin, aspect);
  xmax = MultiplyFixed(ymax, aspect);  
  glFrustumx(xmin, xmax, ymin, ymax, zNear, zFar);
}
//----------------------------------------------------------------------------
void Camera::SetOrtho()
{  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(-100), FixedFromInt(100), 
           FixedFromInt(-100), FixedFromInt(100), 
           FixedFromInt(-100) , FixedFromInt(100));
  glMatrixMode(GL_MODELVIEW);  
}
//----------------------------------------------------------------------------
//just copied from Mesa glu and translated to fixed point
void Camera::LookAt(GLfixed eyex, GLfixed eyey, GLfixed eyez,
	                  GLfixed centerx, GLfixed centery, GLfixed centerz,
	                  GLfixed upx, GLfixed upy, GLfixed upz)
{
   GLfixed m[16];
   GLfixed x[3], y[3], z[3];
   GLfixed mag;

   /* Make rotation matrix */

   /* Z vector */
   z[0] = eyex - centerx;
   z[1] = eyey - centery;
   z[2] = eyez - centerz;
   float fz[3];
   fz[0] = FloatFromFixed(z[0]); fz[1] = FloatFromFixed(z[1]); fz[2] = FloatFromFixed(z[2]);

   mag = FixedFromFloat((float)sqrt(fz[0] * fz[0] + fz[1] * fz[1] + fz[2] * fz[2]));
   if (mag) 
   {
     z[0] = DivideFixed(z[0],mag);
     z[1] = DivideFixed(z[1],mag);
     z[2] = DivideFixed(z[2],mag);
   }

   /* Y vector */
   y[0] = upx;
   y[1] = upy;
   y[2] = upz;

   /* X vector = Y cross Z */
   x[0] = MultiplyFixed(y[1] , z[2])  - MultiplyFixed(y[2] , z[1]);
   x[1] = MultiplyFixed(-y[0] , z[2]) + MultiplyFixed(y[2] , z[0]);
   x[2] = MultiplyFixed(y[0] , z[1])  - MultiplyFixed(y[1] , z[0]);

   /* Recompute Y = Z cross X */
   y[0] = MultiplyFixed(z[1] , x[2])  - MultiplyFixed(z[2] , x[1]);
   y[1] = MultiplyFixed(-z[0] , x[2]) + MultiplyFixed(z[2] , x[0]);
   y[2] = MultiplyFixed(z[0] , x[1])  - MultiplyFixed(z[1] , x[0]);

   float xf[3];
   xf[0] = FloatFromFixed(x[0]);   xf[1] = FloatFromFixed(x[1]);   xf[2] = FloatFromFixed(x[2]);

   mag = FixedFromFloat((float)sqrt(xf[0] * xf[0] + xf[1] * xf[1] + xf[2] * xf[2]));
   if(mag) 
   {
      x[0] = DivideFixed(x[0],mag);
      x[1] = DivideFixed(x[1],mag);
      x[2] = DivideFixed(x[2],mag);
   }

   float yf[3];
   yf[0] = FloatFromFixed(y[0]);   yf[1] = FloatFromFixed(y[1]);   yf[2] = FloatFromFixed(y[2]);

   mag = FixedFromFloat((float)sqrt(yf[0] * yf[0] + yf[1] * yf[1] + yf[2] * yf[2]));
   if(mag)
   {
      y[0] = DivideFixed(y[0],mag);
      y[1] = DivideFixed(y[1],mag);
      y[2] = DivideFixed(y[2],mag);
   }

#define M(row,col)  m[col*4+row]
   M(0, 0) = x[0];
   M(0, 1) = x[1];
   M(0, 2) = x[2];
   M(0, 3) = ZERO;
   M(1, 0) = y[0];
   M(1, 1) = y[1];
   M(1, 2) = y[2];
   M(1, 3) = ZERO;
   M(2, 0) = z[0];
   M(2, 1) = z[1];
   M(2, 2) = z[2];
   M(2, 3) = ZERO;
   M(3, 0) = ZERO;
   M(3, 1) = ZERO;
   M(3, 2) = ZERO;
   M(3, 3) = ONE;
#undef M
   glMultMatrixx(m);   
   glTranslatex(-eyex, -eyey, -eyez);

}
