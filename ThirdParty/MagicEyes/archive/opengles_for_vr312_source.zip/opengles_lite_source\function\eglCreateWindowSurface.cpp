//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglCreateWindowSurface.cpp
//	Description: �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2006/10/20 Gamza context�� viewport/scissor�����κ��� eglMakeCurrent�� �̵�.
//						 viewport �� scissor�� ó�� context�� attach�ɶ�
//						 surfaceũ��� �����ȴ�.
//		2006/10/20 Gamza gles_surface ũ�⸦ ���ڷ� �޵��� ����.
//		2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLSurface eglCreateWindowSurface (EGLDisplay dpy, EGLConfig config, NativeWindowType window, const EGLint *attrib_list)
{
	CALL_LOG;
	const __CONFIG__* pcurconfig = (const __CONFIG__*)config;
	InitializeOAL( pcurconfig->m_SAMPLE_BUFFERS );

	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.
	if (!__EGLSTATE__.m_isInit) 
	{
		EGLSETERROR( EGL_NOT_INITIALIZED );
	}
	// it's not current display.
	if (__EGLSTATE__.m_pCurDisplay != dpy)
	{
		EGLSETERROR( EGL_BAD_DISPLAY );
	}

	/*
	//	EGL_BAD_CONFIG is generated if config is not an EGL frame buffer configuration.
	const __CONFIG__* pconfig = (const __CONFIG__*)config;
	if( ! pconfig || EGLCONFIG_FLAG != pconfig->m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_CONFIG );
		return EGL_NO_SURFACE;
	}
	*/

	//	EGL_BAD_NATIVE_WINDOW may be generated if native_window is not a valid native window.
	if( ! window )
	{
		EGLSETERROR( EGL_BAD_NATIVE_WINDOW );
		return EGL_NO_SURFACE;
	}

	/*
	//	EGL_BAD_ATTRIBUTE is generated if attrib_list contains an invalid window attribute or if an attribute value is not recognized or is out of range.
	//	Must be NULL or empty (first attribute is EGL_NONE).
	if( attrib_list && EGL_NONE != attrib_list[0] )
	{
		EGLSETERROR( EGL_BAD_ATTRIBUTE );
		return EGL_NO_SURFACE;
	}
	
	//	EGL_BAD_MATCH is generated if the attributes of native_window do not correspond to config or if config does not support rendering to windows (the EGL_SURFACE_TYPE attribute does not contain EGL_WINDOW_BIT).
	if( // !!!
		0 == (pconfig->m_SURFACE_TYPE & EGL_WINDOW_BIT) )
	{
		EGLSETERROR( EGL_BAD_MATCH );
		return EGL_NO_SURFACE;
	}
	*/
	//	EGL_BAD_ALLOC is generated if there are not enough resources to allocate the new surface.
	{
		/*
		RECT clientrect;
		GetClientRect( (HWND)window, &clientrect );

		//__EGLSTATE__.m_pSurface = new GLES_Surface;
		
		if ( ! presult )
		{
			GLSETERROR( GL_OUT_OF_MEMORY );
			return EGL_NO_SURFACE;
		}
		presult->m_Config.m_EGLCONFIG      = EGLSURFACE_FLAG;
		presult->m_Config.m_CONFIG_ID      = pconfig->m_CONFIG_ID;
		presult->m_Config.m_WIDTH          = clientrect.right - clientrect.left;
		presult->m_Config.m_HEIGHT         = clientrect.bottom - clientrect.top;
		presult->m_Config.m_LARGEST_PBUFFER= 0;
		presult->m_Config.m_TEXTURE_FORMAT = EGL_NO_TEXTURE;
		presult->m_Config.m_TEXTURE_TARGET = EGL_NO_TEXTURE;
		presult->m_Config.m_MIPMAP_TEXTURE = EGL_FALSE;
		presult->m_Config.m_MIPMAP_LEVEL   = 0;
		presult->m_pContext = NULL;
		presult->m_Window   = window;	// !!! ??
		__EGLSTATE__.m_pCurDrawSurface = window;
		*/

		__EGLSTATE__.m_NativeWindow = window;

		//__EGLSTATE__.m_pSurface = new GLES_Surface;
		//if( !(__EGLSTATE__.m_pSurface->CreateSurface(window,pcurconfig->m_SAMPLE_BUFFERS)) )
		//	return EGL_NO_SURFACE;
		//else
		//	return (EGLSurface)__EGLSTATE__.m_pSurface;

		GLES_Surface* pSurface;

		if( !__EGL_SURFACE__ )
		{
			pSurface = MES_NEW( GLES_Surface );
			if( !(pSurface->CreateSurface(window,pcurconfig->m_SAMPLE_BUFFERS)) )
				return EGL_NO_SURFACE;
			__EGL_SURFACE__ = (unsigned int)pSurface;
		}
		return (EGLSurface)__EGL_SURFACE__;
	}
	
	//return EGL_NO_SURFACE;
}
