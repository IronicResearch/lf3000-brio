//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglDestroyContext.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/10/16 Yuni	matrix stack finalize �߰�.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglDestroyContext (EGLDisplay dpy, EGLContext ctx)
{
	CALL_LOG;
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_CONTEXT is generated if context is not an EGL rendering context.
	//__GLSTATESET__* pglstate = (__GLSTATESET__*)ctx;
	//if( ! pglstate || EGLCONFIG_FLAG != pglstate->m_Config.m_EGLCONFIG )
	//{
	//	EGLSETERROR( EGL_BAD_CONTEXT );
	//	return EGL_FALSE;
	//}

	if( __NumberOfContext__ )
	{
		DestroyDefaultBuffer();	// client side vertex array�� ���� �����ߴ� default buffer ����.
		DeleteDefaultTexture		( &__GLSTATE__ );
		
		// MatrixStack ����.
        __GLSTATE__.m_ProjectionMatrix.Finalize();
        __GLSTATE__.m_ModelViewMatrix .Finalize();
		int i;
        for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
            __GLSTATE__.m_TextureMatrix[i].Finalize();
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
        for( i=0; i<GLPARAM_MAX_PALETTE_MATRICES_OES; i++ )
            __GLSTATE__.m_MatrixPalette[i].Finalize();
#endif
        
        GLCLRERROR;
		__NumberOfContext__ = 0;	
	}
	return EGL_TRUE;
}
