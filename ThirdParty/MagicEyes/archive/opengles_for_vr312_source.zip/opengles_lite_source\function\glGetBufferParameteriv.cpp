//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetBufferParameteriv.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glGetBufferParameter.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glGetBufferParameteriv (GLenum target, GLenum pname, GLint *params)
{
	CALL_LOG;
	//if( GL_ARRAY_BUFFER != target )
	//{
	//	GLSETERROR( GL_INVALID_ENUM );
	//	return;
	//}
	
	int bindedbuffer;
	
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[0];		
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = __GLSTATE__.m_BindedBuffer[1];		
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return; 
	}

	__BUFFER__* pobject = __BUFFER_POOL__.GetObject(bindedbuffer);	

	//	�̷� ��� ��� ó���ϳ�??? -> �ϴ� ��������� GL_INVALID_VALUE
	if (!pobject)
	{
		GLSETERROR( GL_INVALID_VALUE );
		return;
	}

	switch (pname)
	{
	case GL_BUFFER_SIZE:
		*params = pobject->m_Size;
		break;
	case GL_BUFFER_USAGE:
		*params = pobject->m_Usage;
		break;
	case GL_BUFFER_ACCESS:
		*params = GL_WRITE_ONLY;
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		break;
	}
}
