#include <math.h>
#include <Fake_OS.h>
#include "mesh.h"
#include "FrustumCuller.h"

Mesh::Mesh(const char *filename, const char *texture, GLenum filter, GLenum wrap)
{
  m_mesh.Geometry = NULL;
  m_mesh.Indices = NULL;  
  m_mesh.TexCoord = NULL;
  
  m_state = true;
  if(texture)
    m_texture = new Texture(texture,filter,filter, wrap,wrap);    
  else 
    m_texture = NULL;

  if(texture)
  {
    if(!m_texture->GetState())
    {
      m_state = false;
      return;
    }
  }

  GSDHeader header;
  OS_FILE meshFile = OS_fopen(filename,"rb");
  if(!meshFile)
  {
    m_state = false;
    return;
  }

  /*The header holds a brief description of the file, the version number, and the number of meshes
    that are stored in the file. This type of files are thought for static meshes only*/
  OS_fread(&header,sizeof(GSDHeader),1,meshFile); 

  //Check if there is at least one object
  if(header.numberOfSubObjects < 1)
  {
    m_state = false;
    OS_fclose(meshFile);
    return;
  }

  GenericObjectData o;
  
  // we only will use the first object, so we won't iterate over the others, if they exist
  OS_fread(o.Name,sizeof(char)*128,1,meshFile); //read the object name
  OS_fread(o.ParentName,sizeof(char)*128,1,meshFile); //Read the name of the parent object (useful for hierarchies)
  OS_fread(&o.iC,sizeof(unsigned long),1,meshFile); //read the number of vertex indices
  OS_fread(&o.vC,sizeof(unsigned long),1,meshFile); //read the number of vertices

  //allocate enough space for the indices and the GLshort version of them
  o.Indices = new unsigned int[o.iC];
  m_mesh.Indices = new GLshort[o.iC];
  OS_fread(o.Indices,sizeof(unsigned int) * o.iC,1,meshFile); // read all indices

  //allocate enough space for the vertices and the GLfixed version of them
  o.Geometry = new float[o.vC * 3]; 
  m_mesh.Geometry = new GLfixed[o.vC * 3];
  OS_fread(o.Geometry,o.vC * 3 * sizeof(float),1,meshFile); //read all vertices (1 vertex = 3 floats)
  

  //allocate enough space for the texture coordinates and the GLfixed version of them
  o.TexCoord = new float[o.vC * 2];
  m_mesh.TexCoord = new GLfixed[o.vC * 2];
  OS_fread(o.TexCoord,o.vC * 2 * sizeof(float),1,meshFile);//read all texcoords (1 tex coord = 2 floats)
  
    
  //We do not need normals, so we wont load them
  //allocate enough space for the normals and the GLfixed version of them  
  //o.Normals= new float[o.vC * 3];
  //m_mesh.Normals = new GLfixed[o.vC * 3];
  //fread(o.Normals,o.vC * 3* sizeof(float),1,meshFile);//read all normals (1 normal = 3 floats)
    
  OS_fclose(meshFile); //Do not need the file opened anymore

  unsigned int i;
  
  // Convert data to optimized data types for OpenGL ES (GLfixed and GLshort)
  for(i=0;i<o.vC * 3;i++)
  {
    m_mesh.Geometry[i]= FixedFromFloat(o.Geometry[i]);
    //m_mesh.Normals[i] = FixedFromFloat(o.Normals[i]);
  }

  for(i=0;i<o.vC * 2;i++)
    m_mesh.TexCoord[i] = FixedFromFloat(o.TexCoord[i]);
  
  for(i=0;i<o.iC;i++)
    m_mesh.Indices[i] = (GLshort)o.Indices[i];

  m_mesh.indexCounter = (GLshort)o.iC;
  m_mesh.vertexCounter= (GLshort)o.vC;

  //delete original values, we will use only the optimized ones
  delete [] o.Indices;
  delete [] o.Geometry;
  //delete [] o.Normals;
  delete [] o.TexCoord;  
  
  ComputeAABB();
  ComputeBSphere();
}
//----------------------------------------------------------------------------
Mesh::~Mesh()
{
  if(m_texture) delete m_texture;
  if(m_mesh.Geometry) delete [] m_mesh.Geometry;
  if(m_mesh.Indices) delete [] m_mesh.Indices;
  //if(m_mesh.Normals) delete [] m_mesh.Normals;
  if(m_mesh.TexCoord) delete [] m_mesh.TexCoord;
}
//----------------------------------------------------------------------------
int Mesh::Draw(unsigned long elapsedTime,bool showBB) 
{
  //dont needed. the test is done in upper levels (actor, stage, enemy, etc)
  //if(!IsInFrustum())
  //  return;

  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FIXED, 0, m_mesh.Geometry);
    
 // glEnableClientState(GL_NORMAL_ARRAY);
 // glNormalPointer(GL_FIXED, 0, m_mesh.Normals);

  glEnableClientState(GL_TEXTURE_COORD_ARRAY);
  glTexCoordPointer(2,GL_FIXED, 0, m_mesh.TexCoord);
   
  if(m_texture)
    m_texture->BindTexture();

  glDrawElements(GL_TRIANGLES,m_mesh.indexCounter,GL_UNSIGNED_SHORT,m_mesh.Indices);
     
  glDisableClientState(GL_VERTEX_ARRAY);   	
  //glDisableClientState(GL_NORMAL_ARRAY); 
  glDisableClientState(GL_TEXTURE_COORD_ARRAY);   	
  
  if(showBB)
    DrawBoundingBox();
  return 1;
}
//----------------------------------------------------------------------------
void Mesh::ComputeAABB()
{
  int i=1,j=0;     
  m_maxAABBCorner[0]=m_mesh.Geometry[0];
  m_maxAABBCorner[1]=m_mesh.Geometry[1];
  m_maxAABBCorner[2]=m_mesh.Geometry[2];

  m_minorAABBCorner[0]=m_mesh.Geometry[0];
  m_minorAABBCorner[1]=m_mesh.Geometry[1];
  m_minorAABBCorner[2]=m_mesh.Geometry[2];

  for(j=0;i<m_mesh.vertexCounter;i++)
  {
     if(m_mesh.Geometry[j] >   m_maxAABBCorner[0])   m_maxAABBCorner[0] = m_mesh.Geometry[j];
     if(m_mesh.Geometry[j] < m_minorAABBCorner[0]) m_minorAABBCorner[0] = m_mesh.Geometry[j];
     j++;
 
     if(m_mesh.Geometry[j] >   m_maxAABBCorner[1])   m_maxAABBCorner[1] = m_mesh.Geometry[j];
     if(m_mesh.Geometry[j] < m_minorAABBCorner[1]) m_minorAABBCorner[1] = m_mesh.Geometry[j];
     j++;

     if(m_mesh.Geometry[j] >   m_maxAABBCorner[2])   m_maxAABBCorner[2] = m_mesh.Geometry[j];
     if(m_mesh.Geometry[j] < m_minorAABBCorner[2]) m_minorAABBCorner[2] = m_mesh.Geometry[j];
     j++;
  }

    /*vertex 1*/                                                    /*vertex 2*/
  m_boundingBoxVertices[0] = m_minorAABBCorner[0];  m_boundingBoxVertices[3] = m_maxAABBCorner[0];   
  m_boundingBoxVertices[1] = m_minorAABBCorner[1];  m_boundingBoxVertices[4] = m_minorAABBCorner[1];    
  m_boundingBoxVertices[2] = m_minorAABBCorner[2];  m_boundingBoxVertices[5] = m_minorAABBCorner[2];;
  
  
    /*vertex 3*/                                                    /*vertex 4*/
  m_boundingBoxVertices[6] = m_maxAABBCorner[0];    m_boundingBoxVertices[9]  = m_minorAABBCorner[0]; 
  m_boundingBoxVertices[7] = m_maxAABBCorner[1];    m_boundingBoxVertices[10] = m_maxAABBCorner[1]; 
  m_boundingBoxVertices[8] = m_minorAABBCorner[2];  m_boundingBoxVertices[11] = m_minorAABBCorner[2];

 
   /*vertex 5*/                                                     /*vertex 6*/
  m_boundingBoxVertices[12]=m_minorAABBCorner[0];   m_boundingBoxVertices[15]=m_maxAABBCorner[0];
  m_boundingBoxVertices[13]=m_minorAABBCorner[1];   m_boundingBoxVertices[16]=m_minorAABBCorner[1];
  m_boundingBoxVertices[14]=m_maxAABBCorner[2];     m_boundingBoxVertices[17]=m_maxAABBCorner[2];
  
    /*vertex 7*/                                                    /*vertex 8*/
  m_boundingBoxVertices[18]=m_maxAABBCorner[0];     m_boundingBoxVertices[21]=m_minorAABBCorner[0];
  m_boundingBoxVertices[19]=m_maxAABBCorner[1];     m_boundingBoxVertices[22]=m_maxAABBCorner[1];    
  m_boundingBoxVertices[20]=m_maxAABBCorner[2];     m_boundingBoxVertices[23]=m_maxAABBCorner[2];
}

//----------------------------------------------------------------------------
bool Mesh::IsInFrustum() 
{ 
  FrustumCuller *f = FrustumCuller::Instance();
  return f->IsCubeInFrustum(m_boundingBoxVertices);  
}















