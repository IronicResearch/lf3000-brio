#include "t4_render.h"
#include <stdio.h>

namespace __TUTORIAL4__
{

//Some useful global handles
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.

}//namespace

using namespace __TUTORIAL4__;

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial4Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
  
  // Create native window.
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;
  
  if(!InitOGLES()) return GL_FALSE; //OpenGL ES Initialization
  
  //Bring the window to front, focus it and refresh it
  //SetWindowText(hWnd, L"OpenGLES ortho");
  //ShowWindow(hWnd, nCmdShow); 
  //UpdateWindow(hWnd);

  unsigned int startTime = OS_GetTickCount();
  GLboolean enableFog = GL_TRUE;
   
  unsigned int frames = 1800;
  //Message Loop
  //while(!done)
  while(frames--)  
  {
    Render();
    unsigned int curTime = OS_GetTickCount();
  	__int64 interval = (__int64)curTime - (__int64)startTime;
  	
  	if(interval < 0)
  		interval *= -1;
  	
  	if( interval > 500 )
  	{
  		//isPerspective != isPerspective;
  		if( enableFog )
  		{
  			EnableFog();
  			enableFog = GL_FALSE;
  		}
  		else
  		{
  			DisableFog();
  			enableFog = GL_TRUE;	
  		}
  		startTime = curTime;
  	}    
  }

  //Clean up all
  Clean();
 
  return 0;
}
