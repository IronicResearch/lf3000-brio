//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBindHWBufferOES.cpp
//	Description: 
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/27 Yuni first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
//#include "../source/hwbufferobject.h"

// OpenGL|ES extension
void glBindHWBufferOES(GLenum target, GLuint hwbuffer)
{
	CALL_LOG;
	int bindedbuffer;
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = 0;
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = 1;
		break;
	default:
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}

	if( !hwbuffer )
	{
		__GLSTATE__.m_BindedHWBuffer[bindedbuffer] = hwbuffer;
	}
	else
	{
		if ( __HWBUFFER_POOL__.Alloc(hwbuffer) )
		{
			__GLSTATE__.m_BindedHWBuffer[bindedbuffer] = hwbuffer;
		}
		else
		{
			GLSETERROR( GL_OUT_OF_MEMORY );
		}
	}
}
