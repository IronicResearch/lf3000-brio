#include <math.h>
#include "t2_render.h" //We need the defines and prototypes of there

namespace __TUTORIAL2__
{


EGLDisplay glesDisplay;  // EGL display
EGLSurface glesSurface;	 // EGL rendering surface
EGLContext glesContext;	 // EGL rendering context

//Variables declared in main.cpp, but used here too
extern NativeWindowType hNativeWnd; // A handle to the window we will create
extern GLboolean drawInOrtho;

GLboolean InitOGLES()
{  
  EGLConfig configs[10];
  EGLint matchingConfigs;	

  /*configAttribs is a integers list that holds the desired format of 
   our framebuffer. We will ask for a framebuffer with 24 bits of 
   color and 16 bits of z-buffer. We also ask for a window buffer, not 
   a pbuffer or pixmap buffer*/	
  const EGLint configAttribs[] =
  {
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
  
  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 //Ask for an available display

  //Display initialization (we don't care about the OGLES version numbers)
  if(!eglInitialize(glesDisplay, 0, 0)) 
    return GL_FALSE;
	
  /*Ask for the framebuffer confiburation that best fits our 
  parameters. At most, we want 10 configurations*/
  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
   return GL_FALSE;
	
  //If there isn't any configuration enough good
  if (matchingConfigs < 1)  return GL_FALSE;	  

  /*eglCreateWindowSurface creates an onscreen EGLSurface and returns 
  a handle  to it. Any EGL rendering context created with a 
  compatible EGLConfig can be used to render into this surface.*/
  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
  if(!glesSurface) return GL_FALSE;
  
  // Let's create our rendering context
  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

  if(!glesContext) return GL_FALSE;

  //Now we will activate the context for rendering	
  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
    
  /*Remember: because we are programming for a mobile device, we cant 
  use any of the OpenGL ES functions that finish in 'f', we must use 
  the fixed point version (they finish in 'x'*/
  glClearColorx(0, 0, 0, 0);
  //Do not want to see smoothed colors, only a plain color for face
  glShadeModel(GL_FLAT);  
  //Enable the depth test in order to see the cube correctly
  glEnable(GL_DEPTH_TEST);
  /*Taking care of specifying correctly the winding order of the 
  vertices (counter clock wise order), we can cull up all back faces.
  This is probably one of the better optimizations we could work,
  because we are avoiding a lot of computations that wont be reflected
  in the screen, using  glEnable(GL_CULL_FACE) to do the work*/
  
  glEnable(GL_CULL_FACE);
  //glDisable(GL_CULL_FACE);

  //SetOrtho();
  SetPerspective();


  return GL_TRUE;
}
//----------------------------------------------------------------------------
void Render()
{
  static int rotation = 0;
    
  // We are going to draw a cube centered at origin, and with an edge of 10 units
  /*
           7                      6
            +--------------------+
          / |                   /|
        /   |                 /  |
   3  /     |             2 /    |
    +---------------------+      |
    |       |             |      |
    |       |             |      |
    |       |             |      |
    |       |             |      |
    |       |             |      |
    |       |             |      |
    |       |             |      |
    |       |4            |      |5
    |       +-------------|------+
    |     /               |     /
    |   /                 |   /
    | /                   | /
    +---------------------+
   0                      1
  
  */
  

  //static GLubyte front[]  = {2,1,3,0}; //front face
  //static GLubyte front[]  = {0, 1, 2, 0, 2, 3}; //front face
  static GLushort front[] = {2,1,3,0};
  static GLubyte back[]   = {5,6,4,7}; //back face
  static GLubyte top[]    = {6,2,7,3}; //top face
  static GLubyte bottom[] = {1,5,0,4}; //bottom face    
  static GLubyte left[]   = {3,0,7,4}; //left face
  static GLubyte right[]  = {6,5,2,1}; //right face

  
  static GLshort vertices[] = {-5,-5,-5,  5,-5,-5,  5,5,-5, -5,5,-5,  
                               -5,-5,5,   5,-5,5,   5,5,5,  -5,5,5};
  //static GLshort vertices[] = {5,5,-5,5,-5,-5,-5,5,-5,-5,-5,-5}; 

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  

  glLoadIdentity();
  if(drawInOrtho)    
    glTranslatex(0, 0, FixedFromInt(-30));

  glRotatex(FixedFromInt(45), ONE, 0, 0);
  glRotatex(FixedFromInt(rotation++), 0, ONE,0); 
  
  //Enable the vertices array  
  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_SHORT, 0, vertices);
  //3 = XYZ coordinates, GL_SHORT = data type, 0 = 0 stride bytes
  
  /*We are going to draw the cube, face by face, with different colors for 
  each face, using indexed vertex arrays and triangle strips*/

  glColor4x(ONE,0,0,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, front);
  
  glColor4x(0,ONE,0,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, back);

  glColor4x(0,0,ONE,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, top);

  glColor4x(ONE,ONE,0,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, bottom);

  glColor4x(0,ONE,ONE,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, left);

  glColor4x(ONE,0,ONE,0);
  glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, right);

  glDisableClientState(GL_VERTEX_ARRAY);   	
  eglSwapBuffers(glesDisplay, glesSurface);
}
//----------------------------------------------------------------------------
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar)
{
  GLfixed xmin, xmax, ymin, ymax, aspectFixed, znearFixed;     
  
  aspectFixed = FixedFromFloat(aspect);
  znearFixed = FixedFromFloat(zNear);

  ymax = MultiplyFixed(znearFixed, FixedFromFloat((GLfloat)tan(fovy * 3.1415962f / 360.0f)));  
  ymin = -ymax;

  xmin = MultiplyFixed(ymin, aspectFixed);
  xmax = MultiplyFixed(ymax, aspectFixed);  
   
  glFrustumx(xmin, xmax, ymin, ymax, znearFixed, FixedFromFloat(zFar));

}
//----------------------------------------------------------------------------
void SetOrtho()
{
  /*Setup of the orthographic matrix. We use an ortho cube centered 
  at (0,0,0) with 40 units of edge*/
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(-20), FixedFromInt(20), 
           FixedFromInt(-20), FixedFromInt(20), 
           FixedFromInt(-20) , FixedFromInt(20));
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void SetPerspective()
{
  int width, height;
  OS_GetWindowSize(hNativeWnd, &width, &height);
  float ratio = (float)width/height;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();        
  Perspective(45.0f,ratio, 1.0f, 40.0f);
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void Clean()
{
  if(glesDisplay)
  {
    eglMakeCurrent(glesDisplay, 0, 0, 0);  
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }  
}



}	// namespace






