//#include "main.h" //We need the defines and prototypes from in.
#include "t3_render.h"

namespace __TUTORIAL3__
{
//Some useful global handles
//HINSTANCE hInst; //Will hold the current instance of the application.
NativeWindowType hNativeWnd = 0; // A handle to the window we will create.
//HDC hDC;   // A handle to the device context of the window.
}//namespace

using namespace __TUTORIAL3__;

//TCHAR szAppName[] = L"OpenGLES"; /*The application name and the window caption*/
 
//GLboolean drawInOrtho = GL_TRUE; //This variable will change with every click in the touch screen of the pda

/*This is the main function. Here we will create the rendering window, initialize OpenGL ES, write the message loop, and, at the end, clean all and release all used resources*/
#ifdef linux
int main()
#else
int Tutorial3Main() 
#endif
{
  // Initialize native OS
  OS_InitFakeOS();
  GLboolean done = GL_FALSE; 
	  
  // Create native window.	  
  hNativeWnd = OS_CreateWindow();	                  
  if(!hNativeWnd) return GL_FALSE;
  
  if(!InitOGLES()) return GL_FALSE; //OpenGL ES Initialization
  
  //Bring the window to front, focus it and refresh it
  //SetWindowText(hWnd, L"OpenGLES ortho");
  //ShowWindow(hWnd, nCmdShow); 
  //UpdateWindow(hWnd);
 
  unsigned int frames = 1800;
  //Message Loop
  //while(!done)
  while(frames--)  
  {
    Render();
  }
  //Clean up all
  Clean();
  //DestroyWindow(hWnd);
  //UnregisterClass(szAppName, hInst);  
  return 0;
}
