#ifndef GLOBAL_DEFINITIONS_H
#define GLOBAL_DEFINITIONS_H
#include "fixed.h"

const GLfixed TANK_SPEED = FixedFromFloat(0.0075f);
const GLfixed TANK_SHOT_SPEED = FixedFromFloat(0.015f);
const GLfixed ALIEN_SHOT_SPEED = FixedFromFloat(0.0075f);


const GLfixed GRAVITY = FixedFromFloat(-4.905f); //This variable is (-0.5 *9.81), needed for the parabolic shot equation

const int ALIEN_FIRE_RATE = 3; //number of simultaneous alien shots 
const int ALIEN_SHOT_FREQUENCY = 12; //possibilities that an alien will shot
const int BUNKER_STRENGTH = 10; //number of impacts that a bunker can resist before be totally destroyed

const GLfixed ACTOR_DYING_TIME = FixedFromFloat(2.5f*1000); //2,5 seconds of falling back to red

const GLfixed START_H = FixedFromInt(-5);
const GLfixed LIMIT_L = FixedFromFloat(-12.5f); //left limit for aliens motion
const GLfixed LIMIT_R = FixedFromFloat(+12.5f); //right limit for aliens motion
const GLfixed SEPARATION = FixedFromFloat(1.75f); //horizontal separation between aliens
const GLfixed ROW_SEPARATION = FixedFromFloat(1.25f); //Vertical separation between aliens
const GLfixed START_SPEED = FixedFromFloat(0.000625f); //Start speed for aliens
const GLfixed CONQUER_HEIGHT = FixedFromFloat(4.5f);//Height where if aliens reaches it, they have conquered the world

//return codes
const int ALL_ALIENS_DEAD = -1;
const int ALIENS_HAS_CONQUERED_THE_WORLD = -2;
const int TANK_KILLED = -3;
const int CONTINUE_PLAYING = -4;

//game state codes
const int PLAYING             = 0;
const int PRESENTATION_SCREEN = 1;
const int KEYMAP_SCREEN       = 2;
const int CREDITS_SCREEN      = 4;

#endif
