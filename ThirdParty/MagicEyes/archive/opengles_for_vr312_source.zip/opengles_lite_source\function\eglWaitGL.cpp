//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglWaitGL.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglWaitGL (void)
{
	CALL_LOG;
	//	complete GL execution prior to subsequent native rendering calls

	//	eglWaitGL is ignored if there is no current EGL rendering context.
	//if( ! __pCurContext ){ return EGL_TRUE; }

	//	EGL_BAD_NATIVE_SURFACE is generated if the surface associated with
	//  the current context has a native window or pixmap, and that window or pixmap is no longer valid.


	//	The same result can be achieved using glFinish.
	glFinish();
	return EGL_TRUE;
}



