#include <math.h>
#include <stdio.h>
#include "t7_render.h"
#include "t7_fixed.h"
#include "t7_texture.h"
#include "t7_mesh.h"
#include "t7_font.h"
#include "t7_timer.h"

namespace __TUTORIAL7__
{

EGLDisplay glesDisplay;
EGLSurface glesSurface;
EGLContext glesContext;

//Variables declared in main.cpp, but used here too
extern NativeWindowType hNativeWnd; // A handle to the window we will create
extern Timer *timer;

int WindowWidth = 0;
int WindowHeight = 0;


BitmappedFont *font = NULL;
Mesh *mesh = NULL;
Texture *meshTexture = NULL;

GLboolean InitOGLES()
{  
  EGLConfig configs[10];
  EGLint matchingConfigs;	

  const EGLint configAttribs[] =
  {
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
  
  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 
  
  if(!eglInitialize(glesDisplay, NULL, NULL)) 
    return false;
  
  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
    return false;
  
	
  if(matchingConfigs < 1)  return false;	  

  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
  if(!glesSurface) 
    return false;
  
  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

  if(!glesContext) 
    return false;
  
  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
    
  glClearColorx(FixedFromFloat(0.5f), FixedFromFloat(0.5f), FixedFromFloat(0.5f), 0);
  glShadeModel(GL_SMOOTH);  
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);

  OS_GetWindowSize(hNativeWnd, &WindowWidth, &WindowHeight);
  SetPerspective(); 
  //Load all needed resources and create needed objects  
  font = new BitmappedFont("./resources/font.raw"); //Load font texture, as an 1-byte raw file
  bool result = font->GetState();
  mesh = new Mesh("./resources/knot.gsd", true);
  result &= mesh->GetState();  
  meshTexture = new Texture("./resources/fire128.tga",GL_LINEAR_MIPMAP_LINEAR);
  result &= meshTexture->GetState(); 
  return result;
}
//----------------------------------------------------------------------------
void Render()
{  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);      
  
  //Setup a good point of view
  SetPerspective();
  glLoadIdentity();  
  glTranslatex(0,0,FixedFromInt(-100));
  glRotatex(FixedFromInt(10),ONE,0,0);
  static GLfixed angle = ZERO;
  glRotatex(angle, 0, ONE,0);     
  GLfixed speed = DivideFixed(FixedFromInt(timer->GetTimeBetweenTwoFrames()), FixedFromInt(100));
  angle += speed;

  //draw the mesh
  glEnable(GL_TEXTURE_2D);
  //glDisable(GL_TEXTURE_2D);
  meshTexture->BindTexture();
  mesh->Draw();
  glDisable(GL_TEXTURE_2D);

  //draw the fps line. 
  SetOrtho2D();
  glLoadIdentity();  
  glColor4x(ONE,ONE,ONE,0);
  BitmappedFont::EnableStates();
  font->Print(0,0,"FPS: %d",timer->GetFPS());
  BitmappedFont::DisableStates();
  
  eglSwapBuffers(glesDisplay, glesSurface);  
}
//----------------------------------------------------------------------------
void Clean()
{
  if(mesh) delete mesh;
  if(font) delete font;
  if(meshTexture) delete meshTexture;
  if(glesDisplay)
  {
    eglMakeCurrent(glesDisplay, NULL, NULL, NULL);  
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }  
}
//----------------------------------------------------------------------------
void SetOrtho2D()
{  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(0), FixedFromInt(WindowWidth), 
           FixedFromInt(0), FixedFromInt(WindowHeight), 
           FixedFromInt(-1), FixedFromInt(1));
  glMatrixMode(GL_MODELVIEW);  
}
//----------------------------------------------------------------------------
void SetPerspective()
{
  int width, height;
  OS_GetWindowSize(hNativeWnd, &width, &height);
  float ratio = (float)width/height;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();        
  Perspective(45.0f,ratio, 1.0f, 200.0f);
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar)
{
  GLfixed xmin, xmax, ymin, ymax, aspectFixed, znearFixed;     
  
  aspectFixed = FixedFromFloat(aspect);
  znearFixed = FixedFromFloat(zNear);

  ymax = MultiplyFixed(znearFixed, FixedFromFloat((GLfloat)tan(fovy * 3.1415962f / 360.0f)));  
  ymin = -ymax;

  xmin = MultiplyFixed(ymin, aspectFixed);
  xmax = MultiplyFixed(ymax, aspectFixed);  
  glFrustumx(xmin, xmax, ymin, ymax, znearFixed, FixedFromFloat(zFar));
}
//----------------------------------------------------------------------------
void SetOrtho()
{  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();    
  glOrthox(FixedFromInt(-100), FixedFromInt(100), 
           FixedFromInt(-100), FixedFromInt(100), 
           FixedFromInt(-100) , FixedFromInt(100));
  glMatrixMode(GL_MODELVIEW);  
}

}//namespace

