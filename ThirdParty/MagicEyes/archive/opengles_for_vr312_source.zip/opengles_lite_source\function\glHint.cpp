//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glHint.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_9uno.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// !!! ���� ó���ؾ� ���� �𸣰���.... -_-;;
void glHint (GLenum target, GLenum mode)
{
	CALL_LOG;
	if (mode != GL_DONT_CARE && mode != GL_FASTEST && mode != GL_NICEST)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	switch (target)
	{
	case GL_FOG_HINT:                    __GLSTATE__.m_FOG_HINT                    = mode; break;                   
	case GL_LINE_SMOOTH_HINT:            __GLSTATE__.m_LINE_SMOOTH_HINT            = mode; break;           
	case GL_PERSPECTIVE_CORRECTION_HINT: __GLSTATE__.m_PERSPECTIVE_CORRECTION_HINT = mode;
		if( mode == GL_FASTEST )
		{
			unsigned long curRenderState = GLESHAL_GetRenderState();
			curRenderState &= ~GLESHAL_RS_PERSPECTIVE_ENB;
			GLESHAL_SetRenderState( curRenderState );
		}
		else
		{ 
			unsigned long curRenderState = GLESHAL_GetRenderState();
			curRenderState |= GLESHAL_RS_PERSPECTIVE_ENB;
			GLESHAL_SetRenderState( curRenderState );
		}	
		break;
	case GL_POINT_SMOOTH_HINT:           __GLSTATE__.m_POINT_SMOOTH_HINT           = mode; break;
	case GL_GENERATE_MIPMAP_HINT:        __GLSTATE__.m_GENERATE_MIPMAP_HINT        = mode; break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
}

