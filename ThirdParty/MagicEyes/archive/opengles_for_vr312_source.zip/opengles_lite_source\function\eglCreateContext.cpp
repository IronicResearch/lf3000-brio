//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglCreateContext.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/08/31 Gamza config�� ���� �������� context�� ����.
//	   2007/08/02 Gamza FSAA�� ���� SAMPLE_BUFFERS�� 1�� config�߰�.
//		2008/08/02 Gamza FSAA������ eglInitialize���� �ϴ� �ʱ�ȭ�ڵ带
//						 eglCreateContext �� eglCreateWindowSurface �� �ű�.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// EGL_NO_CONTEXT is returned if creation of the context fails.

// EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
// EGL_NOT_INITIALIZED is generated if display has not been initialized.
// EGL_BAD_CONFIG is generated if config is not an EGL frame buffer configuration.
// EGL_BAD_CONTEXT is generated if share_context is not an EGL rendering context and is not EGL_NO_CONTEXT.
// EGL_BAD_ATTRIBUTE is generated if attrib_list contains an invalid context attribute or if an attribute is not recognized or out of range.
// EGL_BAD_ALLOC is generated if there are not enough resources to allocate the new context.

EGLContext eglCreateContext (EGLDisplay dpy, EGLConfig config, EGLContext share_list, const EGLint *attrib_list)
{
	CALL_LOG;
	const __CONFIG__* pcurconfig = (const __CONFIG__*)config;
	InitializeOAL( pcurconfig->m_SAMPLE_BUFFERS );

	/*
	//if( config != (EGLConfig)&__EGL_Configuration__ )
	const __CONFIG__* pconfig = (const __CONFIG__*)config;
	if( ! pconfig || EGLCONFIG_FLAG != pconfig->m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_CONFIG );
		return EGL_NO_CONTEXT;
	}
	
	//if( EGL_NO_CONTEXT != share_list )
	//{
	//		EGL_BAD_CONTEXT
	//}
	*/

	if( 0 < __NumberOfContext__ )
	{
		EGLSETERROR( EGL_BAD_ALLOC );
		return EGL_NO_CONTEXT;
	}

	__GLSTATESET__* pglstate = &__GLSTATE__;
	//pglstate->m_Config = *pconfig;

	__Reset_GLSTATESET__( pglstate );

	// config�� ���� �������� context�� ����.
	pglstate->m_BUFFER_SIZE         = pcurconfig->m_BUFFER_SIZE          ;
	pglstate->m_DEPTH_SIZE          = pcurconfig->m_DEPTH_SIZE           ;
	pglstate->m_ALPHA_SIZE          = pcurconfig->m_ALPHA_SIZE           ; 
	pglstate->m_BLUE_SIZE           = pcurconfig->m_BLUE_SIZE            ; 
	pglstate->m_GREEN_SIZE          = pcurconfig->m_GREEN_SIZE           ; 
	pglstate->m_RED_SIZE            = pcurconfig->m_RED_SIZE             ;
	pglstate->m_MAX_PBUFFER_WIDTH   = pcurconfig->m_MAX_PBUFFER_WIDTH    ;
	pglstate->m_MAX_PBUFFER_HEIGHT  = pcurconfig->m_MAX_PBUFFER_HEIGHT   ;
	pglstate->m_MAX_PBUFFER_PIXELS  = pcurconfig->m_MAX_PBUFFER_PIXELS   ;
	pglstate->m_STENCIL_SIZE        = pcurconfig->m_STENCIL_SIZE         ;
	pglstate->m_SAMPLE_BUFFERS      = pcurconfig->m_SAMPLE_BUFFERS       ;
	pglstate->m_SAMPLES             = pcurconfig->m_SAMPLES              ;

	__NumberOfContext__++;
	return (EGLContext)(pglstate);
}
