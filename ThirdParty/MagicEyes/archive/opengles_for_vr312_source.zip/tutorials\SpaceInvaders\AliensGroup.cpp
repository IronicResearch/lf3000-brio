#include <Fake_OS.h>
#include "AliensGroup.h"
#include "FrustumCuller.h"

AliensGroup::AliensGroup(int numberofActorsInRow, int numberOfRows, GLfixed height)
{
  m_numberofActorsInRow = numberofActorsInRow;
  m_rowsCount = numberOfRows;
  m_height = height;
  m_rows = new AlienRow[m_rowsCount];

  m_alienShapes[0] = new Mesh("./resources/alien1.gsd","./resources/nave1.tga",GL_NEAREST,GL_CLAMP_TO_EDGE);
  m_alienShapes[1] = new Mesh("./resources/alien2.gsd","./resources/nave2.tga",GL_NEAREST,GL_CLAMP_TO_EDGE);  
  
  ReviveAliens();
  
}
//-----------------------------------------------------------------------
AliensGroup::~AliensGroup()
{
  delete m_alienShapes[0];
  delete m_alienShapes[1];
  for(int i=0;i<m_rowsCount;i++)
  {
    for(int j=0;j<m_numberofActorsInRow;j++)
      delete m_rows[i][j];
    delete m_rows[i];
  }
  delete m_rows;
}
//-----------------------------------------------------------------------
int AliensGroup::Draw(unsigned long elapsedTime, bool showBB)
{
  int count = 0;

  //angle for the alien's vertical rotation
  GLfixed angle = DivideFixed(FixedFromInt(elapsedTime),FixedFromInt(50)); 
  GLfixed alpha = ONE;

  for(int i=0;i<m_rowsCount;i++)
  {
    for(int j=0;j<m_numberofActorsInRow;j++)
    {      
      GLfixed dying = m_rows[i][j]->IsDying();
     
      if(dying == ZERO) //if alien is alive, we will rotate and draw
      {
        if(i%2) angle = MultiplyFixed(angle,FixedFromInt(-1));        
        m_rows[i][j]->m_rotation[0] += MultiplyFixed(angle, FixedFromInt(elapsedTime));
        count += m_rows[i][j]->Draw(elapsedTime,showBB);      
      }
      else if((dying>0)&&(dying<ACTOR_DYING_TIME)) //if is in dissapearing process we enable blend and compute the right alpha
      {
        alpha = DivideFixed(m_rows[i][j]->IsDying(), ACTOR_DYING_TIME);
        glColor4x(ONE,0,0,alpha);
        glBlendFunc(GL_ONE_MINUS_SRC_ALPHA,GL_SRC_ALPHA);
        glEnable(GL_BLEND);
        
        if(i%2) angle = MultiplyFixed(angle,FixedFromInt(-1));        
        m_rows[i][j]->m_rotation[0] += MultiplyFixed(angle, FixedFromInt(elapsedTime));
        count += m_rows[i][j]->Draw(elapsedTime,showBB);              
        glDisable(GL_BLEND);
        glColor4x(ONE,ONE,ONE,ONE);
        m_rows[i][j]->UpdateDyingTime(elapsedTime);
      }      
    }  
  }
  //return number og aliens rendered
  return count;
}
//-----------------------------------------------------------------------
int AliensGroup::Update(unsigned long elapsedTime)
{
  /*Get the first alien alive in the first row (first = bottom). if there arent anything alive
    return false. We need the first actor to know a) if there remains any alien alive, or b)
    to know the height of this actor to decide if they have conquered our world*/
  //Actor *actor = GetFirtsActorAliveFromTheBottom();
  Actor *actor = GetNextAliveActor(0,0);  
  if(!actor)
  {
    m_allAliensDead = true;
    return ALL_ALIENS_DEAD;
  }

  if(actor->m_position[1] <= CONQUER_HEIGHT + ROW_SEPARATION)
  {
    return ALIENS_HAS_CONQUERED_THE_WORLD;
  }


  //check if the aliens must step down a row
  //vertical motion management
  GLfixed sign; //horizontal sign flag
  bool StepDownOneRow = false;  
  if(m_motionRightToLeft) 
  {
    sign = FixedFromInt(1);
    if(GetFirstActorAliveInMostRightColumn()->m_position[0]>=LIMIT_R)
    {
      StepDownOneRow = true;
      m_motionRightToLeft = !m_motionRightToLeft;
    }
  }
  else
  {
    sign = FixedFromInt(-1);    
    if(GetFirstActorAliveInMostLeftColumn()->m_position[0]<=LIMIT_L)
    {
      StepDownOneRow = true;
      m_motionRightToLeft = !m_motionRightToLeft;
      m_speedFactor += ONE;
    }
  }


  //horizontal motion management  
  GLfixed alienDisplacement = MultiplyFixed(m_speedFactor, START_SPEED);
  alienDisplacement = MultiplyFixed(alienDisplacement, sign);  
  
  for(int i=0;i<m_rowsCount;i++)
  {
    for(int j=0;j<m_numberofActorsInRow;j++)
    { 
      m_rows[i][j]->m_position[0] += MultiplyFixed(alienDisplacement, FixedFromInt(elapsedTime));
      if(StepDownOneRow) m_rows[i][j]->m_position[1] -= ROW_SEPARATION; //update vertical motion        
    }
  }
  return CONTINUE_PLAYING;
}
//-----------------------------------------------------------------------
Actor *AliensGroup::GetFirstActorAliveInMostRightColumn()
{
  for(int col=m_numberofActorsInRow-1; col>0; col--)
  {
    for(int row=0; row<m_rowsCount; row++)    
    {
      if(!m_rows[row][col]->IsDying())
        return m_rows[row][col];
    }
  }
  return NULL;    
}
//-----------------------------------------------------------------------
Actor *AliensGroup::GetFirstActorAliveInMostLeftColumn()
{
  for(int col=0; col<m_numberofActorsInRow; col++)
  {
    for(int row=0; row<m_rowsCount; row++)    
    {
      if(!m_rows[row][col]->IsDying())
        return m_rows[row][col];
    }
  }
  return NULL;
}
//-----------------------------------------------------------------------
int AliensGroup::GetNumberOfAliensAlive()
{
  int count = 0;
  for(int i=0;i<m_rowsCount;i++)
  {
    for(int j=0;j<m_numberofActorsInRow;j++)
    { 
      int dying = m_rows[i][j]->IsDying();
      if(dying)
        count++;      
    }
  }
  return count;
}
//-----------------------------------------------------------------------
bool AliensGroup::AreAllAliensDead()
{
  return m_allAliensDead;
}
//-----------------------------------------------------------------------
Actor *AliensGroup::CheckShotAgainstAliens(GLfixed *hotPoint)
{
  FrustumCuller *f = FrustumCuller::Instance();
  GLfixed pos[3];
  for(int i=0;i<m_rowsCount;i++)
  {
    for(int j=0;j<m_numberofActorsInRow;j++)
    {
      if((!m_rows[i][j]->IsDying()) && (m_rows[i][j]->m_hitPoints > 0))
      {
        //update bounding shpere position
        pos[0] = m_rows[i][j]->m_sphereCenter[0] + m_rows[i][j]->m_position[0];
        pos[1] = m_rows[i][j]->m_sphereCenter[1] + m_rows[i][j]->m_position[1];
        pos[2] = m_rows[i][j]->m_sphereCenter[2] + m_rows[i][j]->m_position[2];
        if(f->PointVsSphere(pos,m_rows[i][j]->m_sphereRadius, hotPoint))
        {
          //PlaySound(L"NAND Flash/resources/tankXplosion.wav", NULL, SND_ASYNC);
          return m_rows[i][j];
        }
      }
    }
  }  
  return NULL;
}
//-----------------------------------------------------------------------
void AliensGroup::ReviveAliens()
{
  m_speedFactor = FixedFromInt(1);
  m_allAliensDead = false;
  m_motionRightToLeft = false;  
  GLfixed pos[3];
  //START_SPEED;
  pos[0] = START_H;
  pos[1] = m_height;
  pos[2] = ZERO;

  for(int i=0;i<m_rowsCount;i++)
  {
    m_rows[i] = new Actor*[m_numberofActorsInRow];
    pos[0] = START_H;
    for(int j=0;j<m_numberofActorsInRow;j++)
    {      
      m_rows[i][j] = new Actor(m_alienShapes[i%2],1,1);
      m_rows[i][j]->m_position[0] = pos[0];
      m_rows[i][j]->m_position[1] = pos[1];
      m_rows[i][j]->m_position[2] = pos[2];
      pos[0] += SEPARATION;
      m_rows[i][j]->Revive();
    }
    pos[1] += SEPARATION;
  }
}
//-----------------------------------------------------------------------
Actor *AliensGroup::GetNextAliveActor(int aliensPerRow,int row)
{
  for(int j=aliensPerRow;j<m_numberofActorsInRow;j++)
  {      
    for(int i=row;i<m_rowsCount;i++)
    {
      if(!m_rows[i][j]->IsDying())
        return m_rows[i][j];
    }
  }
  return NULL; 
}
