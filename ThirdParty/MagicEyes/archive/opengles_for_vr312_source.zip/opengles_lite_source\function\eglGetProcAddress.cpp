//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglGetProcAddress.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include <string.h>
#include "../source/glstate.h"

extern "C" void (* eglGetProcAddress (const char *procname))()
{
	CALL_LOG;
	static const struct
	{
		char name[40];
		void * pfunc;
	} g_functions[] = {
		{ "glCurrentPaletteMatrixOES",				(void *)glCurrentPaletteMatrixOES			},
		{ "glLoadPaletteFromModelViewMatrixOES",	(void *)glLoadPaletteFromModelViewMatrixOES },
		{ "glMatrixIndexPointerOES",				(void *)glMatrixIndexPointerOES				},
		{ "glWeightPointerOES",						(void *)glWeightPointerOES					},
		{ "glPointSizePointerOES",					(void *)glPointSizePointerOES				},
		{ "glDrawTexsOES",							(void *)glDrawTexsOES						},
		{ "glDrawTexsvOES",							(void *)glDrawTexsvOES						},
		{ "glDrawTexiOES",							(void *)glDrawTexiOES						},
		{ "glDrawTexivOES",							(void *)glDrawTexivOES						},
		{ "glDrawTexfOES",							(void *)glDrawTexfOES						},
		{ "glDrawTexfvOES",							(void *)glDrawTexfvOES						},
		{ "glDrawTexxvOES",							(void *)glDrawTexxvOES						},
		{ "glDrawTexxOES",							(void *)glDrawTexxOES						},
	};

	int i, num = sizeof(g_functions) / sizeof(g_functions[0]);
	if (!procname) return 0;

	for (i = 0; i < num; ++i)
	{
		if (!strcmp(g_functions[i].name, procname))
			return (void (*)(void)) g_functions[i].pfunc;
	}
	return 0;	
}



