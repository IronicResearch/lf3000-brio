//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglTerminate.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : ��Ʈ
//	History    :
//	    2007/10/16 Yuni	 ObjectPool destroy �߰�.
//		2007/09/04 Gamza context�Ǵ� surface�� �������� �ʾҴٸ� ����.
//	    2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
#include "../source/renderprimitives.h"


EGLBoolean eglTerminate (EGLDisplay dpy)
{
	CALL_LOG;
	if ( ! __EGLSTATE__.m_isInit ){ return EGL_TRUE; }
	
	if(__NumberOfContext__) eglDestroyContext(dpy, __EGLSTATE__.m_pCurContext);
	if( __GLSTATE__.m_pSurface ) eglDestroySurface(dpy, __GLSTATE__.m_pSurface);
	if( __EGLSTATE__.m_pCurDrawSurface ) eglDestroySurface(dpy, __EGLSTATE__.m_pCurDrawSurface);
	if( __EGLSTATE__.m_pCurReadSurface ) eglDestroySurface(dpy, __EGLSTATE__.m_pCurReadSurface);
	
    __BUFFER_POOL__.Destroy ();
    __HWBUFFER_POOL__.Destroy ();
    __TEXTURE_POOL__.Destroy();
        
    eglMakeCurrent(dpy, NULL, NULL, NULL);  
	FinalizeOAL();
	return EGL_TRUE;
}
