#include <math.h>
#include "t4_render.h" //We need the defines and prototypes of there

namespace __TUTORIAL4__
{

EGLDisplay glesDisplay;  // EGL display
EGLSurface glesSurface;	 // EGL rendering surface
EGLContext glesContext;	 // EGL rendering context

FixedMesh *mesh = NULL;

//Variables declared in main.cpp, but used here too
extern NativeWindowType hNativeWnd; // A handle to the window we will create

GLboolean InitOGLES()
{  
  EGLConfig configs[10];
  EGLint matchingConfigs;	

  /*configAttribs is a integers list that holds the desired format of 
   our framebuffer. We will ask for a framebuffer with 24 bits of 
   color and 16 bits of z-buffer. We also ask for a window buffer, not 
   a pbuffer or pixmap buffer*/	
  const EGLint configAttribs[] =
  {
      EGL_SURFACE_TYPE,   EGL_WINDOW_BIT,
      EGL_NONE,           EGL_NONE
  };
  
  glesDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);	 //Ask for an available display

  //Display initialization (we don't care about the OGLES version numbers)
  if(!eglInitialize(glesDisplay, 0, 0)) 
    return GL_FALSE;
	
  /*Ask for the framebuffer confiburation that best fits our 
  parameters. At most, we want 10 configurations*/
  if(!eglChooseConfig(glesDisplay, configAttribs, &configs[0], 10,  &matchingConfigs)) 
   return GL_FALSE;
	
  //If there isn't any configuration enough good
  if (matchingConfigs < 1)  return GL_FALSE;	  

  /*eglCreateWindowSurface creates an onscreen EGLSurface and returns 
  a handle  to it. Any EGL rendering context created with a 
  compatible EGLConfig can be used to render into this surface.*/
  glesSurface = eglCreateWindowSurface(glesDisplay, configs[0], hNativeWnd, configAttribs);	
  if(!glesSurface) return GL_FALSE;
  
  // Let's create our rendering context
  glesContext=eglCreateContext(glesDisplay,configs[0],0,configAttribs);

  if(!glesContext) return GL_FALSE;

  //Now we will activate the context for rendering	
  eglMakeCurrent(glesDisplay, glesSurface, glesSurface, glesContext); 
  
  /*Remember: because we are programming for a mobile device, we cant 
  use any of the OpenGL ES functions that finish in 'f', we must use 
  the fixed point version (they finish in 'x'*/
  glClearColorx(FixedFromFloat(0.5f), FixedFromFloat(0.5f), FixedFromFloat(0.5f), ONE);
  //Do not want to see smoothed colors, only a plain color for face
  glShadeModel(GL_SMOOTH);  
  //Enable the depth test in order to see the cube correctly
  glEnable(GL_DEPTH_TEST);
  /*Taking care of specifying correctly the winding order of the 
  vertices (counter clock wise order), we can cull all back faces.
  This is probably one of the best optimizations we could do,
  because, by this way, we avoid a lot of computations that wont be 
  reflected in the screen. Use  glEnable(GL_CULL_FACE) to do the work*/
  glEnable(GL_CULL_FACE);

  SetPerspective();
  
  //Light Settings
  //Set a 50% grey diffuse component
  GLfixed diffuse[] = {FixedFromFloat(0.5f),FixedFromFloat(0.5f),FixedFromFloat(0.5f),ONE};
  glLightxv(GL_LIGHT0, GL_DIFFUSE, diffuse);	
  //Enable lighting computations
  glEnable(GL_LIGHTING);
  //Enable Light0 (switch on it)
  glEnable(GL_LIGHT0);

  //Fog settings
  //50% green fog
  GLfixed fogColor[] = { 0, FixedFromFloat(0.5f), 0, 0 }; 
	glFogxv(GL_FOG_COLOR, fogColor);
  /*We chosen a linear mode for fog. Fog will begin to show its effects at 20 units
    of distance from the camera, all the highest fog density will be reached at 50 units*/
	glFogx(GL_FOG_MODE, GL_LINEAR);
	glFogx(GL_FOG_START, FixedFromInt(20));
  glFogx(GL_FOG_END,   FixedFromInt(50));
    
  //Load our scene file
  mesh = LoadMeshFromFile("./resources/scene.gsd");
  return mesh?true:false;
  
}
//----------------------------------------------------------------------------
void Render()
{
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  

  glLoadIdentity();
    
  static int rotation = 0;
  /*"camera" setup to have a good point of view of the scene, also we will perform a rotation
     on the mesh*/
  glTranslatex(0, FixedFromInt(-5), FixedFromInt(-40));  
  glRotatex(FixedFromInt(20),ONE,0,0);
  glRotatex(FixedFromInt(rotation++),0,ONE,0);
    
  
  //With x and z we compute the points of a circle, with a radius = 30, and the velocity = LightRotation
  static float LightRotation = 0;    
  float x = 0,z = 0;
  LightRotation +=0.2f;  
  x = 30 * (float)sin(LightRotation); //we have to use floats, because we do not 
  z = 30 * (float)cos(LightRotation); //have a fixed point version of sin and cos
  GLfixed lightPosition[] = { 0, FixedFromInt(10), 0, FixedFromInt(1) };
  lightPosition[0] = FixedFromFloat(x);  lightPosition[2] = FixedFromFloat(z); 
  //Setup of Light0 position
	glLightxv(GL_LIGHT0, GL_POSITION, lightPosition);

  glEnableClientState(GL_VERTEX_ARRAY);
  glVertexPointer(3, GL_FIXED, 0, mesh->Geometry);
  
  //Normals are needed for the lighting computations
  glEnableClientState(GL_NORMAL_ARRAY);
  glNormalPointer(GL_FIXED, 0, mesh->Normals);
   
  glDrawElements(GL_TRIANGLES,mesh->indexCounter,GL_UNSIGNED_SHORT,mesh->Indices);
     
  glDisableClientState(GL_VERTEX_ARRAY);   	
  glDisableClientState(GL_NORMAL_ARRAY);   	
  
  eglSwapBuffers(glesDisplay, glesSurface);
}
//----------------------------------------------------------------------------
FixedMesh *LoadMeshFromFile(const char *filename)
{
  GSDHeader header;
  OS_FILE meshFile = OS_fopen(filename,"rb");
  if(!meshFile)
    return NULL;

  /*The header holds a brief description of the file, the version number, and the number of meshes
    that are stored in the file. This type of files are thought for static meshes only*/
  OS_fread(&header,sizeof(GSDHeader),1,meshFile); 

  //Check if there is at least one object
  if(header.numberOfSubObjects < 1)
    return NULL;

  GenericObjectData o;
  FixedMesh *mesh = new FixedMesh;

  // we only will use the first object, so we won't iterate over the others, if they exist
  OS_fread(o.Name,sizeof(char)*128,1,meshFile); //read the object name
  OS_fread(o.ParentName,sizeof(char)*128,1,meshFile); //Read the name of the parent object (useful for hierarchies)
  OS_fread(&o.iC,sizeof(unsigned long),1,meshFile); //read the number of vertex indices
  OS_fread(&o.vC,sizeof(unsigned long),1,meshFile); //read the number of vertices

  //allocate enough space for the indices and the GLshort version of them
  o.Indices = new unsigned int[o.iC];
  mesh->Indices = new GLshort[o.iC];
  OS_fread(o.Indices,sizeof(unsigned int) * o.iC,1,meshFile); // read all indices

  //allocate enough space for the vertices and the GLfixed version of them
  o.Geometry = new float[o.vC * 3]; 
  mesh->Geometry = new GLfixed[o.vC * 3];
  OS_fread(o.Geometry,o.vC * 3 * sizeof(float),1,meshFile); //read all vertices (1 vertex = 3 floats)

  //allocate enough space for the texture coordinates and the GLfixed version of them
  o.TexCoord = new float[o.vC * 2];
  mesh->TexCoord = new GLfixed[o.vC * 2];
  OS_fread(o.TexCoord,o.vC * 2 * sizeof(float),1,meshFile);//read all texcoords (1 tex coord = 2 floats)
  
  //allocate enough space for the normals and the GLfixed version of them
  o.Normals= new float[o.vC * 3];
  mesh->Normals = new GLfixed[o.vC * 3];
  OS_fread(o.Normals,o.vC * 3* sizeof(float),1,meshFile);//read all normals (1 normal = 3 floats)
  OS_fclose(meshFile); //Do not need the file opened anymore


  unsigned int i;
  // Convert data to optimized data types for OpenGL ES (GLfixed and GLshort)
  for(i=0;i<o.vC * 3;i++)
  {
    mesh->Geometry[i]= FixedFromFloat(o.Geometry[i]);
    mesh->Normals[i] = FixedFromFloat(o.Normals[i]);
  }

  for(i=0;i<o.vC * 2;i++)
    mesh->TexCoord[i] = FixedFromFloat(o.TexCoord[i]);
  
  for(i=0;i<o.iC;i++)
    mesh->Indices[i] = (GLshort)o.Indices[i];

  mesh->indexCounter = (GLshort)o.iC;
  mesh->vertexCounter= (GLshort)o.vC;

  //delete original values, we will use only the optimized ones
  delete [] o.Indices;
  delete [] o.Geometry;
  delete [] o.Normals;
  delete [] o.TexCoord;
  
  return mesh;
}
//----------------------------------------------------------------------------
void Perspective (GLfloat fovy, GLfloat aspect, GLfloat zNear,  GLfloat zFar)
{
  GLfixed xmin, xmax, ymin, ymax, aspectFixed, znearFixed;     
  
  aspectFixed = FixedFromFloat(aspect);
  znearFixed = FixedFromFloat(zNear);

  ymax = MultiplyFixed(znearFixed, FixedFromFloat((GLfloat)tan(fovy * 3.1415962f / 360.0f)));  
  ymin = -ymax;

  xmin = MultiplyFixed(ymin, aspectFixed);
  xmax = MultiplyFixed(ymax, aspectFixed);  
  glFrustumx(xmin, xmax, ymin, ymax, znearFixed, FixedFromFloat(zFar));
}
//----------------------------------------------------------------------------
void SetPerspective()
{
  int width, height;
  OS_GetWindowSize(hNativeWnd, &width, &height);
  float ratio = (float)width/height;

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();        
  Perspective(45.0f,ratio,1.0f, 100.0f);
  glMatrixMode(GL_MODELVIEW);
}
//----------------------------------------------------------------------------
void Clean()
{
  if(glesDisplay)
  {
    eglMakeCurrent(glesDisplay, NULL, NULL, NULL);  
    if(glesContext) eglDestroyContext(glesDisplay, glesContext);
    if(glesSurface) eglDestroySurface(glesDisplay, glesSurface);
    eglTerminate(glesDisplay);
  }  

  //delete mesh data
  delete [] mesh->Geometry;
  delete [] mesh->Indices;
  delete [] mesh->Normals;
  delete [] mesh->TexCoord;
  delete mesh;
}
//----------------------------------------------------------------------------
//Functions called by WndProc when the user clicks the touch screen
void EnableFog()
{
  glEnable(GL_FOG);
}
//----------------------------------------------------------------------------
void DisableFog()
{
  glDisable(GL_FOG);
}

}//namespace
