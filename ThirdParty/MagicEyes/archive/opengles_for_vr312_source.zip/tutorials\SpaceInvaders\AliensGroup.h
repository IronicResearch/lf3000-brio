#ifndef ALIENROW_H
#define ALIENROW_H
#include "mesh.h"
#include "Actor.h"
#include "global.h"
#include "IRenderable.h"

typedef Actor** AlienRow;

class AliensGroup 
{
public:
	AliensGroup(int numberofActorsInRow, int numberOfRows, GLfixed height);
	~AliensGroup();  
  //update the positions of the enemies set
  int Update(unsigned long elapsedTime);
  int Draw(unsigned long elapsedTime, bool showBB = false);
  //checks the tank shot against the aliens
  Actor *CheckShotAgainstAliens(GLfixed *hotPoint);
  
  //Get/Is functions
  int GetNumberOfAliensAlive();  
  bool AreAllAliensDead();
  inline int GetNumberOfAliensPerRow() {return m_numberofActorsInRow;};
  inline int GetNumberOfRows()         {return m_rowsCount;};
  
  //revive all aliens
  void ReviveAliens();
  //get the next alive alien starting the [i][j] position
  Actor *GetNextAliveActor(int i,int j);
    
private:  
  Actor *GetFirstActorAliveInMostRightColumn(); 
  Actor *GetFirstActorAliveInMostLeftColumn();  
  bool m_allAliensDead;
  bool m_motionRightToLeft; //direction of the aliens motion
  AlienRow *m_rows;
  Mesh *m_alienShapes[2];
  int m_numberofActorsInRow;
  int m_height, m_rowsCount;
  GLfixed m_speedFactor; //speed factor for the current state
};

#endif 
