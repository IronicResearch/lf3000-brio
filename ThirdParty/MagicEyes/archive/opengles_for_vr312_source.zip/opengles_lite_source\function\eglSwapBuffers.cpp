//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglSwapBuffers.cpp
//	Description: �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/31 Yuni	Window ���� API�� OAL�� �̵���Ű�鼭 
//						surface->BufferSwap()���� ó���ϵ��� ����.
//	   2006/10/30 Yuni	GLESHAL_FlipDisplayBuffer ������ tearing ���� �� display flipping�� �ϵ��� ����.
//	   2006/10/20 Gamza layer ũ�⸦ �������� ũ�⿡ ������ �ʰ�,
//							  ó�� ������ surface�� ũ��� ����.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#define SWAPLOG	0

#if SWAPLOG
#include <stdio.h>
extern int g_CallCount_glDrawArrays_Count[7];
extern int g_CallCount_glDrawArrays;
extern int g_CallCount_glDrawElements_Count[7];
extern int g_CallCount_glDrawElements;
extern "C" unsigned int OS_GetTickCount( void);
#endif

EGLBoolean eglSwapBuffers (EGLDisplay dpy, EGLSurface draw)
{
	CALL_LOG;
#if SWAPLOG
	static unsigned int last_tick=0;
	static unsigned int frames=0;
	static unsigned int polys =0;
	unsigned int cur_tick = OS_GetTickCount();
	frames++;
	polys += (g_CallCount_glDrawArrays_Count[0]-2);
	polys += (g_CallCount_glDrawArrays_Count[1]-2);
	polys += (g_CallCount_glDrawArrays_Count[2]/3);
	polys += (g_CallCount_glDrawElements_Count[0]-2);
	polys += (g_CallCount_glDrawElements_Count[1]-2);
	polys += (g_CallCount_glDrawElements_Count[2]/3);
	if( (cur_tick-last_tick) > 5000 )
	{
		if( last_tick != 0 )
		{
			printf( "FPS: %f , Tri/sec: %f\n", frames*1000.0f/(cur_tick-last_tick), polys*1000.0f/(cur_tick-last_tick) );
		}
		last_tick = cur_tick;
		frames=0;
		polys =0;
	}
#if 0
	//printf("eglSwapBuffers %d\n", g_CallCount_glDrawArrays );
	//g_CallCount_glDrawArrays=0;
	printf( "[eglSwapBuffers] %d glDrawArrays T[%d,%d,%d]P[%d]L[%d,%d,%d], %d glDrawElements T[%d,%d,%d]P[%d]L[%d,%d,%d]\n",
				g_CallCount_glDrawArrays,
				g_CallCount_glDrawArrays_Count[0],
				g_CallCount_glDrawArrays_Count[1],
				g_CallCount_glDrawArrays_Count[2],
				g_CallCount_glDrawArrays_Count[3],
				g_CallCount_glDrawArrays_Count[4],
				g_CallCount_glDrawArrays_Count[5],
				g_CallCount_glDrawArrays_Count[6],
				g_CallCount_glDrawElements,
				g_CallCount_glDrawElements_Count[0],
				g_CallCount_glDrawElements_Count[1],
				g_CallCount_glDrawElements_Count[2],
				g_CallCount_glDrawElements_Count[3],
				g_CallCount_glDrawElements_Count[4],
				g_CallCount_glDrawElements_Count[5],
				g_CallCount_glDrawElements_Count[6]);
#endif
	g_CallCount_glDrawArrays=0;
	g_CallCount_glDrawArrays_Count[0]=0;
	g_CallCount_glDrawArrays_Count[1]=0;
	g_CallCount_glDrawArrays_Count[2]=0;
	g_CallCount_glDrawArrays_Count[3]=0;
	g_CallCount_glDrawArrays_Count[4]=0;
	g_CallCount_glDrawArrays_Count[5]=0;
	g_CallCount_glDrawArrays_Count[6]=0;
	g_CallCount_glDrawElements=0;
	g_CallCount_glDrawElements_Count[0]=0;
	g_CallCount_glDrawElements_Count[1]=0;
	g_CallCount_glDrawElements_Count[2]=0;
	g_CallCount_glDrawElements_Count[3]=0;
	g_CallCount_glDrawElements_Count[4]=0;
	g_CallCount_glDrawElements_Count[5]=0;
	g_CallCount_glDrawElements_Count[6]=0;
#endif
	if( !__EGLSTATE__.m_pCurContext )
	{
		return EGL_FALSE;
	}

	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_SURFACE is generated if surface is not an EGL drawing surface.

	/*
	__SURFACE__* psurface = (__SURFACE__*)draw;
	if( ! psurface || EGLSURFACE_FLAG != psurface->m_Config.m_EGLCONFIG  )
	{
		EGLSETERROR( EGL_BAD_SURFACE );
		return EGL_FALSE;
	}

	//	EGL_CONTEXT_LOST is generated if a power management event has occurred.
	//                   The application must destroy all contexts and reinitialise
	//                   OpenGL ES state and objects to continue rendering.

	//	If surface is a pixel buffer or a pixmap, eglSwapBuffers has no effect, and no error is generated
    
	//	The color buffer of surface is left in an undefined state after calling eglSwap-Buffers.

	//	draw surface�� ȭ�鿡 �����ش�.

	//	eglSwapBuffers performs an implicit glFlush before it returns.
*/


	GLES_Surface* pSurface = (GLES_Surface*)draw;
	// �����ڵ� -> Command buffer�� fornt pointer�� ���� �˻絵 GLESHAL_Flush() ������ ����.


	glFlush();
	pSurface->BufferSwap();  // BufferSwap() ������ GLESOAL_OnWindowMoveSize()�� ȣ���Ͽ� ó��.

	return EGL_TRUE;

	//	�Ʒ� ������ ��ó��???
	//	surface will normally be resized by the EGL implementation at the time the native window is resized.
	//	If the implementation cannot do this transparently to the client, then eglSwapBuffers must detect the
	//	change and resize surface prior to copying its pixels to the native window.
	//	If surface shrinks as a result of resizing, some rendered pixels are lost. If
	//	surface grows, the newly allocated buffer contents are undefined. The resizing
	//	behavior described here only maintains consistency of EGL surfaces and native windows; 
	//	clients are still responsible for detecting window size changes (using platform-specific means) 
	//	and changing their viewport and scissor regions accordingly.
}
