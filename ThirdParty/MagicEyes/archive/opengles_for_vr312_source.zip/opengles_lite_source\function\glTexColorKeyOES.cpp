//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexColorKeyOES.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/04/05 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glTexColorKeyMES(GLboolean enable, GLshort colorkey_r5g6b5 )
{
	CALL_LOG;
	unsigned int curState = GLESHAL_GetRenderState();
	if( enable )
	{
		curState |= GLESHAL_RS_TRANSPARENCY_ENB;
	}
	else
	{
		curState &= ~GLESHAL_RS_TRANSPARENCY_ENB;
	}
	GLESHAL_SetRenderState( curState );

	GLESHAL_SetTransparencyColor( colorkey_r5g6b5 );
}

void glTexColorKeyOES(GLboolean enable, GLshort colorkey_r5g6b5 )
{
	glTexColorKeyMES(enable, colorkey_r5g6b5);
}
