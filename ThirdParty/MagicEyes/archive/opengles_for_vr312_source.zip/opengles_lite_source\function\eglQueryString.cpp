//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglQueryString.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


const char * eglQueryString (EGLDisplay dpy, EGLint name)
{
	CALL_LOG;
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_PARAMETER is generated if name is not an accepted value.
	switch( name )
	{
	case EGL_VENDOR     : return GLPARAM_VENDOR;
	case EGL_VERSION    : return GLPARAM_VERSION;
	case EGL_EXTENSIONS : return GLPARAM_EXTENSIONS;
	default:
		EGLSETERROR( EGL_BAD_PARAMETER );
		return 0;
	}
}
