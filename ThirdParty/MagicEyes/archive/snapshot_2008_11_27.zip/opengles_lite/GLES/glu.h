//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glu.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2005/06/01 Gamza first implementation
//------------------------------------------------------------------------------
#ifndef __glu_h__
#define __glu_h__

#include <GLES/gl.h>

#ifdef __cplusplus
extern "C" {
#endif

// Version
#define GLU_VERSION_1_1                    1
#define GLU_VERSION_1_2                    1
#define GLU_VERSION_1_3                    1

GL_API void GL_APIENTRY gluLookAt (GLfloat eyeX, GLfloat eyeY, GLfloat eyeZ, GLfloat centerX, GLfloat centerY, GLfloat centerZ, GLfloat upX, GLfloat upY, GLfloat upZ);
GL_API void GL_APIENTRY gluOrtho2D (GLfloat left, GLfloat right, GLfloat bottom, GLfloat top);
GL_API void GL_APIENTRY gluPerspective (GLfloat fovy, GLfloat aspect, GLfloat zNear, GLfloat zFar);
GL_API void GL_APIENTRY gluPickMatrix (GLfloat x, GLfloat y, GLfloat delX, GLfloat delY, GLint *viewport);
GL_API GLint GL_APIENTRY gluProject (GLfloat objX, GLfloat objY, GLfloat objZ, const GLfloat *model, const GLfloat *proj, const GLint *view, GLfloat* winX, GLfloat* winY, GLfloat* winZ);
GL_API GLint GL_APIENTRY gluUnProject (GLfloat winX, GLfloat winY, GLfloat winZ, const GLfloat *model, const GLfloat *proj, const GLint *view, GLfloat* objX, GLfloat* objY, GLfloat* objZ);
GL_API GLint GL_APIENTRY gluUnProject4 (GLfloat winX, GLfloat winY, GLfloat winZ, GLfloat clipW, const GLfloat *model, const GLfloat *proj, const GLint *view, GLfloat nearVal, GLfloat farVal, GLfloat* objX, GLfloat* objY, GLfloat* objZ, GLfloat* objW);

#ifdef __cplusplus
}
#endif

#endif /* __glu_h__ */
