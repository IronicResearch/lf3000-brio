//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gles_surface.cpp
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2006/11/02 Yuni  HAL �������� ���� ���ʿ��� �Լ� �� ��� ���� ����
//		2006/10/20 Gamza scissor rect �߰�.
//		2006/10/20 Gamza gles_surface ũ�⸦ ���ڷ� �޵��� ����.
//		2006/10/15 Yuni	 first implementation
//------------------------------------------------------------------------------
#ifdef _WIN32
#	pragma warning( disable:4273 )
#	pragma warning( disable:4100 )
#	pragma warning( disable:4514 )
#endif

#include "gles_surface.h"


EGLBoolean 
GLES_Surface::CreateSurface( NativeWindowType NativeWindow, int FSAA )
{
	GLESOAL_SetNativeWindow( NativeWindow );

	GLESOAL_GetNativeWindowSize( &m_Width, &m_Height );
	
	m_FSAA = FSAA;
	if( m_Width  > 1023 ){ return EGL_FALSE; }
	if( m_Height > 1023 ){ return EGL_FALSE; }

	// 1. gl coord�� window coord�� ��ȯ�ϱ� ���� window size ���� 
	// 2. HAL ���� scissor size�� viewport size �ʱ�ȭ
	GLESHAL_SetWindowSize( (unsigned long)m_Width, (unsigned long)m_Height );

	m_MemWidth  = m_Width * 2;
	m_MemHeight = m_Height;

	//	texture memory �� display memory�� �浹�� ���� ����
	//	�������� 64�� ���, �������� 2�� ����� �޸𸮸� �Ҵ��Ѵ�.

	m_MemWidth  = (m_MemWidth +63) & (~63) ;
	m_MemHeight = (m_MemHeight+ 1) & (~ 1) ;
	if(m_FSAA==1) { m_MemHeight *= 2; }	

	//m_pFrontBuffer	= new GLESOAL_MEMORY2D;
	//m_pBackBuffer	= new GLESOAL_MEMORY2D;
	//m_pDepthBuffer	= new GLESOAL_MEMORY2D;
	m_FrontBufferIndex = 0;
	m_BackBufferIndex = 1;

	int i;
	for( i=0; i<sizeof(m_Buffer)/sizeof(m_Buffer[0]); i++)
	{
		if(!GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_FRAMEBUFFER, 
			m_MemWidth, m_MemHeight, 256*2, 256, &m_Buffer[i] ))
			return EGL_FALSE;
	}

	if(!GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_DEPTHBUFFER, 
		m_MemWidth, m_MemHeight, 256*2, 256, &m_DepthBuffer ))
		return EGL_FALSE;

	GLESHAL_SetDisplayBuffer( m_Buffer[m_BackBufferIndex].PhysicalSegment, 
							 (m_Buffer[m_BackBufferIndex].PhysicalSegX)/2, m_Buffer[m_BackBufferIndex].PhysicalSegY,
 							 m_FSAA );	// FSAA false
	GLESHAL_SetDepthBuffer( m_DepthBuffer.PhysicalSegment, 
						(m_DepthBuffer.PhysicalSegX)/2, m_DepthBuffer.PhysicalSegY );


	// hardware�� initial display address���� 
	GLESHAL_FlipDisplayBuffer( EGL_FALSE, 0 );
	// buffer exchange
	m_FrontBufferIndex = m_BackBufferIndex;
	m_BackBufferIndex = (m_BackBufferIndex+1)%(sizeof(m_Buffer)/sizeof(m_Buffer[0]));

	GLESHAL_SetDisplayBuffer( m_Buffer[m_BackBufferIndex].PhysicalSegment, 
						  	  (m_Buffer[m_BackBufferIndex].PhysicalSegX)/2, m_Buffer[m_BackBufferIndex].PhysicalSegY, 
							  m_FSAA );	// FSAA disable
	GLESHAL_Flush();
	while( !GLESHAL_IsIdleState() )
		GLESOAL_Sleep(0);

	return EGL_TRUE;
}


void GLES_Surface::BufferSwap( void )
{
	if( GLESOAL_IsSoftwareSyncNeeded() )
	{
		GLESHAL_Flush();
		while( !GLESHAL_IsIdleState() )
			GLESOAL_Sleep(0);
		GLESOAL_WaitForDisplayAddressPatched();

		GLESHAL_FlipDisplayBuffer( EGL_FALSE, m_FSAA );
		GLESOAL_PushDisplayAddressPatch( &m_Buffer[m_BackBufferIndex] );
	}
	else
	{
		while( !GLESHAL_IsDoneFlipCommand() )
			GLESOAL_Sleep(0);
		GLESHAL_FlipDisplayBuffer( EGL_TRUE, m_FSAA );
	}

	// buffer exchange
	m_FrontBufferIndex = m_BackBufferIndex;
	m_BackBufferIndex = (m_BackBufferIndex+1)%(sizeof(m_Buffer)/sizeof(m_Buffer[0]));

	GLESHAL_SetDisplayBuffer( m_Buffer[m_BackBufferIndex].PhysicalSegment, 
						  	  (m_Buffer[m_BackBufferIndex].PhysicalSegX)/2, m_Buffer[m_BackBufferIndex].PhysicalSegY, 
							  m_FSAA );	// FSAA disable
	GLESOAL_SwapBufferCallback();
}

void GLES_Surface::DestroySurface( void )
{
	int i;
	for( i=0; i<sizeof(m_Buffer)/sizeof(m_Buffer[0]); i++ )
	{
		if( m_Buffer[i].MemoryHandle )
			GLESOAL_Free2D( &m_Buffer[i] );
	}
	if( m_DepthBuffer.MemoryHandle )
		GLESOAL_Free2D( &m_DepthBuffer );

	GLESOAL_SetNativeWindow(NULL);
}

