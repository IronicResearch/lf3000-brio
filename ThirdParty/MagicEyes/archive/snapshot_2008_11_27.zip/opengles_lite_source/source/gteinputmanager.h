//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : streamreader.h
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2006/11/06 Yuni  first implementation
//------------------------------------------------------------------------------
#include <libgles_cm_lite_hal.h>

#ifndef _GTEINPUTMANAGER_H
#define _GTEINPUTMANAGER_H

namespace __MES_OPENGL_ES__
{
/*
class GTEInputManager
{
public:
	virtual void Upload( const float* pGTEInput ) = 0;
};


class GTEInputManager_V____ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
	}
};

class GTEInputManager_V___P 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// point size
		GLESHAL_SetGTEInput( 4*3+3, 1, &(pGTEInput[15]) );
	}
};

class GTEInputManager_V__N_ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// normal
		GLESHAL_SetGTEInput( 4*3, 3, &(pGTEInput[12]) );
	}
};

class GTEInputManager_V__NP 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// normal & point size
		GLESHAL_SetGTEInput( 4*3, 4, &(pGTEInput[12]) );
	}
};

class GTEInputManager_V_T__ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// texture
		GLESHAL_SetGTEInput( 4*2, 4, &(pGTEInput[8]) );
	}
};

class GTEInputManager_V_T_P 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// texture
		GLESHAL_SetGTEInput( 4*2, 4, &(pGTEInput[8]) );
		// point size
		GLESHAL_SetGTEInput( 4*3+3, 1, &(pGTEInput[15]) );
	}
};

class GTEInputManager_V_TN_ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// texture & normal
		GLESHAL_SetGTEInput( 4*2, 7, &(pGTEInput[8]) );
	}
};

class GTEInputManager_V_TNP 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex
		GLESHAL_SetGTEInput( 0, 4, pGTEInput );
		// texture & normal & point size
		GLESHAL_SetGTEInput( 4*2, 8, &(pGTEInput[8]) );
	}
};

class GTEInputManager_VC___ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex & color
		GLESHAL_SetGTEInput( 0, 8, pGTEInput );
	}
};

class GTEInputManager_VC__P 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex & color
		GLESHAL_SetGTEInput( 0, 8, pGTEInput );
		GLESHAL_SetGTEInput( 4*3+3, 1, &(pGTEInput[15]) );
	}
};

class GTEInputManager_VC_N_ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex & color
		GLESHAL_SetGTEInput( 0, 8, pGTEInput );
		GLESHAL_SetGTEInput( 4*3, 3, &(pGTEInput[12]) );
	}
};

class GTEInputManager_VC_NP 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		// vertex & color
		GLESHAL_SetGTEInput( 0, 8, pGTEInput );
		// normal & point size
		GLESHAL_SetGTEInput( 4*3, 4, &(pGTEInput[12]) );
	}
};


class GTEInputManager_VCT__ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		GLESHAL_SetGTEInput( 0, 12, pGTEInput );
	}
};

class GTEInputManager_VCT_P
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		GLESHAL_SetGTEInput( 0, 12, pGTEInput );
		GLESHAL_SetGTEInput( 4*3+3, 1, &(pGTEInput[15]) );
	}
};


class GTEInputManager_VCTN_ 
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		GLESHAL_SetGTEInput( 0, 15, pGTEInput );
	}
};


class GTEInputManager_VCTNP
	: public GTEInputManager
{
	virtual void Upload( const float* pGTEInput )
	{
		GLESHAL_SetGTEInput( 0, 16, pGTEInput );
	}
};

*/

} // namespace __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;


#endif	//_GTEINPUTMANAGER_H
