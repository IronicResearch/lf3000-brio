//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gtecode.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/10/18 Yuni	GTE const register ��ġ ���� (light 8�� ����)
//	   2006/10/17 Gamza first implementation
//------------------------------------------------------------------------------
#ifndef _GTECODE_H
#define _GTECODE_H

//	����������� �ϳ� �����.
//------------------------------------------------------------------------------
#ifndef MES_ASSERT
#if defined(WIN32) || defined(UNDER_CE)
#pragma warning(disable:4127)
#endif
#define MES_ASSERT(exp)	
#define MES_SPY(exp)	
#define MES_ASSERT_RETURN(exp,return_exp)	{ MES_ASSERT(exp); if( !(exp) ){ return_exp; } }
#endif
//------------------------------------------------------------------------------

#include "glstate.h"

namespace __MES_OPENGL_ES__
{
	// page0
	static unsigned int __Position_dest			= 0;		// size : 4
	static unsigned int __Color_dest			= 1*4;		// size : 4
	static unsigned int __Normalize_const_dest	= 2*4;
	static unsigned int __Normal_dest			= 3*4;		// size : 3
	static unsigned int __PointSize_dest		= 3*4+3;	// size : 1
	static unsigned int __Tex0_dest				= 4*4;		// size : 4
	//unsigned int __Tex1_dest					= 5*4;		// size : 4
	static unsigned int __Weight_dest			= 6*4;		// size : 4
	static unsigned int __PrjMatrix_dest		= 7*4;		// size : 16

	// page1
	static unsigned int __MVMatrix_dest	= 16*4*1 + 0;		// size : 16
	//unsigned int __MVInvMatrix_dest	= 16*4*1 + 4*4;	// size : 16

	// page2 : Texture0
	// page3 : Texture1
	static unsigned int __TexMatrix_dest[2]	= { 16*4*2+0, 16*4*3+0 };

	// page4 ~ 5
	static unsigned int __MatrixPalette_dest	= 16*4*4;	// size : 16 * 8
	
	// page6 : Global Ambient 
	// page7 : Light0
	// page8 : Light1
	static unsigned int __GlobalAmbient_dest	= 16*4*7;
	static unsigned int __Ligth_dest			= 16*4*8;

	// page9 : Point & Line
	static unsigned int __Render_const_dest		= 16*4*6;
	static unsigned int __Render_dest			= 16*4*6 + 4*8;

	GLboolean PrepareRenderingGTE( GLenum DrawingMode );

} // namespace __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;

#endif // #ifndef _PREPARERENDERING_H
