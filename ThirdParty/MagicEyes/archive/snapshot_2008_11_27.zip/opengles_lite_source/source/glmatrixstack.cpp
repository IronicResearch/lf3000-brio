//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glmatrixstack.cpp
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/03/17 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#include "glmatrixstack.h"
#include <math.h>

#define M3_MUL_M3( matrix, m1, m2 ) {\
							mat.m[0][0] = VFMUL(m1->m[0][0],m2->m[0][0]) + \
										  VFMUL(m1->m[0][1],m2->m[1][0]) + \
										  VFMUL(m1->m[0][2],m2->m[2][0]);  \
							mat.m[0][1] = VFMUL(m1->m[0][0],m2->m[0][1]) + \
										  VFMUL(m1->m[0][1],m2->m[1][1]) + \
										  VFMUL(m1->m[0][2],m2->m[2][1]);  \
							mat.m[0][2] = VFMUL(m1->m[0][0],m2->m[0][2]) + \
										  VFMUL(m1->m[0][1],m2->m[1][2]) + \
										  VFMUL(m1->m[0][2],m2->m[2][2]);  \
																	 \
							mat.m[1][0] = VFMUL(m1->m[1][0],m2->m[0][0]) + \
										  VFMUL(m1->m[1][1],m2->m[1][0]) + \
										  VFMUL(m1->m[1][2],m2->m[2][0]);  \
							mat.m[1][1] = VFMUL(m1->m[1][0],m2->m[0][1]) + \
										  VFMUL(m1->m[1][1],m2->m[1][1]) + \
										  VFMUL(m1->m[1][2],m2->m[2][1]);  \
							mat.m[1][2] = VFMUL(m1->m[1][0],m2->m[0][2]) + \
										  VFMUL(m1->m[1][1],m2->m[1][2]) + \
										  VFMUL(m1->m[1][2],m2->m[2][2]);  \
																	 \
  							mat.m[2][0] = VFMUL(m1->m[2][0],m2->m[0][0]) + \
										  VFMUL(m1->m[2][1],m2->m[1][0]) + \
										  VFMUL(m1->m[2][2],m2->m[2][0]);  \
							mat.m[2][1] = VFMUL(m1->m[2][0],m2->m[0][1]) + \
										  VFMUL(m1->m[2][1],m2->m[1][1]) + \
										  VFMUL(m1->m[2][2],m2->m[2][1]);  \
							mat.m[2][2] = VFMUL(m1->m[2][0],m2->m[0][2]) + \
										  VFMUL(m1->m[2][1],m2->m[1][2]) + \
										  VFMUL(m1->m[2][2],m2->m[2][2]);  \
							}		
#define	IS_SIMPLE( mat )	( (mat.m[3][0] == 0) && (mat.m[3][1] == 0)			\
								&& (mat.m[3][2] == 0 ) && ( mat.m[3][3] == VFONE ) )

namespace{

#define	ZERO_TOLERANCE	F2VF(0.0001f)
	int GetRotateInverseMatrix( Matrix4x4* dstMat, const Matrix4x4* srcMat )
	{
/*
		Matrix4x4 mat;

		dstMat->m[0][0] = srcMat->m[0][0];
		dstMat->m[0][1] = srcMat->m[1][0];
		dstMat->m[0][2] = srcMat->m[2][0];
		dstMat->m[0][3] = 0;
		dstMat->m[1][0] = srcMat->m[0][1];
		dstMat->m[1][1] = srcMat->m[1][1];
		dstMat->m[1][2] = srcMat->m[2][1];
		dstMat->m[1][3] = 0;
		dstMat->m[2][0] = srcMat->m[0][2];
		dstMat->m[2][1] = srcMat->m[1][2];
		dstMat->m[2][2] = srcMat->m[2][2];
		dstMat->m[2][3] = 0;
		dstMat->m[3][0] = 0;
		dstMat->m[3][1] = 0;
		dstMat->m[3][2] = 0;
		dstMat->m[3][3] = VFONE;

		M3_MUL_M3( mat, dstMat, srcMat );

		if( ( mat.m[0][0] == VFONE ) && ( mat.m[0][1] == 0 ) && ( mat.m[0][2] == 0 ) &&
			( mat.m[1][0] == 0 ) && ( mat.m[1][1] == VFONE ) && ( mat.m[1][2] == 0 ) &&
			( mat.m[2][0] == 0 ) && ( mat.m[2][1] == 0 ) && ( mat.m[2][2] == VFONE ) )
		{
			//memcpy( dstMat, mat, sizeof(Vfloat) * 9 );
			return 1;
		}
		else
*/
		{
			dstMat->m[0][0] = VFMUL(srcMat->m[1][1], srcMat->m[2][2]) - VFMUL(srcMat->m[1][2], srcMat->m[2][1]);
			dstMat->m[0][1] = VFMUL(srcMat->m[0][2], srcMat->m[2][1]) - VFMUL(srcMat->m[0][1], srcMat->m[2][2]);
			dstMat->m[0][2] = VFMUL(srcMat->m[0][1], srcMat->m[1][2]) - VFMUL(srcMat->m[0][2], srcMat->m[1][1]);
			dstMat->m[1][0] = VFMUL(srcMat->m[1][2], srcMat->m[2][0]) - VFMUL(srcMat->m[1][0], srcMat->m[2][2]);
			dstMat->m[1][1] = VFMUL(srcMat->m[0][0], srcMat->m[2][2]) - VFMUL(srcMat->m[0][2], srcMat->m[2][0]);
			dstMat->m[1][2] = VFMUL(srcMat->m[0][2], srcMat->m[1][0]) - VFMUL(srcMat->m[0][0], srcMat->m[1][2]);
			dstMat->m[2][0] = VFMUL(srcMat->m[1][0], srcMat->m[2][1]) - VFMUL(srcMat->m[1][1], srcMat->m[2][0]);
			dstMat->m[2][1] = VFMUL(srcMat->m[0][1], srcMat->m[2][0]) - VFMUL(srcMat->m[0][0], srcMat->m[2][1]);
			dstMat->m[2][2] = VFMUL(srcMat->m[0][0], srcMat->m[1][1]) - VFMUL(srcMat->m[0][1], srcMat->m[1][0]);

			Vfloat fDet =
				VFMUL(srcMat->m[0][0], dstMat->m[0][0]) +
				VFMUL(srcMat->m[0][1], dstMat->m[1][0]) +
				VFMUL(srcMat->m[0][2], dstMat->m[2][0]);

			if ( VFABS(fDet) <= ZERO_TOLERANCE )
			{
				return 0;
			}

			Vfloat fInvDet = VFDIV( VFONE, fDet );

			dstMat->m[0][0] = VFMUL(dstMat->m[0][0], fInvDet);
			dstMat->m[0][1] = VFMUL(dstMat->m[0][1], fInvDet);
			dstMat->m[0][2] = VFMUL(dstMat->m[0][2], fInvDet);
			dstMat->m[1][0] = VFMUL(dstMat->m[1][0], fInvDet);
			dstMat->m[1][1] = VFMUL(dstMat->m[1][1], fInvDet);
			dstMat->m[1][2] = VFMUL(dstMat->m[1][2], fInvDet);
			dstMat->m[2][0] = VFMUL(dstMat->m[2][0], fInvDet);
			dstMat->m[2][1] = VFMUL(dstMat->m[2][1], fInvDet);
			dstMat->m[2][2] = VFMUL(dstMat->m[2][2], fInvDet);

			return 1;
		}
	}
};

void
MatrixStack::
Rotate    ( Vfloat angle, Vfloat x, Vfloat y, Vfloat z )
{
	Matrix4x4 matrix;
	Vec3D axis = {x, y, z};
	if( !(VFONE == axis.x &&     0 == axis.y &&     0 == axis.z) &&
		!(    0 == axis.x && VFONE == axis.y &&     0 == axis.z) &&
		!(    0 == axis.x &&     0 == axis.y && VFONE == axis.z) )
	{
		V3_NORMALIZE( axis );
	}
	Vfloat r_x = axis.x;
	Vfloat r_y = axis.y;
	Vfloat r_z = axis.z;

	angle = VFMUL(angle, F2VF(static_cast<float>(M_PI) / 180.0f));

	Vfloat sine   = VFSIN(angle);
	Vfloat cosine = VFCOS(angle);
	
	Vfloat one_minus_cosine = VFONE - cosine;

	matrix.m[0][0] = cosine + VFMUL(one_minus_cosine, VFMUL(r_x, r_x));
	matrix.m[0][1] = VFMUL(one_minus_cosine, VFMUL(r_x, r_y)) - VFMUL(r_z, sine);
	matrix.m[0][2] = VFMUL(VFMUL(one_minus_cosine, r_x), r_z) + VFMUL(r_y, sine);
	matrix.m[0][3] = 0;

	matrix.m[1][0] = VFMUL(VFMUL(one_minus_cosine, r_x),  r_y) + VFMUL(r_z, sine);
	matrix.m[1][1] = cosine + VFMUL(VFMUL(one_minus_cosine, r_y), r_y);
	matrix.m[1][2] = VFMUL(VFMUL(one_minus_cosine, r_y), r_z) - VFMUL(r_x, sine);
	matrix.m[1][3] = 0;

	matrix.m[2][0] = VFMUL(VFMUL(one_minus_cosine, r_x), r_z) - VFMUL(r_y, sine);
	matrix.m[2][1] = VFMUL(VFMUL(one_minus_cosine, r_y), r_z) + VFMUL(r_x, sine);
	matrix.m[2][2] = cosine + VFMUL(VFMUL(one_minus_cosine, r_z), r_z);
	matrix.m[2][3] = 0;
	
	matrix.m[3][0] = matrix.m[3][1] = matrix.m[3][2] = 0;
	matrix.m[3][3] = VFONE;
	
	MultMatrix( matrix );
	//m_IsUpdated = false;
}

void
MatrixStack::
Scale     ( Vfloat x, Vfloat y, Vfloat z )
{
	Matrix4x4& curmat = m_Stack[m_StackPointer].m_Matrix;
	m_Stack[m_StackPointer].m_ValidInverse = false;
	for( int i=0; i<4; i++ )
	{
		curmat.m[i][0] = VFMUL(curmat.m[i][0],x);
		curmat.m[i][1] = VFMUL(curmat.m[i][1],y);
		curmat.m[i][2] = VFMUL(curmat.m[i][2],z);
	}	
	//m_IsUpdated = false;
}

void
MatrixStack::
Translate ( Vfloat x, Vfloat y, Vfloat z )
{
	Matrix4x4& curmat = m_Stack[m_StackPointer].m_Matrix;
	m_Stack[m_StackPointer].m_ValidInverse = false;
	for( int i=0; i<4; i++ )
	{
		curmat.m[i][3] += VFMUL(curmat.m[i][0],x) +
						  VFMUL(curmat.m[i][1],y) +
						  VFMUL(curmat.m[i][2],z) ;
	}
	//m_IsUpdated = false;
}

void
MatrixStack::
Frustum   ( Vfloat l, Vfloat r, Vfloat b, Vfloat t, Vfloat n, Vfloat f )
{
	Matrix4x4 matrix;

	Vfloat inv_width  = (r - l) ? VFINV(r - l) : 0;
	Vfloat inv_height = (t - b) ? VFINV(t - b) : 0;
	Vfloat inv_depth  = (f - n) ? VFINV(f - n) : 0;

	Vfloat two_n = n * 2;

	matrix.m[0][0] = VFMUL(two_n, inv_width);
	matrix.m[0][1] = 0;
	matrix.m[0][2] = VFMUL(r + l, inv_width);
	matrix.m[0][3] = 0;

	matrix.m[1][0] = 0;
	matrix.m[1][1] = VFMUL(two_n, inv_height);
	matrix.m[1][2] = VFMUL(t + b, inv_height);
	matrix.m[1][3] = 0;

	matrix.m[2][0] = 0;
	matrix.m[2][1] = 0;
	matrix.m[2][2] = VFMUL(-f - n, inv_depth);
	matrix.m[2][3] = VFMUL(VFMUL(-two_n, inv_depth), f);

	matrix.m[3][0] = 0;
	matrix.m[3][1] = 0;
	matrix.m[3][2] = -VFONE;
	matrix.m[3][3] = 0;	

	MultMatrix( matrix );
	//m_IsUpdated = false;
}

void
MatrixStack::
Ortho     ( Vfloat l, Vfloat r, Vfloat b, Vfloat t, Vfloat n, Vfloat f )
{
	Matrix4x4 matrix;

	Vfloat inv_width  = (r - l) ? VFINV(r - l) : 0;
	Vfloat inv_height = (t - b) ? VFINV(t - b) : 0;
	Vfloat inv_depth  = (f - n) ? VFINV(f - n) : 0;

	matrix.m[0][0] = 2 * inv_width;
	matrix.m[0][1] = 0;
	matrix.m[0][2] = 0;
	matrix.m[0][3] = -VFMUL(r + l, inv_width);

	matrix.m[1][0] = 0;
	matrix.m[1][1] = 2 * inv_height;
	matrix.m[1][2] = 0;
	matrix.m[1][3] = -VFMUL(t + b, inv_height);

	matrix.m[2][0] = 0;
	matrix.m[2][1] = 0;
	matrix.m[2][2] = -2 * inv_depth;
	//matrix.m[2][3] = VFMUL(-f - n, inv_depth);
	matrix.m[2][3] = -VFMUL( (f+n), inv_depth);

	matrix.m[3][0] = 0;
	matrix.m[3][1] = 0;
	matrix.m[3][2] = 0;
	matrix.m[3][3] = VFONE;

	MultMatrix( matrix );
	//m_IsUpdated = false;
}


#define SWAP_ROWS(a, b) { Vfloat *_tmp = a; (a)=(b); (b)=_tmp; }

void MatrixStack::StackItem::MakeInverse( void )
{
	m_ValidInverse = true;

	Matrix4x4 rotInvMat;
	if( IsSimpleMatrix() && GetRotateInverseMatrix( &rotInvMat, &m_Matrix ) )
	{
		m_Inverse.m[0][0] = rotInvMat.m[0][0];  
		m_Inverse.m[0][1] = rotInvMat.m[0][1];  
		m_Inverse.m[0][2] = rotInvMat.m[0][2];  
		m_Inverse.m[0][3] = VFMUL(rotInvMat.m[0][0],-m_Matrix.m[0][3]) + 
					VFMUL(rotInvMat.m[0][1],-m_Matrix.m[1][3]) + 
					VFMUL(rotInvMat.m[0][2],-m_Matrix.m[2][3]);  
												   
		m_Inverse.m[1][0] = rotInvMat.m[1][0];  
		m_Inverse.m[1][1] = rotInvMat.m[1][1];  
		m_Inverse.m[1][2] = rotInvMat.m[1][2];  
		m_Inverse.m[1][3] = VFMUL(rotInvMat.m[1][0],-m_Matrix.m[0][3]) + 
					VFMUL(rotInvMat.m[1][1],-m_Matrix.m[1][3]) + 
					VFMUL(rotInvMat.m[1][2],-m_Matrix.m[2][3]);  
												   
  		m_Inverse.m[2][0] = rotInvMat.m[2][0];  
		m_Inverse.m[2][1] = rotInvMat.m[2][1];  
		m_Inverse.m[2][2] = rotInvMat.m[2][2];  
		m_Inverse.m[2][3] = VFMUL(rotInvMat.m[2][0],-m_Matrix.m[0][3]) + 
					VFMUL(rotInvMat.m[2][1],-m_Matrix.m[1][3]) + 
					VFMUL(rotInvMat.m[2][2],-m_Matrix.m[2][3]);  
												   
  		m_Inverse.m[3][0] = 0;//rotInvMat.m[3][0];  
		m_Inverse.m[3][1] = 0;//rotInvMat.m[3][1];  
		m_Inverse.m[3][2] = 0;//rotInvMat.m[3][2];  
		m_Inverse.m[3][3] = VFONE;

#ifdef MES_DEBUG
#define EPSILON		0.0002f
#define IS_SAME( a, b )		 ( (( VF2F( (a)-(b) ) > EPSILON)  || (VF2F( (a)-(b) ) < -EPSILON) ) ? 0 : 1 )

	Matrix4x4 testMat;
	memcpy( testMat.m, m_Inverse.m, sizeof(Vfloat)*16 );

	   Vfloat wtmp[4][8];
	   Vfloat m0, m1, m2, m3, s;
	   Vfloat *r0, *r1, *r2, *r3;


	   r0 = wtmp[0], r1 = wtmp[1], r2 = wtmp[2], r3 = wtmp[3];

	   r0[0] = m_Matrix.m[0][0], r0[1] = m_Matrix.m[0][1],
	   r0[2] = m_Matrix.m[0][2], r0[3] = m_Matrix.m[0][3],
	   r0[4] = VFONE, r0[5] = r0[6] = r0[7] = 0,

	   r1[0] = m_Matrix.m[1][0], r1[1] = m_Matrix.m[1][1],
	   r1[2] = m_Matrix.m[1][2], r1[3] = m_Matrix.m[1][3],
	   r1[5] = VFONE, r1[4] = r1[6] = r1[7] = 0,

	   r2[0] = m_Matrix.m[2][0], r2[1] = m_Matrix.m[2][1],
	   r2[2] = m_Matrix.m[2][2], r2[3] = m_Matrix.m[2][3],
	   r2[6] = VFONE, r2[4] = r2[5] = r2[7] = 0,

	   r3[0] = m_Matrix.m[3][0], r3[1] = m_Matrix.m[3][1],
	   r3[2] = m_Matrix.m[3][2], r3[3] = m_Matrix.m[3][3],
	   r3[7] = VFONE, r3[4] = r3[5] = r3[6] = 0;

	   if (VFABS(r3[0])>VFABS(r2[0])) SWAP_ROWS(r3, r2);
	   if (VFABS(r2[0])>VFABS(r1[0])) SWAP_ROWS(r2, r1);
	   if (VFABS(r1[0])>VFABS(r0[0])) SWAP_ROWS(r1, r0);
	   if (0 == r0[0]){ M4_IDENTITY( m_Inverse ); return; }

	   m1 = VFDIV(r1[0], r0[0]); m2 = VFDIV(r2[0], r0[0]); m3 = VFDIV(r3[0], r0[0]);
	   s = r0[1]; r1[1] -= VFMUL(m1, s); r2[1] -= VFMUL(m2, s); r3[1] -= VFMUL(m3, s);
	   s = r0[2]; r1[2] -= VFMUL(m1, s); r2[2] -= VFMUL(m2, s); r3[2] -= VFMUL(m3, s);
	   s = r0[3]; r1[3] -= VFMUL(m1, s); r2[3] -= VFMUL(m2, s); r3[3] -= VFMUL(m3, s);
	   s = r0[4];
	   if (s != 0) { r1[4] -= VFMUL(m1, s); r2[4] -= VFMUL(m2, s); r3[4] -= VFMUL(m3, s); }
	   s = r0[5];
	   if (s != 0) { r1[5] -= VFMUL(m1, s); r2[5] -= VFMUL(m2, s); r3[5] -= VFMUL(m3, s); }
	   s = r0[6];
	   if (s != 0) { r1[6] -= VFMUL(m1, s); r2[6] -= VFMUL(m2, s); r3[6] -= VFMUL(m3, s); }
	   s = r0[7];
	   if (s != 0) { r1[7] -= VFMUL(m1, s); r2[7] -= VFMUL(m2, s); r3[7] -= VFMUL(m3, s); }

	   if (VFABS(r3[1])>VFABS(r2[1])) SWAP_ROWS(r3, r2);
	   if (VFABS(r2[1])>VFABS(r1[1])) SWAP_ROWS(r2, r1);
	   if (0 == r1[1]){ M4_IDENTITY( m_Inverse ); return; }

	   m2 = VFDIV(r2[1], r1[1]); m3 = VFDIV(r3[1], r1[1]);
	   r2[2] -= VFMUL(m2, r1[2]); r3[2] -= VFMUL(m3, r1[2]);
	   r2[3] -= VFMUL(m2, r1[3]); r3[3] -= VFMUL(m3, r1[3]);
	   s = r1[4]; if (0 != s) { r2[4] -= VFMUL(m2, s); r3[4] -= VFMUL(m3, s); }
	   s = r1[5]; if (0 != s) { r2[5] -= VFMUL(m2, s); r3[5] -= VFMUL(m3, s); }
	   s = r1[6]; if (0 != s) { r2[6] -= VFMUL(m2, s); r3[6] -= VFMUL(m3, s); }
	   s = r1[7]; if (0 != s) { r2[7] -= VFMUL(m2, s); r3[7] -= VFMUL(m3, s); }

	   if (VFABS(r3[2])>VFABS(r2[2])) SWAP_ROWS(r3, r2);
	   if (0 == r2[2]){ M4_IDENTITY( m_Inverse ); return; }

	   m3 = VFDIV(r3[2], r2[2]);
	   r3[3] -= VFMUL(m3, r2[3]), r3[4] -= VFMUL(m3, r2[4]),
	   r3[5] -= VFMUL(m3, r2[5]), r3[6] -= VFMUL(m3, r2[6]),
	   r3[7] -= VFMUL(m3, r2[7]);

	   if (0 == r3[3]){ M4_IDENTITY( m_Inverse ); return; }

	   s = VFINV(r3[3]);
	   r3[4] = VFMUL(r3[4], s); r3[5] = VFMUL(r3[5], s); r3[6] = VFMUL(r3[6], s); r3[7] = VFMUL(r3[7], s);

	   m2 = r2[3];
	   s  = VFINV(r2[2]);
	   r2[4] = VFMUL(s, (r2[4] - VFMUL(r3[4], m2))), r2[5] = VFMUL(s, (r2[5] - VFMUL(r3[5], m2))),
	   r2[6] = VFMUL(s, (r2[6] - VFMUL(r3[6], m2))), r2[7] = VFMUL(s, (r2[7] - VFMUL(r3[7], m2)));
	   m1 = r1[3];
	   r1[4] -= VFMUL(r3[4], m1), r1[5] -= VFMUL(r3[5], m1),
	   r1[6] -= VFMUL(r3[6], m1), r1[7] -= VFMUL(r3[7], m1);
	   m0 = r0[3];
	   r0[4] -= VFMUL(r3[4], m0), r0[5] -= VFMUL(r3[5], m0),
	   r0[6] -= VFMUL(r3[6], m0), r0[7] -= VFMUL(r3[7], m0);

	   m1 = r1[2];
	   s  = VFINV(r1[1]);
	   r1[4] = VFMUL(s, (r1[4] - VFMUL(r2[4], m1))), r1[5] = VFMUL(s, (r1[5] - VFMUL(r2[5], m1))),
	   r1[6] = VFMUL(s, (r1[6] - VFMUL(r2[6], m1))), r1[7] = VFMUL(s, (r1[7] - VFMUL(r2[7], m1)));
	   m0 = r0[2];
	   r0[4] -= VFMUL(r2[4], m0), r0[5] -= VFMUL(r2[5], m0),
	   r0[6] -= VFMUL(r2[6], m0), r0[7] -= VFMUL(r2[7], m0);

	   m0 = r0[1];
	   s  = VFINV(r0[0]);
	   r0[4] = VFMUL(s, (r0[4] - VFMUL(r1[4], m0))), r0[5] = VFMUL(s, (r0[5] - VFMUL(r1[5], m0))),
	   r0[6] = VFMUL(s, (r0[6] - VFMUL(r1[6], m0))), r0[7] = VFMUL(s, (r0[7] - VFMUL(r1[7], m0)));

	   m_Inverse.m[0][0] = r0[4]; m_Inverse.m[0][1] = r0[5],
	   m_Inverse.m[0][2] = r0[6]; m_Inverse.m[0][3] = r0[7],
	   m_Inverse.m[1][0] = r1[4]; m_Inverse.m[1][1] = r1[5],
	   m_Inverse.m[1][2] = r1[6]; m_Inverse.m[1][3] = r1[7],
	   m_Inverse.m[2][0] = r2[4]; m_Inverse.m[2][1] = r2[5],
	   m_Inverse.m[2][2] = r2[6]; m_Inverse.m[2][3] = r2[7],
	   m_Inverse.m[3][0] = r3[4]; m_Inverse.m[3][1] = r3[5],
	   m_Inverse.m[3][2] = r3[6]; m_Inverse.m[3][3] = r3[7];

	   if( IS_SAME(m_Inverse.m[0][0], testMat.m[0][0]) && IS_SAME(m_Inverse.m[0][1], testMat.m[0][1]) && 
		   IS_SAME(m_Inverse.m[0][2], testMat.m[0][2]) && IS_SAME(m_Inverse.m[0][3], testMat.m[0][3]) && 
		   IS_SAME(m_Inverse.m[1][0], testMat.m[1][0]) && IS_SAME(m_Inverse.m[1][1], testMat.m[1][1]) && 
		   IS_SAME(m_Inverse.m[1][2], testMat.m[1][2]) && IS_SAME(m_Inverse.m[1][3], testMat.m[1][3]) && 
		   IS_SAME(m_Inverse.m[2][0], testMat.m[2][0]) && IS_SAME(m_Inverse.m[2][1], testMat.m[2][1]) && 
		   IS_SAME(m_Inverse.m[2][2], testMat.m[2][2]) && IS_SAME(m_Inverse.m[2][3], testMat.m[2][3]) && 
		   IS_SAME(m_Inverse.m[3][0], testMat.m[3][0]) && IS_SAME(m_Inverse.m[3][1], testMat.m[3][1]) && 
		   IS_SAME(m_Inverse.m[3][2], testMat.m[3][2]) && IS_SAME(m_Inverse.m[3][3], testMat.m[3][3]) )
	   {
			//printf("OK!\n");
		   return;
	   }
	   else
	   {
		   printf("Inverse matrix is not correct!\n");
		   printf( "%5.5f, %5.5f, %5.5f, %5.5f,	\t\t	%5.5f, %5.5f, %5.5f, %5.5f, \n", 
			   VF2F(testMat.m[0][0]), VF2F(testMat.m[0][1]), VF2F(testMat.m[0][2]), VF2F(testMat.m[0][3]), 
			   VF2F(m_Inverse.m[0][0]), VF2F(m_Inverse.m[0][1]), VF2F(m_Inverse.m[0][2]), VF2F(m_Inverse.m[0][3]) );
		   printf( "%5.5f, %5.5f, %5.5f, %5.5f,	\t\t	%5.5f, %5.5f, %5.5f, %5.5f, \n", 
			   VF2F(testMat.m[1][0]), VF2F(testMat.m[1][1]), VF2F(testMat.m[1][2]), VF2F(testMat.m[1][3]), 
			   VF2F(m_Inverse.m[1][0]), VF2F(m_Inverse.m[1][1]), VF2F(m_Inverse.m[1][2]), VF2F(m_Inverse.m[1][3]) );
		   printf( "%5.5f, %5.5f, %5.5f, %5.5f,	\t\t	%5.5f, %5.5f, %5.5f, %5.5f, \n", 
			   VF2F(testMat.m[2][0]), VF2F(testMat.m[2][1]), VF2F(testMat.m[2][2]), VF2F(testMat.m[2][3]), 
			   VF2F(m_Inverse.m[2][0]), VF2F(m_Inverse.m[2][1]), VF2F(m_Inverse.m[2][2]), VF2F(m_Inverse.m[2][3]) );
		   printf( "%5.5f, %5.5f, %5.5f, %5.5f,	\t\t	%5.5f, %5.5f, %5.5f, %5.5f, \n", 
			   VF2F(testMat.m[3][0]), VF2F(testMat.m[3][1]), VF2F(testMat.m[3][2]), VF2F(testMat.m[3][3]), 
			   VF2F(m_Inverse.m[3][0]), VF2F(m_Inverse.m[3][1]), VF2F(m_Inverse.m[3][2]), VF2F(m_Inverse.m[3][3]) );
	   }
#endif
		//}
	}
	else
	{
	   Vfloat wtmp[4][8];
	   Vfloat m0, m1, m2, m3, s;
	   Vfloat *r0, *r1, *r2, *r3;


	   r0 = wtmp[0], r1 = wtmp[1], r2 = wtmp[2], r3 = wtmp[3];

	   r0[0] = m_Matrix.m[0][0], r0[1] = m_Matrix.m[0][1],
	   r0[2] = m_Matrix.m[0][2], r0[3] = m_Matrix.m[0][3],
	   r0[4] = VFONE, r0[5] = r0[6] = r0[7] = 0,

	   r1[0] = m_Matrix.m[1][0], r1[1] = m_Matrix.m[1][1],
	   r1[2] = m_Matrix.m[1][2], r1[3] = m_Matrix.m[1][3],
	   r1[5] = VFONE, r1[4] = r1[6] = r1[7] = 0,

	   r2[0] = m_Matrix.m[2][0], r2[1] = m_Matrix.m[2][1],
	   r2[2] = m_Matrix.m[2][2], r2[3] = m_Matrix.m[2][3],
	   r2[6] = VFONE, r2[4] = r2[5] = r2[7] = 0,

	   r3[0] = m_Matrix.m[3][0], r3[1] = m_Matrix.m[3][1],
	   r3[2] = m_Matrix.m[3][2], r3[3] = m_Matrix.m[3][3],
	   r3[7] = VFONE, r3[4] = r3[5] = r3[6] = 0;

	   /* choose pivot - or die */
	   if (VFABS(r3[0])>VFABS(r2[0])) SWAP_ROWS(r3, r2);
	   if (VFABS(r2[0])>VFABS(r1[0])) SWAP_ROWS(r2, r1);
	   if (VFABS(r1[0])>VFABS(r0[0])) SWAP_ROWS(r1, r0);
	   if (0 == r0[0]){ M4_IDENTITY( m_Inverse ); return; }

	   /* eliminate first variable     */
	   m1 = VFDIV(r1[0], r0[0]); m2 = VFDIV(r2[0], r0[0]); m3 = VFDIV(r3[0], r0[0]);
	   s = r0[1]; r1[1] -= VFMUL(m1, s); r2[1] -= VFMUL(m2, s); r3[1] -= VFMUL(m3, s);
	   s = r0[2]; r1[2] -= VFMUL(m1, s); r2[2] -= VFMUL(m2, s); r3[2] -= VFMUL(m3, s);
	   s = r0[3]; r1[3] -= VFMUL(m1, s); r2[3] -= VFMUL(m2, s); r3[3] -= VFMUL(m3, s);
	   s = r0[4];
	   if (s != 0) { r1[4] -= VFMUL(m1, s); r2[4] -= VFMUL(m2, s); r3[4] -= VFMUL(m3, s); }
	   s = r0[5];
	   if (s != 0) { r1[5] -= VFMUL(m1, s); r2[5] -= VFMUL(m2, s); r3[5] -= VFMUL(m3, s); }
	   s = r0[6];
	   if (s != 0) { r1[6] -= VFMUL(m1, s); r2[6] -= VFMUL(m2, s); r3[6] -= VFMUL(m3, s); }
	   s = r0[7];
	   if (s != 0) { r1[7] -= VFMUL(m1, s); r2[7] -= VFMUL(m2, s); r3[7] -= VFMUL(m3, s); }

	   /* choose pivot - or die */
	   if (VFABS(r3[1])>VFABS(r2[1])) SWAP_ROWS(r3, r2);
	   if (VFABS(r2[1])>VFABS(r1[1])) SWAP_ROWS(r2, r1);
	   if (0 == r1[1]){ M4_IDENTITY( m_Inverse ); return; }

	   /* eliminate second variable */
	   m2 = VFDIV(r2[1], r1[1]); m3 = VFDIV(r3[1], r1[1]);
	   r2[2] -= VFMUL(m2, r1[2]); r3[2] -= VFMUL(m3, r1[2]);
	   r2[3] -= VFMUL(m2, r1[3]); r3[3] -= VFMUL(m3, r1[3]);
	   s = r1[4]; if (0 != s) { r2[4] -= VFMUL(m2, s); r3[4] -= VFMUL(m3, s); }
	   s = r1[5]; if (0 != s) { r2[5] -= VFMUL(m2, s); r3[5] -= VFMUL(m3, s); }
	   s = r1[6]; if (0 != s) { r2[6] -= VFMUL(m2, s); r3[6] -= VFMUL(m3, s); }
	   s = r1[7]; if (0 != s) { r2[7] -= VFMUL(m2, s); r3[7] -= VFMUL(m3, s); }

	   /* choose pivot - or die */
	   if (VFABS(r3[2])>VFABS(r2[2])) SWAP_ROWS(r3, r2);
	   if (0 == r2[2]){ M4_IDENTITY( m_Inverse ); return; }

	   /* eliminate third variable */
	   m3 = VFDIV(r3[2], r2[2]);
	   r3[3] -= VFMUL(m3, r2[3]), r3[4] -= VFMUL(m3, r2[4]),
	   r3[5] -= VFMUL(m3, r2[5]), r3[6] -= VFMUL(m3, r2[6]),
	   r3[7] -= VFMUL(m3, r2[7]);

	   /* last check */
	   if (0 == r3[3]){ M4_IDENTITY( m_Inverse ); return; }

	   s = VFINV(r3[3]);             /* now back substitute row 3 */
	   r3[4] = VFMUL(r3[4], s); r3[5] = VFMUL(r3[5], s); r3[6] = VFMUL(r3[6], s); r3[7] = VFMUL(r3[7], s);

	   m2 = r2[3];                 /* now back substitute row 2 */
	   s  = VFINV(r2[2]);
	   r2[4] = VFMUL(s, (r2[4] - VFMUL(r3[4], m2))), r2[5] = VFMUL(s, (r2[5] - VFMUL(r3[5], m2))),
	   r2[6] = VFMUL(s, (r2[6] - VFMUL(r3[6], m2))), r2[7] = VFMUL(s, (r2[7] - VFMUL(r3[7], m2)));
	   m1 = r1[3];
	   r1[4] -= VFMUL(r3[4], m1), r1[5] -= VFMUL(r3[5], m1),
	   r1[6] -= VFMUL(r3[6], m1), r1[7] -= VFMUL(r3[7], m1);
	   m0 = r0[3];
	   r0[4] -= VFMUL(r3[4], m0), r0[5] -= VFMUL(r3[5], m0),
	   r0[6] -= VFMUL(r3[6], m0), r0[7] -= VFMUL(r3[7], m0);

	   m1 = r1[2];                 /* now back substitute row 1 */
	   s  = VFINV(r1[1]);
	   r1[4] = VFMUL(s, (r1[4] - VFMUL(r2[4], m1))), r1[5] = VFMUL(s, (r1[5] - VFMUL(r2[5], m1))),
	   r1[6] = VFMUL(s, (r1[6] - VFMUL(r2[6], m1))), r1[7] = VFMUL(s, (r1[7] - VFMUL(r2[7], m1)));
	   m0 = r0[2];
	   r0[4] -= VFMUL(r2[4], m0), r0[5] -= VFMUL(r2[5], m0),
	   r0[6] -= VFMUL(r2[6], m0), r0[7] -= VFMUL(r2[7], m0);

	   m0 = r0[1];                 /* now back substitute row 0 */
	   s  = VFINV(r0[0]);
	   r0[4] = VFMUL(s, (r0[4] - VFMUL(r1[4], m0))), r0[5] = VFMUL(s, (r0[5] - VFMUL(r1[5], m0))),
	   r0[6] = VFMUL(s, (r0[6] - VFMUL(r1[6], m0))), r0[7] = VFMUL(s, (r0[7] - VFMUL(r1[7], m0)));

	   m_Inverse.m[0][0] = r0[4]; m_Inverse.m[0][1] = r0[5],
	   m_Inverse.m[0][2] = r0[6]; m_Inverse.m[0][3] = r0[7],
	   m_Inverse.m[1][0] = r1[4]; m_Inverse.m[1][1] = r1[5],
	   m_Inverse.m[1][2] = r1[6]; m_Inverse.m[1][3] = r1[7],
	   m_Inverse.m[2][0] = r2[4]; m_Inverse.m[2][1] = r2[5],
	   m_Inverse.m[2][2] = r2[6]; m_Inverse.m[2][3] = r2[7],
	   m_Inverse.m[3][0] = r3[4]; m_Inverse.m[3][1] = r3[5],
	   m_Inverse.m[3][2] = r3[6]; m_Inverse.m[3][3] = r3[7];
	}
}

//MatrixStack :: MatrixStack(S32 maxStackElements)
//:	m_StackSize(maxStackElements),
//	m_StackPointer(0)
//{
//	m_Stack = new Matrix4x4[maxStackElements];
//}
//
//
//MatrixStack :: ~MatrixStack() {
//	delete[] m_Stack;
//}
//
//bool MatrixStack :: ResizeStack( S32 maxStackElements )
//{
//	S32 newstacksize = maxStackElements;
//	Matrix4x4* newstackheap = new Matrix4x4[newstacksize];
//	if( !newstackheap ){ return false; }
//	for( S32 i=0; i<=m_StackPointer; i++ ){ newstackheap[i] = m_Stack[i]; }
//	delete[] m_Stack;
//	m_StackSize = newstacksize;
//	m_Stack = newstackheap;	
//	return true;
//}
//
//bool MatrixStack :: PopMatrix(void) {
//	if (m_StackPointer > 0) {
//		--m_StackPointer;
//		return true;
//	} else {
//		return false;
//	}
//}
//
//
//bool MatrixStack :: PushMatrix(void) {
//
//	//	@modified 050506 Gamza ������ �����ϸ� Ű���
//	if (m_StackPointer == m_StackSize - 1)
//	{
//		if( ! ResizeStack( m_StackSize*2 ) ){ return false; }
//	}
//	MES_ASSERT( m_StackPointer < m_StackSize - 1 );
//
//	//if (m_StackPointer < m_StackSize - 1) {
//		m_Stack[m_StackPointer + 1] = m_Stack[m_StackPointer];
//		++m_StackPointer;
//		return true;
//	//} else {
//	//	return false;
//	//}
//}
//
//
//void MatrixStack :: MultMatrix(const Matrix4x4& matrix) {
//	LoadMatrix(CurrentMatrix() * matrix);
//}
//
//
//void MatrixStack :: LoadIdentity(void) {
//	CurrentMatrix().MakeIdentity();
//}
//
//
//void MatrixStack :: LoadMatrix(const Matrix4x4& matrix) {
//	CurrentMatrix() = matrix;
//}
