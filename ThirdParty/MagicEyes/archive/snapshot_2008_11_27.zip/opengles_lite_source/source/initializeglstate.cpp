//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : initializeglstate.cpp
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/08/17 Gamza	GL error�� ���߽�Ű�� �ʱ�ȭ �ڵ� ����.
//	   2006/12/07 Yuni	modify the initial value of diffuse and specular for GL_LIGHT0
//	   2006/12/07 Yuni	add light position initialization
//	   2006/11/28 Yuni	add hardware buffer object
//	   2006/10/20 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#include <GLES/gl.h>
#include <GLES/glext.h>

namespace __MES_OPENGL_ES__
{

void Initialize_GLState( void )
{
	GLint i;
	GLint iparams[1];

	glAlphaFunc   ( GL_ALWAYS,0 );
	glClearColor  ( 0,0,0,0 );
	glClearDepthf ( 1 );
	glColor4f     ( 1,1,1,1 );	
	glDepthRangef ( 0,1 );
	glFogf ( GL_FOG_MODE, GL_EXP );
	glFogf ( GL_FOG_DENSITY, 1 );
	glFogf ( GL_FOG_START, 0 );
	glFogf ( GL_FOG_END, 1 );
	GLfloat fogcolor[] = {0,0,0,0};
	glFogfv( GL_FOG_COLOR, fogcolor );		
	glLightModelf ( GL_LIGHT_MODEL_TWO_SIDE, 0 );
	GLfloat lightmodelambient[] = {0.2f,0.2f,0.2f,1};
	glLightModelfv( GL_LIGHT_MODEL_AMBIENT, lightmodelambient );
	glLineWidth ( 1 );
	GLfloat material_ambient [] = {0.2f,0.2f,0.2f,1};
	GLfloat material_diffuse [] = {0.8f,0.8f,0.8f,1};
	GLfloat material_specular[] = {0,0,0,1};
	GLfloat material_emission[] = {0,0,0,1};
	glMaterialf (GL_FRONT_AND_BACK, GL_SHININESS, 0 );
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT            , material_ambient  );
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE            , material_diffuse  );
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR           , material_specular );
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION           , material_emission );
	glNormal3f (0,0,1);
	glPointParameterf ( GL_POINT_SIZE_MIN             , 0);
	glPointParameterf ( GL_POINT_SIZE_MAX             , 1);
	glPointParameterf ( GL_POINT_FADE_THRESHOLD_SIZE  , 1);
	GLfloat point_distance_attenuation[] = {1,0,0};
	glPointParameterfv( GL_POINT_DISTANCE_ATTENUATION , point_distance_attenuation );	
	glPointSize (1);	
	glPolygonOffset (0, 0);		
	glBindBuffer  (GL_ARRAY_BUFFER, 0);
	glBindBuffer  (GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindTexture (GL_TEXTURE_2D, 0);
	glBlendFunc   (GL_ONE, GL_ZERO);
	glClearStencil(0);
	glColorMask   (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	glColorPointer(4, GL_FLOAT, 0, (const GLvoid *)0);
	glCullFace (GL_BACK);
	glDepthFunc(GL_LESS);
	glDepthMask(GL_TRUE);	
	glFrontFace(GL_CCW);
	glHint ( GL_GENERATE_MIPMAP_HINT        , GL_DONT_CARE );
	glHint ( GL_LINE_SMOOTH_HINT            , GL_DONT_CARE );
	glHint ( GL_PERSPECTIVE_CORRECTION_HINT , GL_DONT_CARE );
	glHint ( GL_POINT_SMOOTH_HINT           , GL_DONT_CARE );	
	glLogicOp (GL_COPY);
	glNormalPointer(GL_FLOAT, 0, (const GLvoid *)0);
	glPixelStorei (GL_PACK_ALIGNMENT  , 4);
	glPixelStorei (GL_UNPACK_ALIGNMENT, 4);
	glSampleCoverage (1, GL_FALSE);
	glScissor (0, 0, 1, 1);
	glShadeModel  (GL_SMOOTH);
	glStencilFunc (GL_ALWAYS, 0, 0xFFFFFFFF);
	glStencilMask (0xFFFFFFFF);
	glStencilOp   (GL_KEEP,GL_KEEP,GL_KEEP);
	glVertexPointer (4, GL_FLOAT, 0, (const GLvoid *)0);
	glViewport(0, 0, 1, 1);	
	glMatrixIndexPointerOES (1, GL_UNSIGNED_BYTE, 0, (const GLvoid *)0);	
	glWeightPointerOES (1, GL_FLOAT, 0, (const GLvoid *)0);
	glPointSizePointerOES (GL_FLOAT, 0, (const GLvoid *)0);

	glGetIntegerv( GL_MAX_CLIP_PLANES, iparams );
	for( i=0; i<iparams[0]; i++ )
	{
		GLfloat equation[] = {0,0,0,0};
		glClipPlanef  ( GLenum(GL_CLIP_PLANE0+i), equation );
		glDisable     ( GLenum(GL_CLIP_PLANE0+i) );
	}	
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	glMatrixMode( GL_TEXTURE );
	glGetIntegerv( GL_MAX_TEXTURE_UNITS, iparams );
	for( i=0; i<iparams[0]; i++ )
	{
		glActiveTexture      ( GLenum(GL_TEXTURE0+i) );
		glClientActiveTexture( GLenum(GL_TEXTURE0+i) );
		glLoadIdentity();
		glMultiTexCoord4f( GLenum(GL_TEXTURE0+i), 0,0,0,1 );
		glTexEnvf       ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , GL_MODULATE );
		GLfloat texture_env_color[] = {0,0,0,0};
		glTexEnvfv      ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, texture_env_color );
		glTexEnvf       ( GL_TEXTURE_ENV, GL_COMBINE_RGB      , GL_MODULATE );
		glTexEnvf       ( GL_TEXTURE_ENV, GL_COMBINE_ALPHA    , GL_MODULATE );
		glTexEnvf       ( GL_POINT_SPRITE_OES, GL_COORD_REPLACE_OES, GL_FALSE );	
		glTexParameterf ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST_MIPMAP_LINEAR );
		glTexParameterf ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexParameterf ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S    , GL_REPEAT );
		glTexParameterf ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T    , GL_REPEAT );
		glTexParameterf ( GL_TEXTURE_2D, GL_GENERATE_MIPMAP   , GL_FALSE );
		glTexCoordPointer (4, GL_FLOAT, 0, (const GLvoid *)0);
	}
	glGetIntegerv( GL_MAX_PALETTE_MATRICES_OES, iparams );
	if( iparams[0] > 0 )
	{
		glMatrixMode( GL_MATRIX_PALETTE_OES );	
		for( i=0; i<iparams[0]; i++ )
		{
			glCurrentPaletteMatrixOES( i );
			glLoadIdentity();
		}
	}
	glMatrixMode( GL_MODELVIEW );
	glActiveTexture      ( GL_TEXTURE0 );
	glClientActiveTexture( GL_TEXTURE0 );
	glCurrentPaletteMatrixOES( 0 );

	
	glGetIntegerv( GL_MAX_LIGHTS, iparams );
	for( i=0; i<iparams[0]; i++ )
	{
		glLightf (GLenum(GL_LIGHT0 + i), GL_SPOT_CUTOFF           , 180 );
		glLightf (GLenum(GL_LIGHT0 + i), GL_SPOT_EXPONENT         , 0 );
		glLightf (GLenum(GL_LIGHT0 + i), GL_CONSTANT_ATTENUATION  , 1 );
		glLightf (GLenum(GL_LIGHT0 + i), GL_LINEAR_ATTENUATION    , 0 );
		glLightf (GLenum(GL_LIGHT0 + i), GL_QUADRATIC_ATTENUATION , 0 );
		GLfloat ambient       [] = {0,0,0,1};
		GLfloat diffuse       [] = {0,0,0,0};	
		GLfloat specular      [] = {0,0,0,0};
		//GLfloat emission      [] = {0,0,0,1};
		GLfloat spot_direction[] = {0,0,-1};
		GLfloat position	  [] = {0,0,1,0};

		glLightfv(GLenum(GL_LIGHT0 + i), GL_POSITION			  , position	   );
		glLightfv(GLenum(GL_LIGHT0 + i), GL_AMBIENT               , ambient        );
		glLightfv(GLenum(GL_LIGHT0 + i), GL_DIFFUSE               , diffuse        );
		glLightfv(GLenum(GL_LIGHT0 + i), GL_SPECULAR              , specular       );
		//glLightfv(GLenum(GL_LIGHT0 + i), GL_EMISSION              , emission       );
		glLightfv(GLenum(GL_LIGHT0 + i), GL_SPOT_DIRECTION        , spot_direction );
		glDisable(GLenum(GL_LIGHT0 + i));
	}
	// The initial value for GL_LIGHT0 is (1, 1, 1, 1). For other lights, the initial value is (0, 0, 0, 0).
	GLfloat light0_diffuse_specular[] = {1,1,1,1};
	glLightfv(GL_LIGHT0, GL_DIFFUSE , light0_diffuse_specular  );
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0_diffuse_specular );


	glDisableClientState( GL_COLOR_ARRAY           );
	glDisableClientState( GL_NORMAL_ARRAY          );
	glDisableClientState( GL_TEXTURE_COORD_ARRAY   );
	glDisableClientState( GL_VERTEX_ARRAY          );
	glDisableClientState( GL_WEIGHT_ARRAY_OES      );
	glDisableClientState( GL_MATRIX_INDEX_ARRAY_OES);
	glDisableClientState( GL_POINT_SIZE_ARRAY_OES  );
	
	glDisable(GL_ALPHA_TEST               );
	glDisable(GL_BLEND                    );
	glDisable(GL_COLOR_LOGIC_OP           );
	glDisable(GL_COLOR_MATERIAL           );
	glDisable(GL_CULL_FACE                );
	glDisable(GL_DEPTH_TEST               );
	glEnable (GL_DITHER                   );
	glDisable(GL_FOG                      );
	glDisable(GL_LIGHTING                 );
	glDisable(GL_LINE_SMOOTH              );
	glDisable(GL_MATRIX_PALETTE_OES       );
	glEnable (GL_MULTISAMPLE              );
	glDisable(GL_NORMALIZE                );
	glDisable(GL_POINT_SMOOTH             );
	glDisable(GL_POINT_SPRITE_OES         );
	glDisable(GL_POLYGON_OFFSET_FILL      );
	glDisable(GL_RESCALE_NORMAL           );
	glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE );
	glDisable(GL_SAMPLE_ALPHA_TO_ONE      );
	glDisable(GL_SAMPLE_COVERAGE          );
	glDisable(GL_SCISSOR_TEST             );
	glDisable(GL_STENCIL_TEST             );
	glDisable(GL_TEXTURE_2D               );

	/*
	// hardware buffer object ���� �ʱ�ȭ - glstate.cpp�� �ű�.
	glDisableClientState( GL_HARDWAREBUFFER_ARRAY_OES  );
	glBindHWBufferOES  (GL_ARRAY_BUFFER, 0);
	glBindHWBufferOES  (GL_ELEMENT_ARRAY_BUFFER, 0);
	*/
	//	�ʱ�ȭ �����߿� �߻��� ���� ����� �����Ѵ�.
	glGetError();
}	

} // namespace __MES_OPENGL_ES__

