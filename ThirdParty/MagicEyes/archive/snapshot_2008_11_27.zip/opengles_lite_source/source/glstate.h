//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glstate.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2007/10/17 Yuni  HW buffer object ��� �� ���� ���� �� ������ ���� ����ü �߰�.
//	   2007/09/11 Yuni	Default texture�� Texture pool�� ������ __GLSTATE__�� ��������� ����.
//     2007/09/06 Gamza GL/EGL ������ ���ڷ� ����ϱ����� �Լ� �߰�.
//                      GLERROR_TO_STRING / EGLERROR_TO_STRING
//	   2006/12/15 Yuni	add LIGHTMODE enumeration and SetTextureSize()
//	   2006/11/28 Yuni	add hardware buffer object
//	   2006/11/13 Yuni	add for managing default texture api
//	   2006/11/02 Yuni	change Color8888 type to float array that has 4 elements(r, g, b, a);
//	   2006/03/08 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLSTATE_H
#define _GLSTATE_H

#ifdef UNDER_CE
	#include <mes_memory_debug.h>
#else
	#include <module/mes_memory_debug.h>
#endif

#include <GLES/gl.h>
#include <GLES/egl.h>
#include <GLES/glext.h>
#include "gltypes.h"
#include "glfixed.h"
#include "glmatrixstack.h"
#include "objectpool.h"
#include "gles_surface.h"
#include "renderprimitives.h"

#ifdef _WIN32
#	pragma warning( disable:4273 )
#	pragma warning( disable:4100 )
#	pragma warning( disable:4514 )
#endif

namespace __MES_OPENGL_ES__
{

#define GLPARAM_VENDOR			"MagicEyes"
#define GLPARAM_VERSION			"OpenGL ES-CM 1.1"
// space-separated list of supported extensions to GL
#define GLPARAM_EXTENSIONS		"GL_OES_matrix_palette"
#define GLPARAM_RENDERER		"VR3520F"
#define GLPARAM_MAX_TEXTURE_UNITS                     2
#define GLPARAM_MAX_CLIP_PLANES                       0
#define GLPARAM_MAX_PALETTE_MATRICES_OES              64
#define GLPARAM_MAX_VERTEX_UNITS_OES                  4
#define GLPARAM_MAX_ELEMENTS_INDICES                  65536
#define GLPARAM_MAX_ELEMENTS_VERTICES                 65536
#define GLPARAM_MAX_MODELVIEW_STACK_DEPTH             64  // �ּ� 16
#define GLPARAM_MAX_PROJECTION_STACK_DEPTH            16  // �ּ� 2
#define GLPARAM_MAX_TEXTURE_STACK_DEPTH               16  // �ּ� 2
#define GLPARAM_MAX_PALETTE_MATRICES_OES_STACK_DEPTH  1	  // 0�ϱ� 1�ϱ�..??
#define GLPARAM_MAX_TEXTURE_SIZE                      512  // �ּ� 64
#define GLPARAM_MAX_LIGHTS                            8    // GL_MAX_LIGHTS
#define GLPARAM_SUBPIXEL_BITS                         4    // �ּ� 4
#define GLPARAM_ALIASED_POINT_SIZE_MIN                1
#define GLPARAM_ALIASED_POINT_SIZE_MAX                1024
#define GLPARAM_ALIASED_LINE_WIDTH_MIN                1
#define GLPARAM_ALIASED_LINE_WIDTH_MAX                1024
#define GLPARAM_SMOOTH_POINT_SIZE_MIN                 1
#define GLPARAM_SMOOTH_POINT_SIZE_MAX                 1024
#define GLPARAM_SMOOTH_LINE_WIDTH_MIN                 0
#define GLPARAM_SMOOTH_LINE_WIDTH_MAX                 0
#define	GLPARAM_IMPLEMENTATION_COLOR_READ_FORMAT_OES  GL_RGB
#define	GLPARAM_IMPLEMENTATION_COLOR_READ_TYPE_OES    GL_UNSIGNED_SHORT_5_6_5
#define GLPARAM_NUM_COMPRESSED_TEXTURE_FORMATS        10
/*
#define GLPARAM_COMPRESSED_TEXTURE_FORMATS			\
						GL_PALETTE4_R5_G6_B5_OES,	\
						GL_PALETTE8_R5_G6_B5_OES,	\
						GL_PALETTE4_RGB8_OES,		\
						GL_PALETTE4_RGBA8_OES,		\
						GL_PALETTE4_RGBA4_OES,		\
						GL_PALETTE4_RGB5_A1_OES,	\
						GL_PALETTE8_RGB8_OES,		\
						GL_PALETTE8_RGBA8_OES,		\
						GL_PALETTE8_RGBA4_OES,		\
						GL_PALETTE8_RGB5_A1_OES		
*/						
extern const GLenum COMPRESSED_TEXTURE_FORMATS[GLPARAM_NUM_COMPRESSED_TEXTURE_FORMATS];
//#define GLPARAM_MAX_HWBUFFER_FOR_DRAWPRIMITIVE         64
#define	GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES			2	// matrix palette double buffering

struct __LIGHT__
{
	Vfloat		m_SpotExponent;          // 0
	Vfloat		m_SpotCutoff;            // 180
	Vfloat		m_ConstantAttenuation;   // 1
	Vfloat		m_LinearAttenuation;     // 0
	Vfloat		m_QuadraticAttenuation;  // 0
	Vec4D		m_Position;              // 0,0,1,0
	Vec3D		m_Direction;             // 0,0,1
	Vfloat		m_AmbientColor[4];          // 0,0,0,1
	Vfloat		m_DiffuseColor[4];          // 1,1,1,1
	Vfloat		m_SpecularColor[4];         // 1,1,1,1
	GLboolean	m_IsUpdated;
};

struct __MATERIAL__
{
	Vfloat		m_SpecularExponent;      // 0
	Vfloat		m_AmbientColor[4];          // 0.2,0.2,0.2,1
	Vfloat		m_DiffuseColor[4];          // 0.8,0.8,0.8,1
	Vfloat		m_SpecularColor[4];         // 0,0,0,1
	Vfloat		m_EmissionColor[4];         // 0,0,0,1
};

struct __TEXENV__
{
	GLenum		m_TEXTURE_ENV_MODE; // GL_REPLACE, [GL_MODULATE], GL_DECAL, GL_BLEND, GL_ADD ,GL_COMBINE
	GLenum		m_COMBINE_RGB;      // GL_REPLACE, GL_MODULATE, GL_ADD, GL_ADD_SIGNED, GL_INTERPOLATE, GL_SUBTRACT, GL_DOT3_RGB, GL_DOT3_RGBA
	GLenum		m_COMBINE_ALPHA;    // GL_REPLACE, GL_MODULATE, GL_ADD, GL_ADD_SIGNED, GL_INTERPOLATE, GL_SUBTRACT
	Vfloat		m_RGB_SCALE;
	Vfloat		m_ALPHA_SCALE;
	/*
	GLenum		m_SRC0_RGB; // GL_TEXTURE, GL_CONSTANT, GL_PRIMARY_COLOR, GL_PREVIOUS
	GLenum		m_SRC1_RGB;
	GLenum		m_SRC2_RGB;
	GLenum		m_SRC0_ALPHA;
	GLenum		m_SRC1_ALPHA;
	GLenum		m_SRC2_ALPHA;
	GLenum		m_OPERAND0_RGB; // GL_SRC_COLOR, GL_ONE_MINUS_SRC_COLOR, GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
	GLenum		m_OPERAND1_RGB;
	GLenum		m_OPERAND2_RGB;
	GLenum		m_OPERAND0_ALPHA; // GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA
	GLenum		m_OPERAND1_ALPHA;
	GLenum		m_OPERAND2_ALPHA;
	*/
	GLenum		m_SRC_RGB[3];
	GLenum		m_SRC_ALPHA[3];
	GLenum		m_OPERAND_RGB[3];
	GLenum		m_OPERAND_ALPHA[3];
	
	Vfloat      m_LODBias; // 0
	Vfloat		m_TEXTURE_ENV_COLOR[4]; // 0,0,0,0
	
	GLboolean	m_COORD_REPLACE_OES; // GL_TRUE,[GL_FALSE]
	//bool	m_COORD_REPLACE_OES; // GL_TRUE,[GL_FALSE]
	GLboolean	m_IsEnable;
};

struct __BUFFER__
{
	GLsizeiptr			m_Size;
	GLenum				m_Usage;
	//GLenum			m_Access;		// must be GL_WRITE_ONLY
	//unsigned int*		m_pData;
	//GLboolean			m_IsUpdated;
	unsigned __int64	m_UsedPoint;	// HW�� buffer�� ���������� �˻��ϱ� ���ؼ�.
	GLESOAL_MEMORY1D	m_DataMemory1D;

	__BUFFER__(void) : 
		m_Size(0),
		m_Usage(0),
		//m_Access(0),
		//m_pData(0), 
		m_UsedPoint(0)
		//m_DataMemory1D(NULL)
	{
		m_DataMemory1D.MemoryHandle = 0;
		m_DataMemory1D.VirtualAddress = 0;
		m_DataMemory1D.PhysicalAddress = 0;
	}

	~__BUFFER__(void)
	{
		if( m_DataMemory1D.MemoryHandle )
			GLESOAL_Free1D( &m_DataMemory1D );

		m_DataMemory1D.MemoryHandle = 0;
		m_DataMemory1D.VirtualAddress = 0;
		m_DataMemory1D.PhysicalAddress = 0;
	}
};

struct __PRIMITIVEPARAMETER__
{
	__BUFFER__*		m_pPosition;
	__BUFFER__*		m_pColor;
	__BUFFER__*		m_pNormal;
	__BUFFER__*		m_pPointSize;
	__BUFFER__*		m_pWeight;
	__BUFFER__*		m_pTexCoord[GLPARAM_MAX_TEXTURE_UNITS];
	__BUFFER__*		m_pMatrixIndex;
	__BUFFER__*		m_pMatrixPalette;
	__BUFFER__*		m_pIndex;

	__PRIMITIVEPARAMETER__( void ) :
		m_pPosition(NULL),
		m_pColor(NULL),
		m_pNormal(NULL),
		m_pPointSize(NULL),
		m_pWeight(NULL),
		m_pMatrixIndex(NULL),
		m_pMatrixPalette(NULL),
		m_pIndex(NULL)
	{
		for( int i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
			m_pTexCoord[i] = NULL;
	}
};

/*
struct __HWBUFFER__
{
	GLsizeiptr			m_Size;
	GLenum				m_Format;
	GLenum				m_Stride;
	GLESOAL_MEMORY1D	m_DataMemory1D;
	__HWBUFFER__(void) : 
		m_Size(0),
		m_Format(GL_HWBUFFER_FV_OES),
		m_Stride(16)
	{
		m_DataMemory1D.MemoryHandle = 0;
		m_DataMemory1D.VirtualAddress = 0;
		m_DataMemory1D.PhysicalAddress = 0;
	}
};
*/

struct __TEXTURE__
{
	GLenum		m_TEXTURE_MIN_FILTER; // GL_NEAREST,GL_LINEAR,GL_NEAREST_MIPMAP_NEAREST ,GL_LINEAR_MIPMAP_NEAREST ,[GL_NEAREST_MIPMAP_LINEAR] ,GL_LINEAR_MIPMAP_LINEAR 
	GLenum		m_TEXTURE_MAG_FILTER; // GL_NEAREST,[GL_LINEAR]
	GLenum		m_TEXTURE_WRAP_S; // GL_CLAMP, GL_CLAMP_TO_EDGE, [GL_REPEAT]
	GLenum		m_TEXTURE_WRAP_T; // GL_CLAMP, GL_CLAMP_TO_EDGE, [GL_REPEAT]
	GLboolean	m_GENERATE_MIPMAP; // GL_TRUE,[GL_FALSE]
	GLboolean	m_TILE_INDEX_ENABLE;
	GLint		m_TEXTURE_CROP_RECT_U;		// for glDrawTex()
	GLint		m_TEXTURE_CROP_RECT_V;
	GLint		m_TEXTURE_CROP_RECT_WIDTH;
	GLint		m_TEXTURE_CROP_RECT_HEIGHT;
	GLenum		m_Target;
    GLint		m_Level;
    GLsizei		m_Width;
    GLsizei		m_Height;
    GLint		m_Border;
    GLenum		m_Format;
    GLenum		m_Type;

    GLsizei		m_WidthPowerOf2;
    GLsizei		m_HeightPowerOf2;
    GLint		m_ScaleX;
    GLint		m_ScaleY;

	GLboolean	m_IsCompessed;
    GLint		m_PaletteSize;
    GLint		m_Bpp;

	unsigned __int64	m_UsedPoint;	// HW�� buffer�� ���������� �˻��ϱ� ���ؼ�.
	GLboolean	m_IsUpdated;			// Cache clear�� ���ؼ�.
	
	GLESOAL_MEMORY2D	m_PaletteMemory2D;
	GLESOAL_MEMORY2D	m_TextureDataMemory2D;

	__TEXTURE__(void) : 
		m_TEXTURE_MIN_FILTER(GL_NEAREST_MIPMAP_LINEAR),
		m_TEXTURE_MAG_FILTER(GL_LINEAR),
		m_TEXTURE_WRAP_S(GL_REPEAT),
		m_TEXTURE_WRAP_T(GL_REPEAT),
		m_GENERATE_MIPMAP(GL_FALSE),
		m_TILE_INDEX_ENABLE(GL_FALSE),
		m_TEXTURE_CROP_RECT_U(0),		
		m_TEXTURE_CROP_RECT_V(0),
		m_TEXTURE_CROP_RECT_WIDTH(0),
		m_TEXTURE_CROP_RECT_HEIGHT(0),
		m_Target(GL_TEXTURE_2D),	// must GL_TEXTURE_2D
		m_Level(0),
		m_Width(0),
		m_Height(0),
		m_Border(0),				// must 0
		m_Format(GL_RGB),			// �ʱⰪ��..???		
		m_Type(GL_UNSIGNED_SHORT_5_6_5),	// �ʱⰪ��..???
		m_IsCompessed(GL_FALSE),
		m_PaletteSize(0),
		m_Bpp(0),
		m_UsedPoint(0),
		m_IsUpdated(GL_FALSE)
	{
		m_TextureDataMemory2D.MemoryHandle		= 0;
		m_TextureDataMemory2D.PhysicalSegment	= 0;
		m_TextureDataMemory2D.PhysicalSegX		= 0;
		m_TextureDataMemory2D.PhysicalSegY		= 0;
		m_TextureDataMemory2D.VirtualSegment	= 0;
		m_TextureDataMemory2D.VirtualSegX		= 0;
		m_TextureDataMemory2D.VirtualSegY		= 0;

		m_PaletteMemory2D.MemoryHandle		= 0;
		m_PaletteMemory2D.PhysicalSegment	= 0;
		m_PaletteMemory2D.PhysicalSegX		= 0;
		m_PaletteMemory2D.PhysicalSegY		= 0;
		m_PaletteMemory2D.VirtualSegment	= 0;
		m_PaletteMemory2D.VirtualSegX		= 0;
		m_PaletteMemory2D.VirtualSegY		= 0;

		m_WidthPowerOf2  = 0;
		m_HeightPowerOf2 = 0;
		
		m_ScaleX = 1;
		m_ScaleY = 1;
	}

	~__TEXTURE__(void)
	{
		if ( m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &m_TextureDataMemory2D );
		if ( m_PaletteMemory2D.MemoryHandle )
			GLESOAL_Free2D( &m_PaletteMemory2D );	
	}
};

struct __POINTER__
{
	GLint			m_Size;
	GLenum			m_Type;
	GLsizei			m_Stride;
	const GLvoid*	m_Pointer;
	GLuint			m_Buffer;

	__POINTER__( void ) :
		m_Size(0),
		m_Type(GL_FLOAT),
		m_Stride(0),
		m_Pointer(NULL),
		m_Buffer(0)
	{
	}
};


struct __HWBUFFER__
{
	GLsizeiptr			m_Size;
	GLenum				m_Format;
	GLenum				m_Stride;
	GLuint				m_Buffer;
	//GLESOAL_MEMORY1D	m_DataMemory1D;
	__HWBUFFER__(void) : 
		m_Size(0),
		m_Format(GL_HWBUFFER_FV_OES),
		m_Stride(16),
		m_Buffer(0)
	{
		//m_DataMemory1D.MemoryHandle = 0;
		//m_DataMemory1D.VirtualAddress = 0;
		//m_DataMemory1D.PhysicalAddress = 0;
	}
};

struct __CURRENT_BO_STATE__	//HW buffer object ����� ���� ���� buffer object ���� ����.
{
	GLboolean	m_IsVertexPointerEnable;
	GLboolean	m_IsColorPointerEnable;
	GLboolean	m_IsTexCoordPointerEnable[GLPARAM_MAX_TEXTURE_UNITS];
	GLboolean	m_IsNormalPointerEnable;
	GLboolean	m_IsPointSizePointerEnable;
	
	GLint		m_ClientActiveTexture;
	
	GLint		m_VertexArrayBuffer;
	GLint		m_VertexArraySize;
	GLint		m_VertexArrayStride;
	GLint		m_VertexArrayType;
	const GLvoid*		m_pVertexArrayPointer;
	
	GLint		m_ColorArrayBuffer;
	GLint		m_ColorArraySize;
	GLint		m_ColorArrayStride;
	GLint		m_ColorArrayType;
	const GLvoid*		m_pColorArrayPointer;
	
	GLint		m_NormalArrayBuffer;
	GLint		m_NormalArrayStride;
	GLint		m_NormalArrayType;
	const GLvoid*		m_pNormalArrayPointer;
	
	GLint		m_CurrentActiveClientTexture;
	GLint		m_TexCoordArrayBuffer[GLPARAM_MAX_TEXTURE_UNITS];
	GLint		m_TexCoordArraySize[GLPARAM_MAX_TEXTURE_UNITS];
	GLint		m_TexCoordArrayStride[GLPARAM_MAX_TEXTURE_UNITS];
	GLint		m_TexCoordArrayType	[GLPARAM_MAX_TEXTURE_UNITS];
	const GLvoid*		m_pTexCoordArrayPointer	[GLPARAM_MAX_TEXTURE_UNITS];	
	
	GLint		m_PointSizeArrayBuffer;
	GLint		m_PointSizeArrayStride;
	GLint		m_PointSizeArrayType;
	const GLvoid*		m_pPointSizeArrayPointer;	
	
	GLint		m_BindArrayBuffer;
	GLint		m_BindElementBuffer;
	GLint		m_BindActiveClientTexture;		
};


#define EGLCONFIG_FLAG  0x12345678
#define EGLSURFACE_FLAG 0x9ABCDEF0

struct __CONFIG__
{
	EGLint  m_EGLCONFIG              ; // It must be EGLCONFIG_FLAG. ��ȿ�� egl cofig���� Ȯ���ϱ� ����

	EGLint  m_BUFFER_SIZE            ; // 0 - �� �����ٴ� ũ�� ���� ���� ����ũ�⸦ ���°��� ���ȵ�
	EGLint  m_ALPHA_SIZE             ; // 0 - 0�̸� ������������ ���ȵ�
	EGLint  m_BLUE_SIZE              ; // 0 - 0�̸� ������������ ���ȵ�
	EGLint  m_GREEN_SIZE             ; // 0 - 0�̸� ������������ ���ȵ�
	EGLint  m_RED_SIZE               ; // 0 - 0�̸� ������������ ���ȵ�
	EGLint  m_CONFIG_CAVEAT          ; // EGL_DONT_CARE
	EGLint  m_CONFIG_ID              ; // EGL_DONT_CARE
	EGLint  m_DEPTH_SIZE             ; // 0 - 0�̸� depth buffer�� ���³��� ���ȵ�
	EGLint  m_LEVEL                  ; // 0 ???
	EGLint  m_MAX_PBUFFER_WIDTH      ; // 
	EGLint  m_MAX_PBUFFER_HEIGHT     ; // 
	EGLint  m_MAX_PBUFFER_PIXELS     ; // 
	EGLint  m_NATIVE_RENDERABLE      ; // EGL_DONT_CARE
	EGLint  m_NATIVE_VISUAL_ID       ; // 
	EGLint  m_NATIVE_VISUAL_TYPE     ; // 
	EGLint  m_SAMPLE_BUFFERS         ; // 0
	EGLint  m_SAMPLES                ; //     
	EGLint  m_STENCIL_SIZE           ; // 0 - 0�̸� stencil buffer�� ���³��� ���ȵ�
	EGLint  m_SURFACE_TYPE           ; // EGL_WINDOW_BIT
	EGLint  m_TRANSPARENT_TYPE       ; // EGL_NONE
	EGLint  m_TRANSPARENT_BLUE_VALUE ; // EGL_DONT_CARE
	EGLint  m_TRANSPARENT_GREEN_VALUE; // EGL_DONT_CARE
	EGLint  m_TRANSPARENT_RED_VALUE  ; // EGL_DONT_CARE
	EGLint  m_MIN_SWAP_INTERVAL      ; // 
	EGLint  m_MAX_SWAP_INTERVAL      ; // 
	EGLint  m_BIND_TO_TEXTURE_RGB    ; // EGL_DONT_CARE
	EGLint  m_BIND_TO_TEXTURE_RGBA   ; // EGL_DONT_CARE	
};

struct __SURFACECONFIG__
{
	EGLint  m_EGLCONFIG              ; // It must be EGLSURFACE_FLAG. ��ȿ�� egl surface���� Ȯ���ϱ� ����

	EGLint m_CONFIG_ID      ;
	EGLint m_WIDTH          ;
	EGLint m_HEIGHT         ;
	EGLint m_LARGEST_PBUFFER;
	EGLint m_TEXTURE_FORMAT ;
	EGLint m_TEXTURE_TARGET ;
	EGLint m_MIPMAP_TEXTURE ;
	EGLint m_MIPMAP_LEVEL   ;
};

struct __GLSTATESET__;


struct __DISPLAY__
{

};

struct __EGLSTATESET__
{
    EGLBoolean		m_isInit;		// egl Display are initialized Flag.
    EGLint			m_Error;		// egl Error Detection and Store.
 	//EGLint			m_NumOfConfigs;

	GLESOAL_MEMORY1D	m_CommandQueue;
	//unsigned __int64	m_CommandQueueFrontPointer;	// Tearing ���Ÿ� ���� member ���� -> HAL�� �־���.

	//EGLConfig		m_Configs;
	//EGLSurface		m_Surfaces;		// Windows Surface 
	//EGLContext		m_Contexts;		// Device Dependent Context.

	EGLDisplay		m_pCurDisplay;					// Current EGL Display ID.
	EGLSurface		m_pCurDrawSurface;				// Current EGL Rendering Surface.
	EGLSurface		m_pCurReadSurface;				// 
	EGLContext		m_pCurContext;
	//GLES_Surface*	m_pSurface;

	NativeWindowType	m_NativeWindow;
};


#define SIZEOFCOMMANDQUEUE	(128*1024)
#define SIZEOF_MATRIXPALETTEBUFFER_FLAG		8

struct __GLSTATESET__
{
	GLES_Surface*  	  m_pSurface;

	// config �� ���ִ� ��� ����.
	GLint  m_BUFFER_SIZE            ;
	GLint  m_DEPTH_SIZE             ;
	GLint  m_ALPHA_SIZE             ; 
	GLint  m_BLUE_SIZE              ; 
	GLint  m_GREEN_SIZE             ; 
	GLint  m_RED_SIZE               ; 

	GLint  m_MAX_PBUFFER_WIDTH      ;
	GLint  m_MAX_PBUFFER_HEIGHT     ;
	GLint  m_MAX_PBUFFER_PIXELS     ;
	GLint  m_STENCIL_SIZE           ;

	GLint  m_SAMPLE_BUFFERS         ; // 0
	GLint  m_SAMPLES                ; //    

	GLint		m_PixelStoreUnpackAlignment; // 4
	GLint		m_PixelStorePackAlignment; // 4

	GLenum		m_ActiveTexture; // GL_TEXTURE0
	GLenum		m_ClientActiveTexture; // GL_TEXTURE0
		
	GLenum 		m_AlphaFunc  ; // GL_ALWAYS
	Vclampf		m_AlphaRef   ; // 0
	
	GLuint		m_BindedBuffer[2];		// GL_ARRAY_BUFFER / GL_ELEMENT_ARRAY_BUFFER
	//GLuint		m_BindedHWBuffer[2];	// GL_ARRAY_BUFFER / GL_ELEMENT_ARRAY_BUFFER
	GLuint		m_BindedTexture[GLPARAM_MAX_TEXTURE_UNITS];
	__TEXENV__	m_TexEnv[GLPARAM_MAX_TEXTURE_UNITS];
	
	GLenum		m_BlendFunc_Src; // GL_ONE
	GLenum		m_BlendFunc_Dst; // GL_ZERO
	
	Vfloat		m_ClearColor[4]; // 0,0,0,0
	Vclampf		m_ClearDepth   ; // 1
	GLint		m_ClearStencil ; // 0

#if GLPARAM_MAX_CLIP_PLANES > 0
	Vec4D		m_ClipPlane[GLPARAM_MAX_CLIP_PLANES]; // all 0
#endif	

	Vfloat		m_CurrentColor[4]; // 0,0,0,0
	
	GLboolean	m_ColorMask[4] ; // all GL_TRUE b,g,r,a
	
	__POINTER__ m_VertexPointer; // 
	__POINTER__ m_NormalPointer; // 
	__POINTER__ m_ColorPointer; // 4,GL_FLOAT,0,?
	__POINTER__ m_TexturePointer[GLPARAM_MAX_TEXTURE_UNITS]; // 
	__POINTER__ m_MatrixIndexPointer; // 
	__POINTER__ m_WeightPointer; // 
	__POINTER__ m_PointSizePointer; // 
	__POINTER__ m_IndexPointer;
	
	GLenum		m_CullFace; // GL_BACK
	GLenum		m_FrontFace; // GL_CCW
	
	GLenum		m_DepthFunc; // GL_LESS
	GLboolean	m_DepthMask; // GL_TRUE
	
	Vclampf		m_DepthRangeNear ; // 0
	Vclampf		m_DepthRangeFar  ; // 1

	GLenum 		m_FogMode   ; // GL_LINEAR, GL_EXP, and GL_EXP2. The default fog mode is GL_EXP. 
	Vfloat		m_FogDensity; // 1
	Vfloat		m_FogStart  ; // 0
	Vfloat		m_FogEnd    ; // 1
	Vfloat		m_FogColor[4]; // 0,0,0,0

	GLenum			m_MatrixMode;
	MatrixStack		m_TextureMatrix[GLPARAM_MAX_TEXTURE_UNITS];
	MatrixStack		m_ProjectionMatrix;
	MatrixStack		m_ModelViewMatrix ;
	//MatrixStack		m_LightMatrix;	// ???

	MatrixStack*	m_pCurrentMatrixMode;
	GLuint			m_CurrentPaletteMatrix; // 
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
	MatrixStack	m_MatrixPalette[GLPARAM_MAX_PALETTE_MATRICES_OES];
#endif
	
	EGLint		m_Error; // GL_NO_ERROR 
		
	GLboolean	m_TwoSidedLightning;         // GL_FALSE
	Vfloat		m_LightModelAmbientColor[4];   // (0.2, 0.2, 0.2, 1.0)
	__LIGHT__	m_Lights[GLPARAM_MAX_LIGHTS];
	
	__MATERIAL__ m_FrontMaterial;
	__MATERIAL__ m_BackMaterial;

	Vfloat		m_LineWidth; // 1
	
	GLenum		m_LogicOp; // GL_COPY
				
	Vfloat		m_DefaultTexCoord[GLPARAM_MAX_TEXTURE_UNITS][4];
	Vec3D		m_DefaultNormal;

	Vfloat		m_POINT_SIZE_MIN;
	Vfloat		m_POINT_SIZE_MAX;
	Vfloat		m_POINT_FADE_THRESHOLD_SIZE;
	Vfloat		m_PointDistanceAttenuation[3];
	GLboolean	m_PointSizeAttenuate;
	Vfloat		m_PointSize;

	Vfloat		m_OffsetFactor;
	Vfloat		m_OffsetUnits;

	Vfloat		m_SampleCoverage;
	GLboolean	m_InvertSampleCoverage;

	GLint		m_Scissor_X;
	GLint		m_Scissor_Y;
	GLsizei 	m_Scissor_Width;
	GLsizei 	m_Scissor_Height;

	GLint		m_Viewport_X;
	GLint		m_Viewport_Y;
	GLsizei 	m_Viewport_Width;
	GLsizei 	m_Viewport_Height;

	GLenum		m_ShadingModel; // GL_FLAT [GL_SMOOTH]

	GLenum		m_StencilFunc;
	GLint		m_StencilReference;
	GLuint		m_StencilComparisonMask;
	GLuint		m_StencilMask;
	GLenum		m_StencilFail;
	GLenum		m_StencilZFail;
	GLenum		m_StencilZPass;

	GLboolean	m_Enable_ALPHA_TEST              ;
	GLboolean	m_Enable_BLEND                   ;
#if GLPARAM_MAX_CLIP_PLANES > 0
	GLboolean	m_Enable_CLIP_PLANE[GLPARAM_MAX_CLIP_PLANES];
#endif
	GLboolean m_Enable_COLOR_LOGIC_OP          ;
	GLboolean m_Enable_COLOR_MATERIAL          ;
	GLboolean m_Enable_CULL_FACE               ;
	GLboolean m_Enable_DEPTH_TEST              ;
	GLboolean m_Enable_DITHER                  ;
	GLboolean m_Enable_FOG                     ;
	GLboolean m_Enable_LIGHTING                ;
	GLboolean m_Enable_LIGHT[GLPARAM_MAX_LIGHTS];
	GLboolean m_Enable_LINE_SMOOTH             ;
	GLboolean m_Enable_MATRIX_PALETTE_OES      ;
	GLboolean m_Enable_MULTISAMPLE             ;
	GLboolean m_Enable_NORMALIZE               ;
	GLboolean m_Enable_POINT_SMOOTH            ;
	GLboolean m_Enable_POINT_SPRITE_OES        ;
	GLboolean m_Enable_POLYGON_OFFSET_FILL     ;
	GLboolean m_Enable_RESCALE_NORMAL          ;
	GLboolean m_Enable_SAMPLE_ALPHA_TO_COVERAGE;
	GLboolean m_Enable_SAMPLE_ALPHA_TO_ONE     ;
	GLboolean m_Enable_SAMPLE_COVERAGE         ;
	GLboolean m_Enable_SCISSOR_TEST            ;
	GLboolean m_Enable_STENCIL_TEST            ;
	//GLboolean m_Enable_TEXTURE_2D              ;

	GLenum		m_FOG_HINT                   ;
	GLenum		m_LINE_SMOOTH_HINT           ;
	GLenum		m_PERSPECTIVE_CORRECTION_HINT;
	GLenum		m_POINT_SMOOTH_HINT          ;
	GLenum		m_GENERATE_MIPMAP_HINT       ;

	GLboolean	m_ClientState_COLOR_ARRAY;
	GLboolean	m_ClientState_NORMAL_ARRAY;
	GLboolean	m_ClientState_TEXTURE_COORD_ARRAY[GLPARAM_MAX_TEXTURE_UNITS];
	GLboolean	m_ClientState_VERTEX_ARRAY;
	GLboolean	m_ClientState_WEIGHT_ARRAY_OES;
	GLboolean	m_ClientState_MATRIX_INDEX_ARRAY_OES;
	GLboolean	m_ClientState_POINT_SIZE_ARRAY_OES;		

	// hardware buffer object ������ �߰�.
	GLboolean	m_ClientState_HARDWAREBUFFER_ARRAY_OES;


	//HWBufferObjectPool<HWBufferObject,GLPARAM_MAX_HWBUFFER_FOR_DRAWPRIMITIVE> m_HWBufferObjectPool; // for standard API
	//HWBufferObjectRenderQueue           m_HWBufferObjectRenderQueue;
	
	__TEXTURE__		m_DefaultTexture;
	GLuint			m_DefaultTextureIndex;		// 0�̰�����...

	GLboolean		m_IsLightTurnON;				// matrix palette�� inverse matrix�� ��ü �� ���ϱ� ���� flag
	GLboolean		m_IsGlobalLightingUpdated;
	//LIGHTMODE		m_CurrentLightMode;

	GLboolean		m_IsPrimitiveCacheClear;
	GLenum			m_DrawMode;

	GLboolean		m_IsTextureUpdated;
	GLboolean		m_IsFogUpdated;


	__PRIMITIVEPARAMETER__	m_CurrentPrimitive;

	__BUFFER__		m_DefaultPositionBuffer;
	__BUFFER__		m_DefaultColorBuffer;
	__BUFFER__		m_DefaultTexCoordBuffer[GLPARAM_MAX_TEXTURE_UNITS];
	__BUFFER__		m_DefaultNormalBuffer;
	__BUFFER__		m_DefaultPointSizeBuffer;
	__BUFFER__		m_DefaultWeightBuffer;
	__BUFFER__		m_DefaultMatrixIndexBuffer;
	__BUFFER__		m_DefaultMatrixPalette[GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES];
	__BUFFER__		m_DefaultIndexBuffer;

	GLint			m_CurMatrixPaletteBufferIndex;	// ���� matrix palette buffer�� index.
	// 64���� bit�� 2�� �ʿ��ϹǷ�... flag[buffer num][palette/8]
	unsigned char	m_MatrixPaletteUpdateFlag[GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES][SIZEOF_MATRIXPALETTEBUFFER_FLAG];


	GLuint			m_BindedHWBuffer[2];	// for HW Buffer object

};




extern __GLSTATESET__ __GLSTATE__;
extern ObjectPool<__BUFFER__ ,128,2> __BUFFER_POOL__;
//extern ObjectPool<__HWBUFFER__, 128,2> __HWBUFFER_POOL__;
extern ObjectPool<__TEXTURE__,128,2> __TEXTURE_POOL__;
extern ObjectPool<__HWBUFFER__ ,128,2> __HWBUFFER_POOL__;

//extern __GLSTATESET__* __pCurContext;

extern __EGLSTATESET__ __EGLSTATE__;
extern int             __NumberOfContext__;
extern int            __eglSwapInterval__;
extern const __CONFIG__     __EGL_Configuration__[];
extern const int            __EGL_Number_Of_Configurations__;
extern unsigned int			__EGL_SURFACE__;


void __Reset_GLSTATESET__( __GLSTATESET__* pGLSTATE );
void Initialize_GLState( void );

EGLBoolean InitializeOAL( int FSAA );
void FinalizeOAL( void );

//------------------------------------------------------------------------------
//
//	utils
//
//------------------------------------------------------------------------------
//	glGerError ���� ��ȯ�� ���� ����Ѵ�
const char* GLERROR_TO_STRING ( int error_code );
const char* EGLERROR_TO_STRING( int error_code );
#define GLCLRERROR					{ __GLSTATE__.m_Error = GL_NO_ERROR; }
#define GLSETERROR( ErrorCode )		{ __GLSTATE__.m_Error = ErrorCode; MES_TRACE(("*E:[GL_ERROR(%s)] %s(%d)\n", GLERROR_TO_STRING(ErrorCode), __FILE__, __LINE__ )); }
#define EGLCLRERROR					{ __EGLSTATE__.m_Error  = EGL_SUCCESS; }
#define EGLSETERROR( ErrorCode )	{ __EGLSTATE__.m_Error = ErrorCode; MES_TRACE(("*E:[EGL_ERROR(%s)] %s(%d)\n", EGLERROR_TO_STRING(ErrorCode), __FILE__, __LINE__ )); }

//	�־��� float���� [0,1]���̷� clamp�Ѵ�.
#define CLAMPF( valuef )	( ((valuef)<0) ? 0 : ((valuef)>1) ? 1 : (valuef) ) 
//	�־��� fixed���� [0,1]���̷� clamp�Ѵ�.
#define CLAMPX( valuex )	( ((valuex)<0) ? 0 : ((valuex)>GLFIXED_ONE) ? GLFIXED_ONE : (valuex) ) 

//	�־��� Vfloat���� [0,1]���̷� clamp�Ѵ�.
#define CLAMPVF( value )	( ((value)<0) ? 0 : ((value)>VFONE) ? VFONE : (value) ) 

// Default Texture�� ���� �߰��� API
GLboolean 	MakeDefaultTexture( __GLSTATESET__* pGLSTATE );
GLvoid	 	DeleteDefaultTexture( __GLSTATESET__* pGLSTATE );

// Texture ���� �Լ���.
GLvoid 		TextureInitialize( __TEXTURE__* ptexture );
GLboolean 	IsValidTextureSize( GLsizei value );
GLboolean	IsValidMipmapTextureSize( GLint Level, GLint OrgWidth, GLint OrgHeight, GLint MipmapWidth, GLint MipmapHeight );
GLboolean 	IsValidTextureFormat( GLenum internalFormat,
						  GLenum externalFormat, 
						  GLenum type );
GLboolean		GetValidMinTextureSizeWithScale( GLint bpp, GLint width, GLint height, GLint& scaleX, GLint& scaleY );
//GLboolean		MakeValidMinTexture( void* pDst, const GLvoid* pSrc, __TEXTURE__* ptexture );
GLboolean		MakeValidMinTexture( void* pDst, const GLvoid* pSrc, GLint bpp, GLint width, GLint height, GLint scaleX, GLint scaleY );

// Texture size setting�� texture matrix update flag ������ ���� ������ API�� ��.
// Texture size setting �� �� �׻� �� �Լ��� ��� ��.
void SetTextureSize( __TEXTURE__ *pTexture, GLsizei width, GLsizei height );
GLESHAL_COLORFORMAT GetHALTexColorFormat( unsigned int format, unsigned int type );
GLESHAL_COLORFORMAT GetHALCompressedTexColorFormat( unsigned int type );


// HAL�� TexEnv mode ����. glTexEnv���� ȣ��.
//void SetTexEnvMode( void );


} // namespace __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;


#endif // _GLSTATE_H
