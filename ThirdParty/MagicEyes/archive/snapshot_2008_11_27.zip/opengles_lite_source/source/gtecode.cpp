//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gtecode.cpp
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2008/03/20 Yuni GL_SPOT_EXPONENT, GL_SHINENESS ����
//	   2008/03/12 Yuni GL_NORMALIZE ����
//	   2007/10/18 Yuni Light 8�� ����.
//	   2007/09/06 Gamza __GLSTATE__.m_IsGlobalLightingUpdated = GL_FALSE; ��ġ �ٽ� ����.
//	   2007/09/06 Gamza __GLSTATE__.m_IsGlobalLightingUpdated = GL_FALSE; ��ġ����.
//	   2007/09/01 Gamza glPolygonOffset::factor ������� ����.
//	   2006/12/15 Yuni	GTE code list update �� lighting mode�� 
//						vertex format�� ���� �˸��� GTE loading �ϵ��� ����.
//	   2006/10/17 Gamza first implementation
//------------------------------------------------------------------------------
#include "gtecode.h"
#include "loadgtecode.h"
#include "../../libgles_cm_lite_oal/libgles_cm_lite_oal.h"
#include <math.h>

//	internal functions
//------------------------------------------------------------------------------

#define SETGTECODE(code_name, offset)	\
				GLESHAL_SetGTECode( (code_name), (offset), (sizeof(code_name)/sizeof(unsigned int)) )
#define GETGTECODESIZE(code_name)	(sizeof(code_name)/sizeof(unsigned int))

namespace {

#define Max(a,b) ( ((a)>(b)) ? (a) : (b) )
#define Min(a,b) ( ((a)<(b)) ? (a) : (b) )

	// light ������ ���� GTE code selection�� ���� light mode
	enum LIGHTMODE
	{
		LIGHTMODE_NONE		= 0,
		LIGHTMODE_DIR		= 1,
		LIGHTMODE_DIR_CM	= 2,
		LIGHTMODE_PT		= 3,
		LIGHTMODE_PT_CM		= 4,
		LIGHTMODE_SPOT		= 5,
		LIGHTMODE_SPOT_CM	= 6,
		LIGHTMODE_FORCEU32	= 0x7FFFFFFF
	};

	struct GTECODE
	{
		const unsigned int* m_pCode;
		unsigned int        m_CodeSize;
	};

	
	GTECODE g_GTECodeSetPage[] = { 
		GTECODEBODY(GTECode_setpage_light0),			
		GTECODEBODY(GTECode_setpage_light1),
		GTECODEBODY(GTECode_setpage_light2),			
		GTECODEBODY(GTECode_setpage_light3),
		GTECODEBODY(GTECode_setpage_light4),			
		GTECODEBODY(GTECode_setpage_light5),
		GTECODEBODY(GTECode_setpage_light6),			
		GTECODEBODY(GTECode_setpage_light7)		
	};
	

/*
	GTECODE g_GTECodeLight[] = { 
		GTECODEBODY(GTECode_color_none),		
		GTECODEBODY(GTECode_color_dir),			
		GTECODEBODY(GTECode_color_dir_cm),
		GTECODEBODY(GTECode_color_pt),			
		GTECODEBODY(GTECode_color_pt_cm),		
		GTECODEBODY(GTECode_color_spot),		
		GTECODEBODY(GTECode_color_spot_cm)
	};
*/
	unsigned int SetExponentGTECode( __LIGHT__ *pLight, unsigned int offset )
	{
		unsigned int curSize = 0;
		unsigned int exponent = (unsigned int)( VF2F(pLight->m_SpotExponent) + 0.5f );
		unsigned int expGTECode[16];

		if( exponent != 0 )
		{	
			for( int i=0; i<8; i++ )
			{
				if( exponent & 1 )
				{
					expGTECode[ curSize ]		= 0x91ce6078;		// mul		reg[7],	reg[7],	reg[6]
					expGTECode[ curSize + 1 ]	= 0x918c607a;		// mul		reg[6],	reg[6],	reg[6]
					curSize += 2;
				}
				else
				{
					expGTECode[ curSize ]		= 0x918c607a;
					curSize ++;
				}
				exponent >>= 1;
			}
			//expGTECode[ curSize ] = 0x;				// mov0		reg[7], reg[6], dly(1)
			GLESHAL_SetGTECode( expGTECode, offset, curSize );
		}
		return curSize;
	}

	unsigned int SetShinenessGTECode( unsigned int offset )
	{
		__MATERIAL__ * material = &__GLSTATE__.m_FrontMaterial;

		unsigned int curSize = 0;
		unsigned int shineness = (unsigned int)( VF2F(material->m_SpecularExponent ) + 0.5f );
		unsigned int expGTECode[16];

		if( shineness != 0 )
		{	
			for( int i=0; i<8; i++ )
			{
				if( shineness & 1 )
				{
					expGTECode[ curSize ]		= 0x90426078;	// mul		reg[1],	reg[1],	reg[6]
					expGTECode[ curSize + 1 ]	= 0x918c607a;	// mul		reg[6],	reg[6],	reg[6], dly(2)
					curSize += 2;
				}
				else
				{
					expGTECode[ curSize ]		= 0x918c607a;
					curSize ++;
				}
				shineness >>= 1;
			}
			GLESHAL_SetGTECode( expGTECode, offset, curSize );
		}
		return curSize;
	}

	void GetOffsetMatrix( Matrix4x4* pResult )
	{
		//	(OpenGLES_lite_�����缭.doc) �� Projection matrix �κ� ����.
		//Vfloat PO_factor = __GLSTATE__.m_Enable_POLYGON_OFFSET_FILL ? (__GLSTATE__.m_OffsetFactor ) : VFONE;
		Vfloat PO_factor = __GLSTATE__.m_Enable_POLYGON_OFFSET_FILL ? (__GLSTATE__.m_OffsetFactor ) : 0;
		Vfloat PO_units  = __GLSTATE__.m_Enable_POLYGON_OFFSET_FILL ? (__GLSTATE__.m_OffsetUnits  ) : 0;	
		Vfloat DR_znear  = __GLSTATE__.m_DepthRangeNear;
		Vfloat DR_zfar   = __GLSTATE__.m_DepthRangeFar;
		//Vfloat PO_factor_2 = VFMUL( PO_factor , F2VF(0.5f) );
		//Vfloat A = VFMUL( PO_factor_2 , (DR_zfar - DR_znear) );
		//Vfloat B = VFMUL( PO_units, F2VF(0.00001526f) ) + VFMUL( PO_factor_2 , (DR_zfar + DR_znear) );
		Vfloat A = VFMUL( F2VF(0.5f) , (DR_zfar - DR_znear) );
		Vfloat B = VFMUL( PO_factor + PO_units, F2VF(0.00001526f) ) + VFMUL( F2VF(0.5f) , (DR_zfar + DR_znear) );
		pResult->m[0][0] = F2VF(0.5f);
		pResult->m[0][1] = F2VF(0.0f);
		pResult->m[0][2] = F2VF(0.0f);
		pResult->m[0][3] = F2VF(0.5f);
		pResult->m[1][0] = F2VF(0.0f);
		pResult->m[1][1] = F2VF(0.5f);
		pResult->m[1][2] = F2VF(0.0f);
		pResult->m[1][3] = F2VF(0.5f);
		pResult->m[2][0] = F2VF(0.0f);
		pResult->m[2][1] = F2VF(0.0f);
		pResult->m[2][2] = A;
		pResult->m[2][3] = B;
		pResult->m[3][0] = F2VF(0.0f);
		pResult->m[3][1] = F2VF(0.0f);
		pResult->m[3][2] = F2VF(0.0f);
		pResult->m[3][3] = F2VF(1.0f);
	}

	// Gamza
	LIGHTMODE GetLightMode( int Index, GLenum DrawingMode )
	{
		LIGHTMODE lightMode = LIGHTMODE_NONE;
		if( ! __GLSTATE__.m_Enable_LIGHTING )
		{
			lightMode = LIGHTMODE_NONE;
		}
		else if( __GLSTATE__.m_Enable_LIGHT[Index] )
		{
			__LIGHT__ *pcurLight = &__GLSTATE__.m_Lights[Index];

			if( !pcurLight->m_Position.w )	// directional light
			{
				// GTEConst setting
				if( __GLSTATE__.m_Enable_COLOR_MATERIAL )
				{
					lightMode = LIGHTMODE_DIR_CM;
				}
				else
				{
					lightMode = LIGHTMODE_DIR;
				}
			}
			else
			{

				if( __GLSTATE__.m_Enable_COLOR_MATERIAL )
				{
					if( 180.0f == VF2F( pcurLight->m_SpotCutoff ) )	// point
					{
						lightMode = LIGHTMODE_PT_CM;
					}
					else	// spot
					{
						lightMode = LIGHTMODE_SPOT_CM;
					}
				}
				else
				{
					if( 180.0f == VF2F( pcurLight->m_SpotCutoff ) )	// point
					{
						lightMode = LIGHTMODE_PT;
					}
					else	// spot
					{
						lightMode = LIGHTMODE_SPOT;
					}
				}
			}
		}
		return lightMode;
	}

	void SetLightConstToGTEConst( int Index, LIGHTMODE lightMode )
	{
		__LIGHT__ *pcurLight = &__GLSTATE__.m_Lights[Index];
		//float pgteconst[6*4] = { 0.0f, 0.0f, 1.0f, 0.0f, };	// ( 0, 0, 1 )

		if( (LIGHTMODE_DIR == lightMode) || (LIGHTMODE_DIR_CM == lightMode) )	// directional light
		{
			float pgteconst[5*4];
			// LDIR
			Vec3D LDIR;
			LDIR.x = pcurLight->m_Position.x;
			LDIR.y = pcurLight->m_Position.y;
			LDIR.z = pcurLight->m_Position.z;
			V3_NORMALIZE( LDIR );

			//Vec3D transLDIR;
			//const Matrix4x4& inv_modelview = __GLSTATE__.m_ModelViewMatrix.CurrentInverseMatrix();
			//M4_MUL_V3_ROT(transLDIR, inv_modelview, LDIR )

			// spot
			float spot;
			if( 180.0f == VF2F( pcurLight->m_SpotCutoff ) )
				spot = 1.0f;
			else
			{
				// Lsdir normalize
				Vec3D nLsdir;
				nLsdir.x = pcurLight->m_Direction.x;
				nLsdir.y = pcurLight->m_Direction.y;
				nLsdir.z = pcurLight->m_Direction.z;
				V3_NORMALIZE( nLsdir );

				Vfloat Lscutoff = VFCOS( pcurLight->m_SpotCutoff );
				
				if( V3_DOT( LDIR, nLsdir ) < Lscutoff )
					spot = 0.0f;
				else
				{
					//spot = 1.0f;
					
					Vec3D tVec3D;
					V3_MULT(tVec3D, LDIR, I2VF(-1));
					Vfloat t = V3_DOT( tVec3D, nLsdir );
					spot = VF2F( Max( 0.0f, t ) );
					spot = (float)(pow( (double)spot, (double)(VF2F( pcurLight->m_SpotExponent ))));
					
				}
			}

			// H
			Vec3D H;
			H.x = LDIR.x;
			H.y = LDIR.y;
			H.z = LDIR.z + VFONE;
			//H.z = LDIR.z;
			V3_NORMALIZE(H);

			//Vec3D transH;
			//M4_MUL_V3_ROT(transH, inv_modelview, H );

			// GTEConst setting
			if( LIGHTMODE_DIR_CM == lightMode )
			{
				// Ambient + spot x La
				pgteconst[4*0+0] = spot * VF2F( pcurLight->m_AmbientColor[0]);
				pgteconst[4*0+1] = spot * VF2F( pcurLight->m_AmbientColor[1]);
				pgteconst[4*0+2] = spot * VF2F( pcurLight->m_AmbientColor[2]);
				pgteconst[4*0+3] = spot * VF2F( pcurLight->m_AmbientColor[3]);

				// spot x Ld
				pgteconst[4*1+0] = spot*VF2F( pcurLight->m_DiffuseColor[0] );
				pgteconst[4*1+1] = spot*VF2F( pcurLight->m_DiffuseColor[1] );
				pgteconst[4*1+2] = spot*VF2F( pcurLight->m_DiffuseColor[2] );
				pgteconst[4*1+3] = spot*VF2F( pcurLight->m_DiffuseColor[3] );				
			}
			else	// LIGHTMODE_DIR
			{		
				// spot x La x Ma
				pgteconst[4*0+0] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[0], pcurLight->m_AmbientColor[0]) );
				pgteconst[4*0+1] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[1], pcurLight->m_AmbientColor[1]) );
				pgteconst[4*0+2] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[2], pcurLight->m_AmbientColor[2]) );
				pgteconst[4*0+3] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[3], pcurLight->m_AmbientColor[3]) );

				// spot x Ld x Md
				pgteconst[4*1+0] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[0], pcurLight->m_DiffuseColor[0]) );
				pgteconst[4*1+1] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[1], pcurLight->m_DiffuseColor[1]) );
				pgteconst[4*1+2] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[2], pcurLight->m_DiffuseColor[2]) );
				pgteconst[4*1+3] = spot * VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[3], pcurLight->m_DiffuseColor[3]) );
				
			}

			// spot x Ls x Ms
			pgteconst[4*2+0] = spot *   
				VF2F( VFMUL( pcurLight->m_SpecularColor[0], __GLSTATE__.m_FrontMaterial.m_SpecularColor[0] ) );
			pgteconst[4*2+1] = spot *  
				VF2F( VFMUL( pcurLight->m_SpecularColor[1], __GLSTATE__.m_FrontMaterial.m_SpecularColor[1] ) );
			pgteconst[4*2+2] = spot *   
				VF2F( VFMUL( pcurLight->m_SpecularColor[2], __GLSTATE__.m_FrontMaterial.m_SpecularColor[2] ) );
			pgteconst[4*2+3] = spot *   
				VF2F( VFMUL( pcurLight->m_SpecularColor[3], __GLSTATE__.m_FrontMaterial.m_SpecularColor[3] ) );

			// LDIR
			pgteconst[4*3+0] = VF2F( LDIR.x );//VF2F( transLDIR.x );
			pgteconst[4*3+1] = VF2F( LDIR.y );//VF2F( transLDIR.y );
			pgteconst[4*3+2] = VF2F( LDIR.z );//VF2F( transLDIR.z );
			pgteconst[4*3+3] = 0.0f;

			// H
			pgteconst[4*4+0] = VF2F( H.x );//VF2F( transH.x );
			pgteconst[4*4+1] = VF2F( H.y );//VF2F( transH.y );
			pgteconst[4*4+2] = VF2F( H.z );//VF2F( transH.z );
			pgteconst[4*4+3] = 0.0f;

			GLESHAL_SetGTEConst( __Ligth_dest + Index*16*4, sizeof(pgteconst)/sizeof(pgteconst[0]), pgteconst );
		}
		else
		{
			float pgteconst[8*4];

			if( (LIGHTMODE_PT == lightMode) || (LIGHTMODE_SPOT == lightMode) )
			{
				// La x Ma
				pgteconst[4*0+0] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[0], pcurLight->m_AmbientColor[0]) );
				pgteconst[4*0+1] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[1], pcurLight->m_AmbientColor[1]) );
				pgteconst[4*0+2] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[2], pcurLight->m_AmbientColor[2]) );
				pgteconst[4*0+3] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_AmbientColor[3], pcurLight->m_AmbientColor[3]) );

				// Ld x Md
				pgteconst[4*1+0] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[0], pcurLight->m_DiffuseColor[0]) );
				pgteconst[4*1+1] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[1], pcurLight->m_DiffuseColor[1]) );
				pgteconst[4*1+2] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[2], pcurLight->m_DiffuseColor[2]) );
				pgteconst[4*1+3] = VF2F( VFMUL(__GLSTATE__.m_FrontMaterial.m_DiffuseColor[3], pcurLight->m_DiffuseColor[3]) );

			}
			else	// LIGHTMODE_PT_CM, LIGHTMODE_SPOT_CM
			{
				// La
				pgteconst[4*0+0] = VF2F( pcurLight->m_AmbientColor[0]);
				pgteconst[4*0+1] = VF2F( pcurLight->m_AmbientColor[1]);
				pgteconst[4*0+2] = VF2F( pcurLight->m_AmbientColor[2]);
				pgteconst[4*0+3] = VF2F( pcurLight->m_AmbientColor[3]);

				// Ld
				pgteconst[4*1+0] = VF2F( pcurLight->m_DiffuseColor[0] );
				pgteconst[4*1+1] = VF2F( pcurLight->m_DiffuseColor[1] );
				pgteconst[4*1+2] = VF2F( pcurLight->m_DiffuseColor[2] );
				pgteconst[4*1+3] = VF2F( pcurLight->m_DiffuseColor[3] );
			}

			// Ls x Ms
			pgteconst[4*2+0] = VF2F( VFMUL( pcurLight->m_SpecularColor[0], __GLSTATE__.m_FrontMaterial.m_SpecularColor[0] ) );
			pgteconst[4*2+1] = VF2F( VFMUL( pcurLight->m_SpecularColor[1], __GLSTATE__.m_FrontMaterial.m_SpecularColor[1] ) );
			pgteconst[4*2+2] = VF2F( VFMUL( pcurLight->m_SpecularColor[2], __GLSTATE__.m_FrontMaterial.m_SpecularColor[2] ) );
			pgteconst[4*2+3] = VF2F( VFMUL( pcurLight->m_SpecularColor[3], __GLSTATE__.m_FrontMaterial.m_SpecularColor[3] ) );

			pgteconst[4*3+0] = 0.0f;
			pgteconst[4*3+1] = 0.0f;
			pgteconst[4*3+2] = 1.0f;
			pgteconst[4*3+3] = 0.0f;

			pgteconst[4*4+0] = VF2F( pcurLight->m_Position.x );
			pgteconst[4*4+1] = VF2F( pcurLight->m_Position.y );
			pgteconst[4*4+2] = VF2F( pcurLight->m_Position.z );
			pgteconst[4*4+3] = VF2F( pcurLight->m_Position.w );

			pgteconst[4*5+0] = VF2F( pcurLight->m_ConstantAttenuation );
			pgteconst[4*5+1] = VF2F( pcurLight->m_LinearAttenuation );
			pgteconst[4*5+2] = VF2F( pcurLight->m_QuadraticAttenuation );
			pgteconst[4*5+3] = 0.0f;

			if( (LIGHTMODE_SPOT == lightMode) || (LIGHTMODE_SPOT_CM == lightMode) )
			{	
				Vec3D nLsdir;
				nLsdir.x = pcurLight->m_Direction.x;
				nLsdir.y = pcurLight->m_Direction.y;
				nLsdir.z = pcurLight->m_Direction.z;
				V3_NORMALIZE( nLsdir );

				pgteconst[4*6+0] = VF2F( nLsdir.x );
				pgteconst[4*6+1] = VF2F( nLsdir.y );
				pgteconst[4*6+2] = VF2F( nLsdir.z );
				pgteconst[4*6+3] = 0.0f;

				float angle = VF2F( pcurLight->m_SpotCutoff ) * ( static_cast<float>(M_PI) / 180.0f );
				pgteconst[4*7+0] = ((float)cos(angle));//((float)cos(angle))*((float)cos(angle));  // Lscutoff^2
				pgteconst[4*7+1] = 	pgteconst[4*7+2] = pgteconst[4*7+3] = pgteconst[4*7+0];
			}
			else
			{
				pgteconst[4*6+0] = pgteconst[4*6+1] = pgteconst[4*6+2] = pgteconst[4*6+3] = 0.0f;
				pgteconst[4*7+0] = pgteconst[4*7+1] = pgteconst[4*7+2] = pgteconst[4*7+3] = 0.0f;
			}
			GLESHAL_SetGTEConst( __Ligth_dest + Index*16*4, sizeof(pgteconst)/sizeof(pgteconst[0]), pgteconst );
		}

		pcurLight->m_IsUpdated = GL_FALSE;
	}

	unsigned int SetLightGTE( int Index, unsigned int Offset, GLenum DrawingMode )
	{
		LIGHTMODE lightMode = GetLightMode( Index, DrawingMode );
		unsigned int codeSize = 0;

		if( (LIGHTMODE_NONE != lightMode) && 
			((__GLSTATE__.m_Lights[Index].m_IsUpdated) || (__GLSTATE__.m_IsGlobalLightingUpdated)) ) 
		{
			SetLightConstToGTEConst( Index, lightMode );
		}

		switch( lightMode )
		{
		case LIGHTMODE_NONE		:
			{
				SETGTECODE( g_GTECode_color_none, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_none );
			}
			break;
		case LIGHTMODE_DIR		:
			{
				SETGTECODE( g_GTECode_color_dir_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_dir_0 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_dir_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_dir_1 );
			}
			break;
		case LIGHTMODE_DIR_CM	:
			{
				SETGTECODE( g_GTECode_color_dir_cm_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_dir_cm_0 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_dir_cm_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_dir_cm_1 );
			}

			break;
		case LIGHTMODE_PT		:
			{
				SETGTECODE( g_GTECode_color_pt_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_pt_0 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_pt_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_pt_1 );
			}
			break;
		case LIGHTMODE_PT_CM	:
			{
				SETGTECODE( g_GTECode_color_pt_cm_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_pt_cm_0 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_pt_cm_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_pt_cm_1 );
			}
			break;
		case LIGHTMODE_SPOT		:
			{
				SETGTECODE( g_GTECode_color_spot_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_0 );


				codeSize += SetExponentGTECode( &(__GLSTATE__.m_Lights[Index]), Offset + codeSize );

				SETGTECODE( g_GTECode_color_spot_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_1 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_spot_2, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_2 );
			}
			break;
		case LIGHTMODE_SPOT_CM	:
			{
				SETGTECODE( g_GTECode_color_spot_0, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_0 );

				codeSize += SetExponentGTECode( &(__GLSTATE__.m_Lights[Index]), Offset + codeSize );

				SETGTECODE( g_GTECode_color_spot_cm_1, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_cm_1 );

				codeSize += SetShinenessGTECode( Offset + codeSize );

				SETGTECODE( g_GTECode_color_spot_cm_2, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_spot_cm_2 );
			}
			break;
		default:
			break;
		}
		return codeSize;
	}

	unsigned int SetPositonNormalGTECode( unsigned int Offset )
	{
		GLboolean	isLighting = GL_FALSE;
		if( __GLSTATE__.m_Enable_LIGHTING ) 
			isLighting = GL_TRUE;

		if( __GLSTATE__.m_ProjectionMatrix.m_IsUpdated )
		{
			const Matrix4x4	mat_prj = __GLSTATE__.m_ProjectionMatrix.CurrentMatrix();
			Matrix4x4	mat_offset;
			Matrix4x4	mat_prj_offset;
			GetOffsetMatrix( &mat_offset );
			M4_MUL_M4( mat_prj_offset, mat_offset, mat_prj );
		
			float mat[16];
			MatrixToFloat( mat, mat_prj_offset );
			GLESHAL_SetGTEConst( __PrjMatrix_dest, 16, mat );
			
			__GLSTATE__.m_ProjectionMatrix.m_IsUpdated = GL_FALSE;
		}

		if( __GLSTATE__.m_Enable_MATRIX_PALETTE_OES )
		{
			if( isLighting )
			{
				SETGTECODE( g_GTECode_pos_norm_pm, Offset );
				unsigned int codeSize = GETGTECODESIZE( g_GTECode_pos_norm_pm );
				
				if( __GLSTATE__.m_Enable_NORMALIZE )
				{
					SETGTECODE( g_GTECode_norm_normalize, Offset + codeSize );
					codeSize += GETGTECODESIZE( g_GTECode_norm_normalize );
				}
				return codeSize;
			}
			else
			{
				SETGTECODE( g_GTECode_pos_pm, Offset );
				return GETGTECODESIZE( g_GTECode_pos_pm );
			}
		}
		else
		{
			if( __GLSTATE__.m_ModelViewMatrix.m_IsUpdated )
			{
				// Lighting�� ���µ��� �ұ��ϰ� inverse matrix�� �����ϴ� ���� ��ȿ�����̱� ������
				// __GLSTATE__.m_ModelViewMatrix.m_IsUpdated �÷��� ���� �����ϴ� �κп� ������ ������ �־�
				// ��¥�� CurrentInverseMatrix()�� �Ź� ���Ǵ� �Լ��� �ƴϹǷ� �׳� �ξ���.
				const Matrix4x4& mat_modelview= __GLSTATE__.m_ModelViewMatrix.CurrentMatrix();
				Matrix4x4 mat_inv_modelview = __GLSTATE__.m_ModelViewMatrix.CurrentInverseMatrix();
				
				if( __GLSTATE__.m_Enable_RESCALE_NORMAL )
				{
					float m31 = VF2F(mat_inv_modelview.m[2][0]);
					float m32 = VF2F(mat_inv_modelview.m[2][1]);
					float m33 = VF2F(mat_inv_modelview.m[2][2]);
					float len = (float)sqrt( m31*m31 + m32*m32 + m33*m33 );
					Vfloat f  = len ? F2VF( 1.0f / len ) : 0 ;
					for( int i=0; i<4; i++ )
					for( int j=0; j<4; j++ )
					{
						mat_inv_modelview.m[i][j] = VFMUL( mat_inv_modelview.m[i][j], f );
					}
				}
				Matrix4x4 invtrans_modelview;
				M4_TRANSPOSE( invtrans_modelview, mat_inv_modelview );
				float mat[32];
				MatrixToFloat( mat, mat_modelview );
				MatrixToFloat( &mat[16], invtrans_modelview );
				GLESHAL_SetGTEConst( __MVMatrix_dest, 32, mat );

				__GLSTATE__.m_ModelViewMatrix.m_IsUpdated = GL_FALSE;
			}	
			if( isLighting )
			{
				SETGTECODE( g_GTECode_pos_norm, Offset );
				unsigned int codeSize = GETGTECODESIZE( g_GTECode_pos_norm );

				if( __GLSTATE__.m_Enable_NORMALIZE )
				{
					SETGTECODE( g_GTECode_norm_normalize, Offset + codeSize );
					codeSize += GETGTECODESIZE( g_GTECode_norm_normalize );
				}
				return codeSize;
			}
			else
			{
				SETGTECODE( g_GTECode_pos, Offset );
				return GETGTECODESIZE( g_GTECode_pos );
			}	
		}
	}

	unsigned int SetColorGTECode( unsigned int Offset, GLenum DrawingMode )
	{
		unsigned int codeSize = 0;
	
		if( __GLSTATE__.m_Enable_LIGHTING )
		{
			// global ambient
			if( __GLSTATE__.m_Enable_COLOR_MATERIAL )
			{
				SETGTECODE( g_GTECode_color_amb_cm, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_amb_cm );
				if( __GLSTATE__.m_IsGlobalLightingUpdated )
				{
					float pgteconst[ 2*4 ];

					pgteconst[0] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[0] );
					pgteconst[1] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[1] );
					pgteconst[2] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[2] );
					pgteconst[3] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[3] );

					// Ambient
					pgteconst[4] = VF2F( __GLSTATE__.m_LightModelAmbientColor[0] );
					pgteconst[5] = VF2F( __GLSTATE__.m_LightModelAmbientColor[1] );
					pgteconst[6] = VF2F( __GLSTATE__.m_LightModelAmbientColor[2] );
					pgteconst[7] = VF2F( __GLSTATE__.m_LightModelAmbientColor[3] );

					GLESHAL_SetGTEConst( __GlobalAmbient_dest, sizeof(pgteconst)/sizeof(pgteconst[0]), pgteconst );						
				}
			}
			else
			{
				SETGTECODE( g_GTECode_color_amb, Offset + codeSize );
				codeSize += GETGTECODESIZE( g_GTECode_color_amb );
				if( __GLSTATE__.m_IsGlobalLightingUpdated )
				{
					float pgteconst[ 1*4 ];

					// Me + Ambient x Ma
					pgteconst[0] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[0] ) +
						VF2F( VFMUL( __GLSTATE__.m_LightModelAmbientColor[0], __GLSTATE__.m_FrontMaterial.m_AmbientColor[0]) );
					pgteconst[1] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[1] ) +
						VF2F( VFMUL( __GLSTATE__.m_LightModelAmbientColor[1], __GLSTATE__.m_FrontMaterial.m_AmbientColor[1]) );
					pgteconst[2] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[2] ) +
						VF2F( VFMUL( __GLSTATE__.m_LightModelAmbientColor[2], __GLSTATE__.m_FrontMaterial.m_AmbientColor[2]) );
					pgteconst[3] = VF2F( __GLSTATE__.m_FrontMaterial.m_EmissionColor[3] ) +
						VF2F( VFMUL( __GLSTATE__.m_LightModelAmbientColor[3], __GLSTATE__.m_FrontMaterial.m_AmbientColor[3]) );

					GLESHAL_SetGTEConst( __GlobalAmbient_dest, sizeof(pgteconst)/sizeof(pgteconst[0]), pgteconst );			
				}
			}
			
			int i;
			for( i=0; i<GLPARAM_MAX_LIGHTS; i++ )
			{
				if( __GLSTATE__.m_Enable_LIGHT[i] )
				{
					GLESHAL_SetGTECode( g_GTECodeSetPage[i].m_pCode, codeSize + Offset, g_GTECodeSetPage[i].m_CodeSize );
					codeSize +=  g_GTECodeSetPage[i].m_CodeSize;
					codeSize += SetLightGTE( i, codeSize + Offset, DrawingMode );
				}
			}

			__GLSTATE__.m_IsGlobalLightingUpdated = GL_FALSE;
		}
		else
		{
			SETGTECODE( g_GTECode_color_none, Offset + codeSize );
			codeSize += GETGTECODESIZE( g_GTECode_color_none );
		}
		
		return codeSize;
	}

	unsigned int SetTextureGTECode( unsigned int Offset )
	{
		int i;
		for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_TexEnv[i].m_IsEnable )
			{
				__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[i]);

				if( __GLSTATE__.m_TextureMatrix[i].m_IsUpdated || __GLSTATE__.m_IsTextureUpdated )
				{
					MatrixStack& texturematrixstack = __GLSTATE__.m_TextureMatrix[i];
					Matrix4x4 mat_texture = texturematrixstack.CurrentMatrix();						
					int j;
					for( j=0; j<4; j++ )
					{
						mat_texture.m[0][j] *= ( ptexture->m_Width * ptexture->m_ScaleX ) ;
						mat_texture.m[1][j] *= ( ptexture->m_Height * ptexture->m_ScaleY );
					}
					
					float mat[16];
					MatrixToFloat( mat, mat_texture );
					GLESHAL_SetGTEConst( __TexMatrix_dest[i], 16, mat );

					//__GLSTATE__.m_TextureMatrix[i].m_IsUpdated = GL_FALSE;					
				}
			}
		}
		
		__GLSTATE__.m_IsTextureUpdated = GL_FALSE;

		// point sprite�̸� texture coordinate ������ ���� GTE �ڵ�� �ʿ����.
		// ��� render GTE code���� ó���Ұ���. 
		if( __GLSTATE__.m_TexEnv[0].m_IsEnable )
		{
			if( __GLSTATE__.m_TexEnv[1].m_IsEnable )
			{
				// multi-texture
				SETGTECODE( g_GTECode_tex_all, Offset );
				return GETGTECODESIZE( g_GTECode_tex_all );	
			}
			else
			{
				// texture disable
				SETGTECODE( g_GTECode_tex_0, Offset );
				return GETGTECODESIZE( g_GTECode_tex_0 );	
			}
		}
		else
		{
			if( __GLSTATE__.m_TexEnv[1].m_IsEnable )
			{
				SETGTECODE( g_GTECode_tex_1, Offset );
				return GETGTECODESIZE( g_GTECode_tex_1 );	
			}
			else	// texture disable
			{
				return 0;
			}
		}
		
	}

	unsigned int SetRenderGTECode( unsigned int Offset, GLenum DrawingMode )
	{
		if( DrawingMode == GL_TRIANGLE_STRIP ||
			DrawingMode == GL_TRIANGLE_FAN   ||
			DrawingMode == GL_TRIANGLES      )	
		{
			if( __GLSTATE__.m_ShadingModel == GL_SMOOTH )
			{
				SETGTECODE( g_GTECode_render_triangle, Offset );
				return GETGTECODESIZE( g_GTECode_render_triangle );
			}
			else
			{
				SETGTECODE( g_GTECode_render_triangle_flat, Offset );
				return GETGTECODESIZE( g_GTECode_render_triangle_flat );
			}		

		}
		else if( DrawingMode == GL_POINTS )
		{
			//float gteconst[ 4*2 ];
			float gteconst[ 4*6 ];

			int i;
			for( i=0; i<2; i++ )
			{
				if( __GLSTATE__.m_TexEnv[i].m_IsEnable )
				{
					__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[i]);
					gteconst[ i*2 ]		= (float)ptexture->m_Width;
					gteconst[ i*2+1 ]	= (float)ptexture->m_Height;
				}
			}

			//int viewWidth, viewHeight;
			//GLESOAL_GetNativeWindowSize( &viewWidth, &viewHeight );
			gteconst[ 4*1+0 ] = 1 / (float)( 2*__GLSTATE__.m_Viewport_Width );
			gteconst[ 4*1+1 ] = 1 / (float)( 2*__GLSTATE__.m_Viewport_Height );
			gteconst[ 4*1+2 ] = 0.0f;
			gteconst[ 4*1+3 ] = 0.0f;

			gteconst[ 4*2+0 ] = VF2F( __GLSTATE__.m_PointDistanceAttenuation[0] );
			gteconst[ 4*2+1 ] = VF2F( __GLSTATE__.m_PointDistanceAttenuation[1] );
			gteconst[ 4*2+2 ] = VF2F( __GLSTATE__.m_PointDistanceAttenuation[2] );
			gteconst[ 4*2+3 ] = 0.0f;

			gteconst[ 4*3+0 ] = gteconst[ 4*3+1 ] = gteconst[ 4*3+2 ] = gteconst[ 4*3+3 ] = VF2F( __GLSTATE__.m_POINT_SIZE_MIN );
			gteconst[ 4*4+0 ] = gteconst[ 4*4+1 ] = gteconst[ 4*4+2 ] = gteconst[ 4*4+3 ] = VF2F( __GLSTATE__.m_POINT_SIZE_MAX );
			gteconst[ 4*5+0 ] = gteconst[ 4*5+1 ] = gteconst[ 4*5+2 ] = gteconst[ 4*5+3 ] = VF2F( __GLSTATE__.m_POINT_FADE_THRESHOLD_SIZE );

			GLESHAL_SetGTEConst( __Render_dest, sizeof(gteconst)/sizeof(gteconst[0]), gteconst );		// page 9

			// point sprite
			if( __GLSTATE__.m_Enable_POINT_SPRITE_OES )
			{
				if( __GLSTATE__.m_TexEnv[0].m_COORD_REPLACE_OES )
				{
					// 0: point sprite, 1: point sprite
					if( __GLSTATE__.m_TexEnv[1].m_COORD_REPLACE_OES )
					{
						SETGTECODE( g_GTECode_render_pointsprite_all, Offset );
						return GETGTECODESIZE( g_GTECode_render_pointsprite_all );
					}
					// 0: point sprite, 1: point
					else
					{
						SETGTECODE( g_GTECode_render_pointsprite_0, Offset );
						return GETGTECODESIZE( g_GTECode_render_pointsprite_0 );
					}
				}
				else	
				{
					// 0: point, 1: point sprite
					if( __GLSTATE__.m_TexEnv[1].m_COORD_REPLACE_OES )
					{
						SETGTECODE( g_GTECode_render_pointsprite_1, Offset );
						return GETGTECODESIZE( g_GTECode_render_pointsprite_1 );
					}
					// �׳� point.
					else
					{
						SETGTECODE( g_GTECode_render_point, Offset );
						return GETGTECODESIZE( g_GTECode_render_point );
					}
				}
			}
			else
			{
				SETGTECODE( g_GTECode_render_point, Offset );
				return GETGTECODESIZE( g_GTECode_render_point );
			}
		}
        else	// GL_LINE_STRIP, GL_LINE_LOOP, GL_LINES
		{
			float gteconst[ 4*3 ];

			gteconst[ 4*0+0 ] = (float)__GLSTATE__.m_Viewport_Width ;
			gteconst[ 4*0+1 ] = (float)__GLSTATE__.m_Viewport_Height ;
			gteconst[ 4*0+2 ] = 0.0f;
			gteconst[ 4*0+3 ] = 0.0f;

			gteconst[ 4*1+0 ] = VF2F(__GLSTATE__.m_LineWidth) / (float)( 2*__GLSTATE__.m_Viewport_Width  );
			gteconst[ 4*1+1 ] = VF2F(__GLSTATE__.m_LineWidth) / (float)( 2*__GLSTATE__.m_Viewport_Height );
			gteconst[ 4*1+2 ] = 0.0f;
			gteconst[ 4*1+3 ] = 0.0f;
			
			gteconst[ 4*2+0 ] = 1 / (float)( __GLSTATE__.m_Viewport_Width );
			gteconst[ 4*2+1 ] = 1 / (float)( __GLSTATE__.m_Viewport_Height );
			gteconst[ 4*2+2 ] = 0.0f;
			gteconst[ 4*2+3 ] = 0.0f;			

			GLESHAL_SetGTEConst( __Render_dest, sizeof(gteconst)/sizeof(gteconst[0]), gteconst );		// page 9
			
			if( __GLSTATE__.m_ShadingModel == GL_SMOOTH )
			{
				SETGTECODE( g_GTECode_render_line, Offset );
				return GETGTECODESIZE( g_GTECode_render_line );					
			}
			else
			{
				SETGTECODE( g_GTECode_render_line_flat, Offset );
				return GETGTECODESIZE( g_GTECode_render_line_flat );									
			}
		}
	}
}
//------------------------------------------------------------------------------

namespace __MES_OPENGL_ES__ {

	//LIGHTMODE g_CurrentLightMode = LIGHTMODE_NONE;

	GLboolean PrepareRenderingGTE( GLenum DrawingMode )
	{
		unsigned int gteOffset = 0;
		
		gteOffset += SetPositonNormalGTECode( gteOffset );
		gteOffset += SetColorGTECode( gteOffset, DrawingMode );
		gteOffset += SetTextureGTECode( gteOffset );
		SetRenderGTECode( gteOffset, DrawingMode );

		return GL_TRUE;
	}
}// namespace __MES_OPENGL_ES__
