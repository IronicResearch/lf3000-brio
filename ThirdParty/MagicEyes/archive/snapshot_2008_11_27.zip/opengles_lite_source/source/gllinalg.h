//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gllinalg.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/12/06 Yuni	add matrix transpose
//	   2006/04/18 Gamza append inverse matrix
//	   2006/03/16 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLLINALG_H
#define _GLLINALG_H

#include "gltypes.h"

namespace __MES_OPENGL_ES__
{

#ifndef M_PI
#	define M_PI       3.14159265358979323846
#endif

#define VFSIN(angle)	(F2VF(sin(VF2F(angle))))
#define VFCOS(angle)	(F2VF(cos(VF2F(angle))))


//------------------------------------------------------------------------------
struct Vec3D
{
	Vfloat x,y,z;
};
//------------------------------------------------------------------------------
#define V3_MULT( out, v, scalar )	{\
									out.x = VFMUL(v.x, scalar );\
									out.y = VFMUL(v.y, scalar );\
									out.z = VFMUL(v.z, scalar );\
									}
#define V3_ADD( out, v1, v2 )		{\
									out.x = v1.x + v2.x;		\
									out.y = v1.y + v2.y;		\
									out.z = v1.z + v2.z;		\
									}
#define V3_DOT( v1, v2 )			( VFMUL(v1.x,v2.x) + VFMUL(v1.y,v2.y) + VFMUL(v1.z,v2.z) )
#define V3_SELFDOT( v )		        ( VFMUL(v.x,v.x) + VFMUL(v.y,v.y) + VFMUL(v.z,v.z) )
#define V3_LENGTH( v )				VFSQRT( V3_SELFDOT( v ) )
#define V3_INVLENGTH( v )			VFINVSQRT( V3_SELFDOT( v ) )
#define V3_NORMALIZE( v )			{\
									Vfloat invlength = V3_INVLENGTH( v ); \
									v.x =  VFMUL(v.x,invlength);          \
									v.y =  VFMUL(v.y,invlength);          \
									v.z =  VFMUL(v.z,invlength);          \
									}
#define V3_CROSS( result, v1, v2 )	{\
									result.x =  VFMUL(v1.y, v2.m_z) - VFMUL(v1.z, v2.m_y);\
									result.y = -VFMUL(v1.x, v2.m_z) + VFMUL(v1.z, v2.m_x);\
									result.z =  VFMUL(v1.x, v2.m_y) - VFMUL(v1.y, v2.m_x);\
									}

//------------------------------------------------------------------------------
struct Vec4D
{
	Vfloat x,y,z,w;
};
//------------------------------------------------------------------------------
#define V4_MULT( out, v, scalar )	{\
									out.x = VFMUL(v.x, scalar);\
									out.y = VFMUL(v.y, scalar);\
									out.z = VFMUL(v.z, scalar);\
									out.w = VFMUL(v.w, scalar);\
									}
#define V4_ADD( out, v1, v2 )		{\
									out.x = v1.x + v2.x;		\
									out.y = v1.y + v2.y;		\
									out.z = v1.z + v2.z;		\
									out.w = v1.w + v2.w;		\
									}
#define V4_DOT( v1, v2 )			( VFMUL(v1.x,v2.x) + VFMUL(v1.y,v2.y) + VFMUL(v1.z,v2.z) + VFMUL(v1.w,v2.w) )
#define V4_SELFDOT( v )				( VFMUL(v.x,v.x) + VFMUL(v.y,v.y) + VFMUL(v.z,v.z) + VFMUL(v.w,v.w) )
#define V4_LENGTH( v )				VFSQRT( V4_SELFDOT( v ) )
#define V4_INVLENGTH( v )			VFINVSQRT( V4_SELFDOT( v ) )
#define V4_NORMALIZE( v )			{\
									Vfloat invlength = V4_INVLENGTH( v ); \
									v.x =  VFMUL(v.x,invlength);          \
									v.y =  VFMUL(v.y,invlength);          \
									v.z =  VFMUL(v.z,invlength);          \
									v.w =  VFMUL(v.w,invlength);          \
									}

#define PROJECT( v3, v4 )			{\
									Vfloat invw = VFINV( v4.w ); \
									v3.x =  VFMUL(v4.x,invw);    \
									v3.y =  VFMUL(v4.y,invw);    \
									v3.z =  VFMUL(v4.z,invw);    \
									}

#define DIRECTION( v3, from, to )	{\
									v3.x = VFMUL(to.x, from.w) - VFMUL(from.x(), to.w);    \
									v3.y = VFMUL(to.y, from.w) - VFMUL(from.y(), to.w);    \
									v3.z = VFMUL(to.z, from.w) - VFMUL(from.z(), to.w);    \
									}

//------------------------------------------------------------------------------
struct Matrix4x4
{
	Vfloat m[4][4]; // [row][colum]
};
//------------------------------------------------------------------------------
#define M4_IDENTITY( mat )	{\
							mat.m[0][0] = mat.m[1][1] = mat.m[2][2] = mat.m[3][3] = VFONE; \
							mat.m[0][1] = mat.m[1][0] = mat.m[2][0] = mat.m[3][0] =        \
							mat.m[0][2] = mat.m[1][2] = mat.m[2][1] = mat.m[3][1] =        \
							mat.m[0][3] = mat.m[1][3] = mat.m[2][3] = mat.m[3][2] =     0; \
							}
#define M4_MUL_M4( r, m1, m2 ) {\
							r.m[0][0] = VFMUL(m1.m[0][0],m2.m[0][0]) + \
										VFMUL(m1.m[0][1],m2.m[1][0]) + \
										VFMUL(m1.m[0][2],m2.m[2][0]) + \
										VFMUL(m1.m[0][3],m2.m[3][0]);  \
							r.m[0][1] = VFMUL(m1.m[0][0],m2.m[0][1]) + \
										VFMUL(m1.m[0][1],m2.m[1][1]) + \
										VFMUL(m1.m[0][2],m2.m[2][1]) + \
										VFMUL(m1.m[0][3],m2.m[3][1]);  \
							r.m[0][2] = VFMUL(m1.m[0][0],m2.m[0][2]) + \
										VFMUL(m1.m[0][1],m2.m[1][2]) + \
										VFMUL(m1.m[0][2],m2.m[2][2]) + \
										VFMUL(m1.m[0][3],m2.m[3][2]);  \
							r.m[0][3] = VFMUL(m1.m[0][0],m2.m[0][3]) + \
										VFMUL(m1.m[0][1],m2.m[1][3]) + \
										VFMUL(m1.m[0][2],m2.m[2][3]) + \
										VFMUL(m1.m[0][3],m2.m[3][3]);  \
																	   \
							r.m[1][0] = VFMUL(m1.m[1][0],m2.m[0][0]) + \
										VFMUL(m1.m[1][1],m2.m[1][0]) + \
										VFMUL(m1.m[1][2],m2.m[2][0]) + \
										VFMUL(m1.m[1][3],m2.m[3][0]);  \
							r.m[1][1] = VFMUL(m1.m[1][0],m2.m[0][1]) + \
										VFMUL(m1.m[1][1],m2.m[1][1]) + \
										VFMUL(m1.m[1][2],m2.m[2][1]) + \
										VFMUL(m1.m[1][3],m2.m[3][1]);  \
							r.m[1][2] = VFMUL(m1.m[1][0],m2.m[0][2]) + \
										VFMUL(m1.m[1][1],m2.m[1][2]) + \
										VFMUL(m1.m[1][2],m2.m[2][2]) + \
										VFMUL(m1.m[1][3],m2.m[3][2]);  \
							r.m[1][3] = VFMUL(m1.m[1][0],m2.m[0][3]) + \
										VFMUL(m1.m[1][1],m2.m[1][3]) + \
										VFMUL(m1.m[1][2],m2.m[2][3]) + \
										VFMUL(m1.m[1][3],m2.m[3][3]);  \
																	   \
  							r.m[2][0] = VFMUL(m1.m[2][0],m2.m[0][0]) + \
										VFMUL(m1.m[2][1],m2.m[1][0]) + \
										VFMUL(m1.m[2][2],m2.m[2][0]) + \
										VFMUL(m1.m[2][3],m2.m[3][0]);  \
							r.m[2][1] = VFMUL(m1.m[2][0],m2.m[0][1]) + \
										VFMUL(m1.m[2][1],m2.m[1][1]) + \
										VFMUL(m1.m[2][2],m2.m[2][1]) + \
										VFMUL(m1.m[2][3],m2.m[3][1]);  \
							r.m[2][2] = VFMUL(m1.m[2][0],m2.m[0][2]) + \
										VFMUL(m1.m[2][1],m2.m[1][2]) + \
										VFMUL(m1.m[2][2],m2.m[2][2]) + \
										VFMUL(m1.m[2][3],m2.m[3][2]);  \
							r.m[2][3] = VFMUL(m1.m[2][0],m2.m[0][3]) + \
										VFMUL(m1.m[2][1],m2.m[1][3]) + \
										VFMUL(m1.m[2][2],m2.m[2][3]) + \
										VFMUL(m1.m[2][3],m2.m[3][3]);  \
																	   \
  							r.m[3][0] = VFMUL(m1.m[3][0],m2.m[0][0]) + \
										VFMUL(m1.m[3][1],m2.m[1][0]) + \
										VFMUL(m1.m[3][2],m2.m[2][0]) + \
										VFMUL(m1.m[3][3],m2.m[3][0]);  \
							r.m[3][1] = VFMUL(m1.m[3][0],m2.m[0][1]) + \
										VFMUL(m1.m[3][1],m2.m[1][1]) + \
										VFMUL(m1.m[3][2],m2.m[2][1]) + \
										VFMUL(m1.m[3][3],m2.m[3][1]);  \
							r.m[3][2] = VFMUL(m1.m[3][0],m2.m[0][2]) + \
										VFMUL(m1.m[3][1],m2.m[1][2]) + \
										VFMUL(m1.m[3][2],m2.m[2][2]) + \
										VFMUL(m1.m[3][3],m2.m[3][2]);  \
							r.m[3][3] = VFMUL(m1.m[3][0],m2.m[0][3]) + \
										VFMUL(m1.m[3][1],m2.m[1][3]) + \
										VFMUL(m1.m[3][2],m2.m[2][3]) + \
										VFMUL(m1.m[3][3],m2.m[3][3]);  \
							}										 										 

#define M4_MUL_V3( out, mat, v3 )	{\
									out.x =	VFMUL(v3.x, mat.m[0][0]) + \
											VFMUL(v3.y, mat.m[0][1]) + \
											VFMUL(v3.z, mat.m[0][2]) + \
											mat.m[0][3];               \
									out.y =	VFMUL(v3.x, mat.m[1][0]) + \
											VFMUL(v3.y, mat.m[1][1]) + \
											VFMUL(v3.z, mat.m[1][2]) + \
											mat.m[1][3];               \
									out.z =	VFMUL(v3.x, mat.m[2][0]) + \
											VFMUL(v3.y, mat.m[2][1]) + \
											VFMUL(v3.z, mat.m[2][2]) + \
											mat.m[2][3];               \
									out.w =	VFMUL(v3.x, mat.m[3][0]) + \
											VFMUL(v3.y, mat.m[3][1]) + \
											VFMUL(v3.z, mat.m[3][2]) + \
											mat.m[3][3];               \
									}
#define M4_MUL_V3_ROT( out, mat, v3 )	{\
									out.x =	VFMUL(v3.x, mat.m[0][0]) + \
											VFMUL(v3.y, mat.m[0][1]) + \
											VFMUL(v3.z, mat.m[0][2]) ; \
									out.y =	VFMUL(v3.x, mat.m[1][0]) + \
											VFMUL(v3.y, mat.m[1][1]) + \
											VFMUL(v3.z, mat.m[1][2]) ; \
									out.z =	VFMUL(v3.x, mat.m[2][0]) + \
											VFMUL(v3.y, mat.m[2][1]) + \
											VFMUL(v3.z, mat.m[2][2]) ; \
									}
#define M4_MUL_V4( out, mat, v4 )		{\
									out.x =	VFMUL(v4.x, mat.m[0][0]) + \
											VFMUL(v4.y, mat.m[0][1]) + \
											VFMUL(v4.z, mat.m[0][2]) + \
											VFMUL(v4.w, mat.m[0][3]) ; \
									out.y =	VFMUL(v4.x, mat.m[1][0]) + \
											VFMUL(v4.y, mat.m[1][1]) + \
											VFMUL(v4.z, mat.m[1][2]) + \
											VFMUL(v4.w, mat.m[1][3]) ; \
									out.z =	VFMUL(v4.x, mat.m[2][0]) + \
											VFMUL(v4.y, mat.m[2][1]) + \
											VFMUL(v4.z, mat.m[2][2]) + \
											VFMUL(v4.w, mat.m[2][3]) ; \
									out.w =	VFMUL(v4.x, mat.m[3][0]) + \
											VFMUL(v4.y, mat.m[3][1]) + \
											VFMUL(v4.z, mat.m[3][2]) + \
											VFMUL(v4.w, mat.m[3][3]) ; \
									}

#define M4_TRANSPOSE( OutMat, mat ) {\
							OutMat.m[0][0] = mat.m[0][0]; \
							OutMat.m[0][1] = mat.m[1][0]; \
							OutMat.m[0][2] = mat.m[2][0]; \
							OutMat.m[0][3] = mat.m[3][0]; \
							OutMat.m[1][0] = mat.m[0][1]; \
							OutMat.m[1][1] = mat.m[1][1]; \
							OutMat.m[1][2] = mat.m[2][1]; \
							OutMat.m[1][3] = mat.m[3][1]; \
							OutMat.m[2][0] = mat.m[0][2]; \
							OutMat.m[2][1] = mat.m[1][2]; \
							OutMat.m[2][2] = mat.m[2][2]; \
							OutMat.m[2][3] = mat.m[3][2]; \
							OutMat.m[3][0] = mat.m[0][3]; \
							OutMat.m[3][1] = mat.m[1][3]; \
							OutMat.m[3][2] = mat.m[2][3]; \
							OutMat.m[3][3] = mat.m[3][3]; \
							}

//void V3_DOT( Matrix4x4* pOutMat, const Vec3D* pVec1, const Vec3D* pVec2 );
//void V3_DOT( Matrix4x4* pOutMat, const Vec3D* pVec1, const Vec3D* pVec2 );


//void M4_TRANSPOSE( Matrix4x4* pOutMat, const Matrix4x4& mat );

inline void MatrixToFloat( float* pDest, const Matrix4x4& Matrix )
{
	int i;
	for( i=0; i<4; i++ )
	{
		*pDest++ = VF2F(Matrix.m[i][0]);
		*pDest++ = VF2F(Matrix.m[i][1]);
		*pDest++ = VF2F(Matrix.m[i][2]);
		*pDest++ = VF2F(Matrix.m[i][3]);
	}
}

} // __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;
							
#endif // _GLLINALG_H

							
//		inline Vfloat& Element(int row, int column) {
//			return m_elements[row + column * ROWS]; 
//		}

//		// ----------------------------------------------------------------------
//		// Calculate the matrix for which the upper left 3x3 matrix is the 
//		// inverse of the upper left 3x3 matrix of the receiver canconically
//		// embedded into 4-dimensional space
//		// ----------------------------------------------------------------------
//		Matrix4x4 InverseUpper3(bool rescale) const;
//
//		// ----------------------------------------------------------------------
//		// Compute general inverse of a 4 by 4 matrix
//		// ----------------------------------------------------------------------
//		Matrix4x4 Inverse() const;
//
//		Matrix4x4 Transpose() const {
//			Matrix4x4 result;
//
//			for (int i = 0; i < ROWS; ++i) {
//				for (int j = 0; j < COLUMNS; ++j) {
//					result.Element(i, j) = Element(j, i);
//				}
//			}
//
//			result.m_identity = m_identity;
//			return result;
//		}

//#endif // ndef EGL_LINALG_H

