//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : renderprimitives.cpp
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2008/09/11 Yuni	 Matrix palette�� vertex stream�� data format�� matrix index�� ���˿� ������ �޴� ���� ����.
//	    2008/03/20 Yuni	 Two side lighting ����.
//		2007/09/07 Yuni	 UpdateTexture ����. -> size�� 0�� texture�� ��� disable ���·� ����.
//		2007/09/07 Yuni	 GTEconst�� weight�� 0���� �ʱ�ȭ.
//		2007/09/07 Yuni	 m_CurrentPrimitive�� �ʱ�ȭ�� �� matrix palette�� null�� ����� ���� ����.
//						 matrix palette�� ���ο��� ������ �ִ� ���̹Ƿ� ������ �ʿ� ����.
//		2007/06/01 Yuni  first implementation
//------------------------------------------------------------------------------
//#include <cstring>
#include <string.h>
#include "glstate.h"
#include "renderprimitives.h"
#include "gtecode.h"

#include <stdio.h>
// internal funcitons
namespace {

#define INV_S8		( 2.0f/(float)( (1<<8)-1 ) )
#define INV_S16		( 2.0f/(float)( (1<<16)-1 ) )

#define	GTE_CONST_DEST			(0x1000/4)

typedef enum 
{
	VERTEXSTREAM_MATRIXINDEX	= 0,
	VERTEXSTREAM_POSITION		= 1,
	VERTEXSTREAM_COLOR			= 2,
	VERTEXSTREAM_NORMAL			= 3,
	VERTEXSTREAM_TEXCOORD0		= 4,
	VERTEXSTREAM_TEXCOORD1		= 5,
	VERTEXSTREAM_POINTSIZE		= 6,
	VERTEXSTREAM_WEIGHT			= 6,
	VERTEXSTREAM_MATRIXPALETTE	= 7,
	VERTEXSTREAM_FORCES32		= 0x7FFFFFFF
}VERTEXSTREAM;

	const void* GetEffectiveAddress( const __POINTER__& Pointer, __BUFFER__* pBuffer, GLint first, GLsizei count )
	{
		//MES_SPY( "GetEffectiveAddress" );
		const void* psrc;

		if( Pointer.m_Buffer )
		{
			if ( !pBuffer ){ return 0; }
			unsigned int offset = static_cast<const char *>(Pointer.m_Pointer) - static_cast<const char *>(0);
			psrc = (const char*)pBuffer->m_DataMemory1D.PhysicalAddress 
								+ offset + (Pointer.m_Stride * first);
			//psrc = (const char*)pcurrentbuffer->m_pData + offset + (Pointer.m_Stride * first);
			return psrc;
		}
		else
		{
			unsigned int pointerSize = Pointer.m_Stride * count;
			psrc = (const char*)(Pointer.m_Pointer) + (Pointer.m_Stride * first);

			if( pBuffer->m_UsedPoint )
			{
				while( pBuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			}
			/*
			GLESHAL_Flush();
			while( !GLESHAL_IsIdleState() )
				GLESOAL_Sleep(0);
			*/

			if( !pBuffer->m_DataMemory1D.MemoryHandle )
				GLESOAL_Malloc1D( pointerSize, 8, &pBuffer->m_DataMemory1D );
			else if( pBuffer->m_DataMemory1D.Size < pointerSize )
			{
				GLESOAL_Free1D( &pBuffer->m_DataMemory1D );
				GLESOAL_Malloc1D( pointerSize, 8, &pBuffer->m_DataMemory1D );
			}
			memcpy( (void*)(pBuffer->m_DataMemory1D.VirtualAddress), psrc, Pointer.m_Stride * count );
			return (const char*)pBuffer->m_DataMemory1D.PhysicalAddress;
		}
	}

	const void* GetIndexAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_IndexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = __BUFFER_POOL__.GetObject(__GLSTATE__.m_IndexPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = &__GLSTATE__.m_DefaultIndexBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}
		return GetEffectiveAddress( __GLSTATE__.m_IndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pIndex, first, count );
	}

	const void* GetPositionAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_VertexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = __BUFFER_POOL__.GetObject(__GLSTATE__.m_VertexPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = &__GLSTATE__.m_DefaultPositionBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}
		return GetEffectiveAddress( __GLSTATE__.m_VertexPointer, __GLSTATE__.m_CurrentPrimitive.m_pPosition, first, count );
	}

	const void* GetColorAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_ColorPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pColor = __BUFFER_POOL__.GetObject(__GLSTATE__.m_ColorPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pColor = &__GLSTATE__.m_DefaultColorBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}
		return GetEffectiveAddress( __GLSTATE__.m_ColorPointer, __GLSTATE__.m_CurrentPrimitive.m_pColor, first, count );
	}

	const void* GetNormalAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_NormalPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = __BUFFER_POOL__.GetObject(__GLSTATE__.m_NormalPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = &__GLSTATE__.m_DefaultNormalBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}

		return GetEffectiveAddress( __GLSTATE__.m_NormalPointer, __GLSTATE__.m_CurrentPrimitive.m_pNormal, first, count );
	}

	const void* GetPointSizeAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_PointSizePointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = __BUFFER_POOL__.GetObject(__GLSTATE__.m_PointSizePointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = &__GLSTATE__.m_DefaultPointSizeBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}

		return GetEffectiveAddress( __GLSTATE__.m_PointSizePointer, __GLSTATE__.m_CurrentPrimitive.m_pPointSize, first, count );
	}

	const void* GetWeightAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_WeightPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = __BUFFER_POOL__.GetObject(__GLSTATE__.m_WeightPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = &__GLSTATE__.m_DefaultWeightBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}

		return GetEffectiveAddress( __GLSTATE__.m_WeightPointer, __GLSTATE__.m_CurrentPrimitive.m_pWeight, first, count );
	}

	const void* GetTexCoordAddress( GLint index, GLint first, GLsizei count )
	{
		if( index >=  GLPARAM_MAX_TEXTURE_UNITS )
			return NULL;

		if( __GLSTATE__.m_TexturePointer[index].m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index] = __BUFFER_POOL__.GetObject(__GLSTATE__.m_TexturePointer[index].m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index] = &__GLSTATE__.m_DefaultTexCoordBuffer[index];
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}

		return GetEffectiveAddress( __GLSTATE__.m_TexturePointer[index], __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[index], first, count );
	}

	const void* GetMatrixIndexAddress( GLint first, GLsizei count )
	{
		if( __GLSTATE__.m_MatrixIndexPointer.m_Buffer )
		{
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = __BUFFER_POOL__.GetObject(__GLSTATE__.m_MatrixIndexPointer.m_Buffer);
		}
		else
		{
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = &__GLSTATE__.m_DefaultMatrixIndexBuffer;
			__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
		}

		return GetEffectiveAddress( __GLSTATE__.m_MatrixIndexPointer, __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex, first, count );
	}


	GLboolean GetHALVertexType( GLenum type, GLESHAL_VSTYPE& HALType )
	{
		switch( type )
		{
		case GL_UNSIGNED_BYTE:
			HALType = GLESHAL_VSTYPE_U8;
			break;
		case GL_BYTE:
			HALType = GLESHAL_VSTYPE_S8;
			break;
		case GL_SHORT:
			HALType = GLESHAL_VSTYPE_S16;
			break;
		case GL_FIXED:
			HALType = GLESHAL_VSTYPE_FIXED;
			break;
		case GL_FLOAT:
			HALType = GLESHAL_VSTYPE_FLOAT;
			break;
		
		default:
			return GL_FALSE;
		}
		return GL_TRUE;
	}

	GLboolean UpdateMatrixPaletteState( void )
	{
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0		
		__BUFFER__* pbuffer = __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette;
		if( !pbuffer || !pbuffer->m_DataMemory1D.MemoryHandle )
			return GL_FALSE;

		while( pbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.


		Matrix4x4 curMatrix;
		Matrix4x4 curInvMatrix;
		Matrix4x4 curInvTransMatrix;

		if( __GLSTATE__.m_IsLightTurnON )	// matrix palette�� ��ü inverse matrix�� ���ض�.
		{
			float mat[32];
			for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
			{
				// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
				unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];

				for( int j=0; j<8; j++ )
				{
					curInvMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentInverseMatrix();
					M4_TRANSPOSE( curInvTransMatrix, curInvMatrix );
					MatrixToFloat( &mat[16], curInvTransMatrix );
					if( curIndex & (1<<j) )
					{
						// update
						curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
						MatrixToFloat( mat, curMatrix );

						char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
						memcpy( pData, mat, sizeof(float) * 32 );
					}
					else
					{
						char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float)*((i*8+j) * 32 + 16) );
						memcpy( pData, mat, sizeof(float) * 16 );
					}
				}
				__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
				__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
			}
			__GLSTATE__.m_IsLightTurnON = GL_FALSE;
		}
		else
		{
			if( __GLSTATE__.m_Enable_LIGHTING )	// transform & inverse transform �� �� copy.
			{
				float mat[32];

				for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
				{
					// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
					unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];
					if( curIndex )
					{
						for( int j=0; j<8; j++ )
						{
							if( curIndex & (1<<j) )
							{
								// update
								curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
								curInvMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentInverseMatrix();
								M4_TRANSPOSE( curInvTransMatrix, curInvMatrix )
								MatrixToFloat( mat, curMatrix );
								MatrixToFloat( &mat[16], curInvTransMatrix );

								char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
								memcpy( pData, mat, sizeof(float) * 32 );
							}
						}
						__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
						__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
					}
				}
			}
			else	// transform�� copy.
			{
				float mat[16];

				for( int i=0; i<SIZEOF_MATRIXPALETTEBUFFER_FLAG; i++ )
				{
					// ����� matrix�� �ٽ� ������Ʈ �Ѵ�.
					unsigned char curIndex = __GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i];
					if( curIndex )
					{
						for( int j=0; j<8; j++ )
						{
							if( curIndex & (1<<j) )
							{
								// update
								curMatrix = __GLSTATE__.m_MatrixPalette[i*8+j].CurrentMatrix();
								MatrixToFloat( mat, curMatrix );
								char* pData = reinterpret_cast<char*>(pbuffer->m_DataMemory1D.VirtualAddress) + (sizeof(float) * (i*8+j) * 32);
								memcpy( pData, mat, sizeof(float) * 16 );
							}
						}
						__GLSTATE__.m_MatrixPaletteUpdateFlag[__GLSTATE__.m_CurMatrixPaletteBufferIndex][i] = 0;
						__GLSTATE__.m_IsPrimitiveCacheClear = GL_TRUE;
					}
				}
			}
		}
#endif // GLPARAM_MAX_PALETTE_MATRICES_OES > 0		
		return GL_TRUE;
	}


	void SetTextureBlendMode( unsigned int textureStage, __TEXTURE__* ptexture )
	{
		if( !(__GLSTATE__.m_TexEnv[textureStage].m_IsEnable) )
		{
			if( 0 == textureStage )
				GLESHAL_SetTextureBlend( 0, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C,
										GLESHAL_RGBOP_REPLACE, 
										GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A,
										GLESHAL_AOP_REPLACE );
											
			else if( 1 == textureStage )
				GLESHAL_SetTextureBlend( 1, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C,
										GLESHAL_RGBOP_REPLACE, 
										GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A,
										GLESHAL_AOP_REPLACE );				
			
		}
		else
		{
			GLESHAL_RGBARG	rgbArg[3] = { 
					GLESHAL_RGBARG_FRAGMENT_C, 
					GLESHAL_RGBARG_FRAGMENT_C, 
					GLESHAL_RGBARG_FRAGMENT_C 
			};
			GLESHAL_RGBOP	rgbOp = GLESHAL_RGBOP_REPLACE;
			GLESHAL_AARG	aArg[3] = {
					GLESHAL_AARG_FRAGMENT_A,
					GLESHAL_AARG_FRAGMENT_A, 
					GLESHAL_AARG_FRAGMENT_A
			};
			GLESHAL_AOP		aOp = GLESHAL_AOP_REPLACE;
			GLESHAL_RGBARG	rgbPreArg;
			GLESHAL_AARG	aPreArg;

			// 1. Stage level check
			// 2. Internal format check
			if( 0 == textureStage )
			{
				rgbPreArg		= GLESHAL_RGBARG_FRAGMENT_C;
				aPreArg			= GLESHAL_AARG_FRAGMENT_A;
			}
			else	
			{
				rgbPreArg		= GLESHAL_RGBARG_PREVIOUS_C;
				aPreArg			= GLESHAL_AARG_PREVIOUS_A;			
			}

			__TEXENV__* ptexenv = &__GLSTATE__.m_TexEnv[textureStage];

			switch( ptexenv->m_TEXTURE_ENV_MODE )
			{
				case GL_REPLACE:
				{
					if( GL_ALPHA == ptexture->m_Format )
					{
						rgbArg[0] = rgbPreArg;
						aArg[0]	= GLESHAL_AARG_SOURCE_A;
					}
					else if(( GL_LUMINANCE_ALPHA == ptexture->m_Format ) || ( GL_RGBA == ptexture->m_Format ))
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						aArg[0]	= GLESHAL_AARG_SOURCE_A;
					}
					else
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						aArg[0]	= aPreArg;
					}
					rgbOp	= GLESHAL_RGBOP_REPLACE;
					aOp		= GLESHAL_AOP_REPLACE;
				}
				break;

				case GL_MODULATE:
				{ 
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_SOURCE_C;
					
					if( GL_ALPHA == ptexture->m_Format )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else
						rgbOp	= GLESHAL_RGBOP_MODULATE;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;
				
				case GL_DECAL:
				{
					if(( GL_RGB == ptexture->m_Format ) || ( GL_RGBA == ptexture->m_Format ))
					{
						rgbArg[0] = GLESHAL_RGBARG_SOURCE_C;
						rgbArg[1] = rgbPreArg;		
						rgbArg[2] = GLESHAL_RGBARG_SOURCE_A;
						rgbOp	= GLESHAL_RGBOP_INTERPOLATE;

						aArg[0]	= aPreArg;
						aOp		= GLESHAL_AOP_REPLACE;
					}
					else
					{
						//GLSETERROR(GL_INVALID_VALUE);
						return;
					}
				}
				break;

				case GL_ADD:
				{
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_SOURCE_C;
					
					if( GL_ALPHA == ptexture->m_Format )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else				
						rgbOp	= GLESHAL_RGBOP_ADD;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;

				case GL_BLEND:
				{
					rgbArg[0] = rgbPreArg;
					rgbArg[1] = GLESHAL_RGBARG_CONST_C;
					rgbArg[2] = GLESHAL_RGBARG_SOURCE_1_C;
					
					if( GL_ALPHA == ptexture->m_Format )
						rgbOp	= GLESHAL_RGBOP_REPLACE;
					else				
						rgbOp	= GLESHAL_RGBOP_INTERPOLATE;

					aArg[0]	= aPreArg;
					aArg[1]	= GLESHAL_AARG_SOURCE_A;
					aOp		= GLESHAL_AOP_MODULATE;
				}
				break;

				case GL_COMBINE:
				{
					int previousSrcNum = 3;
					if( 0 == textureStage )
						previousSrcNum = 2;
					
					for( int i=0; i<3; i++ )
					{
						int srcNum = 0;
						int opNum = 0;
						
						// RGB args
						if( GL_TEXTURE == ptexenv->m_SRC_RGB[i] )				srcNum = 0;
						else if(  GL_CONSTANT == ptexenv->m_SRC_RGB[i] )		srcNum = 1;
						else if(  GL_PRIMARY_COLOR == ptexenv->m_SRC_RGB[i] )	srcNum = 2;
						else if( GL_PREVIOUS == ptexenv->m_SRC_RGB[i] )			srcNum = previousSrcNum;
						/*
						{
							if( 0 == __GLSTATE__.m_ActiveTexture )	srcNum = 2;
							else									srcNum = 3;
						}
						*/

						if( GL_SRC_COLOR == ptexenv->m_OPERAND_RGB[i] )					opNum = 0;
						else if( GL_ONE_MINUS_SRC_COLOR == ptexenv->m_OPERAND_RGB[i] )	opNum = 1;
						else if( GL_SRC_ALPHA == ptexenv->m_OPERAND_RGB[i] )			opNum = 2;
						else if( GL_ONE_MINUS_SRC_ALPHA == ptexenv->m_OPERAND_RGB[i] )	opNum = 3;

						rgbArg[i] = (GLESHAL_RGBARG)( srcNum*4 + opNum );

						// ALPHA args
						if( GL_TEXTURE == ptexenv->m_SRC_ALPHA[i] )				srcNum = 0;
						else if(  GL_CONSTANT == ptexenv->m_SRC_ALPHA[i] )		srcNum = 1;
						else if(  GL_PRIMARY_COLOR == ptexenv->m_SRC_ALPHA[i] )	srcNum = 2;
						else if( GL_PREVIOUS == ptexenv->m_SRC_ALPHA[i] )		srcNum = previousSrcNum;
						/*
						{
							if( 0 == __GLSTATE__.m_ActiveTexture )	srcNum = 2;
							else									srcNum = 3;
						}
						*/

						if( GL_SRC_ALPHA == ptexenv->m_OPERAND_ALPHA[i] )					opNum = 0;
						else if( GL_ONE_MINUS_SRC_ALPHA == ptexenv->m_OPERAND_ALPHA[i] )	opNum = 1;

						aArg[i] = (GLESHAL_AARG)( srcNum*2 + opNum );
					}

					// RGB Operand
					if( GL_REPLACE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_REPLACE;
					else if( GL_MODULATE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_MODULATE;
					else if( GL_ADD == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_ADD;
					else if( GL_ADD_SIGNED == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_ADD_SIGNED;
					else if( GL_INTERPOLATE == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_INTERPOLATE;
					else if( GL_SUBTRACT == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_SUBTRACT;
					else if( GL_DOT3_RGB == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_DOT3_RGB;
					else if( GL_DOT3_RGBA == ptexenv->m_COMBINE_RGB )	
						rgbOp = GLESHAL_RGBOP_DOT3_RGBA;

					// ALPHA Operand
					if( GL_REPLACE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_REPLACE;
					else if( GL_MODULATE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_MODULATE;
					else if( GL_ADD == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_ADD;
					else if( GL_ADD_SIGNED == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_ADD_SIGNED;
					else if( GL_INTERPOLATE == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_INTERPOLATE;
					else if( GL_SUBTRACT == ptexenv->m_COMBINE_ALPHA )	
						aOp = GLESHAL_AOP_SUBTRACT;

				}
				break;
			default:
				return;
			}

			GLESHAL_SetTextureBlend( textureStage, 
									rgbArg[0], rgbArg[1], rgbArg[2], rgbOp, 
									aArg[0], aArg[1], aArg[2], aOp );		
		}
	}	

	void SetBufferUseLog( void )
	{
		GLESHAL_Nops( 8 );

		unsigned __int64 curPointer = GLESHAL_GetFrontOfCommandQueue();	
				
		while( 0 != (curPointer&7) )
		{
			GLESHAL_Nop();
			curPointer = GLESHAL_GetFrontOfCommandQueue();			
		}

		if( __GLSTATE__.m_CurrentPrimitive.m_pIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pIndex->m_UsedPoint = curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pPosition )
			__GLSTATE__.m_CurrentPrimitive.m_pPosition->m_UsedPoint = curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pColor )
			__GLSTATE__.m_CurrentPrimitive.m_pColor->m_UsedPoint	= curPointer;
		if( __GLSTATE__.m_CurrentPrimitive.m_pNormal )
			__GLSTATE__.m_CurrentPrimitive.m_pNormal->m_UsedPoint = curPointer;

		for( int i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_BindedTexture[i] && __GLSTATE__.m_TexEnv[i].m_IsEnable )
			{
				__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[i]);
				ptexture->m_UsedPoint = curPointer;
			}

			if( __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] )
				__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i]->m_UsedPoint = curPointer;
		}

		if( __GLSTATE__.m_Enable_MATRIX_PALETTE_OES )
		{
			if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex )
				__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex->m_UsedPoint	= curPointer;
			if( __GLSTATE__.m_CurrentPrimitive.m_pWeight )
				__GLSTATE__.m_CurrentPrimitive.m_pWeight->m_UsedPoint		= curPointer;
			if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette )
				__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_UsedPoint = curPointer;

			SetCurMatrixPaletteBufferIndex();	// matrix palette buffer change
		}
		else
		{
			if( __GLSTATE__.m_CurrentPrimitive.m_pPointSize )
				__GLSTATE__.m_CurrentPrimitive.m_pPointSize->m_UsedPoint = curPointer;
		}
	}
	
	void InitCurrentPrimitive( void )
	{
		if( __GLSTATE__.m_CurrentPrimitive.m_pPosition )
			__GLSTATE__.m_CurrentPrimitive.m_pPosition = NULL;
		if( __GLSTATE__.m_CurrentPrimitive.m_pColor )	
			__GLSTATE__.m_CurrentPrimitive.m_pColor = NULL;
		if( __GLSTATE__.m_CurrentPrimitive.m_pNormal )
			__GLSTATE__.m_CurrentPrimitive.m_pNormal = NULL;
		if( __GLSTATE__.m_CurrentPrimitive.m_pPointSize )
			__GLSTATE__.m_CurrentPrimitive.m_pPointSize = NULL;
		if( __GLSTATE__.m_CurrentPrimitive.m_pWeight )
			__GLSTATE__.m_CurrentPrimitive.m_pWeight = NULL;
		
		int i;
		for( i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
		{
			if( __GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] )
				__GLSTATE__.m_CurrentPrimitive.m_pTexCoord[i] = NULL;
		}
		
		if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pMatrixIndex = NULL;
		//if( __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette )
		//	__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette = NULL;	// Matrix palette�� NULL�� ����� �ȵſ�~
		if( __GLSTATE__.m_CurrentPrimitive.m_pIndex )
			__GLSTATE__.m_CurrentPrimitive.m_pIndex = NULL;
	}
	
	// Set fog to HAL
	void SetFog( void )
	{
		GLESHAL_FOGMODE fogMode;
		
		if( GL_LINEAR == __GLSTATE__.m_FogMode )
		{
			GLESHAL_SetLinearFog( VF2F(__GLSTATE__.m_FogStart), VF2F(__GLSTATE__.m_FogEnd) );
		}
		else
		{
			if( GL_EXP == __GLSTATE__.m_FogMode )
				fogMode = GLESHAL_FOGMODE_EXP;
			else
				fogMode = GLESHAL_FOGMODE_EXP2;
			
			GLESHAL_SetFog( fogMode, VF2F(__GLSTATE__.m_FogDensity) );
		}
		
		GLESHAL_SetFogColor( VF2F(__GLSTATE__.m_FogColor[0]),
						     VF2F(__GLSTATE__.m_FogColor[1]),
						     VF2F(__GLSTATE__.m_FogColor[2]),
						     VF2F(__GLSTATE__.m_FogColor[3]) );
						     
		__GLSTATE__.m_IsFogUpdated = GL_FALSE;
	}

	float __ConstForNormalize__;
	
}	// namespace

namespace __MES_OPENGL_ES__ {


void UpdateTexture( void )
{
	// Texture blending
	// Const color
	// Multi-texture, texture enable flag setting
	// Texture palette or texture segment, option setting
	// Texture filtering
	// **** filtering�� constant color ������ ���, multi-texturing�̸� tex[0]�� ������
	// �� �� �ϳ��� enable�̸� enable �� texture�� ������ ������. ****
	
	unsigned long curRenderState = GLESHAL_GetRenderState();
		
	if( !__GLSTATE__.m_TexEnv[0].m_IsEnable && !__GLSTATE__.m_TexEnv[1].m_IsEnable )
	{
		GLESHAL_SetTextureBlend( 0, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C, GLESHAL_RGBARG_FRAGMENT_C,
								GLESHAL_RGBOP_REPLACE, 
								GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A, GLESHAL_AARG_FRAGMENT_A,
								GLESHAL_AOP_REPLACE );
		/*	// multi-texture enable ���°� �ƴ϶�� tex1�� blending�� ������ �ʿ� ����.						
		GLESHAL_SetTextureBlend( 1, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C, GLESHAL_RGBARG_PREVIOUS_C,
								GLESHAL_RGBOP_REPLACE, 
								GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A, GLESHAL_AARG_PREVIOUS_A,
								GLESHAL_AOP_REPLACE );								
		*/
		curRenderState &= ~GLESHAL_RS_TEXTURE_ENB;
		curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
		GLESHAL_SetRenderState( curRenderState );		
		return;
	}
	
	GLboolean isValidTex[GLPARAM_MAX_TEXTURE_UNITS];
	__TEXTURE__* ptexture[GLPARAM_MAX_TEXTURE_UNITS];
	
	int i;
	// size�� 0�� ��� disable ���·� ���. (spec ����)
	// enable ���¶�� ptexture�� �ش� texture ���.
	for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
	{
		if( __GLSTATE__.m_TexEnv[i].m_IsEnable )
		{
			ptexture[i] = __TEXTURE_POOL__.GetObject( __GLSTATE__.m_BindedTexture[i] );
			if( !ptexture[i]->m_Width || !ptexture[i]->m_Height )	// width or height�� 0�̸�.
			{
				ptexture[i] = NULL;
				isValidTex[i] = GL_FALSE;
			}
			else
			{
				isValidTex[i] = GL_TRUE;
			}
		}
		else
		{
			ptexture[i] = NULL;
			isValidTex[i] = GL_FALSE;
		}
	}

	// texture const color�� ���� enable �Ǿ� �ִ� texture�� env color�� ����.
	// render state ����.
	if( isValidTex[0] )
	{
		GLESHAL_SetTextureConstColor( VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[0]),
									VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[1]),
									VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[2]),
									VF2F(__GLSTATE__.m_TexEnv[0].m_TEXTURE_ENV_COLOR[3]) );

		// texture enable
		curRenderState |= GLESHAL_RS_TEXTURE_ENB;

		if( isValidTex[1] )		// multi-texture
			curRenderState |= GLESHAL_RS_MULTITEX_ENB;
		else
			curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
		
		// texture filtering
		if( GL_NEAREST == ptexture[0]->m_TEXTURE_MAG_FILTER )
		{
			curRenderState &= ~GLESHAL_RS_BILINEAR_FILTER_ENB;
			curRenderState &= ~GLESHAL_RS_ABILINEAR_FILTER_ENB;
		}
		else if( GL_LINEAR == ptexture[0]->m_TEXTURE_MAG_FILTER )
		{
			curRenderState |= GLESHAL_RS_BILINEAR_FILTER_ENB;
			curRenderState |= GLESHAL_RS_ABILINEAR_FILTER_ENB;
		}			
	}
	else
	{
		if( isValidTex[1] )
		{
			// texture enable, mult-texture
			curRenderState |= GLESHAL_RS_TEXTURE_ENB;
			curRenderState |= GLESHAL_RS_MULTITEX_ENB;

			ptexture[0] = &__GLSTATE__.m_DefaultTexture;

			GLESHAL_SetTextureConstColor( VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[0]),
										VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[1]),
										VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[2]),
										VF2F(__GLSTATE__.m_TexEnv[1].m_TEXTURE_ENV_COLOR[3]) );
										
			if( GL_NEAREST == ptexture[1]->m_TEXTURE_MAG_FILTER )
			{
				curRenderState &= ~GLESHAL_RS_BILINEAR_FILTER_ENB;
				curRenderState &= ~GLESHAL_RS_ABILINEAR_FILTER_ENB;
			}
			else if( GL_LINEAR == ptexture[1]->m_TEXTURE_MAG_FILTER )
			{
				curRenderState |= GLESHAL_RS_BILINEAR_FILTER_ENB;
				curRenderState |= GLESHAL_RS_ABILINEAR_FILTER_ENB;
			}												
		}
		else
		{
			// texture disable
			curRenderState &= ~GLESHAL_RS_TEXTURE_ENB;
			curRenderState &= ~GLESHAL_RS_MULTITEX_ENB;
			GLESHAL_SetRenderState( curRenderState );
			return;
		}
	}
	GLESHAL_SetRenderState( curRenderState );

	// texture ���� ����.
	for( i=0; i<2/*GLPARAM_MAX_TEXTURE_UNITS*/; i++ )
	{
		SetTextureBlendMode( i, ptexture[i] );
		
		if( !ptexture[i] )
			break;

		GLESHAL_COLORFORMAT colorFormat;
		if( ptexture[i]->m_IsCompessed )
			colorFormat = GetHALCompressedTexColorFormat( ptexture[i]->m_Format );
		else
			colorFormat = GetHALTexColorFormat( ptexture[i]->m_Format, ptexture[i]->m_Type );
		
		if( ptexture[i]->m_TextureDataMemory2D.MemoryHandle )
		{
			GLESHAL_TEXTUREADDRESS wrapS = GLESHAL_TEXTUREADDRESS_CLAMP;
			GLESHAL_TEXTUREADDRESS wrapT = GLESHAL_TEXTUREADDRESS_CLAMP;
			if( GL_REPEAT == ptexture[i]->m_TEXTURE_WRAP_S )
				wrapS = GLESHAL_TEXTUREADDRESS_WRAP;
			if( GL_REPEAT == ptexture[i]->m_TEXTURE_WRAP_T )
				wrapT = GLESHAL_TEXTUREADDRESS_WRAP;
			
			GLESHAL_SetTextureWithSegment( i, 
								ptexture[i]->m_IsUpdated,
								ptexture[i]->m_TextureDataMemory2D.PhysicalSegment, 
								colorFormat,
								( ptexture[i]->m_TEXTURE_MIN_FILTER == GL_NEAREST_MIPMAP_NEAREST ) && ( ptexture[i]->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE ),
								wrapS, //(GLESHAL_TEXTUREADDRESS)ptexture[i]->m_TEXTURE_WRAP_S,
								wrapT, //(GLESHAL_TEXTUREADDRESS)ptexture[i]->m_TEXTURE_WRAP_T,
								(ptexture[i]->m_TextureDataMemory2D.PhysicalSegX)/2, 
								ptexture[i]->m_TextureDataMemory2D.PhysicalSegY, 
								ptexture[i]->m_WidthPowerOf2 * ptexture[i]->m_Bpp / 16, 
								ptexture[i]->m_HeightPowerOf2 );
								
			// compressed texture�̸� palette ����
			if( (ptexture[i]->m_IsCompessed) && (ptexture[i]->m_PaletteMemory2D.MemoryHandle) )
			{
				switch( ptexture[i]->m_PaletteSize )
				{
				case 16:
					if( !GLESHAL_SetPalette16( i,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegment,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegX/2,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegY ))
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					break;

				case 256:
					if( !GLESHAL_SetPalette256( i, 
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegment,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegX/2,
											   ptexture[i]->m_PaletteMemory2D.PhysicalSegY ))
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					break;

				default:
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
			}
			ptexture[i]->m_IsUpdated = GL_FALSE;
		}
	}
}

unsigned int Preparerendering( GLint first, GLsizei count )
{
	float gteConst[4*7];
	unsigned int vertexStream[3*8];
	if( !__GLSTATE__.m_ClientState_VERTEX_ARRAY )
		return 0;

	GLESHAL_VSTYPE HALType;

	unsigned int bufferenableflag = 1<<GLESHAL_VERTEXSTREAM_POSITION;
	if( !GetHALVertexType( __GLSTATE__.m_VertexPointer.m_Type, HALType ) )
		return 0; 

	vertexStream[ VERTEXSTREAM_POSITION * 3 + 0 ] = (unsigned int)(GetPositionAddress( first, count ));
	vertexStream[ VERTEXSTREAM_POSITION * 3 + 1 ] = __GLSTATE__.m_VertexPointer.m_Stride;
	vertexStream[ VERTEXSTREAM_POSITION * 3 + 2 ] = ((GTE_CONST_DEST + __Position_dest)<<20) | 
													((__GLSTATE__.m_VertexPointer.m_Size - 1)<<8) | 
													(unsigned int)HALType;

	gteConst[__Position_dest + 0] = 0.0f;
	gteConst[__Position_dest + 1] = 0.0f;
	gteConst[__Position_dest + 2] = 0.0f;
	gteConst[__Position_dest + 3] = 1.0f;

	if( __GLSTATE__.m_ClientState_COLOR_ARRAY )
	{ 
		bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_COLOR); 
		gteConst[__Color_dest + 0] = 0.0f;
		gteConst[__Color_dest + 1] = 0.0f;
		gteConst[__Color_dest + 2] = 0.0f;
		gteConst[__Color_dest + 3] = 1.0f;

		if( !GetHALVertexType( __GLSTATE__.m_ColorPointer.m_Type, HALType ) )
			return 0; 
		if ( GLESHAL_VSTYPE_U8 == HALType )
			HALType = GLESHAL_VSTYPE_NORMALIZED_U8;

		vertexStream[ VERTEXSTREAM_COLOR * 3 + 0 ] = (unsigned int)(GetColorAddress( first, count ));
		vertexStream[ VERTEXSTREAM_COLOR * 3 + 1 ] = __GLSTATE__.m_ColorPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_COLOR * 3 + 2 ] = ((GTE_CONST_DEST + __Color_dest)<<20) | 
													((__GLSTATE__.m_ColorPointer.m_Size - 1)<<8) | 
													(unsigned int)HALType;
	}
	else
	{
		gteConst[__Color_dest + 0] = VF2F(__GLSTATE__.m_CurrentColor[0]);
		gteConst[__Color_dest + 1] = VF2F(__GLSTATE__.m_CurrentColor[1]);
		gteConst[__Color_dest + 2] = VF2F(__GLSTATE__.m_CurrentColor[2]);
		gteConst[__Color_dest + 3] = VF2F(__GLSTATE__.m_CurrentColor[3]);
	}

	if( (__GLSTATE__.m_ClientState_NORMAL_ARRAY) && (__GLSTATE__.m_Enable_LIGHTING) ) 
	{
		bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_NORMAL); 

		if( !GetHALVertexType( __GLSTATE__.m_NormalPointer.m_Type, HALType ) )
			return 0; 

		//float normalized;

		switch( HALType )
		{
			case GLESHAL_VSTYPE_S8:
				__ConstForNormalize__ = INV_S8;
				break;
			case GLESHAL_VSTYPE_S16:
				__ConstForNormalize__ = INV_S16;
				break;
			case GLESHAL_VSTYPE_FIXED:
				__ConstForNormalize__ = 1.0f;
				break;
			case GLESHAL_VSTYPE_FLOAT:
				__ConstForNormalize__ = 1.0f;
				break;
			default:
				__ConstForNormalize__ = 1.0f;
				break;
		}
		
		gteConst[__Normalize_const_dest + 0] = __ConstForNormalize__;
		gteConst[__Normalize_const_dest + 1] = __ConstForNormalize__;
		gteConst[__Normalize_const_dest + 2] = __ConstForNormalize__;
		gteConst[__Normalize_const_dest + 3] = 1.0f;


		gteConst[__Normal_dest + 0] = 0.0f;
		gteConst[__Normal_dest + 1] = 0.0f;
		gteConst[__Normal_dest + 2] = 1.0f;

		vertexStream[ VERTEXSTREAM_NORMAL * 3 + 0 ] = (unsigned int)(GetNormalAddress( first, count ));
		vertexStream[ VERTEXSTREAM_NORMAL * 3 + 1 ] = __GLSTATE__.m_NormalPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_NORMAL * 3 + 2 ] = ((GTE_CONST_DEST + __Normal_dest)<<20) | 
													((__GLSTATE__.m_NormalPointer.m_Size - 1)<<8) | 
													(unsigned int)HALType;
	}
	else
	{
		__ConstForNormalize__ = 1.0f;
		gteConst[__Normalize_const_dest + 0] = 1.0f;
		gteConst[__Normalize_const_dest + 1] = 1.0f;
		gteConst[__Normalize_const_dest + 2] = 1.0f;
		gteConst[__Normalize_const_dest + 3] = 1.0f;

		gteConst[__Normal_dest + 0] = VF2F(__GLSTATE__.m_DefaultNormal.x);
		gteConst[__Normal_dest + 1] = VF2F(__GLSTATE__.m_DefaultNormal.y);
		gteConst[__Normal_dest + 2] = VF2F(__GLSTATE__.m_DefaultNormal.z);
	}

	if( __GLSTATE__.m_Enable_MATRIX_PALETTE_OES )
	{
		bufferenableflag |= ( (1<<GLESHAL_VERTEXSTREAM_MATRIXINDEX) |
							( 1<<GLESHAL_VERTEXSTREAM_WEIGHT )		|
							( 1<<GLESHAL_VERTEXSTREAM_MATRIXPALETTE) );

		gteConst[__PointSize_dest] = (float)(__GLSTATE__.m_PointSize);
		//gteConst[__PointSize_dest] = 0.0f;

		if( !GetHALVertexType( __GLSTATE__.m_MatrixIndexPointer.m_Type, HALType ) )
			return 0; 

		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 0 ] = (unsigned int)(GetMatrixIndexAddress( first, count ));
		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 1 ] = __GLSTATE__.m_MatrixIndexPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_MATRIXINDEX * 3 + 2 ] = ((GTE_CONST_DEST + 15*4)<<20) | 
													((__GLSTATE__.m_MatrixIndexPointer.m_Size - 1)<<8) | 
													(unsigned int)HALType;

		if( !GetHALVertexType( __GLSTATE__.m_WeightPointer.m_Type, HALType ) )
			return 0; 

		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 0 ] = (unsigned int)(GetWeightAddress( first, count ));
		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 1 ] = __GLSTATE__.m_WeightPointer.m_Stride;
		vertexStream[ VERTEXSTREAM_WEIGHT * 3 + 2 ] = ((GTE_CONST_DEST + __Weight_dest)<<20) | 
													((__GLSTATE__.m_WeightPointer.m_Size - 1)<<8) | 
													(unsigned int)HALType;

		gteConst[__Weight_dest + 0] = 0.0f;
		gteConst[__Weight_dest + 1] = 0.0f;
		gteConst[__Weight_dest + 2] = 0.0f;
		gteConst[__Weight_dest + 3] = 0.0f;
		

		if( !UpdateMatrixPaletteState() )	// ����� matrix palette update
			return 0;

		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 0 ] = (unsigned int)(__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_DataMemory1D.PhysicalAddress);
		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 1 ] = __GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_Size * sizeof(GLfloat);
		vertexStream[ VERTEXSTREAM_MATRIXPALETTE * 3 + 2 ] = ((GTE_CONST_DEST + __MatrixPalette_dest)<<20) | 
													((__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette->m_Size - 1)<<8) | 
													GLESHAL_VSTYPE_FLOAT;
	}
	else
	{
		if( __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES )
		{ 
			bufferenableflag |= (1<<GLESHAL_VERTEXSTREAM_POINTSIZE); 

			gteConst[__PointSize_dest] = 1.0f;

			if( !GetHALVertexType( __GLSTATE__.m_PointSizePointer.m_Type, HALType ) )
				return 0; 

			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 0 ] = (unsigned int)(GetPointSizeAddress( first, count ));
			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 1 ] = __GLSTATE__.m_PointSizePointer.m_Stride;
			vertexStream[ VERTEXSTREAM_POINTSIZE * 3 + 2 ] = ((GTE_CONST_DEST + __PointSize_dest)<<20) | 
														((__GLSTATE__.m_PointSizePointer.m_Size - 1)<<8) | 
														(unsigned int)HALType;
		}
		else
		{
			gteConst[__PointSize_dest] = VF2F(__GLSTATE__.m_PointSize);
		}
	}

	// texture update
	UpdateTexture();

	for( int i = 0; i < GLPARAM_MAX_TEXTURE_UNITS; i++ )
	{
		if(__GLSTATE__.m_TexEnv[i].m_IsEnable )
		{
			if( __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[i] )
			{
				bufferenableflag |= (1<<(GLESHAL_VERTEXSTREAM_TEXCOORD0+i)); 

				gteConst[__Tex0_dest + 4*i + 0] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 1] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 2] = 0.0f;
				gteConst[__Tex0_dest + 4*i + 3] = 1.0f;

				if( !GetHALVertexType( __GLSTATE__.m_TexturePointer[i].m_Type, HALType ) )
					return 0; 

				vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 0 ] = (unsigned int)GetTexCoordAddress( i, first, count );
				vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 1 ] = __GLSTATE__.m_TexturePointer[i].m_Stride;
				vertexStream[ (VERTEXSTREAM_TEXCOORD0 + i) * 3 + 2 ] = ((GTE_CONST_DEST + __Tex0_dest + i*4)<<20) | 
															((__GLSTATE__.m_TexturePointer[i].m_Size - 1)<<8) | 
															(unsigned int)HALType;
			}
			else
			{
				gteConst[__Tex0_dest + 4*i + 0] = VF2F(__GLSTATE__.m_DefaultTexCoord[i][0]);
				gteConst[__Tex0_dest + 4*i + 1] = VF2F(__GLSTATE__.m_DefaultTexCoord[i][1]);
				gteConst[__Tex0_dest + 4*i + 2] = 0.0f;//VF2F(__GLSTATE__.m_DefaultTexCoord[i][2]); // �����ϱ�� spec�� ���õǾ� ����.
				gteConst[__Tex0_dest + 4*i + 3] = 1.0f;//VF2F(__GLSTATE__.m_DefaultTexCoord[i][3]);
			}
		}
	}

	GLESHAL_SetGTEConst( 0, 4*7, gteConst );	// GTE input register �ʱⰪ ����.
	
	//Fog setting
	if( __GLSTATE__.m_Enable_FOG && __GLSTATE__.m_IsFogUpdated )
		SetFog();

	GLESHAL_SetVertexStreams( vertexStream );
	return bufferenableflag;
}


GLboolean RenderPrimitiveArrays( unsigned int StreamValidFlag, GLenum mode, GLint first, GLsizei count )
{

	if(!count)
		return GL_FALSE;
	
	GLboolean result = (GLboolean)GLESHAL_SetPrimitiveControl( StreamValidFlag, (GLESHAL_INDEXTYPE)0, 
							__GLSTATE__.m_IsPrimitiveCacheClear, 
							( (GL_LINE_LOOP==mode) ? GL_TRUE : GL_FALSE ) , 
							GL_FALSE, 
							__GLSTATE__.m_Enable_MATRIX_PALETTE_OES,
							first, first + count - 1 );

	if( !result ) return GL_FALSE;

	if( ( (mode == GL_TRIANGLE_STRIP) | ( mode == GL_TRIANGLE_FAN) | ( mode == GL_TRIANGLES) ) && 
		( __GLSTATE__.m_Enable_LIGHTING ) && ( __GLSTATE__.m_TwoSidedLightning ) ) 
	{
		float gteConst[4];
		gteConst[0] = gteConst[1] = gteConst[2] = -1.0f * __ConstForNormalize__;
		gteConst[3] = 1.0f;

		if( __GLSTATE__.m_Enable_CULL_FACE )
		{
			if( __GLSTATE__.m_CullFace == GL_FRONT )
			{
				GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
			}
			result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		}
		else
		{
			unsigned long curRenderState = GLESHAL_GetRenderState();
			// back face culling and draw
			GLESHAL_SetRenderState( curRenderState | GLESHAL_RS_BACKFACECULL_ENB );
			GLESHAL_SetCullFace( GLESHAL_CULLFACE_BACK );
			result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

			// front face culling and draw
			GLESHAL_SetCullFace( GLESHAL_CULLFACE_FRONT );
			GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
			result |= (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

			GLESHAL_SetRenderState( curRenderState );	// culling disable ����.
			//glCullFace( __GLSTATE__.m_CullFace );		// culling mode ����.
			
			//result = (GLboolean)GLESHAL_RunPrimitive();	// test
		}

		if( !result ) return GL_FALSE;	
	}
	else
	{
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		if( !result ) return GL_FALSE;	
	}

	SetBufferUseLog();		// ����� ���۵鿡 ���� use point ǥ��.
	InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.

	return GL_TRUE;
}

GLboolean RenderPrimitiveElements( unsigned int StreamValidFlag, GLenum mode, GLsizei count )
{
	if(!count)
		return GL_FALSE;
	
	unsigned int StartIndexAddr = (unsigned int)GetIndexAddress( 0, count );
	
	GLboolean result = (GLboolean)GLESHAL_SetPrimitiveControl( StreamValidFlag, 
							(GLESHAL_INDEXTYPE)(__GLSTATE__.m_IndexPointer.m_Type), 
							__GLSTATE__.m_IsPrimitiveCacheClear, 
							( (GL_LINE_LOOP==mode) ? GL_TRUE : GL_FALSE ),
							GL_TRUE, 
							__GLSTATE__.m_Enable_MATRIX_PALETTE_OES,
							StartIndexAddr, 
							StartIndexAddr + ( (count-1) * __GLSTATE__.m_IndexPointer.m_Stride ) );
							
	if( !result ) return GL_FALSE;
	
	if( ( (mode == GL_TRIANGLE_STRIP) | ( mode == GL_TRIANGLE_FAN) | ( mode == GL_TRIANGLES) ) && 
		( __GLSTATE__.m_Enable_LIGHTING ) && ( __GLSTATE__.m_TwoSidedLightning ) ) 
	{
		float gteConst[4];
		gteConst[0] = gteConst[1] = gteConst[2] = -1.0f * __ConstForNormalize__;
		gteConst[3] = 1.0f;

		if( __GLSTATE__.m_Enable_CULL_FACE )
		{
			if( __GLSTATE__.m_CullFace == GL_FRONT )
			{
				GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
			}
			result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		}
		else
		{
			unsigned long curRenderState = GLESHAL_GetRenderState();
			// back face culling and draw
			GLESHAL_SetRenderState( curRenderState | GLESHAL_RS_BACKFACECULL_ENB );
			GLESHAL_SetCullFace( GLESHAL_CULLFACE_BACK );
			result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

			// front face culling and draw
			GLESHAL_SetCullFace( GLESHAL_CULLFACE_FRONT );
			GLESHAL_SetGTEConst( __Normalize_const_dest, sizeof(gteConst)/sizeof(gteConst[0]), gteConst );
			result |= (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering

			GLESHAL_SetRenderState( curRenderState );	// culling disable ����.
			//glCullFace( __GLSTATE__.m_CullFace );		// culling mode ����.
			
			//result = (GLboolean)GLESHAL_RunPrimitive();	// test
		}

		if( !result ) return GL_FALSE;	
	}
	else
	{
		result = (GLboolean)GLESHAL_RunPrimitive();	// primitive rendering
		if( !result ) return GL_FALSE;	
	}

	SetBufferUseLog();	// ����� ���۵鿡 ���� use point ǥ��.
	InitCurrentPrimitive();	// current primitivepointer���� NULL�� �ʱ�ȭ.	

	return GL_TRUE;
}


GLboolean SetPrimitiveControlParam( GLenum mode )
{
	if( __GLSTATE__.m_DrawMode == mode )
		return GL_TRUE;
		
	switch( mode )
	{
	case GL_POINTS:
		//GLESHAL_SetParamData( 0, 2, 0, 0, 0 );
		//GLESHAL_SetPrimitiveParamLoopControl( 0, 0 );
		break;
	case GL_LINE_STRIP:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );		
		GLESHAL_SetPrimitiveParamLoopControl( 1, 1 );
		break;
	case GL_LINE_LOOP:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );		
		GLESHAL_SetPrimitiveParamLoopControl( 1, 1 );
		break;
	case GL_LINES:
		GLESHAL_SetParamData( 0, 0, 4, 0, 0 );	
		GLESHAL_SetPrimitiveParamLoopControl( 0, 1 );
		break;
	case GL_TRIANGLE_STRIP:
		GLESHAL_SetParamData( 0, 0, 1, 6, 12 );
		GLESHAL_SetParamData( 1, 5, 14, 4, 13 );
		GLESHAL_SetPrimitiveParamLoopControl( 2, 7 );
		break;
	case GL_TRIANGLE_FAN:
		GLESHAL_SetParamData( 0, 0, 1, 6, 13 );
		GLESHAL_SetPrimitiveParamLoopControl( 2, 3 );
		break;
	case GL_TRIANGLES:
		GLESHAL_SetParamData( 0, 0, 1, 6, 0 );
		GLESHAL_SetPrimitiveParamLoopControl( 0, 2 );
		break;
	default:
		return GL_FALSE; 
	}

	__GLSTATE__.m_DrawMode = mode;
	return GL_TRUE;
}

void DestroyDefaultBuffer( void )
{
	GLESHAL_Flush();
	if( __GLSTATE__.m_DefaultPositionBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultPositionBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultPositionBuffer.m_DataMemory1D );
	}

	if( __GLSTATE__.m_DefaultColorBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultColorBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultColorBuffer.m_DataMemory1D );
	}

	int i = 0;
	for( i=0; i<GLPARAM_MAX_TEXTURE_UNITS; i++ )
	{
		if( __GLSTATE__.m_DefaultTexCoordBuffer[i].m_DataMemory1D.MemoryHandle )
		{
			while( __GLSTATE__.m_DefaultTexCoordBuffer[i].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultTexCoordBuffer[i].m_DataMemory1D );
		}
	}

	if( __GLSTATE__.m_DefaultNormalBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultNormalBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultNormalBuffer.m_DataMemory1D );
	}

	if( __GLSTATE__.m_DefaultPointSizeBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultPointSizeBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultPointSizeBuffer.m_DataMemory1D );
	}

	if( __GLSTATE__.m_DefaultWeightBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultWeightBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultWeightBuffer.m_DataMemory1D );
	}

	if( __GLSTATE__.m_DefaultMatrixIndexBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultMatrixIndexBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultMatrixIndexBuffer.m_DataMemory1D );
	}

	for( i=0; i<GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES; i++ )
	{
		while( __GLSTATE__.m_DefaultMatrixPalette[i].m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
	
		if( __GLSTATE__.m_DefaultMatrixPalette[i].m_DataMemory1D.MemoryHandle )
			GLESOAL_Free1D( &__GLSTATE__.m_DefaultMatrixPalette[i].m_DataMemory1D );			
	}
	
	if( __GLSTATE__.m_DefaultIndexBuffer.m_DataMemory1D.MemoryHandle )
	{
		while( __GLSTATE__.m_DefaultIndexBuffer.m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
		GLESOAL_Free1D( &__GLSTATE__.m_DefaultIndexBuffer.m_DataMemory1D );
	}
}

void SetCurMatrixPaletteBufferIndex( void )
{
	__GLSTATE__.m_CurMatrixPaletteBufferIndex = 
				( __GLSTATE__.m_CurMatrixPaletteBufferIndex + 1 ) % GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES;

	__GLSTATE__.m_CurrentPrimitive.m_pMatrixPalette = 
				&(__GLSTATE__.m_DefaultMatrixPalette[ __GLSTATE__.m_CurMatrixPaletteBufferIndex ]);
}

void EnableMatrixPaletteUpdate( GLint index ) 
{
	GLint row = index / 8;
	GLint col = index % 8;
	for( int i=0; i<GLPARAM_MAX_MATRIXPALETTE_BUFFER_OES; i++ )
	{
		__GLSTATE__.m_MatrixPaletteUpdateFlag[i][row] |= (1<<col);
	}
}


}	// namespace __MES_OPENGL_ES__


