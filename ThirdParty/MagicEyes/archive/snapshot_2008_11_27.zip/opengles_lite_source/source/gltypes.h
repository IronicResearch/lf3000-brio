//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : gltypes.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/02 Yuni	change Color8888 type to float array that has 4 elements.
//	   2006/03/15 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLTYPES_H
#define _GLTYPES_H

#ifdef _WIN32
	#include <stdio.h>
	#define MES_TRACE( exp ) printf exp
#elif defined(__arm)
	#include <stdio.h>
	#define MES_TRACE( exp ) printf exp
#elif defined(__GNUC__)
	#define MES_TRACE( exp )
#else
	#error "Unknown platform"
#endif

namespace __MES_OPENGL_ES__
{

/*
union Color8888
{
	unsigned char argb[4]; // 0:b 1:g 2:r 3:a
	unsigned int  color32;	
};
*/

//struct Color9999
//{
//	unsigned short argb[4]; // 0:b 1:g 2:r 3:a
//};

#include <float.h>
#include "glfixed.h"

#define NULL	0

#define INTERNAL_FLOAT 
#ifdef INTERNAL_FLOAT
	// internal float type
	typedef float Vfloat;
	#define VFONE	F2VF(1.0f)
	#define VFPINFINITY	( FLT_MAX)  // +infinity
	#define VFNINFINITY	(-FLT_MAX) // -infinity
	#define F2VF(f)	(Vfloat)(f)
	#define I2VF(f)	(Vfloat)(f)
	#define X2VF(f)	(Vfloat)Fixed2Float(f)
	#define VF2F(f)	(float)(f)
	#define VF2I(f)	(int)(f)
	#define VF2X(f)	Float2Fixed(f)
	#define VFABS(f) ( ((f)<0) ? (-(f)) : (+(f)) )

	// internal clamped float type [0.0f~1.0f]
	typedef float Vclampf;
	#define VCFONE		F2VCF(1.0f)
	#define F2VCF(f)	(Vclampf)(f)
	#define I2VCF(f)	(Vclampf)(f)
	#define X2VCF(f)	(Vclampf)Fixed2Float(f)
	#define VCF2F(f)	(float)(f)
	#define VCF2I(f)	(int)(f)
	#define VCF2X(f)	Float2Fixed(f)
	#define VCFABS(f)   ( ((f)<0) ? (-(f)) : (+(f)) )

	#define VFMUL( f1,f2 )	(Vfloat)((f1)*(f2))
	#define VFDIV( f1,f2 )	(Vfloat)((f1)/(f2))
	#define VFINV( f )		((0!=(f)) ? VFDIV( F2VF(1),f ) : VFPINFINITY )
	#define VFSQRT( f )		F2VF(sqrt(VF2F(f)))
	#define VFINVSQRT( f )	VFINV(F2VF(sqrt(VF2F(f))))
#else // #ifdef INTERNAL_FLOAT
	// internal float type
	typedef int Vfloat;
	#define VFONE		GLFIXED_ONE
	#define VFPINFINITY	(GLFIXED_PINF) // +infinity
	#define VFNINFINITY	(GLFIXED_MINF) // -infinity
	#define F2VF(f)		Float2Fixed(f)
	#define I2VF(f)		Int2Fixed(f)
	#define X2VF(f)		(f)
	#define VF2F(f)		Fixed2Float(f)
	#define VF2I(f)		Fixed2Int(f)
	#define VF2X(f)		(f)
	#define VFABS(f)	( ((f)<0) ? (-(f)) : (+(f)) )

	// internal clamped float type [0.0f~1.0f]
	typedef int Vclampf;
	#define VCFONE		F2VCF(1.0f)
	#define F2VCF(f)	Float2Fixed(f)
	#define I2VCF(f)	Int2Fixed(f)
	#define X2VCF(f)	(f)
	#define VCF2F(f)	Fixed2Float(f)
	#define VCF2I(f)	Fixed2Int(f)
	#define VCF2X(f)	(f)
	#define VCFABS(f)   ( ((f)<0) ? (-(f)) : (+(f)) )

	#define VFMUL( f1,f2 )	(Vfloat)(((__int64)(f1)*(f2))>>GLFIXED_PRECISION)
	#define VFDIV( f1,f2 )	(Vfloat)(((__int64)(f1)<<GLFIXED_PRECISION)/(f2))
	#define VFINV( f )		((0!=(f)) ? VFDIV( VFONE,f ) : VFPINFINITY )
	#define VFSQRT( f )		F2VF(sqrt(VF2F(f)))
	#define VFINVSQRT( f )	VFINV(F2VF(sqrt(VF2F(f))))
#endif

} // namespace __MES_OPENGL_ES__
using namespace __MES_OPENGL_ES__;

#endif // _GLTYPES_H

