//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glfixed.h
//	Description: 
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/03/15 Gamza first implementation in HOME
//------------------------------------------------------------------------------
#ifndef _GLFIXED_H
#define _GLFIXED_H

#include "GLES/gl.h"

#define GLFIXED_PRECISION	16					    // number of fractional bits
#define GLFIXED_ONE			(1 << GLFIXED_PRECISION)	// representation of 1
#define GLFIXED_ZERO	    0						// representation of 0
#define GLFIXED_HALF	    0x08000				// S15.16 0.5 
#define GLFIXED_PINF	    0x7fffffff			// +inf 
#define GLFIXED_MINF	    0x80000000			// -inf 

#define GLFIXED_2PI			FixedFromFloat(6.28318530717958647692f)
#define GLFIXED_R2PI		FixedFromFloat(1.0f/6.28318530717958647692f)

#define Float2Fixed(value) static_cast<GLfixed>((value) * static_cast<float>(GLFIXED_ONE))
#define Fixed2Float(value) ((value) * (1.0f/static_cast<float>(GLFIXED_ONE)))

#define Fixed2Int(value) ((int)((value) >> GLFIXED_PRECISION))
#define Int2Fixed(value) ((GLfixed)((value) << GLFIXED_PRECISION))


#endif // _GLFIXED_H




// #ifndef FIXED_FIXED_H
// #define FIXED_FIXED_H 1
// 
// // ==========================================================================
// //
// // fixed.h	Implementation of Fixed Point Arithmetic
// //			If Intel Graphics Performance Primitives (GPP) are available,
// //			the functions defined in this header should be mapped to
// //			the assembler primitives provided in this library.
// //
// //			Fixed point numbers are represented in 16.16 format, where
// //			the high 16 bits represent the signed integer part, while the
// //			lower 16 bits represent the fractional part of a number.
// //
// // --------------------------------------------------------------------------
// //
// // 08-07-2003	Hans-Martin Will	initial version
// // 10-02-2003	Hans-Martin Will	reworked to make this header file 
// //									platform indepdendent
// //
// // --------------------------------------------------------------------------
// //
// // Copyright (c) 2004, Hans-Martin Will. All rights reserved.
// // 
// // Redistribution and use in source and binary forms, with or without 
// // modification, are permitted provided that the following conditions are 
// // met:
// // 
// //	 *  Redistributions of source code must retain the above copyright
// // 		notice, this list of conditions and the following disclaimer. 
// //   *	Redistributions in binary form must reproduce the above copyright
// // 		notice, this list of conditions and the following disclaimer in the 
// // 		documentation and/or other materials provided with the distribution. 
// // 
// // THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// // AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
// // IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
// // ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
// // LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
// // OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
// // SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// // INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
// // CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
// // ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
// // THE POSSIBILITY OF SUCH DAMAGE.
// //
// // ==========================================================================
// 
// 
// #include "OGLES.h"
// #include <math.h>
// #include <assert.h>
// 
// 
// // --------------------------------------------------------------------------
// // Constants
// // --------------------------------------------------------------------------
// 
// 
// #define GLFIXED_PRECISION 16					// number of fractional bits
// #define GLFIXED_ONE		  (1 << GLFIXED_PRECISION)	// representation of 1
// #define GLFIXED_ZERO	  0						// representation of 0
// #define GLFIXED_HALF	  0x08000				// S15.16 0.5 
// #define GLFIXED_PINF	  0x7fffffff			// +inf 
// #define GLFIXED_MINF	  0x80000000			// -inf 
// 
// #define GLFIXED_2PI			FIXED_FixedFromFloat(6.28318530717958647692f)
// #define GLFIXED_R2PI		FIXED_FixedFromFloat(1.0f/6.28318530717958647692f)
// 
// typedef S32 FIXED_Fixed;
// 
// #define F FIXED_FixedFromFloat
// 
// 
// inline static S32 FIXED_CLAMP(S32 value, S32 min, S32 max) {
// 	if (value < min) {
// 		return min;
// 	} else if (value > max) {
// 		return max;
// 	} else {
// 		return value;
// 	}
// }
// 
// inline static U32 FIXED_CLAMP(U32 value, U32 min, U32 max) {
// 	if (value < min) {
// 		return min;
// 	} else if (value > max) {
// 		return max;
// 	} else {
// 		return value;
// 	}
// }
// 
// 
// static inline S32 FIXED_Abs(S32 value) {
// 	if (value < 0) {
// 		return -value;
// 	} else {
// 		return value;
// 	}
// }
// 
// 
// static inline S32 FIXED_Min(S32 first, S32 second) {
// 	return first < second ? first : second;
// }
// 
// 
// static inline S32 FIXED_Max(S32 first, S32 second) {
// 	return first > second ? first : second;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Convert integer value to fixed point number
// //
// // Parameters:
// //	value		-	Integer value to be converted to fixed point number
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_FixedFromInt(S32 value) {
// 	return value << GLFIXED_PRECISION;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Convert fixed point number to integer value
// //
// // Parameters:
// //	value		-	Fixed point number to be converted to integer value
// // --------------------------------------------------------------------------
// inline S32 FIXED_IntFromFixed(FIXED_Fixed value) {
// 	return value >> GLFIXED_PRECISION;
// }
// 
// 
// 
// // --------------------------------------------------------------------------
// // Retrieve fractional part from fixed point number 
// //
// // Parameters:
// //	value		-	Fractional part from fixed point number 
// // --------------------------------------------------------------------------
// inline S32 FIXED_FractionFromFixed(FIXED_Fixed value) {
// 	return value & ((1 << GLFIXED_PRECISION) - 1);
// }
// 
// 
// 
// // --------------------------------------------------------------------------
// // Convert fixed point number to integer value by round to nearest
// //
// // Parameters:
// //	value		-	Fixed point number to be rounded to integer value
// // --------------------------------------------------------------------------
// inline S32 FIXED_Round(FIXED_Fixed value) {
// 	return (value + GLFIXED_ONE/2) >> GLFIXED_PRECISION;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Round fixed point number to nearest integer value by round to nearest
// //
// // Parameters:
// //	value		-	Fixed point number to be rounded to integer value
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_NearestInt(FIXED_Fixed value) {
// 	return (value + (GLFIXED_ONE/2 - 1)) & 0xffff0000;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Convert floating point value to fixed point number
// //
// // Parameters:
// //	value		-	Floatin point value to be converted to fixed point number
// // --------------------------------------------------------------------------
// inline S32 FIXED_FixedFromFloat(float value) {
// 	return static_cast<FIXED_Fixed>(value * static_cast<float>(GLFIXED_ONE));
// }
// 
// 
// // --------------------------------------------------------------------------
// // Convert fixed point number to floating point value
// //
// // Parameters:
// //	value		-	Fixed point number to be converted to floating point 
// //					value
// // --------------------------------------------------------------------------
// inline float FIXED_FloatFromFixed(FIXED_Fixed value) {
// 	return value * (1.0f/static_cast<float>(GLFIXED_ONE));
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate product of two fixed point numbers
// //
// // Parameters:
// //	a			-	first operand
// //	b			-	second operand
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Mul(FIXED_Fixed a, FIXED_Fixed b) {
// 	return (FIXED_Fixed) (((S64) a * (S64) b)  >> GLFIXED_PRECISION);
// }
// 
// 
// #ifndef FIXED_USE_GPP
// // ==========================================================================
// // Implementation if GPP is not available
// // ==========================================================================
// 
// 
// // --------------------------------------------------------------------------
// // Calculate inverse of fixed point number
// //
// // Parameters:
// //	value		-	the number whose inverse should be calculated
// // --------------------------------------------------------------------------
// FIXED_Fixed FIXED_Inverse(FIXED_Fixed value);
// 
// 
// // --------------------------------------------------------------------------
// // Perform division of two fixed point numbers
// //
// // Parameters:
// //	a			-	dividend
// //	b			-	divisor
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Div(FIXED_Fixed a, FIXED_Fixed b) {
// 
// 	if ((b >> 24) && (b >> 24) + 1) {
// 		return FIXED_Mul(a >> 8, FIXED_Inverse(b >> 8));
// 	} else {
// 		return FIXED_Mul(a, FIXED_Inverse(b));
// 	}
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate square root of fixed point number
// //
// // Parameters:
// //	value		-	the number whose square root should be calculated
// // --------------------------------------------------------------------------
// FIXED_Fixed FIXED_Sqrt(FIXED_Fixed value);
// 
// 
// // --------------------------------------------------------------------------
// // Calculate the inverse of the square root of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose inverse of square root should be 
// //					calculated
// // --------------------------------------------------------------------------
// FIXED_Fixed FIXED_InvSqrt(FIXED_Fixed value);
// 
// 
// // --------------------------------------------------------------------------
// // Calculate square root of fixed point number; fast calculation using
// // inverse and inverse square root
// //
// // Parameters:
// //	value		-	the number whose square root should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_FastSqrt(FIXED_Fixed value) {
// 	return value <= 0 ? 0 : FIXED_Inverse(FIXED_InvSqrt(value));
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate sine of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose sine should be calculated
// // --------------------------------------------------------------------------
// FIXED_Fixed FIXED_Sin(FIXED_Fixed value);
// 
// 
// // --------------------------------------------------------------------------
// // Calculate cosine of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose cosine should be calculated
// // --------------------------------------------------------------------------
// FIXED_Fixed FIXED_Cos(FIXED_Fixed value);
// 
// 
// #else 
// // ==========================================================================
// // Implementation if GPP is available
// // ==========================================================================
// 
// 
// // --------------------------------------------------------------------------
// // Perform division of two fixed point numbers
// //
// // Parameters:
// //	a			-	dividend
// //	b			-	divisor
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Div(FIXED_Fixed a, FIXED_Fixed b) {
// 	assert(b);
// 	assert(-b);
// 	S32 result;
// 	gppDiv_16_32s(a, b, &result);
// 	return result;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate inverse of fixed point number
// //
// // Parameters:
// //	value		-	the number whose inverse should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Inverse(FIXED_Fixed value) {
// 	S32 result;
// 	assert(value);
// 	assert(-value);
// 	gppInv_16_32s(value, &result);
// 	return result;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate square root of fixed point number
// //
// // Parameters:
// //	value		-	the number whose square root should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_FastSqrt(FIXED_Fixed value) {
// 	U32 result;
// 	gppSqrtLP_16_32s(static_cast<U32>(value), &result);
// 	return static_cast<S32>(result);
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate square root of fixed point number
// //
// // Parameters:
// //	value		-	the number whose square root should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Sqrt(FIXED_Fixed value) {
// 	U32 result;
// 	gppSqrtHP_16_32s(static_cast<U32>(value), &result);
// 	return static_cast<S32>(result);
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate the inverse of the square root of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose inverse of square root should be 
// //					calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_InvSqrt(FIXED_Fixed value) {
// 	U32 result;
// 	gppInvSqrtLP_16_32s(static_cast<U32>(value), &result);
// 	return static_cast<S32>(result);
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate sine of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose sine should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Sin(FIXED_Fixed value) {
// 	S32 result;
// 	gppSinHP_16_32s(value, &result);
// 	return result;
// }
// 
// 
// // --------------------------------------------------------------------------
// // Calculate cosine of fixed point number
// //
// // Parameters:
// //	value		-	the numbers whose cosine should be calculated
// // --------------------------------------------------------------------------
// inline FIXED_Fixed FIXED_Cos(FIXED_Fixed value) {
// 	S32 result;
// 	gppCosHP_16_32s(value, &result);
// 	return result;
// }
// 
// 
// #endif // ndef FIXED_USE_GPP
// 
// 
// // --------------------------------------------------------------------------
// // Poor man's exponentiation, only exponents of 0, 1 and 2 are supported
// //
// // Parameters:
// //	value		-	the basis; assume 0 <= value <= 1
// //	exponent	-	the exponent, exponent >= 0
// // --------------------------------------------------------------------------
// GL_API FIXED_Fixed FIXED_Power(FIXED_Fixed value, FIXED_Fixed exponent);
// 
// 
// // --------------------------------------------------------------------------
// // map [0..1] to [0..1)
// // --------------------------------------------------------------------------
// inline static FIXED_Fixed FIXED_MAP_0_1(FIXED_Fixed value) {
// 	return FIXED_Mul(value, 0xffff);
// }
// 
// 
// // --------------------------------------------------------------------------
// // clamp to [0..1], then map into range 0 .. 2^k-1
// // --------------------------------------------------------------------------
// inline static U32 FIXED_MAP_BITFIELD(S32 value, unsigned bits) {
// 
// 	S32 mask = (1 << bits) - 1;
// 	return (U32) FIXED_Mul(FIXED_CLAMP(value, 0, GLFIXED_ONE), mask) & mask;
// }
// 
// 
// 
// 
// #endif //ndef FIXED_FIXED_H
