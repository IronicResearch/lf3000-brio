//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : hwbufferobject.h
//	Description: 
//	Author     : Yuni	(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2007/06/12 Yuni  first implementation
//------------------------------------------------------------------------------

#include "glstate.h"

#ifndef _HWBUFFEROBJECT_H
#define _HWBUFFEROBJECT_H

namespace __MES_OPENGL_ES__
{

#define GLPARAM_MAX_HWBUFFER_FOR_DRAWPRIMITIVE         64

	//extern GLuint		g_BindedHWBuffer[2];	// GL_ARRAY_BUFFER / GL_ELEMENT_ARRAY_BUFFER
	//extern ObjectPool<__HWBUFFER__ ,128,2> __HWBUFFER_POOL__;

	void __Initialize_HWBuffer__( void );
	GLboolean	SetupHWBufferToBufferObject( GLboolean IsIndex );

	void GetCurrentBufferObjectState( __CURRENT_BO_STATE__* pCurState );
	void SetCurrentBufferObjectState( const __CURRENT_BO_STATE__* pCurState );

} // namespace __MES_OPENGL_ES__

#endif // #ifndef _HWBUFFEROBJECT_H
