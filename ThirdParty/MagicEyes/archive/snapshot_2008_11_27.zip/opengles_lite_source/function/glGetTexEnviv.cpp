//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetTexEnviv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_9unq.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/08/25 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#define _C( c )		int( (c) * (double(0x7FFFFFFF)/255.0) )
#define _I( i )		int(i)
#define _B( b )		((b) ? 1 : 0 )
#define _BUF( buf )	int(buf)
#define _VF( v )	VF2I((v)+F2VF(0.5f))
#define _VCF( v )	int( VCF2F(v) * double(0x7FFFFFFF) )

void glGetTexEnviv (GLenum target, GLenum pname, GLint *params)
{
#	include "glGetTexEnvv.inl"
}
