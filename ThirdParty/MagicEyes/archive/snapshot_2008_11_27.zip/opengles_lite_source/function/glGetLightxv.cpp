//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetLightxv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_0644.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glGetLightxv (GLenum light, GLenum pname, GLfixed *params)
{
	if (light < GL_LIGHT0 || light > GL_LIGHT7) {
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__LIGHT__ * pLight = __GLSTATE__.m_Lights + (light - GL_LIGHT0);

	switch (pname) {
	case GL_AMBIENT:
		/*
		params[0] = Int2Fixed(pLight->m_AmbientColor.argb[2]) / 255; // r
		params[1] = Int2Fixed(pLight->m_AmbientColor.argb[1]) / 255; // g
		params[2] = Int2Fixed(pLight->m_AmbientColor.argb[0]) / 255; // b
		params[3] = Int2Fixed(pLight->m_AmbientColor.argb[3]) / 255; // a
		*/
		params[0] = VF2X(pLight->m_AmbientColor[0]); // r
		params[1] = VF2X(pLight->m_AmbientColor[1]); // g
		params[2] = VF2X(pLight->m_AmbientColor[2]); // b
		params[3] = VF2X(pLight->m_AmbientColor[3]); // a
		break;

	case GL_DIFFUSE:
		/*
		params[0] = Int2Fixed(pLight->m_DiffuseColor.argb[2]) / 255; // r
		params[1] = Int2Fixed(pLight->m_DiffuseColor.argb[1]) / 255; // g
		params[2] = Int2Fixed(pLight->m_DiffuseColor.argb[0]) / 255; // b
		params[3] = Int2Fixed(pLight->m_DiffuseColor.argb[3]) / 255; // a
		*/
		params[0] = VF2X(pLight->m_DiffuseColor[0]); // r
		params[1] = VF2X(pLight->m_DiffuseColor[1]); // g
		params[2] = VF2X(pLight->m_DiffuseColor[2]); // b
		params[3] = VF2X(pLight->m_DiffuseColor[3]); // a
		break;

	case GL_SPECULAR:
		/*
		params[0] = Int2Fixed(pLight->m_SpecularColor.argb[2]) / 255; // r
		params[1] = Int2Fixed(pLight->m_SpecularColor.argb[1]) / 255; // g
		params[2] = Int2Fixed(pLight->m_SpecularColor.argb[0]) / 255; // b
		params[3] = Int2Fixed(pLight->m_SpecularColor.argb[3]) / 255; // a
		*/
		params[0] = VF2X(pLight->m_SpecularColor[0]); // r
		params[1] = VF2X(pLight->m_SpecularColor[1]); // g
		params[2] = VF2X(pLight->m_SpecularColor[2]); // b
		params[3] = VF2X(pLight->m_SpecularColor[3]); // a
		break;

	case GL_POSITION:
		{
			params[0] = VF2X(pLight->m_Position.x); // x
			params[1] = VF2X(pLight->m_Position.y); // y
			params[2] = VF2X(pLight->m_Position.z); // z
			params[3] = VF2X(pLight->m_Position.w); // w
		}
		break;

	case GL_SPOT_DIRECTION:
		{
			params[0] = VF2X(pLight->m_Direction.x); // x
			params[1] = VF2X(pLight->m_Direction.y); // y
			params[2] = VF2X(pLight->m_Direction.z); // z
		}
		break;

	case GL_SPOT_EXPONENT:
		params[0] = VF2X(pLight->m_SpotExponent);
		break;

	case GL_SPOT_CUTOFF:
		params[0] = VF2X(pLight->m_SpotCutoff);
		break;

	case GL_CONSTANT_ATTENUATION:
		params[0] = VF2X(pLight->m_ConstantAttenuation);
		break;

	case GL_LINEAR_ATTENUATION:
		params[0] = VF2X(pLight->m_LinearAttenuation);
		break;

	case GL_QUADRATIC_ATTENUATION:
		params[0] = VF2X(pLight->m_QuadraticAttenuation);
		break;

	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
}


