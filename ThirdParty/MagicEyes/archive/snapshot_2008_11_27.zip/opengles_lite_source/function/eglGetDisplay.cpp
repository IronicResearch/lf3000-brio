//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglGetDisplay.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


struct stDisplay 
{
	int nType;	
};

static struct stDisplay DefaultDisplay = {(int)EGL_DEFAULT_DISPLAY};

EGLDisplay eglGetDisplay (NativeDisplayType display)
{
	// !!! defalutDisplay�� �������� �ؾ� �ұ�?
	//EGLDisplay defaultDisplay = 0;

	if( __EGLSTATE__.m_isInit)
		return __EGLSTATE__.m_pCurDisplay;

	//if( !display )
	//	return EGL_NO_DISPLAY;

	if( display == EGL_DEFAULT_DISPLAY )
	{
		__EGLSTATE__.m_pCurDisplay = &DefaultDisplay;//defaultDisplay;
		return __EGLSTATE__.m_pCurDisplay;
	}

	__EGLSTATE__.m_pCurDisplay = display;
	
	return __EGLSTATE__.m_pCurDisplay;
}
