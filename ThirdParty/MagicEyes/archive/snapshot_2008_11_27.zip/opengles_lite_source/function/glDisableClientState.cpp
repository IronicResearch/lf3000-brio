//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDisableClientState.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_72at.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/28 Yuni	add hardware buffer object
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glDisableClientState (GLenum array)
{
	switch( array )
	{
	case GL_COLOR_ARRAY:			__GLSTATE__.m_ClientState_COLOR_ARRAY           = GL_FALSE; break;
	case GL_NORMAL_ARRAY:			__GLSTATE__.m_ClientState_NORMAL_ARRAY          = GL_FALSE; break;
	case GL_TEXTURE_COORD_ARRAY:	
		__GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[__GLSTATE__.m_ClientActiveTexture] = GL_FALSE; break;
	case GL_VERTEX_ARRAY:			__GLSTATE__.m_ClientState_VERTEX_ARRAY          = GL_FALSE; break;
	case GL_WEIGHT_ARRAY_OES:		__GLSTATE__.m_ClientState_WEIGHT_ARRAY_OES      = GL_FALSE; break;
	case GL_MATRIX_INDEX_ARRAY_OES:	__GLSTATE__.m_ClientState_MATRIX_INDEX_ARRAY_OES= GL_FALSE; break;
	case GL_POINT_SIZE_ARRAY_OES:	__GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES	= GL_FALSE; break;
	case GL_HARDWAREBUFFER_ARRAY_OES:	
		__GLSTATE__.m_ClientState_HARDWAREBUFFER_ARRAY_OES	= GL_FALSE; 
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		break;
	}
}
