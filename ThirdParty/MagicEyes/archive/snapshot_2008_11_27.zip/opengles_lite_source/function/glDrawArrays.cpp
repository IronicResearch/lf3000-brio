//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDrawArrays.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_8oqb.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2007/11/05 Yuni  Vertex array�� ���� client state�� disable�� ��쿡 ���� ó�� �߰�.
//		2007/10/17 Yuni  HW buffer object ��� �� ���� ���� �� ����
//	    2006/11/28 Yuni	add hardware buffer object
//	    2006/10/16 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
//#include "../source/preparerendering.h"
#include "../source/renderprimitives.h"
#include "../source/gtecode.h"
#include "../source/hwbufferobject.h"

void glDrawArrays (GLenum mode, GLint first, GLsizei count)
{
	//printf("-arrays- (count:%d, mode:%d)\n", count, mode );

	if( !SetPrimitiveControlParam( mode ) )	// mode �˻�� �Բ� primitive control parameter ����.
	{ GLSETERROR(GL_INVALID_ENUM); return; }

	if( 0 > count ){ GLSETERROR(GL_INVALID_VALUE); return; }

	if( ( mode == GL_TRIANGLE_STRIP || mode == GL_TRIANGLE_FAN   || mode == GL_TRIANGLES )
		&& __GLSTATE__.m_Enable_CULL_FACE && __GLSTATE__.m_CullFace == GL_FRONT_AND_BACK )
	{
		//	�������ε�, �ø��ɼ��� GL_FRONT_AND_BACK�̸� �׸��� �ʴ´�.
		return;
	}


	// HW buffer object�� ó��.
	__CURRENT_BO_STATE__ pState;
	if( __GLSTATE__.m_ClientState_HARDWAREBUFFER_ARRAY_OES )
	{
		if( count <= 0 )
			return;
		
		GetCurrentBufferObjectState( &pState );

		if( !SetupHWBufferToBufferObject( GL_FALSE ) )	// primitive control prarmeter setting
			return;
	}
	else if( !__GLSTATE__.m_ClientState_VERTEX_ARRAY )
		return;		

	// point�� ��� perspective correction�� ����.
	if( (GL_POINTS==mode) || (GL_LINE_STRIP==mode) || (GL_LINES==mode) || (GL_LINE_LOOP==mode) )
	{
		unsigned long curRenderState = GLESHAL_GetRenderState();

		if(GL_POINTS==mode)
			curRenderState &= ~GLESHAL_RS_PERSPECTIVE_ENB;

		curRenderState &= ~GLESHAL_RS_BACKFACECULL_ENB;
		GLESHAL_SetRenderState( curRenderState );
	}

	unsigned int streamValid = Preparerendering( first, count );
	if( !streamValid )
		return;
	PrepareRenderingGTE( mode );
	RenderPrimitiveArrays( streamValid, mode, 0, count );

	// ���� perspective correction�� �ٽ� �Ҵ�.
	if( (GL_POINTS==mode) || (GL_LINE_STRIP==mode) || (GL_LINES==mode) || (GL_LINE_LOOP==mode) )
	{
		unsigned long curRenderState = GLESHAL_GetRenderState();
		curRenderState |= GLESHAL_RS_PERSPECTIVE_ENB;

		if(__GLSTATE__.m_Enable_CULL_FACE)
			curRenderState |= GLESHAL_RS_BACKFACECULL_ENB;

		GLESHAL_SetRenderState( curRenderState );
	}
	__GLSTATE__.m_IsPrimitiveCacheClear = GL_FALSE;
	
	// HW buffer object�� ó��.
	if( __GLSTATE__.m_ClientState_HARDWAREBUFFER_ARRAY_OES )
	{
		SetCurrentBufferObjectState( &pState );						
	}	
}

