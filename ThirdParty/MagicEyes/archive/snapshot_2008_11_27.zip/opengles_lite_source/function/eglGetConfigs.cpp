//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglGetConfigs.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/08/02 Gamza FSAA�� ���� SAMPLE_BUFFERS�� 1�� config�߰�.
//	   2006/04/24 Gamza __EGLSTATE__.m_isInit �� ������� ȣ�Ⱑ���� �Լ���.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

EGLBoolean eglGetConfigs (EGLDisplay dpy, EGLConfig *configs, EGLint config_size, EGLint *num_config)
{
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_PARAMETER is generated if num_config is NULL.

	//if (!__EGLSTATE__.m_isInit) 
	//{
	//	EGLSETERROR( EGL_NOT_INITIALIZED );
	//	return EGL_FALSE;
	//}

	if ( ! num_config )
	{
		EGLSETERROR( EGL_BAD_PARAMETER );
		return EGL_FALSE;
	}
	
	if ( !configs )
	{
		// special case: inquire number of configurations available
		(*num_config) = __EGL_Number_Of_Configurations__;//__EGLSTATE__.m_NumOfConfigs;
		return EGL_TRUE;
	}

	if ( config_size <= 0 )
	{
		EGLSETERROR( EGL_BAD_PARAMETER );
		return EGL_FALSE;
	}

	if( __EGLSTATE__.m_pCurDisplay != dpy)
	{
		EGLSETERROR( EGL_BAD_DISPLAY );
	}
	//if (config_size > 1) { config_size = 1; }

	for( (*num_config)=0;
		 (*num_config) < __EGL_Number_Of_Configurations__ &&
		 (*num_config) < config_size;
		 (*num_config)++ )
	{
		configs[(*num_config)]  = (EGLConfig)(&__EGL_Configuration__[(*num_config)]);
	}
	return EGL_TRUE;
}







