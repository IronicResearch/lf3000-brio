//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDepthFunc.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_5kkj.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

void glDepthFunc (GLenum func)
{
	switch( func )
	{
	case GL_NEVER: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_NEVER );
		break;
	case GL_LESS: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_LESS );
		break;
	case GL_LEQUAL: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_LESSEQUAL );
		break;
	case GL_EQUAL: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_EQUAL );
		break;
	case GL_GREATER: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_GREATER );
		break;
	case GL_NOTEQUAL: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_NOTEQUAL );
		break;
	case GL_GEQUAL: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_GREATEREQUAL );
		break;
	case GL_ALWAYS: 
		GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC_ALWAYS );
		break;
	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__GLSTATE__.m_DepthFunc = func;
}
