//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglQueryContext.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglQueryContext (EGLDisplay dpy, EGLContext ctx, EGLint attribute, EGLint *value)
{
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.
	
	//	EGL_BAD_CONTEXT is generated if context is not an EGL rendering context.
	//__GLSTATESET__* pglstate = (__GLSTATESET__*)ctx;
	//if( ! pglstate || EGLCONFIG_FLAG != pglstate->m_Config.m_EGLCONFIG )
	//{
	//	EGLSETERROR( EGL_BAD_CONTEXT );
	//	return EGL_FALSE;
	//}

	//return eglGetConfigAttrib (dpy, (EGLConfig)&pglstate->m_Config, attribute, value);
	return 0;
}
