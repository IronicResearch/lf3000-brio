//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glColor4x.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_62b6.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

// These functions set the current color.

//	for GL
//	glColor3b, glColor3d, glColor3f, glColor3i, glColor3s, 
//	glColor3ub, glColor3ui, glColor3us, glColor4b, glColor4d, 
//	glColor4f, glColor4i, glColor4s, glColor4ub, glColor4ui, 
//	glColor4us, glColor3bv, glColor3dv, glColor3fv, glColor3iv, 
//	glColor3sv, glColor3ubv, glColor3uiv, glColor3usv, 
//	glColor4bv, glColor4dv, glColor4fv, glColor4iv, glColor4sv, 
//	glColor4ubv, glColor4uiv, glColor4usv.

//	for GL-ES
//	glColor4f, glColor4ub, glColor4x

// The glColor3 variants specify new red, green, and blue values explicitly, and set the current alpha value to 1.0 implicitly. 
// The glColor4 variants specify all four color components explicitly. 

//	Current color values are stored in floating-point format,
//	
//	glGet with argument GL_CURRENT_COLOR
//	glGet with argument GL_RGBA_MODE


void glColor4x (GLfixed red, GLfixed green, GLfixed blue, GLfixed alpha)
{
	__GLSTATE__.m_CurrentColor[0] = X2VF( CLAMPX(red) );
	__GLSTATE__.m_CurrentColor[1] = X2VF( CLAMPX(green) );
	__GLSTATE__.m_CurrentColor[2] = X2VF( CLAMPX(blue) );
	__GLSTATE__.m_CurrentColor[3] = X2VF( CLAMPX(alpha) );
}
