//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexImage2D.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/07 Yuni	size�� 0�̾ error�� �ƴ�. ���, memory�� �Ҵ���� �ʴ´�.
//	   2007/09/06 Gamza 2�� ��� ������ IsValidTextureSize�Լ������� Ǯ�����.
//	   2007/09/06 Gamza pixels�� NULL�̸� �����͸� ���ε� ���� �ʰ�
//						���������� �ؽ��İ� �����Ǿ�� ��.
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//GL_INVALID_ENUM is generated if target is not GL_TEXTURE_2D.
//GL_INVALID_ENUM is generated if format is not an accepted constant.
//GL_INVALID_ENUM is generated if type is not a type constant.
//GL_INVALID_VALUE is generated if level is less than 0.
//GL_INVALID_VALUE may be generated if level is greater than log2max, where max is the returned value of GL_MAX_TEXTURE_SIZE.
//GL_INVALID_VALUE is generated if internalformat is not an accepted constant.
//GL_INVALID_VALUE is generated if width or height is less than 0 or greater than GL_MAX_TEXTURE_SIZE, or if either cannot be represented as 2k + 2border for some integer k.
//GL_INVALID_VALUE is generated if border is not 0.
//GL_INVALID_OPERATION is generated if internalformat and format are not the same.
//GL_INVALID_OPERATION is generated if type is GL_UNSIGNED_SHORT_5_6_5 and format is not GL_RGB.
//GL_INVALID_OPERATION is generated if typeis one of GL_UNSIGNED_SHORT_4_4_4_4, or GL_UNSIGNED_SHORT_5_5_5_1 and formatis not GL_RGBA.
namespace {

	GLint (* UploadTexture)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* CreateMipmapTexture)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* UploadMipmap)( const GLESOAL_MEMORY2D* pMemory2D, 
							unsigned int X, unsigned int Y,
							unsigned int Width, unsigned int Height, 
							const void* pSrc, unsigned int SrcStride );

	GLint (* CopyTexture)( const GLESOAL_MEMORY2D* pSrcMemory2D, 
							const GLESOAL_MEMORY2D* pDstMemory2D, 
							unsigned int Width, unsigned int Height );

	GLint (* GetMipmapPosition)(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
								  unsigned int *X, unsigned int *Y );

	GLboolean GetInfomation( GLenum format,	GLenum type, int &TexBitCount, int &MemBitCount )
	{
		{
			switch( format )
			{
			case GL_ALPHA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						TexBitCount = 1;
						MemBitCount = 1;
						UploadTexture = GLESOAL_UploadTexture_A8;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_A8;
						UploadMipmap		= GLESOAL_UploadMipmap_U8;
						CopyTexture			= GLESOAL_CopyTexture_U8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U8;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_RGB:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						TexBitCount = 2;
						MemBitCount = 3;
						UploadTexture = GLESOAL_UploadTexture_RGB8;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_RGB8;
						UploadMipmap		= GLESOAL_UploadMipmap_RGB8;
						CopyTexture			= GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_5_6_5 )
					{
						TexBitCount = 2;
						MemBitCount = 2;
						UploadTexture = GLESOAL_UploadTexture_R5G6B5;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_R5G6B5;
						UploadMipmap = GLESOAL_UploadMipmap_U16;
						CopyTexture	 = GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_RGBA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						TexBitCount = 2;
						MemBitCount = 4;
						UploadTexture = GLESOAL_UploadTexture_RGBA8;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_RGBA8;
						UploadMipmap = GLESOAL_UploadMipmap_RGBA8;
						CopyTexture	 = GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_4_4_4_4 )
					{
						TexBitCount = 2;
						MemBitCount = 2;
						UploadTexture = GLESOAL_UploadTexture_RGBA4;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_RGBA4;
						UploadMipmap = GLESOAL_UploadMipmap_U16;
						CopyTexture	 = GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else if ( type == GL_UNSIGNED_SHORT_5_5_5_1 )
					{
						TexBitCount = 2;
						MemBitCount = 2;
						UploadTexture = GLESOAL_UploadTexture_RGB5A1;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_RGB5A1;
						UploadMipmap = GLESOAL_UploadMipmap_U16;
						CopyTexture	 = GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_LUMINANCE:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						TexBitCount = 1;
						MemBitCount = 1;
						UploadTexture = GLESOAL_UploadTexture_L8;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_L8;
						UploadMipmap = GLESOAL_UploadMipmap_U8;
						CopyTexture	 = GLESOAL_CopyTexture_U8;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U8;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			case GL_LUMINANCE_ALPHA:
				{
					if ( type == GL_UNSIGNED_BYTE )
					{
						TexBitCount = 2;
						MemBitCount = 2;
						UploadTexture = GLESOAL_UploadTexture_LA8;
						CreateMipmapTexture = GLESOAL_CreateMipmapTexture_LA8;
						UploadMipmap = GLESOAL_UploadMipmap_U16;
						CopyTexture	 = GLESOAL_CopyTexture_U16;
						GetMipmapPosition	= GLESOAL_GetMipmapPosition_U16;
					}
					else 
					{
						GLSETERROR(GL_INVALID_OPERATION);
						return GL_FALSE;
					}
				}
				break;
			default:
				GLSETERROR(GL_INVALID_VALUE);
				return GL_FALSE;;
			}
		}	
		return GL_TRUE;
	}
}


void glTexImage2D (GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels)
{
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}

	// ���� texture�� ��������� ��.	
	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( border != 0 )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( type	!= GL_UNSIGNED_BYTE &&
		 type	!= GL_UNSIGNED_SHORT_5_6_5 &&
		 type	!= GL_UNSIGNED_SHORT_4_4_4_4 &&
		 type	!= GL_UNSIGNED_SHORT_5_5_5_1 )
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}


	if ( (width < 0 || width > GLPARAM_MAX_TEXTURE_SIZE ) ||
	   (height < 0 || height > GLPARAM_MAX_TEXTURE_SIZE ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	/*
	// �������̾�� �Ѵٴ� ������ �ϴ��� Ǯ�������. -> IsValidTextureSize �Լ����ο��� Ǯ�������
	if( !IsValidTextureSize( width ) || !IsValidTextureSize( height ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	*/
	if( !IsValidTextureFormat( internalformat, format, type ) )
	{
		// GLSETERROR()�� IsValidTextureFormat �Լ� �ȿ��� �� ����.
		// ��쿡 ���� error ������ �޶� �ε����ϰ�.. -_-
		return;
	}

	if( (0 == width) || (0 == height) )
		return;

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.


	int bytePerPixel_tex;
	int bytePerPixel_mem;

	if( !GetInfomation( format, type, bytePerPixel_tex, bytePerPixel_mem ) )
		return;

	// ������ �̹����� ������ ���� �ִ� ���¶�� �޸� ���� �� �ٽ� �Ҵ�.
	ptexture->m_IsCompessed = GL_FALSE;
    ptexture->m_PaletteSize = 0;	

	if ( ptexture->m_PaletteMemory2D.MemoryHandle )
		GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );

	unsigned char* pNewSrc = NULL;
	__TEXTURE__ curTexture;

	if( level == 0 )
	{
		const GLvoid* pSrc = NULL;
		
		// �ּ� �ؽ��� ������� �����.
		GLboolean result = GetValidMinTextureSizeWithScale( bytePerPixel_tex * 8, width, height, curTexture.m_ScaleX, curTexture.m_ScaleY );
		SetTextureSize( &curTexture, width, height );	
		
		if( result )
		{
			int size = (int)( ( width * curTexture.m_ScaleX ) * ( height * curTexture.m_ScaleY ) * bytePerPixel_mem );
			pNewSrc = MES_NEW_ARRAY( unsigned char, size );
			MakeValidMinTexture( pNewSrc, pixels, bytePerPixel_mem * 8, curTexture.m_Width, curTexture.m_Height, curTexture.m_ScaleX, curTexture.m_ScaleY );
			pSrc = (GLvoid*)pNewSrc;
		}
		else
			pSrc = pixels;

		// mipmap auto generation
		if( ptexture->m_GENERATE_MIPMAP )
		{
			if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
				GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

			if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
				curTexture.m_WidthPowerOf2 * bytePerPixel_tex, 
				curTexture.m_HeightPowerOf2, 
				1, 1, &ptexture->m_TextureDataMemory2D ) )	
			{
				//GLSETERROR(GL_INVALID_OPERATION);
				//return;
				goto error;
			}

			// ���� �� mipmap ����.
			if( pixels )
			{
				if( !UploadTexture( &ptexture->m_TextureDataMemory2D, 0, 0, width*curTexture.m_ScaleX, height*curTexture.m_ScaleY, pSrc, bytePerPixel_mem*width ) )
					goto error;
				CreateMipmapTexture( &ptexture->m_TextureDataMemory2D, 0, 0, width*curTexture.m_ScaleX, height*curTexture.m_ScaleY, pSrc, bytePerPixel_mem*width );
			}
		}
		else
		{
			// �̹� �Ҵ�� ���� �ִ� �ؽ��Ķ��..
			if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			{
				if( ( ptexture->m_Format != format ) || 
					( ptexture->m_Width != width ) || ( ptexture->m_Height != height ) )
				{
					if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
						GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

					if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
						curTexture.m_WidthPowerOf2 * bytePerPixel_tex, 
						curTexture.m_HeightPowerOf2, 
						1, 1, &ptexture->m_TextureDataMemory2D ) )	
					{
						//GLSETERROR(GL_INVALID_OPERATION);
						//return;
						goto error;
					}
				}
				if( pixels ) // ���� �ؽ��Ŀ� �Ҵ�� ������ �����ϴٸ�..
				{
					if( !UploadTexture( &ptexture->m_TextureDataMemory2D, 0, 0, width*curTexture.m_ScaleX, height*curTexture.m_ScaleY, pSrc, bytePerPixel_mem*width ) )
						goto error;
				}
			}
			// ó�� ����� �ؽ��Ķ��..
			else
			{
				if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_TEXTURE, 
					curTexture.m_WidthPowerOf2 * bytePerPixel_tex, 
					curTexture.m_HeightPowerOf2, 
					1, 1, &ptexture->m_TextureDataMemory2D ) )	
				{
					//GLSETERROR(GL_INVALID_OPERATION);
					//return;
					goto error;
				}
				if( pixels )
				{
					if( !UploadTexture( &ptexture->m_TextureDataMemory2D, 0, 0, width*curTexture.m_ScaleX, height*curTexture.m_ScaleY, pSrc, bytePerPixel_mem*width ) )
						goto error;
				}
			}
		}

		ptexture->m_Width			= curTexture.m_Width;
		ptexture->m_WidthPowerOf2	= curTexture.m_WidthPowerOf2;
		ptexture->m_Height			= curTexture.m_Height;
		ptexture->m_HeightPowerOf2	= curTexture.m_HeightPowerOf2;
		ptexture->m_ScaleX			= curTexture.m_ScaleX;
		ptexture->m_ScaleY			= curTexture.m_ScaleY;
	}
	else // �ؽ��� ������ 0�� �ƴ϶��..
	{
		// ���� ������ ���
		
		int orgWidth = width * (1<<level);
		int orgHeight = height * (1<<level);

		int scaleX, scaleY;
		GetValidMinTextureSizeWithScale( bytePerPixel_tex, orgWidth, orgHeight, scaleX, scaleY );

		// �̹� ������ ���� �ִ� texture�ΰ�?
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
		{
			if( ( ptexture->m_Format != format ) || 
					( ptexture->m_Width != orgWidth ) || ( ptexture->m_Height != orgHeight ) )
			{
				GLSETERROR(GL_INVALID_VALUE);
				return;
			}
			else
			{
				if( !IsValidMipmapTextureSize( level, ptexture->m_Width, ptexture->m_Height, width, height ) )
				{
					GLSETERROR(GL_INVALID_VALUE);
					return;
				}
				if( pixels )
				{
					if( ptexture->m_TextureDataMemory2D.Type != GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
					{
						// 1. ���ο� �޸� �Ҵ�	2. ���� ����	3. �Ӹ� ���ε�
						GLESOAL_MEMORY2D newTexMemory2D;
						if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
							orgWidth * scaleX * bytePerPixel_tex, 
							orgHeight * scaleY, 
							1, 1, &newTexMemory2D ) )
						{
							GLSETERROR(GL_INVALID_OPERATION);
							return;
							//goto error;
						}
						CopyTexture( &ptexture->m_TextureDataMemory2D, &newTexMemory2D, orgWidth * scaleX, orgHeight * scaleY );
						GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
						ptexture->m_TextureDataMemory2D = newTexMemory2D;
					}
					unsigned int x, y;
 					if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
					{	
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
					if( !UploadMipmap( &ptexture->m_TextureDataMemory2D, x, y, width, height, pixels, bytePerPixel_mem*width ) )
					{	
						GLSETERROR(GL_INVALID_OPERATION);
						return;
					}
				}
			}
		}
		// ó�� ����� texture�ΰ�?
		else
		{
			//if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );

			if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE, 
				orgWidth * scaleX * bytePerPixel_tex, 
				orgHeight * scaleY, 
				1, 1, &ptexture->m_TextureDataMemory2D ) )	
			{
				//GLSETERROR(GL_INVALID_OPERATION);
				//return;
				goto error;
			}
			if( pixels )
			{
				unsigned int x, y;
				if( !GetMipmapPosition( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
				{	
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
				if( !UploadMipmap( &ptexture->m_TextureDataMemory2D, x, y, width, height, pixels, bytePerPixel_mem*width ) )
				{	
					GLSETERROR(GL_INVALID_OPERATION);
					return;
				}
			}
		}
	}

	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );

	ptexture->m_Target	= target;
	ptexture->m_Level	= level;
	ptexture->m_Border	= border;
	ptexture->m_Format	= format;
	ptexture->m_Type	= type;
	ptexture->m_Bpp		= bytePerPixel_tex * 8;	

	ptexture->m_IsUpdated = GL_TRUE;
	__GLSTATE__.m_IsTextureUpdated = GL_TRUE;
	return;

error:
	//if( ptexture->m_TextureDataMemory2D.MemoryHandle )
	//	GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
	TextureInitialize( ptexture );
	
	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );
		
	GLSETERROR(GL_INVALID_OPERATION);
	return;
}
