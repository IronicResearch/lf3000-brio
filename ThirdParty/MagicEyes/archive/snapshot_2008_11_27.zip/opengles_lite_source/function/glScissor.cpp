//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glScissor.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/20 Gamza hardware setting
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glScissor (GLint x, GLint y, GLsizei width, GLsizei height)
{
	if (width < 0 || height < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__GLSTATE__.m_Scissor_X      = x;
	__GLSTATE__.m_Scissor_Y      = y;
	__GLSTATE__.m_Scissor_Width  = width;
	__GLSTATE__.m_Scissor_Height = height;

	GLESHAL_SetScissorSize( __GLSTATE__.m_Scissor_X,
							__GLSTATE__.m_Scissor_Y,
							__GLSTATE__.m_Scissor_Width,
							__GLSTATE__.m_Scissor_Height );

}

