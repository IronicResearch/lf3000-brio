//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glBindBuffer.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glBindBuffer.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	openGL|ES only

void glBindBuffer (GLenum target, GLuint buffer)
{
	int bindedbuffer;
	switch( target )
	{
	case GL_ARRAY_BUFFER:
		bindedbuffer = 0;
		break;
	case GL_ELEMENT_ARRAY_BUFFER:
		bindedbuffer = 1;
		break;
	default:
		GLSETERROR( GL_INVALID_ENUM );
		return;
	}

	if( !buffer )
	{
		__GLSTATE__.m_BindedBuffer[bindedbuffer] = buffer;
	}
	else
	{
		if ( __BUFFER_POOL__.Alloc(buffer) )
		{
			__GLSTATE__.m_BindedBuffer[bindedbuffer] = buffer;
		}
		else
		{
			GLSETERROR( GL_OUT_OF_MEMORY );
		}
	}
}


