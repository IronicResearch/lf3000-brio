//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glPointParameterfv.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glPointParameter.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glPointParameterfv (GLenum pname, const GLfloat *params)
{
	switch (pname)
	{
	case GL_POINT_DISTANCE_ATTENUATION:
		__GLSTATE__.m_PointDistanceAttenuation[0] = F2VF(params[0]);
		__GLSTATE__.m_PointDistanceAttenuation[1] = F2VF(params[1]);
		__GLSTATE__.m_PointDistanceAttenuation[2] = F2VF(params[2]);
		__GLSTATE__.m_PointSizeAttenuate =  (__GLSTATE__.m_PointDistanceAttenuation[0] != VFONE) || 
											(__GLSTATE__.m_PointDistanceAttenuation[1] != 0 ) ||
											(__GLSTATE__.m_PointDistanceAttenuation[2] != 0 ) ;
		break;

	default:
		glPointParameterx(pname, (int)(*params));
		break;
	}
}
