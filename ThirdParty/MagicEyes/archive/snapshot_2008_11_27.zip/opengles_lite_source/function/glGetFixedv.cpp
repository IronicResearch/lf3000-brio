//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetFixedv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_5ub8.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/08/23 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	for GL
//	glGetDoublev

//	for GL-ES
//	glGetBooleanv, glGetFloatv, glGetIntegerv

//	These functions return the value or values of a selected parameter.

//	GL_INVALID_ENUM  pname was not an accepted value. 
//	GL_INVALID_OPERATION  glGet was called between a call to glBegin and the corresponding call to glEnd. 

#define _C( c )		Float2Fixed((c)/255.0f)
#define _I( i )		Int2Fixed(i)
#define _B( b )		((b) ? GLFIXED_ONE : GLFIXED_ZERO )
#define _BUF( buf )	GLFIXED_ZERO
#define _VF( v )	VF2X(v)
#define _VCF( v )	VCF2X(v)

void glGetFixedv (GLenum pname, GLfixed *params)
{
#	include "glGet.inl"
}
