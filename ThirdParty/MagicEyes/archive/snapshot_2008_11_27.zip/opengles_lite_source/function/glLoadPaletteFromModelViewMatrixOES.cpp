//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLoadPaletteFromModelViewMatrixOES.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glLoadPaletteFromModelViewMatrix.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glLoadPaletteFromModelViewMatrixOES (void)
{
#if GLPARAM_MAX_PALETTE_MATRICES_OES > 0
	__GLSTATE__.m_MatrixPalette[__GLSTATE__.m_CurrentPaletteMatrix].LoadMatrix( __GLSTATE__.m_ModelViewMatrix.CurrentMatrix() );
	EnableMatrixPaletteUpdate( __GLSTATE__.m_CurrentPaletteMatrix );
#endif
}
