//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glPointParameterf.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glPointParameter.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glPointParameterf (GLenum pname, GLfloat param)
{
	switch ( pname )
	{
	case GL_POINT_SIZE_MIN:
		if( param < 0 ){ GLSETERROR(GL_INVALID_VALUE); return; }
		__GLSTATE__.m_POINT_SIZE_MIN = F2VF(param);
		break;
		
	case GL_POINT_SIZE_MAX:
		if( param < 0 ){ GLSETERROR(GL_INVALID_VALUE); return; }
		__GLSTATE__.m_POINT_SIZE_MAX = F2VF(param);
		break;
		
	case GL_POINT_FADE_THRESHOLD_SIZE:
		if( param < 0 ){ GLSETERROR(GL_INVALID_VALUE); return; }
		__GLSTATE__.m_POINT_FADE_THRESHOLD_SIZE = F2VF(param);
		break;

	default:
		GLSETERROR(GL_INVALID_ENUM);
		break;
	}
}


