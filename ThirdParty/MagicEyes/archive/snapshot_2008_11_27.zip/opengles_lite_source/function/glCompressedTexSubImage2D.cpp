//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glCompressedTexSubImage2D.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glCompressedTexSubImage2D.html
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	openGL|ES only

void glCompressedTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const GLvoid *data)
{
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}

	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( (width < 0 || width > GL_MAX_TEXTURE_SIZE ) ||
		 (height < 0 || height > GL_MAX_TEXTURE_SIZE ) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( ! ptexture->m_IsCompessed )	// ���� texture�� compressed texture�� �ƴ϶��.
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	unsigned char* pNewSrc = NULL;
	const GLvoid* pSrc = NULL;
    
    if ( width * ptexture->m_Bpp * height != imageSize)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	
	GLint widthByteSize = ( (width * ptexture->m_ScaleX * ptexture->m_Bpp )+7 )/8;	
	
	if( (1 !=ptexture->m_ScaleX) || (1 !=ptexture->m_ScaleY) )
	{
		int size = (int)( ( height * ptexture->m_ScaleY ) * widthByteSize );
		pNewSrc = MES_NEW_ARRAY( unsigned char, size );
		
		MakeValidMinTexture( pNewSrc, data, ptexture->m_Bpp, width, height, ptexture->m_ScaleX, ptexture->m_ScaleY );
		pSrc = (GLvoid*)pNewSrc;
	}
	else
		pSrc = data;

	if( NULL == ptexture->m_TextureDataMemory2D.MemoryHandle )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		goto error;
	}
		
	while( ptexture->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	// buffer�� ������̶�� ��ٸ���.
	
	if( level == 0 )
	{
		GLESOAL_UploadTexture_index8( &ptexture->m_TextureDataMemory2D,
									xoffset * ptexture->m_ScaleX, yoffset * ptexture->m_ScaleY, 
									widthByteSize, height * ptexture->m_ScaleY, pSrc, widthByteSize );
	}
	else if( ptexture->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
	{
		unsigned int x, y;
		if( !GLESOAL_GetMipmapPosition_U8( &ptexture->m_TextureDataMemory2D, level, &x, &y ) )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}
		if( !GLESOAL_UploadTexture_index8( &ptexture->m_TextureDataMemory2D,
									( xoffset + x ), ( yoffset + y ), 
									widthByteSize/ptexture->m_ScaleX, height, pSrc, widthByteSize ) )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}
	}
/*
	unsigned int widthByteSize;
	switch( ptexture->m_PaletteSize )
	{
	case 16:
		widthByteSize = ( (width*4)+7 )/8;

		GLESOAL_UploadTexture_index4( &ptexture->m_TextureDataMemory2D,
								   xoffset, yoffset, width, height,
 								   data, widthByteSize );	
		break;
	case 256:
		widthByteSize = ( (width*8)+7 )/8;
		GLESOAL_UploadTexture_index8( &ptexture->m_TextureDataMemory2D,
								   xoffset, yoffset, width, height,
 								   data, widthByteSize );	
		break;
	default:
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
*/
	ptexture->m_IsUpdated = GL_TRUE;
	return;
	
error:
	if( pNewSrc )
		MES_DELETE_ARRAY( pNewSrc );
		
	return;
}
