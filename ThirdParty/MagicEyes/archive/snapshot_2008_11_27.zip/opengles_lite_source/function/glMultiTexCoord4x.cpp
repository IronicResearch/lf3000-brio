//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glMultiTexCoord4x.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glMultiTexCoord.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glMultiTexCoord4x (GLenum target, GLfixed s, GLfixed t, GLfixed r, GLfixed q)
{
	if (target < GL_TEXTURE0 || target >= GL_TEXTURE0 + GLPARAM_MAX_TEXTURE_UNITS)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	signed int unit = target - GL_TEXTURE0;

	__GLSTATE__.m_DefaultTexCoord[unit][0] = X2VF(s);
	__GLSTATE__.m_DefaultTexCoord[unit][1] = X2VF(t);
	__GLSTATE__.m_DefaultTexCoord[unit][2] = X2VF(r);
	__GLSTATE__.m_DefaultTexCoord[unit][3] = X2VF(q);
}
