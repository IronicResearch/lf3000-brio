//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDisable.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_3l5x.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glDisable (GLenum cap)
{
	const GLboolean enabled = GL_FALSE;
	unsigned long curRenderState = GLESHAL_GetRenderState();

	// RenderState�� ������ �ʿ䰡 ���� factor���� return �ع�����.
	switch( cap )
	{
	case GL_ALPHA_TEST:
		{
			__GLSTATE__.m_Enable_ALPHA_TEST = enabled; 
			curRenderState &= ~GLESHAL_RS_ALPHATEST_ENB;
		}
		break;
	case GL_BLEND: 
		{
			__GLSTATE__.m_Enable_BLEND = enabled; 
			curRenderState &= ~GLESHAL_RS_ALPHA_ENB;
		}
		break;
	case GL_COLOR_LOGIC_OP: 
		{
			__GLSTATE__.m_Enable_COLOR_LOGIC_OP = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_COLOR_MATERIAL:
		{
			__GLSTATE__.m_Enable_COLOR_MATERIAL = enabled; 
			__GLSTATE__.m_IsGlobalLightingUpdated = GL_TRUE;
			// Light ����� �ٽ� �����غ���. 
		}
		return;
	case GL_CULL_FACE : 
		{
			__GLSTATE__.m_Enable_CULL_FACE = enabled; 
			curRenderState &= ~GLESHAL_RS_BACKFACECULL_ENB;
			//GLESHAL_SetCullingState( __GLSTATE__.m_Enable_CULL_FACE );
			//return;
		}
		break;
	case GL_DEPTH_TEST: 
		{
			__GLSTATE__.m_Enable_DEPTH_TEST = enabled; 
			curRenderState &= ~( GLESHAL_RS_ZBUFFER_ENB | GLESHAL_RS_ZBUFFERWRITE_ENB );
		}
		break;
	case GL_DITHER: 
		{
			__GLSTATE__.m_Enable_DITHER = enabled; 
			curRenderState &= ~GLESHAL_RS_DITHER_ENB;
		}
		break;
	case GL_FOG: 
		{
			__GLSTATE__.m_Enable_FOG = enabled; 
			curRenderState &= ~GLESHAL_RS_FOG_ENB;
		}
		break;
	case GL_LIGHTING : 
		{
			__GLSTATE__.m_Enable_LIGHTING = enabled;
			__GLSTATE__.m_IsLightTurnON = GL_FALSE;
			// rendering �ÿ� ����.
		}
		return;
	case GL_LINE_SMOOTH: 
		{
			__GLSTATE__.m_Enable_LINE_SMOOTH = enabled; 
			// rendering �ÿ� ����.
		}
		return;		
	case GL_MATRIX_PALETTE_OES: 
		{
			__GLSTATE__.m_Enable_MATRIX_PALETTE_OES = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_MULTISAMPLE: 
		{
			__GLSTATE__.m_Enable_MULTISAMPLE = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_NORMALIZE: 
		{
			__GLSTATE__.m_Enable_NORMALIZE = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_POINT_SMOOTH: 
		{
			__GLSTATE__.m_Enable_POINT_SMOOTH = enabled; 
			// rendering �ÿ� ����.
		}
		return;
	case GL_POINT_SPRITE_OES: 
		{
			__GLSTATE__.m_Enable_POINT_SPRITE_OES = enabled; 
			// rendering �ÿ� ����.
		}
		return;
	case GL_POLYGON_OFFSET_FILL: 
		{
			__GLSTATE__.m_Enable_POLYGON_OFFSET_FILL = enabled; 
		}
		return;
	case GL_RESCALE_NORMAL: 
		{
			if( __GLSTATE__.m_Enable_RESCALE_NORMAL != enabled )
				__GLSTATE__.m_ModelViewMatrix.m_IsUpdated = 1;
			__GLSTATE__.m_Enable_RESCALE_NORMAL = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_SAMPLE_ALPHA_TO_COVERAGE: 
		{
			__GLSTATE__.m_Enable_SAMPLE_ALPHA_TO_COVERAGE = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_SAMPLE_ALPHA_TO_ONE: 
		{
			__GLSTATE__.m_Enable_SAMPLE_ALPHA_TO_ONE = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_SAMPLE_COVERAGE: 
		{
			__GLSTATE__.m_Enable_SAMPLE_COVERAGE = enabled;
			// Ĩ���� �������� ����.
		}
		return;
	case GL_SCISSOR_TEST: 
		{
			__GLSTATE__.m_Enable_SCISSOR_TEST = enabled; 
			GLESHAL_ScissorDisable();	// scissor ����� window size�� �ʱ�ȭ�ϴ� ����.
		}
		return;
	case GL_STENCIL_TEST: 
		{
			__GLSTATE__.m_Enable_STENCIL_TEST = enabled; 
			// Ĩ���� �������� ����.
		}
		return;
	case GL_TEXTURE_2D: 
		{
			__GLSTATE__.m_TexEnv[__GLSTATE__.m_ActiveTexture].m_IsEnable = enabled;
			__GLSTATE__.m_IsTextureUpdated = GL_TRUE;

			//__GLSTATE__.m_Enable_TEXTURE_2D = enabled; 
			//curRenderState &= ~GLESHAL_RS_TEXTURE0_ENB;
		}
		break;
	default:
		if( cap >= GL_CLIP_PLANE0 && cap < GL_CLIP_PLANE0+GLPARAM_MAX_CLIP_PLANES )
		{
#if GLPARAM_MAX_CLIP_PLANES > 0
			__GLSTATE__.m_Enable_CLIP_PLANE[cap-GL_CLIP_PLANE0] = enabled; 
#endif
		}
		else if( cap >= GL_LIGHT0 && cap < GL_LIGHT0+GLPARAM_MAX_LIGHTS )
		{
			__GLSTATE__.m_Enable_LIGHT[cap-GL_LIGHT0] = enabled; 
		}
		else
		{
			GLSETERROR(GL_INVALID_ENUM);
		}
		return;
	}
	GLESHAL_SetRenderState( curRenderState );
}
