//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexImage2DFromVideoOES.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     : 
//	History    :
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//     2007/09/06 Gamza GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE �߰�.
//	   2007/03/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

void glTexImage2DFromVideoOES( const GLvoid *pY,const GLvoid *pCb,const GLvoid *pCr,
							   GLint clipx, GLint clipy, GLsizei clipwidth, GLsizei clipheight )
{
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}
	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( ptexture->m_Width  != clipwidth ||
		ptexture->m_Height != clipheight ||
		ptexture->m_IsCompessed ||
		ptexture->m_TextureDataMemory2D.MemoryHandle == 0 ||
		ptexture->m_TextureDataMemory2D.Type != GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE )
	{
		// texture �� ����.
		ptexture->m_IsCompessed = GL_FALSE;
		ptexture->m_PaletteSize = 0;
		if ( ptexture->m_TextureDataMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_TextureDataMemory2D );
		if ( ptexture->m_PaletteMemory2D.MemoryHandle )
			GLESOAL_Free2D( &ptexture->m_PaletteMemory2D );
		ptexture->m_Target	= GL_TEXTURE_2D;
		ptexture->m_Level	= 0;
		ptexture->m_Border	= 0;
		ptexture->m_Format	= GL_RGB;
		SetTextureSize( ptexture, clipwidth, clipheight );
		ptexture->m_Type	= GL_UNSIGNED_SHORT_5_6_5;

		if( !GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE, 
								ptexture->m_WidthPowerOf2*2, ptexture->m_HeightPowerOf2,
								1, 1, &ptexture->m_TextureDataMemory2D ) )
		{
			GLSETERROR(GL_OUT_OF_MEMORY);
			return;
		}
	/*	
		if( !GLESHAL_SetTextureSegment( __GLSTATE__.m_ActiveTexture, ptexture->m_TextureDataMemory2D.PhysicalSegment ) )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}

		if( ! GLESHAL_SetTexture( __GLSTATE__.m_ActiveTexture, GLESHAL_COLORFORMAT_R5G6B5,
								 (ptexture->m_TextureDataMemory2D.PhysicalSegX)/2, 
								 ptexture->m_TextureDataMemory2D.PhysicalSegY, 
								 ptexture->m_WidthPowerOf2, ptexture->m_HeightPowerOf2 ) )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}
	*/	
	}
	
/*
	if( ! GLESHAL_ClearTextureCache() )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
*/
	if( ! GLESOAL_ConvertColorSpace420( pY,pCb,pCr,
										clipx, clipy, clipwidth, clipheight,
										&ptexture->m_TextureDataMemory2D ) )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
	ptexture->m_IsUpdated = GL_TRUE;
}
