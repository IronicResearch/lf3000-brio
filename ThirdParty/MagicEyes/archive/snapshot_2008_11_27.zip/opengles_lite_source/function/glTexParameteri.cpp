//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexParameteri.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_9upe.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#define _I( i )		int(i)
#define _B( b )		((b)!=0 ? GL_TRUE : GL_FALSE )
#define _VF( v )	I2VF(v)
#define _VCF( v )	F2VCF( (v) / double(0x7FFFFFFF) )

void glTexParameteri (GLenum target, GLenum pname, GLint param)
{
/*
	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	switch (pname)
	{
	case GL_GENERATE_MIPMAP:
		ptexture->m_GENERATE_MIPMAP = (param != 0);
		break;

	case GL_TEXTURE_MAG_FILTER:
		if( GL_NEAREST                != param &&
			GL_LINEAR                 != param )
			{
				GLSETERROR(GL_INVALID_ENUM);
				return;
			}
		ptexture->m_TEXTURE_MAG_FILTER = (GLenum)param;
		break;

	case GL_TEXTURE_MIN_FILTER:
		if( GL_NEAREST                != param &&
			GL_LINEAR                 != param &&
			GL_NEAREST_MIPMAP_NEAREST != param &&
			GL_LINEAR_MIPMAP_NEAREST  != param &&
			GL_NEAREST_MIPMAP_LINEAR  != param &&
			GL_LINEAR_MIPMAP_LINEAR   != param )
			{
				GLSETERROR(GL_INVALID_ENUM);
				return;
			}
		ptexture->m_TEXTURE_MIN_FILTER = (GLenum)param;

	case GL_TEXTURE_WRAP_S:	// HAL���� wrapping mode�� s, t ������ ���� �����ϹǷ�
							// s������ ���� chip�� ����.
		if( param == GL_CLAMP_TO_EDGE )
		{
			if( !GLESHAL_SetTextureWrappingMode( GLESHAL_TEXTUREADDRESS_CLAMP ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		else if( param == GL_REPEAT )
		{
			if( !GLESHAL_SetTextureWrappingMode( GLESHAL_TEXTUREADDRESS_WRAP ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		else
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}
		ptexture->m_TEXTURE_WRAP_S = (GLenum)param; // , , []
		break;

	case GL_TEXTURE_WRAP_T:
		if( GL_CLAMP_TO_EDGE != param &&
			GL_REPEAT        != param  )
			{
				GLSETERROR(GL_INVALID_ENUM);
				return;
			}
		ptexture->m_TEXTURE_WRAP_T = (GLenum)param;
		break;

	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
*/
	#include "glTexParameter.inl"	
}
