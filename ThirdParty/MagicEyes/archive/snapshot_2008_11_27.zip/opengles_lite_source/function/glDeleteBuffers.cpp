//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDeleteBuffers.cpp
//	Description: http://www.khronos.org/opengles/documentation/opengles1_1/gl_egl_ref_1_1_20041110/glDeleteBuffers.html
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/?? Yuni	0�� ��� �����ϸ� �ȵ�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//	openGL|ES only

void glDeleteBuffers (GLsizei n, const GLuint *buffers)
{
	if (n < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}
	__BUFFER__* pcurrentbuffer;

	// buffer�� ������̶�� ����� ���������� ��ٷ��� �Ѵ�.
	int i;
	for( i=0; i<n; i++ )
	{
		if( buffers[i] )	// 0�̸� free�ϸ� �ȵ�.
		{
			pcurrentbuffer = __BUFFER_POOL__.GetObject(buffers[i]);
			
			if( pcurrentbuffer && (pcurrentbuffer->m_DataMemory1D.MemoryHandle) )
			{
				while( pcurrentbuffer->m_UsedPoint > GLESHAL_GetRearOfCommandQueue() );//{ NULL; }	
				GLESOAL_Free1D( &pcurrentbuffer->m_DataMemory1D );
			}
			__BUFFER_POOL__.Free( 1 , &buffers[i] );
		}
	}

	//__BUFFER_POOL__.Free( n , buffers );
}
