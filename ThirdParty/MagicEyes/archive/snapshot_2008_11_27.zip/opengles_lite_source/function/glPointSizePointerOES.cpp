//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glPointSizePointerOES.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glPointSizePointerOES (GLenum type, GLsizei stride, const GLvoid *pointer)
{
	if (type != GL_FIXED && type != GL_FLOAT)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	const signed int size = 1;

	if (stride < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if (stride == 0)
	{
		switch (type)
		{
		case GL_FIXED:
			stride = sizeof (GLfixed) * size;
			break;

		case GL_FLOAT:
			stride = sizeof (GLfloat) * size;
			break;
		}
	}

	__GLSTATE__.m_PointSizePointer.m_Size = size;
	__GLSTATE__.m_PointSizePointer.m_Type = type;
	__GLSTATE__.m_PointSizePointer.m_Stride = stride;
	__GLSTATE__.m_PointSizePointer.m_Pointer = pointer;
	__GLSTATE__.m_PointSizePointer.m_Buffer = __GLSTATE__.m_BindedBuffer[0];
}
