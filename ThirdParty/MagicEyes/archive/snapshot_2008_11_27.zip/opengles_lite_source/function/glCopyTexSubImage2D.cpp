//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glCopyTexSubImage2D.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_7gpw.asp
//	Author     : Gamza(nik@mesdigital.com) �����Ұ�
//	Export     :
//	History    :
//	   2007/09/06 Gamza 0 �� ��ȿ�� texture �̸��̴�.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

/*
GL_INVALID_ENUM is generated if target is not GL_TEXTURE_2D.
GL_INVALID_OPERATION is generated if the texture array has not been defined by a previous glTexImage2D or glCopyTexImage2D operation or if the internal format of the currently bound texture is not compatible with the color buffer format.
GL_INVALID_VALUE is generated if level is less than 0.
GL_INVALID_VALUE may be generated if level is greater than log2max, where max is the returned value of GL_MAX_TEXTURE_SIZE.
GL_INVALID_VALUE is generated if x < - b, or y < - b, where b is the border of the texture being modified.
GL_INVALID_VALUE is generated if xoffset < - b, xoffset + width > (w - b) , yoffset < - b, or yoffset + height > (h - b) , where w is the texture width, h is the texture height, and b is the border of the texture image being modified. Note that w and h include twice the border width.
*/
void glCopyTexSubImage2D (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height)
{
	//if( ! __GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture] )
	//{
	//	GLSETERROR(GL_INVALID_OPERATION);
	//	return;
	//}

	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if ( 0 > level ) // || if level is greater than log2max
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( ! ptexture->m_TextureDataMemory2D.MemoryHandle )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( (xoffset < -(ptexture->m_Border) ) || 
		(xoffset+width) > (ptexture->m_Width)-(ptexture->m_Border)	||
		(yoffset+height) > (ptexture->m_Height)-(ptexture->m_Border) )
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}	

	//GLESHAL_WaitToIdleState();	// Frame buffer�� �����ؾ� �ϹǷ� �۾��� ���� ������ ��ٸ���.
	GLESHAL_Flush();
	while( !GLESHAL_IsIdleState() )
		GLESOAL_Sleep(0);

	switch( ptexture->m_Format )
	{
	case GL_RGB:
		if( level == 0 )
		{
			if( ! GLESOAL_CopyDisplayToTexture_R5G6B5( __GLSTATE__.m_pSurface->GetColorBuffer(),
													   x,  y, 
													   width, height,
													   ptexture->m_ScaleX, ptexture->m_ScaleY,
													   &ptexture->m_TextureDataMemory2D, 
													   xoffset, yoffset,
													   __GLSTATE__.m_SAMPLE_BUFFERS ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		else if( ptexture->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
		{
			unsigned int offsetX, offsetY;
			if( !GLESOAL_GetMipmapPosition_U16( &ptexture->m_TextureDataMemory2D, level, &offsetX, &offsetY ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			if( !GLESOAL_UploadCopyTextureMipmap_U16(
				__GLSTATE__.m_pSurface->GetColorBuffer(), &ptexture->m_TextureDataMemory2D, x, y, offsetX, offsetY, width, height ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		break;
	case GL_LUMINANCE:
		if( level == 0 )
		{
			if( ! GLESOAL_CopyDisplayToTexture_L8( __GLSTATE__.m_pSurface->GetColorBuffer(),
													   x,  y, 
													   width, height,
													   ptexture->m_ScaleX, ptexture->m_ScaleY,
													   &ptexture->m_TextureDataMemory2D, 
													   xoffset, yoffset,
													   __GLSTATE__.m_SAMPLE_BUFFERS  ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		else if( ptexture->m_TextureDataMemory2D.Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
		{
			unsigned int offsetX, offsetY;
			if( !GLESOAL_GetMipmapPosition_U8( &ptexture->m_TextureDataMemory2D, level, &offsetX, &offsetY ) )
			{
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
			if( !GLESOAL_UploadCopyTextureMipmap_L8(
				__GLSTATE__.m_pSurface->GetColorBuffer(), &ptexture->m_TextureDataMemory2D, x, y, offsetX, offsetY, width, height ) )
			{	
				GLSETERROR(GL_INVALID_OPERATION);
				return;
			}
		}
		break;
	default:
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
	
	ptexture->m_IsUpdated = GL_TRUE;

}
