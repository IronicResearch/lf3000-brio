//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglQuerySurface.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglQuerySurface (EGLDisplay dpy, EGLSurface surface, EGLint attribute, EGLint *value)
{
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_SURFACE is generated if surface is not an EGL surface.
	/*d
	__SURFACE__* psurface = (__SURFACE__*)surface;
	if( ! psurface || EGLSURFACE_FLAG != psurface->m_Config.m_EGLCONFIG  )
	{
		EGLSETERROR( EGL_BAD_SURFACE );
		return EGL_FALSE;
	}

	//	EGL_BAD_ATTRIBUTE is generated if attribute is not a valid surface attribute.
	switch( attribute )
	{
	case EGL_CONFIG_ID      : *value = psurface->m_Config.m_CONFIG_ID; break;
	case EGL_WIDTH          : *value = psurface->m_Config.m_WIDTH; break;
	case EGL_HEIGHT         : *value = psurface->m_Config.m_HEIGHT; break;
	case EGL_LARGEST_PBUFFER: *value = psurface->m_Config.m_LARGEST_PBUFFER; break;
	case EGL_TEXTURE_FORMAT : *value = psurface->m_Config.m_TEXTURE_FORMAT; break;
	case EGL_TEXTURE_TARGET : *value = psurface->m_Config.m_TEXTURE_TARGET; break;
	case EGL_MIPMAP_TEXTURE : *value = psurface->m_Config.m_MIPMAP_TEXTURE; break;
	case EGL_MIPMAP_LEVEL   : *value = psurface->m_Config.m_MIPMAP_LEVEL; break;
	default:
		EGLSETERROR( EGL_BAD_ATTRIBUTE );
		return EGL_FALSE;
	}
	*/
	return EGL_TRUE;
}
