//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glViewport.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/19 Gamza	openGL�� �����ϴ��� ������������,
//						3D core�� ��������� ������ �־����.
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glViewport (GLint x, GLint y, GLsizei width, GLsizei height)
{
	if (width < 0 || height < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	__GLSTATE__.m_Viewport_X     = x;     
	__GLSTATE__.m_Viewport_Y     = y;     
	__GLSTATE__.m_Viewport_Width = width; 
	__GLSTATE__.m_Viewport_Height= height;

	GLESHAL_SetViewport( x, y, width, height );
	
}
