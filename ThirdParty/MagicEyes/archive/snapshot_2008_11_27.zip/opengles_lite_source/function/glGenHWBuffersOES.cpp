//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGenHWBuffersOES.cpp
//	Description: 
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/11/27 Yuni first implementation
//------------------------------------------------------------------------------
//#include "../source/glstate.h"
#include "../source/hwbufferobject.h"

// OpenGL|ES extension
void glGenHWBuffersOES(GLsizei n, GLuint *hwbuffers)
{
	if (n < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( !__HWBUFFER_POOL__.Alloc( n, hwbuffers ) )
	{
		GLSETERROR( GL_OUT_OF_MEMORY );
	}
	
	for( int i = 0; i < n; i++ )
	{
		__HWBUFFER__* pcurrentbuffer;
		pcurrentbuffer = __HWBUFFER_POOL__.GetObject(hwbuffers[i]);
		if ( !hwbuffers[i] || !pcurrentbuffer )
		{
			GLSETERROR(GL_INVALID_OPERATION);
			return;
		}	
		glGenBuffers( 1, &pcurrentbuffer->m_Buffer );
	}

}
