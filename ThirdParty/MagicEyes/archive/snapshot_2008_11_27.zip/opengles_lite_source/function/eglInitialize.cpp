//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglInitialize.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2006/10/23 Gamza GLESHAL_InitializeWithAddress�� �Ѱ��� �ּҰ���
//						 OAL�κ��� �޵��� ����.
//		2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglInitialize (EGLDisplay dpy, EGLint *major, EGLint *minor)
{
	/*
#ifdef WIN32_EMUL
	// Set Default Display Config.
	memset(g_Configs, 0, sizeof(g_Configs));
	g_Configs[0].depthSize = 16;
	g_Configs[0].stencilSize = 1;
	g_Configs[0].surfaceType = EGL_PBUFFER_BIT | EGL_PIXMAP_BIT | EGL_WINDOW_BIT;
	
	g_EGLState.configs = &g_Configs[0];
#endif
	*/

	if( __EGLSTATE__.m_pCurDisplay != dpy )
	{
		EGLSETERROR( EGL_BAD_DISPLAY );
		return EGL_FALSE;
	}
	/*
	if ( !__EGLSTATE__.m_isInit ) 
	{
		EGLSETERROR( EGL_NOT_INITIALIZED );
		return EGL_FALSE;
	}
	*/

	__NumberOfContext__ = 0;
	__eglSwapInterval__ = 1;

#if   defined(EGL_VERSION_1_2)
	if (major != 0){ *major = 1; }
	if (minor != 0){ *minor = 2; }
#elif defined(EGL_VERSION_1_1)
	if (major != 0){ *major = 1; }
	if (minor != 0){ *minor = 1; }
#elif defined(EGL_VERSION_1_0)
	if (major != 0){ *major = 1; }
	if (minor != 0){ *minor = 0; }
#else
#	error "Unknown version of EGL"
#endif
/*
	if( GLESOAL_Initialize_Internal() )
	{
		//GLESHAL_InitializeWithAddress( GLESOAL_GetVirtualAddressOf3DCore() );
		GLESHAL_Initialize();
		GLESHAL_OpenModule();

		#if 0 < SIZEOFCOMMANDQUEUE
		{
			if( !GLESOAL_Malloc1D( SIZEOFCOMMANDQUEUE, 8, &(__EGLSTATE__.m_CommandQueue) ) )
				return EGL_FALSE;
			if( !( __EGLSTATE__.m_CommandQueue.MemoryHandle ) ){ return EGL_FALSE; }
			// front pointer�� �ʱ�ȭ�� �� �Լ� �ȿ��� �̷������.
			GLESHAL_OpenCommandQueue( (unsigned int*)(__EGLSTATE__.m_CommandQueue.VirtualAddress), 
									  (unsigned int*)(__EGLSTATE__.m_CommandQueue.PhysicalAddress), 
									  SIZEOFCOMMANDQUEUE/8 );
		}
		#endif

		EGLCLRERROR;

		__EGLSTATE__.m_isInit = EGL_TRUE;

		return EGL_TRUE;		
	}
	else
	{
		EGLSETERROR( GL_INVALID_OPERATION );
		return EGL_FALSE;	
	}
*/
	return EGL_TRUE;

}
