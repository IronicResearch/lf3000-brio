//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDepthMask.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_35ij.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glDepthMask (GLboolean flag)
{
	__GLSTATE__.m_DepthMask = flag;

	unsigned int curState = GLESHAL_GetRenderState();

	if( __GLSTATE__.m_Enable_DEPTH_TEST )
	{
		if( flag )
		{
			curState |= GLESHAL_RS_ZBUFFERWRITE_ENB;
		}
		else
		{
			curState &= ~GLESHAL_RS_ZBUFFERWRITE_ENB;
		}
	}

	GLESHAL_SetRenderState( curState );
}
