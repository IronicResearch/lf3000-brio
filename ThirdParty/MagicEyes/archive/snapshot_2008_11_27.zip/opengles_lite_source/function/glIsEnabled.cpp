//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glIsEnabled.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_7pgk.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


GLboolean glIsEnabled (GLenum cap)
{
	switch( cap )
	{
	case GL_ALPHA_TEST               : return __GLSTATE__.m_Enable_ALPHA_TEST               ; // glAlphaFunc                       
	case GL_BLEND                    : return __GLSTATE__.m_Enable_BLEND                    ; // glBlendFunc, glLogicOp            
	//case GL_CLIP_PLANEi              : return __GLSTATE__.m_Enable_CLIP_PLANE i             ; // glClipPlane                       
	case GL_COLOR_LOGIC_OP           : return __GLSTATE__.m_Enable_COLOR_LOGIC_OP           ; // glLogicOp                         
	case GL_COLOR_MATERIAL           : return __GLSTATE__.m_Enable_COLOR_MATERIAL           ; // glColorMaterial                   
	case GL_CULL_FACE                : return __GLSTATE__.m_Enable_CULL_FACE                ; // glCullFace                        
	case GL_DEPTH_TEST               : return __GLSTATE__.m_Enable_DEPTH_TEST               ; // glDepthFunc, glDepthRange         
	case GL_DITHER                   : return __GLSTATE__.m_Enable_DITHER                   ; // glEnable                          
	case GL_FOG                      : return __GLSTATE__.m_Enable_FOG                      ; // glFog                             
	case GL_LIGHTING                 : return __GLSTATE__.m_Enable_LIGHTING                 ; // glLight, glLightModel, glMaterial 
	//case GL_LIGHTi                   : return __GLSTATE__.m_Enable_LIGHT i                  ; // glLight, glLightModel             
	case GL_LINE_SMOOTH              : return __GLSTATE__.m_Enable_LINE_SMOOTH              ; // glLineWidth                       
	case GL_MATRIX_PALETTE_OES       : return __GLSTATE__.m_Enable_MATRIX_PALETTE_OES       ; // glMatrixMode                      
	case GL_MULTISAMPLE              : return __GLSTATE__.m_Enable_MULTISAMPLE              ; // glEnable                          
	case GL_NORMALIZE                : return __GLSTATE__.m_Enable_NORMALIZE                ; // glNormal                          
	case GL_POINT_SMOOTH             : return __GLSTATE__.m_Enable_POINT_SMOOTH             ; // glPointSize                       
	case GL_POINT_SPRITE_OES         : return __GLSTATE__.m_Enable_POINT_SPRITE_OES         ; // glEnable, glTexEnv                
	case GL_POLYGON_OFFSET_FILL      : return __GLSTATE__.m_Enable_POLYGON_OFFSET_FILL      ; // glPolygonOffset                   
	case GL_RESCALE_NORMAL           : return __GLSTATE__.m_Enable_RESCALE_NORMAL           ; // glEnable                          
	case GL_SAMPLE_ALPHA_TO_COVERAGE : return __GLSTATE__.m_Enable_SAMPLE_ALPHA_TO_COVERAGE ; // glEnable                          
	case GL_SAMPLE_ALPHA_TO_ONE      : return __GLSTATE__.m_Enable_SAMPLE_ALPHA_TO_ONE      ; // glEnable                          
	case GL_SAMPLE_COVERAGE          : return __GLSTATE__.m_Enable_SAMPLE_COVERAGE          ; // glEnable                          
	case GL_SCISSOR_TEST             : return __GLSTATE__.m_Enable_SCISSOR_TEST             ; // glScissor                         
	case GL_STENCIL_TEST             : return __GLSTATE__.m_Enable_STENCIL_TEST             ; // glStencilFunc, glStencilOp        
	//case GL_TEXTURE_2D               : return __GLSTATE__.m_Enable_TEXTURE_2D               ; // glTexImage2D                      
	case GL_TEXTURE_2D               : return __GLSTATE__.m_TexEnv[__GLSTATE__.m_ActiveTexture].m_IsEnable; // glTexImage2D               

	case GL_COLOR_ARRAY              : return __GLSTATE__.m_ClientState_COLOR_ARRAY;// glColorPointer                    
	case GL_MATRIX_INDEX_ARRAY_OES   : return __GLSTATE__.m_ClientState_MATRIX_INDEX_ARRAY_OES;// glEnableClientState               
	case GL_NORMAL_ARRAY             : return __GLSTATE__.m_ClientState_NORMAL_ARRAY;// glNormalPointer                   
	case GL_POINT_SIZE_ARRAY_OES     : return __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES;// glEnableClientState               
	case GL_TEXTURE_COORD_ARRAY      : return __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[__GLSTATE__.m_ClientActiveTexture];// glTexCoordPointer
	case GL_VERTEX_ARRAY             : return __GLSTATE__.m_ClientState_VERTEX_ARRAY;// glVertexPointer                   
	case GL_WEIGHT_ARRAY_OES         : return __GLSTATE__.m_ClientState_WEIGHT_ARRAY_OES;// glEnableClientState               
	case GL_ARRAY_BUFFER_BINDING         : return ( 0 != __GLSTATE__.m_BindedBuffer[0] );// glBindBuffer
	case GL_ELEMENT_ARRAY_BUFFER_BINDING : return ( 0 != __GLSTATE__.m_BindedBuffer[1] );// glBindBuffer

	default:
		if( cap >= GL_CLIP_PLANE0 && cap < GL_CLIP_PLANE0+GLPARAM_MAX_CLIP_PLANES )
		{
#if GLPARAM_MAX_CLIP_PLANES > 0
			return __GLSTATE__.m_Enable_CLIP_PLANE[cap-GL_CLIP_PLANE0]; 
#endif
		}
		else if( cap >= GL_LIGHT0 && cap < GL_LIGHT0+GLPARAM_MAX_LIGHTS )
		{
			return __GLSTATE__.m_Enable_LIGHT[cap-GL_LIGHT0]; 
		}
		else
		{
			GLSETERROR(GL_INVALID_ENUM);
			return GL_FALSE;
		}
		break;
	}
	return GL_FALSE;
}
