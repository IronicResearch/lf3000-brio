//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glGetTexParameterxv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc02_5cqa.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#define _VF( v )	VF2X(v)

void glGetTexParameterxv (GLenum target, GLenum pname, GLfixed *params)
{
/*
	if (target != GL_TEXTURE_2D)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	__TEXTURE__* ptexture = __TEXTURE_POOL__.GetObject(__GLSTATE__.m_BindedTexture[__GLSTATE__.m_ActiveTexture]);
	if( ! ptexture )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	switch (pname)
	{
	case GL_GENERATE_MIPMAP:
		params[0] = (GLfixed)(ptexture->m_GENERATE_MIPMAP ? 1 : 0);
		break;

	case GL_TEXTURE_MAG_FILTER:
		params[0] = (GLint)ptexture->m_TEXTURE_MAG_FILTER;
		break;

	case GL_TEXTURE_MIN_FILTER:
		params[0] = (GLint)ptexture->m_TEXTURE_MIN_FILTER;
		break;

	case GL_TEXTURE_WRAP_S:
		params[0] = (GLint)ptexture->m_TEXTURE_WRAP_S; // GL_CLAMP, GL_CLAMP_TO_EDGE, [GL_REPEAT]
		break;

	case GL_TEXTURE_WRAP_T:
		params[0] = (GLint)ptexture->m_TEXTURE_WRAP_T; // GL_CLAMP, GL_CLAMP_TO_EDGE, [GL_REPEAT]
		break;

	default:
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}
*/
	#include "glGetTexParameter.inl"

}
