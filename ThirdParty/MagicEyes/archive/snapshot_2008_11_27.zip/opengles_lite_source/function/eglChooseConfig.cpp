//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglChooseConfig.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/05 Gamza configs�� NULL�� �ƴ� ��� num_config�� ���� �迭�� ����� ������ ��ȯ�ؾ��Ѵ�.
//	   2007/09/05 Gamza FSAA�� ���� SAMPLE_BUFFERS�� 1�� config�߰�.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


//	EGL_FALSE           is returned on failure, EGL_TRUE otherwise.
//				           configs and num_config are not modified when EGL_FALSE is returned.
//	EGL_BAD_DISPLAY     is generated if display is not an EGL display connection.
//	EGL_BAD_ATTRIBUTE   is generated if attribute_list contains an invalid frame buffer configuration attribute or an attribute value that is unrecognized or out of range.
//	EGL_NOT_INITIALIZED is generated if display has not been initialized.
//	EGL_BAD_PARAMETER   is generated if num_config is NULL.

EGLBoolean eglChooseConfig
(
	EGLDisplay dpy,
	const EGLint *attrib_list,
	EGLConfig *configs, // NULL �̸� ��Ī�Ǵ� ������ ��ȯ�Ѵ�.
	EGLint config_size,
	EGLint *num_config
)
{
	// EGL_NOT_INITIALIZED ??
	// EGL_BAD_DISPLAY ??
	//if (!__EGLSTATE__.m_isInit) 
	//{
	//	EGLSETERROR( EGL_NOT_INITIALIZED );
	//}
	// it's not current display.
	if (__EGLSTATE__.m_pCurDisplay != dpy)
	{
		EGLSETERROR( EGL_BAD_DISPLAY );
	}
	
	if( ! num_config )
	{
		EGLSETERROR( EGL_BAD_PARAMETER );
		return EGL_FALSE;
	}
	

	//	EGL_CONFIG_ID�� ��� �� ��� �ٸ� ��� �Ӽ������� ���õȴ�!!
	bool has_config_id = false;
	GLint config_id = EGL_DONT_CARE;
	int index = 0;
	while( attrib_list && EGL_NONE != attrib_list[ index * 2 ] )
	{
		if( EGL_CONFIG_ID == attrib_list[ index * 2 + 0 ] &&
			EGL_DONT_CARE != attrib_list[ index * 2 + 1 ] )
		{
			has_config_id = true;
			config_id     = attrib_list[ index * 2 + 1 ];
			break;
		}
		index++;
	}
		
	
	(*num_config) = 0;
	for( int config_idx=0;
		 config_idx<__EGL_Number_Of_Configurations__;
		 config_idx++ )
	{
		bool validflag;	
		const __CONFIG__* pcurconfig = &__EGL_Configuration__[config_idx];

		validflag = true;

		//	EGL_CONFIG_ID�� ��� �� ��� �ٸ� ��� �Ӽ������� ���õȴ�!!
		if( has_config_id )
		{
			if( config_id != EGL_DONT_CARE &&
				config_id != pcurconfig->m_CONFIG_ID )
			{
				validflag = false;
			}
		}
		else
		{
			EGLint param, value;
			index = 0;		
			while( attrib_list && EGL_NONE != attrib_list[ index * 2 ] )
			{
				param = attrib_list[ index * 2 + 0 ];
				value = attrib_list[ index * 2 + 1 ];
				index++;
				switch( param )
				{
				case EGL_BUFFER_SIZE            :				
					if( value > pcurconfig->m_BUFFER_SIZE ){ validflag = false; }
					break;		
				case EGL_ALPHA_SIZE             :
					if( value > pcurconfig->m_ALPHA_SIZE ){ validflag = false; }
					break;		
				case EGL_BLUE_SIZE              :
					if( ( value > pcurconfig->m_BLUE_SIZE ) && ( 8 != value ) )		// RGB 888�� Ư���� �����ѵ�. 
																					// ( �̹� ������ tutorial sample ������.. )
					{ validflag = false; }
					break;		
				case EGL_GREEN_SIZE             :
					if( ( value > pcurconfig->m_GREEN_SIZE ) && ( 8 != value) )
					{ validflag = false; }
					break;		
				case EGL_RED_SIZE               :
					if( ( value > pcurconfig->m_RED_SIZE ) && ( 8 != value) )
					{ validflag = false; }
					break;		
				case EGL_CONFIG_CAVEAT          :
					if( value != EGL_DONT_CARE &&
						value != pcurconfig->m_CONFIG_CAVEAT ){ validflag = false; }
					break;		
				//case EGL_CONFIG_ID              :
					//	EGL_CONFIG_ID�� ��� �� ��� �ٸ� ��� �Ӽ������� ���õȴ�!!
				//	if( value != EGL_DONT_CARE &&
				//		value != pcurconfig->m_CONFIG_ID ){ validflag = false; }
				//	break;		
				case EGL_DEPTH_SIZE             :
					if( value > pcurconfig->m_DEPTH_SIZE ){ validflag = false; }
					break;		
				case EGL_LEVEL                  :
					if( value != pcurconfig->m_LEVEL ){ validflag = false; }
					break;		
				case EGL_MAX_PBUFFER_WIDTH      :
					if( value > pcurconfig->m_MAX_PBUFFER_WIDTH ){ validflag = false; }
					break;		
				case EGL_MAX_PBUFFER_HEIGHT     :
					if( value > pcurconfig->m_MAX_PBUFFER_HEIGHT ){ validflag = false; }
					break;		
				case EGL_MAX_PBUFFER_PIXELS     :
					if( value > pcurconfig->m_MAX_PBUFFER_PIXELS ){ validflag = false; }
					break;		
				case EGL_NATIVE_RENDERABLE      :
					if( value != EGL_DONT_CARE && value != EGL_FALSE &&
						value != pcurconfig->m_NATIVE_RENDERABLE ){ validflag = false; }
					break;		
				case EGL_NATIVE_VISUAL_ID       :
					if( value != EGL_DONT_CARE && 
						value != pcurconfig->m_NATIVE_VISUAL_ID ){ validflag = false; }
					break;		
				case EGL_NATIVE_VISUAL_TYPE     :
					if( value != EGL_DONT_CARE && 
						value > pcurconfig->m_NATIVE_VISUAL_TYPE ){ validflag = false; }
					break;		
				case EGL_SAMPLE_BUFFERS         :
					if( value > pcurconfig->m_SAMPLE_BUFFERS ){ validflag = false; }
					break;		
				case EGL_SAMPLES                :
					if( value > pcurconfig->m_SAMPLES ){ validflag = false; }
					break;		
				case EGL_STENCIL_SIZE           :
					if( value > pcurconfig->m_STENCIL_SIZE ){ validflag = false; }
					break;		
				case EGL_SURFACE_TYPE           :
					if( 0 == (value & pcurconfig->m_SURFACE_TYPE) ){ validflag = false; }
					break;		
				case EGL_TRANSPARENT_TYPE       :
					if( value != EGL_NONE &&
						EGL_NONE == pcurconfig->m_TRANSPARENT_TYPE ){ validflag = false; }
					break;		
				case EGL_TRANSPARENT_BLUE_VALUE : // EGL_DONT_CARE
					break;
				case EGL_TRANSPARENT_GREEN_VALUE: // EGL_DONT_CARE
					break;
				case EGL_TRANSPARENT_RED_VALUE  : // EGL_DONT_CARE
					break;		
				case EGL_MIN_SWAP_INTERVAL      :
					if( value != EGL_DONT_CARE && 
						value < pcurconfig->m_MIN_SWAP_INTERVAL ){ validflag = false; }
					break;		
				case EGL_MAX_SWAP_INTERVAL      :
					if( value != EGL_DONT_CARE && 
						value > pcurconfig->m_MAX_SWAP_INTERVAL ){ validflag = false; }
					break;		
				case EGL_BIND_TO_TEXTURE_RGB    : // EGL_DONT_CARE
					if( value != EGL_FALSE && 
						EGL_FALSE == pcurconfig->m_BIND_TO_TEXTURE_RGB ){ validflag = false; }
					break;		
				case EGL_BIND_TO_TEXTURE_RGBA   : // EGL_DONT_CARE
					if( value != EGL_FALSE && 
						EGL_FALSE == pcurconfig->m_BIND_TO_TEXTURE_RGBA ){ validflag = false; }
					break;		
				default:			
					EGLSETERROR( EGL_BAD_ATTRIBUTE );
					return EGL_FALSE;
				}
				if( ! validflag ){ break; }
			}
		}	
		
		if( validflag )
		{
			if( configs && (*num_config)<config_size )
			{
				configs[(*num_config)] = (EGLConfig)(pcurconfig);
			}
			if( !configs || (*num_config)<config_size )
			{
				(*num_config)++;
			}
		}
	}

	return ((*num_config)>0) ? EGL_TRUE : EGL_FALSE;
}
