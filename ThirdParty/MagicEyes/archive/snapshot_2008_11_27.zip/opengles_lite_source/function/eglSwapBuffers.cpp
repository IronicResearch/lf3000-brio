//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglSwapBuffers.cpp
//	Description: �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/31 Yuni	Window ���� API�� OAL�� �̵���Ű�鼭 
//						surface->BufferSwap()���� ó���ϵ��� ����.
//	   2006/10/30 Yuni	GLESHAL_FlipDisplayBuffer ������ tearing ���� �� display flipping�� �ϵ��� ����.
//	   2006/10/20 Gamza layer ũ�⸦ �������� ũ�⿡ ������ �ʰ�,
//							  ó�� ������ surface�� ũ��� ����.
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglSwapBuffers (EGLDisplay dpy, EGLSurface draw)
{
	if( !__EGLSTATE__.m_pCurContext )
	{
		return EGL_FALSE;
	}

	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	//	EGL_BAD_SURFACE is generated if surface is not an EGL drawing surface.

	/*
	__SURFACE__* psurface = (__SURFACE__*)draw;
	if( ! psurface || EGLSURFACE_FLAG != psurface->m_Config.m_EGLCONFIG  )
	{
		EGLSETERROR( EGL_BAD_SURFACE );
		return EGL_FALSE;
	}

	//	EGL_CONTEXT_LOST is generated if a power management event has occurred.
	//                   The application must destroy all contexts and reinitialise
	//                   OpenGL ES state and objects to continue rendering.

	//	If surface is a pixel buffer or a pixmap, eglSwapBuffers has no effect, and no error is generated
    
	//	The color buffer of surface is left in an undefined state after calling eglSwap-Buffers.

	//	draw surface�� ȭ�鿡 �����ش�.

	//	eglSwapBuffers performs an implicit glFlush before it returns.
*/


	GLES_Surface* pSurface = (GLES_Surface*)draw;
	// �����ڵ� -> Command buffer�� fornt pointer�� ���� �˻絵 GLESHAL_Flush() ������ ����.


	glFlush();
	pSurface->BufferSwap();  // BufferSwap() ������ GLESOAL_OnWindowMoveSize()�� ȣ���Ͽ� ó��.

	return EGL_TRUE;

	//	�Ʒ� ������ ��ó��???
	//	surface will normally be resized by the EGL implementation at the time the native window is resized.
	//	If the implementation cannot do this transparently to the client, then eglSwapBuffers must detect the
	//	change and resize surface prior to copying its pixels to the native window.
	//	If surface shrinks as a result of resizing, some rendered pixels are lost. If
	//	surface grows, the newly allocated buffer contents are undefined. The resizing
	//	behavior described here only maintains consistency of EGL surfaces and native windows; 
	//	clients are still responsible for detecting window size changes (using platform-specific means) 
	//	and changing their viewport and scissor regions accordingly.
}
