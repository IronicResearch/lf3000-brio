//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glStencilFunc.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glStencilFunc (GLenum func, GLint ref, GLuint mask)
{
	if( GL_NEVER    != func &&
		GL_LESS     != func && 
		GL_LEQUAL   != func && 
		GL_GREATER  != func && 
		GL_GEQUAL   != func && 
		GL_EQUAL    != func && 
		GL_NOTEQUAL != func && 
		GL_ALWAYS   != func )
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}

	// todo : ref is clamped to the range [ 0 , 2^n - 1 ] ,
	//		 where n is the number of bitplanes in the stencil buffer
	
	__GLSTATE__.m_StencilFunc = func;
	__GLSTATE__.m_StencilReference = ref;
	__GLSTATE__.m_StencilComparisonMask = mask;
}
