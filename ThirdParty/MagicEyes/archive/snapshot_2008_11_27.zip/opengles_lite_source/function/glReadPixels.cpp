//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glReadPixels.cpp
//	Description: �ϵ��������
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

/*
GL_INVALID_ENUM is generated if format is not GL_RGBA or the value of GL_IMPLEMENTATION_COLOR_READ_FORMAT_OES.
GL_INVALID_ENUM is generated if type is not GL_UNSIGNED_BYTE or the value of GL_IMPLEMENTATION_COLOR_READ_TYPE_OES.
GL_INVALID_VALUE is generated if either width or height is negative.
GL_INVALID_OPERATION is generated if format and type are neither (GL_RGBA, GL_UNSIGNED_BYTE) nor the values of (GL_IMPLEMENTATION_COLOR_READ_FORMAT_OES, GL_IMPLEMENTATION_COLOR_READ_TYPE_OES).

 */

void glReadPixels (GLint x, GLint y, GLsizei width, GLsizei height, GLenum format, GLenum type, GLvoid *pixels)
{
	if (format != GL_RGBA && format != GLPARAM_IMPLEMENTATION_COLOR_READ_FORMAT_OES)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (type != GL_UNSIGNED_BYTE && type != GLPARAM_IMPLEMENTATION_COLOR_READ_TYPE_OES)
	{
		GLSETERROR(GL_INVALID_ENUM);
		return;
	}

	if (width < 0 || height < 0)
	{
		GLSETERROR(GL_INVALID_VALUE);
		return;
	}

	if ( !pixels )
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}

	if( format == GL_RGBA && type == GL_UNSIGNED_BYTE )
	{
	//	GLESHAL_WaitToIdleState();	// Frame buffer�� �����ؾ� �ϹǷ� �۾��� ���� ������ ��ٸ���.
		GLESHAL_Flush();
		while( !GLESHAL_IsIdleState() )
			GLESOAL_Sleep(0);

		GLESOAL_CopyDisplayToMemory_RGBA8( __GLSTATE__.m_pSurface->GetColorBuffer(),
										   x,  y, width, height,
										   pixels, width*4,
										   __GLSTATE__.m_SAMPLE_BUFFERS );
	}
	else if( format == GLPARAM_IMPLEMENTATION_COLOR_READ_FORMAT_OES && type == GLPARAM_IMPLEMENTATION_COLOR_READ_TYPE_OES )
	{
		//GLESHAL_WaitToIdleState();	// Frame buffer�� �����ؾ� �ϹǷ� �۾��� ���� ������ ��ٸ���.
		GLESHAL_Flush();
		while( !GLESHAL_IsIdleState() )
			GLESOAL_Sleep(0);

		GLESOAL_CopyDisplayToMemory_RGB565( __GLSTATE__.m_pSurface->GetColorBuffer(),
										    x,  y, width, height,
											pixels, width*2,
											__GLSTATE__.m_SAMPLE_BUFFERS );
	}
	else
	{
		GLSETERROR(GL_INVALID_OPERATION);
		return;
	}
	
	//if (!result) {
	//	GLSETERROR(GL_INVALID_VALUE);
	//}
}
