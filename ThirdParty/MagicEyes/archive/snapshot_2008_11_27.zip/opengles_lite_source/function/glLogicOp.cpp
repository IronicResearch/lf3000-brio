//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glLogicOp.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_7wkw.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


void glLogicOp (GLenum opcode)
{
	if( GL_CLEAR         != opcode && 
		GL_SET           != opcode && 
		GL_COPY          != opcode && 
		GL_COPY_INVERTED != opcode && 
		GL_NOOP          != opcode && 
		GL_INVERT        != opcode && 
		GL_AND           != opcode && 
		GL_NAND          != opcode && 
		GL_OR            != opcode && 
		GL_NOR           != opcode && 
		GL_XOR           != opcode && 
		GL_EQUIV         != opcode && 
		GL_AND_REVERSE   != opcode && 
		GL_AND_INVERTED  != opcode && 
		GL_OR_REVERSE    != opcode && 
		GL_OR_INVERTED	 != opcode )
		{
			GLSETERROR(GL_INVALID_ENUM);
			return;
		}
	__GLSTATE__.m_LogicOp = opcode;
}
