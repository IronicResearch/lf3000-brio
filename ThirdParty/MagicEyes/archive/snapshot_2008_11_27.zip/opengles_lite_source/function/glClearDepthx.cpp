//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glClearDepthx.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_4j1k.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//The glClearDepth function specifies the clear value for the depth buffer.

//depth 
// The depth value used when the depth buffer is cleared. 
// The glClearDepth function specifies the depth value used by glClear
//	to clear the depth buffer.
//	Values specified by glClearDepth are clamped to the range [0,1].
//
//	glGet with argument GL_DEPTH_CLEAR_VALUE
//
//	GL_INVALID_OPERATION  glClearDepth was called between a call to glBegin and the corresponding call to glEnd. 

void glClearDepthx (GLclampx depth)
{
	__GLSTATE__.m_ClearDepth=  X2VCF( CLAMPX( depth ) ) ;
}
