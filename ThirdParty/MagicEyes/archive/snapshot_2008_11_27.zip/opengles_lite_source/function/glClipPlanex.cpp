//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glClipPlanex.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_9g11.asp
//	Author     : Gamza(nik@mesdigital.com) �ǹ�
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

//The glClipPlane function specifies a plane against which all geometry is clipped.

// plane 
//	The clipping plane that is being positioned.
//	Symbolic names of the form GL_CLIP_PLANEi,
//	where i is an integer between 0 and GL_MAX_CLIP_PLANES-1, are accepted. 
//	GL_MAX_CLIP_PLANES is at least six in all implementations.
//	Because the resulting clipping region is the intersection of the defined half-spaces, it is always convex.
// equation 
//	The address of an array of four single-precision floating-point values.
//	These values are interpreted as a plane equation. 
//
// When you call glClipPlane, equation is transformed by the inverse of the modelview matrix
// and stored in the resulting eye coordinates.
// Subsequent(������) changes to the modelview matrix have no effect on the stored plane-equation components.
// If the dot product of the eye coordinates of a vertex with the stored plane equation components is positive or zero,
// the vertex is in with respect to that clipping plane. Otherwise, it is out.
// �������� ������ �Ẹ�� : (ModelViewMatrix * vertex) dot (InverseModelViewMatrix! * equation) < 0 �̸� �߷�����!!!
//
//	glGetClipPlane
//	glIsEnabled with argument GL_CLIP_PLANEi
//
//	GL_INVALID_ENUM  plane was not an accepted value. 
//	GL_INVALID_OPERATION  glClipPlane was called between a call to glBegin and the corresponding call to glEnd.  

void glClipPlanex (GLenum plane, const GLfixed *equation)
{
	if( GL_CLIP_PLANE0 > plane || GL_CLIP_PLANE0+GLPARAM_MAX_CLIP_PLANES <= plane ){ GLSETERROR( GL_INVALID_ENUM );	return; }
#if GLPARAM_MAX_CLIP_PLANES > 0
	Vec4D& clipplane = __GLSTATE__.m_ClipPlane[plane-GL_CLIP_PLANE0];
	
	// plane equation in eye coordinates = InverseModelViewMatrix.Transpose() * (equation);
	Vec4D plane_eq = {X2VF(equation[0]),X2VF(equation[1]),X2VF(equation[2]),X2VF(equation[3]) };
	const Matrix4x4 &invmodelview = __GLSTATE__.m_ModelViewMatrix.CurrentInverseMatrix();
	clipplane.x = VFMUL( invmodelview.m[0][0], plane_eq.x ) +
					VFMUL( invmodelview.m[1][0], plane_eq.y ) +
					VFMUL( invmodelview.m[2][0], plane_eq.z ) +
					VFMUL( invmodelview.m[3][0], plane_eq.w );
	clipplane.y = VFMUL( invmodelview.m[0][1], plane_eq.x ) +
					VFMUL( invmodelview.m[1][1], plane_eq.y ) +
					VFMUL( invmodelview.m[2][1], plane_eq.z ) +
					VFMUL( invmodelview.m[3][1], plane_eq.w );
	clipplane.z = VFMUL( invmodelview.m[0][2], plane_eq.x ) +
					VFMUL( invmodelview.m[1][2], plane_eq.y ) +
					VFMUL( invmodelview.m[2][2], plane_eq.z ) +
					VFMUL( invmodelview.m[3][2], plane_eq.w );
	clipplane.w = VFMUL( invmodelview.m[0][3], plane_eq.x ) +
					VFMUL( invmodelview.m[1][3], plane_eq.y ) +
					VFMUL( invmodelview.m[2][3], plane_eq.z ) +
					VFMUL( invmodelview.m[3][3], plane_eq.w );	
#endif
}
