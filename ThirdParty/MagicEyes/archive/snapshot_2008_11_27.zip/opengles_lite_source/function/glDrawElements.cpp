//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glDrawElements.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc01_1kz7.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//		2007/11/05 Yuni  Index address �� �ִ� index�� ���ϴ� ��ƾ ����.
//						 vertex array�� ���� client state�� disable�� ��쿡 ���� ó�� �߰�.
//		2007/10/17 Yuni  HW buffer object ��� �� ���� ���� �� ����
//	    2006/10/16 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"
//#include "../source/preparerendering.h"
#include "../source/renderprimitives.h"
#include "../source/gtecode.h"
#include "../source/hwbufferobject.h"


namespace 
{
	int	GetMaxIndexU8( const GLubyte* indices, GLsizei count )
	{	
		int maxIndex = 0;
		//printf("GetMaxIndexU8 - indices: 0x%x, count:%d\n", indices, count);
		for( int i = 0; i < count; i++ )
		{
			if( maxIndex < indices[i] )
				maxIndex = indices[i];
		}
		return maxIndex;
	}
	
	int	GetMaxIndexU16( const GLushort* indices, GLsizei count )
	{	
		int maxIndex = 0;
		//printf("GetMaxIndexU16 - indices: 0x%x, count:%d\n", indices, count);
		for( int i = 0; i < count; i++ )
		{
			if( maxIndex < indices[i] )
				maxIndex = indices[i];
		}
		return maxIndex;
	}
	
}

void glDrawElements (GLenum mode, GLsizei count, GLenum type, const GLvoid *indices)
{
	//printf("-element- (count:%d, mode:%d)\n", count, mode );
	if( !SetPrimitiveControlParam( mode ) )	// mode �˻�� �Բ� primitive control parameter ����.
	{ GLSETERROR(GL_INVALID_ENUM); return; }

	if( 0 > count ){ GLSETERROR(GL_INVALID_VALUE); return; }

	if( ( mode == GL_TRIANGLE_STRIP || mode == GL_TRIANGLE_FAN   || mode == GL_TRIANGLES )
		&& __GLSTATE__.m_Enable_CULL_FACE && __GLSTATE__.m_CullFace == GL_FRONT_AND_BACK )
	{
		//	�������ε�, �ø��ɼ��� GL_FRONT_AND_BACK�̸� �׸��� �ʴ´�.
		return;
	}

	GLESHAL_INDEXTYPE indexType;
	int indexStride = 0;
	if( GL_UNSIGNED_BYTE == type )
	{
		indexType = GLESHAL_INDEXTYPE_8;
		indexStride = 1;
	}
	else if( GL_UNSIGNED_SHORT == type )
	{
		indexType = GLESHAL_INDEXTYPE_16;
		indexStride = 2;
	}
	else
	{
		GLSETERROR(GL_INVALID_ENUM); 
		return; 
	}
	
	// HW buffer object�� ó��.
	__CURRENT_BO_STATE__ pState;	
	if( __GLSTATE__.m_ClientState_HARDWAREBUFFER_ARRAY_OES )
	{
		if( count <= 0 )
			return;
		
		GetCurrentBufferObjectState( &pState );		

		if( !SetupHWBufferToBufferObject( GL_TRUE ) )
			return;
	}
	else if( !__GLSTATE__.m_ClientState_VERTEX_ARRAY )
		return;		

	__GLSTATE__.m_IndexPointer.m_Buffer = __GLSTATE__.m_BindedBuffer[1];
	__GLSTATE__.m_IndexPointer.m_Pointer= indices;
	__GLSTATE__.m_IndexPointer.m_Size   = 1;
	__GLSTATE__.m_IndexPointer.m_Stride = indexStride;
	__GLSTATE__.m_IndexPointer.m_Type   = (GLint)indexType;

	// point�� ��� perspective correction�� ����.
	// Point�� line�� back face culling�� �ʿ����.
	if( (GL_POINTS==mode) || (GL_LINE_STRIP==mode) || (GL_LINES==mode) || (GL_LINE_LOOP==mode) )
	{
		unsigned long curRenderState = GLESHAL_GetRenderState();

		if(GL_POINTS==mode)
			curRenderState &= ~GLESHAL_RS_PERSPECTIVE_ENB;

		curRenderState &= ~GLESHAL_RS_BACKFACECULL_ENB;
		GLESHAL_SetRenderState( curRenderState );
	}
	int maxIndex = 0;

	if( !( __GLSTATE__.m_IndexPointer.m_Buffer ) &&
		(!( __GLSTATE__.m_VertexPointer.m_Buffer ) ||
		( __GLSTATE__.m_ClientState_COLOR_ARRAY ? !( __GLSTATE__.m_ColorPointer.m_Buffer ) : GL_FALSE ) || 
		( __GLSTATE__.m_ClientState_NORMAL_ARRAY ? !( __GLSTATE__.m_NormalPointer.m_Buffer ) : GL_FALSE ) ||
		( __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[0] ? !( __GLSTATE__.m_TexturePointer[0].m_Buffer ) : GL_FALSE ) || 
		( __GLSTATE__.m_ClientState_TEXTURE_COORD_ARRAY[1] ? !( __GLSTATE__.m_TexturePointer[1].m_Buffer ) : GL_FALSE ) ||
		( __GLSTATE__.m_ClientState_WEIGHT_ARRAY_OES ? !( __GLSTATE__.m_WeightPointer.m_Buffer ) : GL_FALSE ) ||
		( __GLSTATE__.m_ClientState_MATRIX_INDEX_ARRAY_OES ? !( __GLSTATE__.m_MatrixIndexPointer.m_Buffer ) : GL_FALSE ) ||
		( __GLSTATE__.m_ClientState_POINT_SIZE_ARRAY_OES ? !( __GLSTATE__.m_ColorPointer.m_Buffer ) : GL_FALSE ) ) )
	{
		const void* psrc = (const char*)(__GLSTATE__.m_IndexPointer.m_Pointer);

		if( GLESHAL_INDEXTYPE_8 == __GLSTATE__.m_IndexPointer.m_Type )
			maxIndex = GetMaxIndexU8( (GLubyte*)psrc, count );
		else
			maxIndex = GetMaxIndexU16( (GLushort*)psrc, count );
	}

	unsigned int streamValid = Preparerendering( 0, maxIndex + 1 );

	if( !streamValid )
		return;

	PrepareRenderingGTE( mode );
	RenderPrimitiveElements( streamValid, mode, count );

	// ���� perspective correction�� �ٽ� �Ҵ�.
	if( (GL_POINTS==mode) || (GL_LINE_STRIP==mode) || (GL_LINES==mode) || (GL_LINE_LOOP==mode) )
	{
		unsigned long curRenderState = GLESHAL_GetRenderState();
		curRenderState |= GLESHAL_RS_PERSPECTIVE_ENB;

		if(__GLSTATE__.m_Enable_CULL_FACE)
			curRenderState |= GLESHAL_RS_BACKFACECULL_ENB;

		GLESHAL_SetRenderState( curRenderState );
	}
	__GLSTATE__.m_IsPrimitiveCacheClear = GL_FALSE;
	
	// HW buffer object�� ó��.
	if( __GLSTATE__.m_ClientState_HARDWAREBUFFER_ARRAY_OES )
	{
		SetCurrentBufferObjectState( &pState );		
	}
}

