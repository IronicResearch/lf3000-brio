//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : glTexParameteriv.cpp
//	Description: http://msdn.microsoft.com/library/default.asp?url=/library/en-us/opengl/glfunc03_9upe.asp
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/15 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"

#define	_PARAMS_
#define _C( c )		(unsigned char)( (c) * (255.0/double(0x7FFFFFFF)) )
#define _I( i )		int(i)
#define _B( b )		((b)!=0 ? GL_TRUE : GL_FALSE )
#define _VF( v )	F2VF(v)
#define _VCF( v )	F2VCF(v)

void glTexParameteriv (GLenum target, GLenum pname, const GLint *params)
{
	//glTexParameteri (target, pname, (GLint)params[0]);
	#include "glTexParameter.inl"
}
