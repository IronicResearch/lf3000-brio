//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglMakeCurrent.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLBoolean eglMakeCurrent (EGLDisplay dpy, EGLSurface draw, EGLSurface read, EGLContext ctx)
{
	//	EGL_BAD_DISPLAY is generated if display is not an EGL display connection.
	//	EGL_NOT_INITIALIZED is generated if display has not been initialized.

	if (!__EGLSTATE__.m_isInit) 
	{
		EGLSETERROR( EGL_NOT_INITIALIZED );
	}
	// it's not current display.
	if (__EGLSTATE__.m_pCurDisplay != dpy)
	{
		EGLSETERROR( EGL_BAD_DISPLAY );
	}


	//	EGL_BAD_MATCH is generated if draw or read are not compatible with context,
	//                or if context is set to EGL_NO_CONTEXT and draw or read are not set to EGL_NO_SURFACE,
	//                or if draw or read are set to EGL_NO_SURFACE and context is not set to EGL_NO_CONTEXT.
	if( ( EGL_NO_CONTEXT == ctx && ( EGL_NO_SURFACE != read || EGL_NO_SURFACE != draw ) ) ||
		( EGL_NO_CONTEXT != ctx && ( EGL_NO_SURFACE == read || EGL_NO_SURFACE == draw ) ) )
	{
		EGLSETERROR( EGL_BAD_MATCH );
		return EGL_FALSE;
	}

	/*
	//	EGL_BAD_SURFACE is generated if draw or read is not an EGL surface.
	GLES_Surface* preadsurface = (GLES_Surface*)read;
	GLES_Surface* pdrawsurface = (GLES_Surface*)draw;
	if( EGL_NO_SURFACE != read && EGLSURFACE_FLAG != preadsurface->m_Config.m_EGLCONFIG ||
		EGL_NO_SURFACE != draw && EGLSURFACE_FLAG != pdrawsurface->m_Config.m_EGLCONFIG )
	{
		EGLSETERROR( EGL_BAD_SURFACE );
		return EGL_FALSE;
	}
	*/

	//	EGL_BAD_CONTEXT is generated if context is not an EGL rendering context.
	//__GLSTATESET__* pglstate = (__GLSTATESET__*)ctx;
	//if( EGL_NO_CONTEXT != ctx && EGLCONFIG_FLAG != pglstate->m_Config.m_EGLCONFIG )
	/*
	if( EGL_NO_CONTEXT == ctx )
	{
		EGLSETERROR( EGL_BAD_CONTEXT );
		return EGL_FALSE;
	}
	*/

	// Set Current Surface..
    if (dpy) 
	{ 
		__EGLSTATE__.m_pCurDrawSurface = draw; 
		__EGLSTATE__.m_pCurReadSurface = read; 
	}
	//	When a GL context is first attached to a surface (e.g. window),
	//	viewport and scissor are set to the dimensions of that surface.
	if( __GLSTATE__.m_pSurface != (GLES_Surface*)draw )
	{
		// it's first attached
		__GLSTATE__.m_pSurface = (GLES_Surface*)draw;

		if( __GLSTATE__.m_pSurface )
		{
			glViewport( 0,0, __GLSTATE__.m_pSurface->GetWidth(), __GLSTATE__.m_pSurface->GetHeight() );
			glScissor ( 0,0, __GLSTATE__.m_pSurface->GetWidth(), __GLSTATE__.m_pSurface->GetHeight() );
		}
		
	}	
	__EGLSTATE__.m_pCurContext = ctx;


	//	EGL_BAD_ACCESS is generated if context is current to some other thread	.
	//	EGL_BAD_NATIVE_PIXMAP may be generated if a native pixmap underlying either draw or read is no longer valid.
	//	EGL_BAD_NATIVE_WINDOW may be generated if a native window underlying either draw or read is no longer valid.
	//	EGL_BAD_CURRENT_SURFACE is generated if the previous context has unflushed commands and the previous surface is no longer valid.
	//	EGL_BAD_ALLOC may be generated if allocation of ancillary buffers for draw or read were delayed until eglMakeCurrent is called, and there are not enough resources to allocate them.
	//	EGL_CONTEXT_LOST is generated if a power management event has occurred. The application must destroy all contexts and reinitialise OpenGL ES state and objects to continue rendering.

/*
	__pCurContext = pglstate;
	if( __pCurContext )
	{
		//__pCurContext->m_pReadSurface = preadsurface;
		//__pCurContext->m_pDrawSurface = pdrawsurface;
		if( preadsurface )
		{
			preadsurface->m_pContext = __pCurContext;
		}
		if( pdrawsurface )
		{
			pdrawsurface->m_pContext = __pCurContext;
		}
	}
*/	


	return EGL_TRUE;
}
