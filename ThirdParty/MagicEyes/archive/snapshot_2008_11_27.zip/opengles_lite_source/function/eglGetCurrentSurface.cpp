//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE
//	AND WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING
//	BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR
//	FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : eglGetCurrentSurface.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2006/04/24 Gamza first implementation
//------------------------------------------------------------------------------
#include "../source/glstate.h"


EGLSurface eglGetCurrentSurface (EGLint readdraw)
{
	//if( ! __pCurContext ){ return EGL_NO_SURFACE; }

	switch( readdraw )
	{
	case EGL_READ:
		//if( ! __pCurContext->m_pReadSurface ){ return EGL_NO_SURFACE; }  // (EGL_NO_SURFACE == NULL) �̱⶧���� ��������.
		//return (EGLSurface)__pCurContext->m_pReadSurface;
		return (EGLSurface)__GLSTATE__.m_pSurface;
	case EGL_DRAW:
		//if( ! __pCurContext->m_pDrawSurface ){ return EGL_NO_SURFACE; }  // (EGL_NO_SURFACE == NULL) �̱⶧���� ��������.
		//return (EGLSurface)__pCurContext->m_pDrawSurface;
		return (EGLSurface)__GLSTATE__.m_pSurface;
	}
	return EGL_NO_SURFACE;
}
