//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza GLESOAL_WritePixel_RGBA8 ������Ʈ�� ������Ʈ �����ϵ��� ����.
//	   2007/08/28 Gamza 2�� �¼����� �ƴ� �ؽ����� ����ó���� ���� �Լ� �߰�.
//						GLESOAL_MakeEdgeForNonPowerOf2_8BPP
//						GLESOAL_MakeEdgeForNonPowerOf2_16BPP
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#include <GLESOAL_TextureCopy.h>
#include "mes_memory_debug.h"

#if defined(WIN32) || defined(UNDER_CE)
#pragma warning( disable:4514 )
#endif


namespace {

#define MAKE_R5G6B5( R, G, B )	(unsigned short)((((unsigned int)(R)&0xf8)<<8)|(((unsigned int)(G)&0xfc)<<3)|(((unsigned int)(B)&0xf8)>>3))


#define AddressTMEM( SubSegment, X, Y )		(						\
					(((SubSegment)&~1)<<21) | (((SubSegment)&1)<<16) |		\
					(((Y)&0x03E0)<<12)|(((Y)&0x001E)<<6)|(((Y)&0x0001)<<2)|	\
					(((X)&0x07C0)<< 5)|(((X)&0x003C)<<1)|(((X)&0x0003)<<0)	\
					)
#define AddressDMEM( SubSegment, X, Y )		(						\
					(((SubSegment)&~1)<<21) | (((SubSegment)&1)<<16) |		\
					(((Y)&0x03E0)<<12)|(((Y)&0x001F)<<6)|					\
					(((X)&0x07C0)<< 5)|(((X)&0x003F)<<0)					\
					)

//static unsigned char g_Mipmap[256*256*4];

inline void GetSegmentAddressWithLevel( unsigned int X, unsigned int Y, int level, unsigned int &nX, unsigned int &nY )
{
	int temp = 2;
	nY = 0;
	nX = 0;
	for( int i = 1; i < level; i++ )
	{
		nX += 256/temp;
		nY += 256/temp;
		temp *= 2;
	}

	nX += X/temp;
	nY += Y/temp;
}

inline void GetSegmentAddressWithLevel_U8( unsigned int X, unsigned int Y, int level, unsigned int &nX, unsigned int &nY )
{
	int temp = 2;
	nX = 0;
	nY = 0;
	for( int i = 1; i < level; i++ )
	{
		nX += 512/temp;
		nY += 256/temp;
		temp *= 2;
	}

	nX += X/temp;
	nY += Y/temp;
}

static void WriteTMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,				/// [in] x position in block memory (unit:16bit)
	unsigned int Y,				/// [in] y position in block memory
	unsigned short Data			/// [in] 16bit data
)
{

	*((unsigned short*)AddressTMEM( SubSegment, X*2, Y )) = Data;
}

static void WriteTMEM8
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,				/// [in] x position in block memory (unit:8bit)
	unsigned int Y,				/// [in] y position in block memory
	unsigned char Data			/// [in] 16bit data
)
{
	*((unsigned char*)AddressTMEM( SubSegment, X, Y )) = Data;
}

static unsigned short ReadDMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned short*)AddressDMEM( SubSegment, X*2, Y ));
}

static unsigned char ReadTMEM8
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned char*)AddressTMEM( SubSegment, X, Y ));
}

static unsigned short ReadTMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned short*)AddressTMEM( SubSegment, X*2, Y ));
}

GLESOALbool GLESOAL_CopyPixelToTexture_U4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned char value;
	unsigned int offsetX = X + pMemory2D->VirtualSegX;
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	Width = (Width+1)/2;	// char�� �д� ��� Width�� 1/2 �Ѵ�.
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *((unsigned char*)pSrc+(i + SrcStride*j));
			WriteTMEM8( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}

GLESOALbool GLESOAL_CopyPixelToTexture_U8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned char value;
	unsigned int offsetX = X + pMemory2D->VirtualSegX;
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *((unsigned char*)pSrc+(i+ SrcStride*j));
			WriteTMEM8( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}


GLESOALbool GLESOAL_CopyPixelToTexture_U16( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned short value;
	unsigned int offsetX = X + (pMemory2D->VirtualSegX/2);
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	int pixelPerByte = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *( (unsigned short*)((unsigned char*)pSrc+(i*pixelPerByte + SrcStride*j)) );
			WriteTMEM16( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}



//------------------------------------------------------------------------------
//
//	classes for template function
//
//------------------------------------------------------------------------------

/* read class */
class GLESOAL_ReadPixel_RGB8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 3
	};

// functions
public:
	GLESOAL_ReadPixel_RGB8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned char* pStart = (unsigned char*)m_pAddress+(X*BYTE_PER_PIXEL + m_Stride*Y);
		//unsigned short dstValue = MAKE_R5G6B5(pStart[0], pStart[1], pStart[2]);
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>3)<<11) |
												    ((pStart[1]>>2)<<5) |
												    (pStart[2]>>3) );

		return dstValue;
	}
};

class GLESOAL_ReadPixel_RGBA8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 4
	};

// functions
public:
	GLESOAL_ReadPixel_RGBA8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned char* pStart = (unsigned char*)m_pAddress+(X*BYTE_PER_PIXEL + m_Stride*Y);
/*
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>3)<<11) |
								  ((pStart[1]>>2)<<5) |
								  (pStart[2]>>3) );
*/
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>4)<<12) |
								  ((pStart[1]>>4)<<8) |
								  ((pStart[2]>>4)<<4 ) |
								  (pStart[3]>>4) );
		return dstValue;
	}
};


/* write class */
class GLESOAL_WritePixel_RGBA8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 4
	};

// functions
public:
	GLESOAL_WritePixel_RGBA8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		unsigned int curValue;
		unsigned char r = (unsigned char)((Value>>11)<<3);
		unsigned char g = (unsigned char)(((Value>>5)&0x3F)<<2);
		unsigned char b = (unsigned char)((Value&0x1F)<<3);
		unsigned char a = 0xFF;
		r = (unsigned char)( r | ( r>>5 ) );
		g = (unsigned char)( g | ( g>>6 ) );
		b = (unsigned char)( b | ( b>>5 ) );
		((unsigned char*)&curValue)[0] = r;
		((unsigned char*)&curValue)[1] = g;
		((unsigned char*)&curValue)[2] = b;
		((unsigned char*)&curValue)[3] = a;
		*((unsigned int*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y )) = curValue;
	}
};

class GLESOAL_WritePixel_R5G6B5
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 2
	};

// functions
public:
	GLESOAL_WritePixel_R5G6B5( const void *pDst, unsigned int DstStride )
	{
		m_pAddress = pDst;
		m_Stride = DstStride;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		*((unsigned short*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y)) = Value;
	}
};

//------------------------------------------------------------------------------
//
//	Memory2D Read/Write classes
//
//------------------------------------------------------------------------------
class GLESOAL_ReadMem2D_R5G6B5
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_ReadMem2D_R5G6B5( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		//return ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y);
		return ReadDMEM16( m_Segment, m_OffsetX+X, (m_OffsetY-g_WindowHeight+Y) );
	}
};

class GLESOAL_ReadMem2D_R5G6B5_FSAA
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_ReadMem2D_R5G6B5_FSAA( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned short color0 = ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY-(g_WindowHeight-Y)*2 + 0 );
		unsigned short color1 = ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY-(g_WindowHeight-Y)*2 + 1 );
		int r = ( ((color0>>11) & 0x1F) + ((color1>>11) & 0x1F) ) >> 1 ;
		int g = ( ((color0>> 5) & 0x3F) + ((color1>> 5) & 0x3F) ) >> 1 ;
		int b = ( ((color0>> 0) & 0x1F) + ((color1>> 0) & 0x1F) ) >> 1 ;
		return ((r<<11) | (g<<5) | b);
	}
};

class GLESOAL_WriteMem2D_R5G6B5
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_WriteMem2D_R5G6B5( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		WriteTMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y, Value );
		//*((unsigned short*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y)) = Value;
	}
};

class GLESOAL_WriteMem2D_L8
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_WriteMem2D_L8( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{		
		// refer to Table 3.15 in OpenGL v2.1 spec(3.8 Textureing)
		unsigned char curValue = (unsigned char)(Value>>11);
		curValue = (unsigned char)((curValue<<3)|(curValue>>2));
		WriteTMEM8( m_Segment, m_OffsetX+X, m_OffsetY+Y, curValue );
	}
};


class GLESOAL_ReadTex2D_R5G6B5
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;

public:

	GLESOAL_ReadTex2D_R5G6B5( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		//return ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y);
		return ReadTMEM16( m_Segment, m_OffsetX+X, (m_OffsetY-g_WindowHeight+Y) );
	}
};

class GLESOAL_ReadTex2D_L8
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_ReadTex2D_L8( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		//return ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y);
		return ReadTMEM16( m_Segment, m_OffsetX+X, (m_OffsetY-g_WindowHeight+Y) );
	}
};



}	// namespace

//------------------------------------------------------------------------------
//
//	export functions
//
//------------------------------------------------------------------------------
GLESOALbool GLESOAL_CopyTexture_U8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height )
{
	unsigned char value;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadTMEM8( pSrcMemory2D->VirtualSegment, pSrcMemory2D->VirtualSegX+i, pSrcMemory2D->VirtualSegY+j );
			WriteTMEM8( pDstMemory2D->VirtualSegment, pDstMemory2D->VirtualSegX+i, pDstMemory2D->VirtualSegY+j, value );
		}

	return 1;
}

GLESOALbool GLESOAL_CopyTexture_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height )
{
	unsigned short value;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadTMEM16( pSrcMemory2D->VirtualSegment, pSrcMemory2D->VirtualSegX/2+i, pSrcMemory2D->VirtualSegY+j );
			WriteTMEM16( pDstMemory2D->VirtualSegment, pDstMemory2D->VirtualSegX/2+i, pDstMemory2D->VirtualSegY+j, value );
		}

	return 1;
}



GLESOALbool GLESOAL_GetMipmapPosition_U16(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y )
{
	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	unsigned int newX, newY;

	GetSegmentAddressWithLevel( (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Level, newX, newY );
	if( (newX>=256) || (newY>=256) )
		return 0;

	*X = offsetX + newX;
	*Y = offsetY + newY;

	return 1;
}

GLESOALbool GLESOAL_GetMipmapPosition_U8(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y )
{
	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 1024 + 512;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	unsigned int newX, newY;

	GetSegmentAddressWithLevel_U8( (pMemory2D->VirtualSegX%1024), (pMemory2D->VirtualSegY%512), Level, newX, newY );
	if( (newX>=512) || (newY>=256) )
		return 0;

	*X = offsetX + newX;
	*Y = offsetY + newY;

	return 1;
}

GLESOALbool GLESOAL_UploadMipmap_U8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	unsigned char value;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *((unsigned char*)pSrc+(i+ SrcStride*j));
			WriteTMEM8( pMemory2D->VirtualSegment, X+i, Y+j, value );
		}

	return 1;
}

GLESOALbool GLESOAL_UploadCopyTextureMipmap_L8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height )
{
	unsigned short value;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadDMEM16( pSrcMemory2D->VirtualSegment, pSrcMemory2D->VirtualSegX/2 + i + X, pSrcMemory2D->VirtualSegY + g_WindowHeight-1-j - Y );

			unsigned char curValue = (unsigned char)(value>>11);
			curValue = (unsigned char)((curValue<<3)|(curValue>>2));
			WriteTMEM8( pTexMemory2D->VirtualSegment, OffsetX+i, OffsetY+j, curValue );
		}
	return 1;
}

GLESOALbool GLESOAL_UploadMipmap_U16( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	unsigned short value;

	int pixelPerByte = 2;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *( (unsigned short*)((unsigned char*)pSrc+(i*pixelPerByte + SrcStride*j)) );
			WriteTMEM16( pMemory2D->VirtualSegment, X+i, Y+j, value );
		}

	return 1;
}

GLESOALbool GLESOAL_UploadCopyTextureMipmap_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height )
{
	unsigned short value;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadDMEM16( pSrcMemory2D->VirtualSegment, pSrcMemory2D->VirtualSegX/2 + i + X, pSrcMemory2D->VirtualSegY + g_WindowHeight-1-j - Y );
			WriteTMEM16( pTexMemory2D->VirtualSegment, OffsetX+i, OffsetY+j, value );
		}

	return 1;
}


GLESOALbool GLESOAL_UploadMipmap_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	GLESOAL_ReadPixel_RGB8 Reader( pSrc, SrcStride );
	GLESOAL_WriteMem2D_R5G6B5 Writer( pMemory2D->VirtualSegment, X, Y );
	
	unsigned int curWidth = SrcStride / GLESOAL_ReadPixel_RGB8::BYTE_PER_PIXEL;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	TextureCopyWithObject< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGB8 >( Writer, Reader, curWidth, Height );
	return 1;
}

GLESOALbool GLESOAL_UploadMipmap_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	GLESOAL_ReadPixel_RGBA8 Reader( pSrc, SrcStride );

	unsigned short value;

	//int pixelPerByte = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = Reader.Read( i, j );
			WriteTMEM16( pMemory2D->VirtualSegment, X+i, Y+j, value );
		}

	return 1;
}



GLESOALbool GLESOAL_UploadTexture_index4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{

	unsigned int curWidth = SrcStride * 2;	// 4bit �̹Ƿ� 1/2byte�� ��.
	if( curWidth != Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		return 0;

	return GLESOAL_CopyPixelToTexture_U4( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_index8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned int curWidth = SrcStride;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_A8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
	unsigned int curWidth = SrcStride;	// source�� ���� width ���.
	if( curWidth != Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		return 0;

	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}


GLESOALbool WriteMipmapTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 1024 + 512;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel_U8( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_U8( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX], SrcStride );

		level++;
	}
	return true;
}

void CreateMipmapWithLevel_A8( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256*2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel_U8( OffsetX, OffsetY, Level, newX, newY );
	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned char* curPixel = &(((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2)]);
			unsigned char* pDstPixel = &(((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i )]);
			pDstPixel[0] =  ( (unsigned int)(curPixel[0]) + curPixel[1] + curPixel[0 + Stride] + curPixel[1 + Stride] )/4;
			// �ݿø�?
		}
	}
	CreateMipmapWithLevel_A8( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_A8( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024), (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_A8( pMemory2D, (pMemory2D->VirtualSegX%1024), (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256 * 2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_UploadTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;

	GLESOAL_ReadPixel_RGB8 Reader( pSrc, SrcStride );
	GLESOAL_WriteMem2D_R5G6B5 Writer( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+X, pMemory2D->VirtualSegY+Y );
	
	unsigned int curWidth = SrcStride / GLESOAL_ReadPixel_RGB8::BYTE_PER_PIXEL;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	TextureCopyWithObject< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGB8 >( Writer, Reader, curWidth, Height );
	return 1;
}

GLESOALbool WriteMipmapTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;
/*
	unsigned char* pData = ( unsigned char* )pSrc;

	for( int j = 0; j < 256; j++ )
	{
		for( int i = 0; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 255;
			pData[ (j * 256 + i) * 3 + 1 ] = 255;
			pData[ (j * 256 + i) * 3 + 2 ] = 255;
		}
	}

	for( j = 128; j < 256; j++ )
	{
		for( int i = 128; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 0;
			pData[ (j * 256 + i) * 3 + 1 ] = 255;
			pData[ (j * 256 + i) * 3 + 2 ] = 0;
		}
	}

	for( j = 192; j < 256; j++ )
	{
		for( int i = 192; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 0;
			pData[ (j * 256 + i) * 3 + 1 ] = 0;
			pData[ (j * 256 + i) * 3 + 2 ] = 255;
		}
	}

	for( j = 224; j < 256; j++ )
	{
		for( int i = 224; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 255;
			pData[ (j * 256 + i) * 3 + 1 ] = 255;
			pData[ (j * 256 + i) * 3 + 2 ] = 0;
		}
	}

	for( j = 240; j < 256; j++ )
	{
		for( int i = 240; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 255;
			pData[ (j * 256 + i) * 3 + 1 ] = 0;
			pData[ (j * 256 + i) * 3 + 2 ] = 255;
		}
	}

	for( j = 248; j < 256; j++ )
	{
		for( int i = 248; i < 256; i++ )
		{
			pData[ (j * 256 + i) * 3 + 0 ] = 0;
			pData[ (j * 256 + i) * 3 + 1 ] = 255;
			pData[ (j * 256 + i) * 3 + 2 ] = 255;
		}
	}

	GLESOAL_UploadMipmap_RGB8( pMemory2D, offsetX, offsetY, 256, 256, 
		pData, SrcStride );
*/

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_RGB8( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 3], SrcStride );

		level++;
	}

	return true;
}

void CreateMipmapWithLevel_RGB8( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 3;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned char* curPixel = &((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 3];
			unsigned char* pDstPixel = &((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 3];
			pDstPixel[0] = ( (unsigned int)(curPixel[0]) + curPixel[3] + curPixel[0 + Stride] + curPixel[3 + Stride] )/4; 
			pDstPixel[1] = ( (unsigned int)(curPixel[1]) + curPixel[4] + curPixel[1 + Stride] + curPixel[4 + Stride] )/4;
			pDstPixel[2] = ( (unsigned int)(curPixel[2]) + curPixel[5] + curPixel[2 + Stride] + curPixel[5 + Stride] )/4;
		}
	}
	CreateMipmapWithLevel_RGB8( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 3 );
	CreateMipmapWithLevel_RGB8( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = WriteMipmapTexture_RGB8( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), 
		Width, Height, pMipmap, 256*3 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_UploadTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGBA8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );

	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;
	
	GLESOAL_ReadPixel_RGBA8 Reader( pSrc, SrcStride );

	unsigned int curWidth = SrcStride / GLESOAL_ReadPixel_RGBA8::BYTE_PER_PIXEL;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	unsigned short value;
	unsigned int offsetX = X + (pMemory2D->VirtualSegX/2);
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<curWidth; i++ )
		{
			value = Reader.Read( i, j );
			WriteTMEM16( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}	

	return 1;
}

GLESOALbool WriteMipmapTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_RGBA8( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 4], SrcStride );

		level++;
	}
	return true;
}

void CreateMipmapWithLevel_RGBA8( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 4;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned char* curPixel = &((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 4];
			unsigned char* pDstPixel = &((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 4];
			pDstPixel[0] = ( (unsigned int)(curPixel[0]) + curPixel[4] + curPixel[0 + Stride] + curPixel[4 + Stride] )/4;
			pDstPixel[1] = ( (unsigned int)(curPixel[1]) + curPixel[5] + curPixel[1 + Stride] + curPixel[5 + Stride] )/4;
			pDstPixel[2] = ( (unsigned int)(curPixel[2]) + curPixel[6] + curPixel[2 + Stride] + curPixel[6 + Stride] )/4;
			pDstPixel[3] = ( (unsigned int)(curPixel[3]) + curPixel[7] + curPixel[3 + Stride] + curPixel[7 + Stride] )/4;
		}
	}
	CreateMipmapWithLevel_RGBA8( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 4 );
	CreateMipmapWithLevel_RGBA8( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_RGBA8( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*4 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}

GLESOALbool GLESOAL_UploadTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	//if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )	// width�� ���� �ʳ�..?
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )
		return 0;

	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool WriteMipmapTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_U16( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 2], SrcStride );

		level++;
	}
	return 1;
}

void CreateMipmapWithLevel_R5G6B5( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned short* curPixel = (unsigned short*)(&((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 2]);
			unsigned short* pDstPixel = (unsigned short*)(&((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 2]);
			unsigned int color0 = curPixel[0];
			unsigned int color1 = curPixel[1];
			unsigned int color2 = curPixel[Stride/2+0];
			unsigned int color3 = curPixel[Stride/2+1];
			/*
			pDstPixel[0] = (( 0xF800 & color0 ) + ( 0xF800 & color1 ) + ( 0xF800 & color2 ) + ( 0xF800 & color3 ))/4 |
							(( 0x07E0 & color0 ) + ( 0x07E0 & color1 ) + ( 0x07E0 & color2 ) + ( 0x07E0 & color3 ))/4 |
							(( 0x001F & color0 ) + ( 0x001F & color1 ) + ( 0x001F & color2 ) + ( 0x001F & color3 ))/4;
			*/
			unsigned int red = (( 0xF800 & color0 ) + ( 0xF800 & color1 ) + ( 0xF800 & color2 ) + ( 0xF800 & color3 ))/4;
			unsigned int green = (( 0x07E0 & color0 ) + ( 0x07E0 & color1 ) + ( 0x07E0 & color2 ) + ( 0x07E0 & color3 ))/4;
			unsigned int blue = (( 0x001F & color0 ) + ( 0x001F & color1 ) + ( 0x001F & color2 ) + ( 0x001F & color3 ))/4;

			pDstPixel[0] = red | green | blue;
		}
	}
	CreateMipmapWithLevel_R5G6B5( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_R5G6B5( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_R5G6B5( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_UploadTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_R5G6B5 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;

	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool WriteMipmapTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_U16( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 2], SrcStride );

		level++;
	}
	return true;
}

void CreateMipmapWithLevel_RGB5A1( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned short* curPixel = (unsigned short*)(&((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 2]);
			unsigned short* pDstPixel = (unsigned short*)(&((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 2]);
			unsigned int color0 = curPixel[0];
			unsigned int color1 = curPixel[1];
			unsigned int color2 = curPixel[Stride+0];
			unsigned int color3 = curPixel[Stride+1];
			pDstPixel[ 0] = (( 0xF800 & color0 ) + ( 0xF800 & color1 ) + ( 0xF800 & color2 ) + ( 0xF800 & color3 ))/4 |
				(( 0x07D0& color0 ) + ( 0x07D0 & color1 ) + ( 0x07D0 & color2 ) + ( 0x07D0 & color3 ))/4 |
				(( 0x003E & color0 ) + ( 0x003E & color1 ) + ( 0x003E & color2 ) + ( 0x003E & color3 ))/4 |
				(( 0x0001 & color0 ) + ( 0x0001 & color1 ) + ( 0x0001 & color2 ) + ( 0x0001 & color3 ))/4;
			// �ݿø�?
		}
	}
	CreateMipmapWithLevel_RGB5A1( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_RGB5A1( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_RGB5A1( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_UploadTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGB5A1 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );

	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	//if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )	// width�� ���� �ʳ�..?	
		return 0;
		
	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool WriteMipmapTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_U16( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 2], SrcStride );

		level++;
	}
	return true;
}

void CreateMipmapWithLevel_RGBA4( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned short* curPixel = (unsigned short*)(&((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 2]);
			unsigned short* pDstPixel = (unsigned short*)(&((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 2]);
			unsigned int color0 = curPixel[0];
			unsigned int color1 = curPixel[1];
			unsigned int color2 = curPixel[Stride+0];
			unsigned int color3 = curPixel[Stride+1];
			pDstPixel[ 0] = (( 0xF000 & color0 ) + ( 0xF000 & color1 ) + ( 0xF000 & color2 ) + ( 0xF000 & color3 ))/4 |
							(( 0x0F00 & color0 ) + ( 0x0F00 & color1 ) + ( 0x0F00 & color2 ) + ( 0x0F00 & color3 ))/4 |
							(( 0x00F0 & color0 ) + ( 0x00F0 & color1 ) + ( 0x00F0 & color2 ) + ( 0x00F0 & color3 ))/4 |
							(( 0x000F & color0 ) + ( 0x000F & color1 ) + ( 0x000F & color2 ) + ( 0x000F & color3 ))/4;
			// �ݿø�?
		}
	}
	CreateMipmapWithLevel_RGBA4( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_RGBA4( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_RGBA4( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_UploadTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_L8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;
	
	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool WriteMipmapTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 1024 + 512;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel_U8( X, Y, level, newX, newY );

		GLESOAL_UploadMipmap_U8( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX], SrcStride );

		level++;
	}

	//GLESOAL_UploadMipmap_U8( pMemory2D, offsetX, offsetY, 256*2, 256, &((unsigned char*)pSrc)[0], SrcStride );


	return true;
}

void CreateMipmapWithLevel_L8( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel_U8( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned char* curPixel = &((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2)];
			unsigned char* pDstPixel = &((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i )];
			pDstPixel[0] =  ( (unsigned int)(curPixel[0]) + curPixel[1] + curPixel[0 + Stride] + curPixel[1 + Stride] )/4;
			// �ݿø�?
		}
	}
	CreateMipmapWithLevel_L8( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool GLESOAL_CreateMipmapTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_L8( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024), (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	//memset( pMipmap, 0xff, sizeof(unsigned char) * 256 * 256 * 2 );
	GLESOALbool result = 
		WriteMipmapTexture_L8( pMemory2D, (pMemory2D->VirtualSegX%1024), (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}

GLESOALbool GLESOAL_UploadTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_LA8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;

	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

void CreateMipmapWithLevel_LA8( void* pSrcData, unsigned int Stride,
								unsigned int X, unsigned int Y,
								unsigned int OffsetX, unsigned int OffsetY,
								unsigned int Width, unsigned int Height,
								void* pDstData, int Level )
{
	unsigned int newX, newY;
	unsigned int dstStride = 256 * 2;

	if( ( Width == 1 ) || (Height == 1 ) )
		return;

	GetSegmentAddressWithLevel( OffsetX, OffsetY, Level, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			//unsigned char* curPixel = &((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 2];
			//unsigned char* pDstPixel = &((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 2];
			//pDstPixel[0] =  ( (unsigned int)(curPixel[0]) + curPixel[2] + curPixel[0 + Stride] + curPixel[2 + Stride] )/4;
			//pDstPixel[1] =  ( (unsigned int)(curPixel[1]) + curPixel[3] + curPixel[1 + Stride] + curPixel[3 + Stride] )/4;
			// �ݿø�?

			unsigned short* curPixel = (unsigned short*)(&((unsigned char*)pSrcData)[(Y+j*2) * Stride + (X+i*2) * 2]);
			unsigned short* pDstPixel = (unsigned short*)(&((unsigned char*)pDstData)[(newY + j) * dstStride + (newX + i ) * 2]);
			unsigned int color0 = curPixel[0];
			unsigned int color1 = curPixel[1];
			unsigned int color2 = curPixel[Stride/2+0];
			unsigned int color3 = curPixel[Stride/2+1];
			pDstPixel[ 0] = (( 0xFF00 & color0 ) + ( 0xFF00 & color1 ) + ( 0xFF00 & color2 ) + ( 0xFF00 & color3 ))/4 |
							(( 0x00FF & color0 ) + ( 0x00FF & color1 ) + ( 0x00FF & color2 ) + ( 0x00FF & color3 ))/4;
		}
	}
	CreateMipmapWithLevel_LA8( pDstData, dstStride, newX, newY, OffsetX, OffsetY, Width/2, Height/2, pDstData, Level+1 );
}

GLESOALbool WriteMipmapTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
								unsigned int X, unsigned int Y,
								unsigned int Width, unsigned int Height, 
								const void* pSrc, unsigned int SrcStride )
{
	unsigned int newX, newY;
	unsigned int level = 1;

	unsigned int offsetX = pMemory2D->VirtualSegX/1024 * 512 + 256;
	unsigned int offsetY = pMemory2D->VirtualSegY/512 * 512 + 256;

	while( (Width/2 != 1) && (Height/2 != 1) )
	{
		Width /= 2;
		Height /= 2;

		GetSegmentAddressWithLevel( X, Y, level, newX, newY );
		GLESOAL_UploadMipmap_U16( pMemory2D, newX + offsetX, newY + offsetY, Width, Height, 
			&((unsigned char*)pSrc)[newY*SrcStride + newX * 2], SrcStride );

		level++;
	}
	return true;
}

GLESOALbool GLESOAL_CreateMipmapTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	if( Width > 512 )
		return false;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	CreateMipmapWithLevel_LA8( (void*)pSrc, SrcStride, 0, 0, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 1 );
	GLESOALbool result = 
		WriteMipmapTexture_LA8( pMemory2D, (pMemory2D->VirtualSegX%1024)/2, (pMemory2D->VirtualSegY%512), Width, Height, pMipmap, 256*2 );	

	MES_DELETE_ARRAY( pMipmap );
	return result;
}


GLESOALbool GLESOAL_CopyDisplayToMemory_RGB565( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );
	GLESOAL_WritePixel_R5G6B5 Writer( pDst, DstStride );

	unsigned int curWidth = DstStride / GLESOAL_WritePixel_R5G6B5::BYTE_PER_PIXEL;
	if( curWidth > Width )
		curWidth = Width;

	if( !FSAA )
		ReadDisplayWriteTexture< GLESOAL_WritePixel_R5G6B5, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, curWidth, Height );
	else
		ReadDisplayWriteTexture< GLESOAL_WritePixel_R5G6B5, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, curWidth, Height );
	return 1;
/*
	unsigned int curWidth = DstStride / 2;
	if( Width > curWidth )
		Width = curWidth;

	unsigned short value;
	unsigned int offsetX = X + pSrcMemory2D->VirtualSegX/2;
	unsigned int offsetY = pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y;

	int bytePerPixel = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadDMEM16( pSrcMemory2D->VirtualSegment, offsetX+i, (offsetY-j) );
			*((unsigned short*)((unsigned char*)pDst + (i*bytePerPixel + DstStride*j))) = value;
		}
	return 1;		
*/
}

GLESOALbool GLESOAL_CopyDisplayToMemory_RGBA8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
									 
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );
	GLESOAL_WritePixel_RGBA8 Writer( pDst, DstStride );

	unsigned int curWidth = DstStride / GLESOAL_WritePixel_RGBA8::BYTE_PER_PIXEL;
	if( curWidth > Width )
		curWidth = Width;

	if( !FSAA )
		ReadDisplayWriteTexture< GLESOAL_WritePixel_RGBA8, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, curWidth, Height );
	else
		ReadDisplayWriteTexture< GLESOAL_WritePixel_RGBA8, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, curWidth, Height );
	return 1;				
}

//---------------------------------------------------------------------------------------------------------------------------------------
GLESOALbool GLESOAL_CreateMipmapCopyTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height )
{
	if( Width > 512 )
		return false;

	unsigned int dstStride	= 256 * 2;
	unsigned int newX, newY;
	unsigned int offsetX = (pMemory2D->VirtualSegX%1024)/2;
	unsigned int offsetY = pMemory2D->VirtualSegY%512;

	if( ( Width == 1 ) || (Height == 1 ) )
		return true;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	GetSegmentAddressWithLevel( offsetX, offsetY, 1, newX, newY );
	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{		
			unsigned short* pDstPixel = (unsigned short*)(&(pMipmap[(newY + j) * dstStride + (newX + i )*2]));
			unsigned short color0 = ReadTMEM16( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+(X+i*2), pMemory2D->VirtualSegY +(Y+j*2) );
			unsigned short color1 = ReadTMEM16( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+(X+i*2+1), pMemory2D->VirtualSegY +(Y+j*2) );
			unsigned short color2 = ReadTMEM16( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+(X+i*2), pMemory2D->VirtualSegY +(Y+j*2+1) );
			unsigned short color3 = ReadTMEM16( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+(X+i*2+1), pMemory2D->VirtualSegY +(Y+j*2+1) );

			pDstPixel[ 0] = (unsigned short)((float)(( 0xF800 & color0 ) + ( 0xF800 & color1 ) + ( 0xF800 & color2 ) + ( 0xF800 & color3 ))/4 + 0.5f) |
							(unsigned short)((float)(( 0x07E0 & color0 ) + ( 0x07E0 & color1 ) + ( 0x07E0 & color2 ) + ( 0x07E0 & color3 ))/4 + 0.5f) |
							(unsigned short)((float)(( 0x001F & color0 ) + ( 0x001F & color1 ) + ( 0x001F & color2 ) + ( 0x001F & color3 ))/4 + 0.5f);

			//unsigned char curValue = (unsigned char)(Value>>11);
			//pDstPixel[ 0] = (unsigned char)((curValue<<3)|(curValue>>2));
			// �ݿø�?
		}
	}

	CreateMipmapWithLevel_R5G6B5( pMipmap, dstStride, newX, newY, offsetX, offsetY, Width/2, Height/2, pMipmap, 2 );
	GLESOALbool result = 
		WriteMipmapTexture_R5G6B5( pMemory2D, offsetX, offsetY, Width, Height, pMipmap, 256*2 );

	MES_DELETE_ARRAY( pMipmap );
	return result;
}

GLESOALbool GLESOAL_CopyDisplayToTexture_R5G6B5( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )	
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	if( ( (OffsetX+Width)>(pDstMemory2D->Width/2) ) || ((OffsetY+Height)>pDstMemory2D->Height) )		
		return 0;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );

	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 			pSrcMemory2D->VirtualSegX/2+X, 
									 			pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );

	GLESOAL_WriteMem2D_R5G6B5 Writer( pDstMemory2D->VirtualSegment, 
									  pDstMemory2D->VirtualSegX/2+OffsetX, 
									  pDstMemory2D->VirtualSegY+OffsetY );

	if( ! FSAA )	
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, Width, Height, ScaleX, ScaleY );
	else
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, Width, Height, ScaleX, ScaleY );
	return 1;
}

GLESOALbool GLESOAL_CreateMipmapCopyTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height )
{
	if( Width > 512 )
		return false;

	unsigned int dstStride	= 256 * 2;
	unsigned int newX, newY;
	unsigned int offsetX = pMemory2D->VirtualSegX%1024;
	unsigned int offsetY = pMemory2D->VirtualSegY%512;

	if( ( Width == 1 ) || (Height == 1 ) )
		return true;

	unsigned char* pMipmap = MES_NEW_ARRAY( unsigned char, 256 * 256 * 2 );
	//memset( pMipmap, 0x00, sizeof(unsigned char) * 256 * 256 * 2 );

	GetSegmentAddressWithLevel_U8( offsetX, offsetY, 1, newX, newY );

	for( unsigned int j = 0; j < Height/2; j++ )
	{
		for( unsigned int i = 0; i < Width/2; i++ )
		{
			unsigned char* pDstPixel = &(pMipmap[(newY + j) * dstStride + (newX + i )]);
			unsigned char color0 = ReadTMEM8( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX+(X+i*2), pMemory2D->VirtualSegY +(Y+j*2) );
			unsigned char color1 = ReadTMEM8( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX+(X+i*2+1), pMemory2D->VirtualSegY +(Y+j*2) );
			unsigned char color2 = ReadTMEM8( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX+(X+i*2), pMemory2D->VirtualSegY +(Y+j*2+1) );
			unsigned char color3 = ReadTMEM8( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX+(X+i*2+1), pMemory2D->VirtualSegY +(Y+j*2+1) );

			pDstPixel[ 0] = ((unsigned int)color0 + color1 + color2 + color3)/4;
		}
	}
 	CreateMipmapWithLevel_L8( pMipmap, dstStride, newX, newY, offsetX, offsetY, Width/2, Height/2, pMipmap, 2 );
	GLESOALbool result = 
		WriteMipmapTexture_L8( pMemory2D, offsetX, offsetY, Width, Height, pMipmap, 256*2 );

/*
	CreateMipmapWithLevel_L8( (void*)pMipmap, dstStride, newX, newY, offsetX, offsetY, Width, Height, pMipmap, 2 );
	GLESOALbool result = 
		WriteMipmapTexture_L8( pMemory2D, offsetX, offsetY, Width, Height, pMipmap, 256*2 );
*/
	MES_DELETE_ARRAY( pMipmap );
	return result;
}

GLESOALbool GLESOAL_CopyDisplayToTexture_L8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	if( ( (OffsetX+Width)>(pDstMemory2D->Width) ) || ((OffsetY+Height)>pDstMemory2D->Height) )		
		return 0;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
									 
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );

	GLESOAL_WriteMem2D_L8 Writer( pDstMemory2D->VirtualSegment, 
								  pDstMemory2D->VirtualSegX+OffsetX, 
								  pDstMemory2D->VirtualSegY+OffsetY );

	if( ! FSAA )
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_L8, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, Width, Height, ScaleX, ScaleY );
	else
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_L8, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, Width, Height, ScaleX, ScaleY );

	return 1;
}

void GLESOAL_MakeEdgeForNonPowerOf2_8BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height )
{
	int seg   = pMemory2D->VirtualSegment;
	int seg_x = pMemory2D->VirtualSegX;
	int seg_y = pMemory2D->VirtualSegY;
	int mem_w = pMemory2D->Width;
	int mem_h = pMemory2D->Height;
	if( mem_h > Height )
	{
		for( int x=0; x < Width; x++ )
		{
			unsigned char data0 = ReadTMEM8 ( seg, seg_x+x, seg_y          );
			unsigned char data1 = ReadTMEM8 ( seg, seg_x+x, seg_y+Height-1 );
			WriteTMEM8( seg, seg_x+x, seg_y+mem_h-1, data0 );
			WriteTMEM8( seg, seg_x+x, seg_y+Height,  data1 );
		}
	}
	if( mem_w > Width )
	{
		for( int y=0; y < Height; y++ )
		{
			unsigned char data0 = ReadTMEM8 ( seg, seg_x,         seg_y+y );
			unsigned char data1 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y+y );
			WriteTMEM8( seg, seg_x+mem_w-1, seg_y+y, data0 );
			WriteTMEM8( seg, seg_x+Width,   seg_y+y, data1 );
		}
	}
	
	if( mem_w > Width && mem_h > Height )
	{
		unsigned char data0 = ReadTMEM8 ( seg, seg_x        , seg_y );
		unsigned char data1 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y );
		unsigned char data2 = ReadTMEM8 ( seg, seg_x        , seg_y+Height-1 );
		unsigned char data3 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y+Height-1 );
		WriteTMEM8( seg, seg_x+mem_w-1, seg_y+mem_h-1, data0 );
		WriteTMEM8( seg, seg_x+Width,   seg_y+mem_h-1, data1 );
		WriteTMEM8( seg, seg_x+mem_w-1, seg_y+Height,  data2 );
		WriteTMEM8( seg, seg_x+Width,   seg_y+Height,  data3 );
	}
}

void GLESOAL_MakeEdgeForNonPowerOf2_16BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height )
{
	int seg   = pMemory2D->VirtualSegment;
	int seg_x = pMemory2D->VirtualSegX / 2;
	int seg_y = pMemory2D->VirtualSegY;
	int mem_w = pMemory2D->Width / 2;
	int mem_h = pMemory2D->Height;
	if( mem_h > Height )
	{
		for( int x=0; x < Width; x++ )
		{
			unsigned short data0 = ReadTMEM16 ( seg, seg_x+x, seg_y          );
			unsigned short data1 = ReadTMEM16 ( seg, seg_x+x, seg_y+Height-1 );
			WriteTMEM16( seg, seg_x+x, seg_y+mem_h-1, data0 );
			WriteTMEM16( seg, seg_x+x, seg_y+Height,  data1 );
		}
	}
	if( mem_w > Width )
	{
		for( int y=0; y < Height; y++ )
		{
			unsigned short data0 = ReadTMEM16 ( seg, seg_x,         seg_y+y );
			unsigned short data1 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y+y );
			WriteTMEM16( seg, seg_x+mem_w-1, seg_y+y, data0 );
			WriteTMEM16( seg, seg_x+Width,   seg_y+y, data1 );
		}
	}
	
	if( mem_w > Width && mem_h > Height )
	{
		unsigned short data0 = ReadTMEM16 ( seg, seg_x        , seg_y );
		unsigned short data1 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y );
		unsigned short data2 = ReadTMEM16 ( seg, seg_x        , seg_y+Height-1 );
		unsigned short data3 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y+Height-1 );
		WriteTMEM16( seg, seg_x+mem_w-1, seg_y+mem_h-1, data0 );
		WriteTMEM16( seg, seg_x+Width,   seg_y+mem_h-1, data1 );
		WriteTMEM16( seg, seg_x+mem_w-1, seg_y+Height,  data2 );
		WriteTMEM16( seg, seg_x+Width,   seg_y+Height,  data3 );
	}
}
