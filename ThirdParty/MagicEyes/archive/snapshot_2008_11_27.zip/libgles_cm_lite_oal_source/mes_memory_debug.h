//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : memory management
//	File       : mes_memory_debug.h
//	Description:
//	Author     : Gamza (gamza@mesgraphics.com)
//	Export     : MES_MALLOC
//				 MES_FREE
//				 MES_NEW
//				 MES_NEW_ARRAY
//				 MES_DELETE
//				 MES_DELETE_ARRAY
//	History    :
//     2007/10/18 Gamza	RVDS���� MES_NEW/MES_DELETE/..���� ������ �ȵǴ� ���� ����.
//     2007/09/12 Gamza	AUTO_DESTROYER�Ҵ���п� ���� ���ܻ�Ȳ�� �������� �ʾƵ� �ǵ��� ������.
//						AUTO_DESTROYER�� heap�� �������� �ʰ�, singleton�� ���.
//     2007/08/24 Gamza	������� �Ǽ������� memory leak���� �����ϵ��� ����.
//						�̰��� ���� MES_MEMORY_DEBUG_ReportMemoryLeak ȣ���
//						�������� ���� ��� �޸𸮸� �����ϵ��� �Ѵ�.
//     2007/08/23 Gamza	first description
//------------------------------------------------------------------------------
#ifndef _MES_MEMORY_DEBUG_H
#define _MES_MEMORY_DEBUG_H

// MES_CHECK_MEMORY_LEAK

//------------------------------------------------------------------------------
//
//
//	if MES_CHECK_MEMORY_LEAK is not defined
//
//
//------------------------------------------------------------------------------
#ifndef MES_CHECK_MEMORY_LEAK

	#include <stdlib.h>
	#define MES_MALLOC( Size )		malloc( Size )
	#define MES_FREE( Pointer )		free( Pointer )
#ifdef __cplusplus
	#define MES_NEW( Type )						new Type
	#define MES_NEW_ARRAY( Type,NumberOfItems )	new Type[NumberOfItems]
	#define MES_DELETE( Pointer )				delete   Pointer
	#define MES_DELETE_ARRAY( Pointer )			delete[] Pointer
#endif // __cplusplus

//------------------------------------------------------------------------------
//
//
//	if MES_CHECK_MEMORY_LEAK is defined
//
//
//------------------------------------------------------------------------------
#else // MES_CHECK_MEMORY_LEAK

#ifdef __cplusplus
extern "C" {
#endif
	#define MES_MALLOC( Size )		MES_MEMORY_DEBUG_Malloc( Size   , __FILE__, __LINE__ )
	#define MES_FREE( Pointer )		MES_MEMORY_DEBUG_Free  ( Pointer, __FILE__, __LINE__ )

	void* MES_MEMORY_DEBUG_Malloc( int Size, const char* SourceFileName, int SourceLineNumber );
	void  MES_MEMORY_DEBUG_Free  ( void* Address, const char* SourceFileName, int SourceLineNumber );
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
	#define MES_NEW( Type )						MES_MEMORY_DEBUG_NEW_IMPL<Type>( #Type, __FILE__, __LINE__ )
	#define MES_NEW_ARRAY( Type,NumberOfItems )	MES_MEMORY_DEBUG_NEW_IMPL<Type>( #Type, NumberOfItems, __FILE__, __LINE__ )
	#define MES_DELETE( Pointer )				MES_MEMORY_DEBUG_DELETE_IMPL( Pointer, false, __FILE__, __LINE__ )
	#define MES_DELETE_ARRAY( Pointer )			MES_MEMORY_DEBUG_DELETE_IMPL( Pointer, true, __FILE__, __LINE__ )

	class MES_MEMORY_DEBUG_AUTO_DESTROYER
	{
	public:
		virtual void Delete( void* pObject ) const = 0;
	};

	void  MES_MEMORY_DEBUG_PushScope( const char* Name );
	void  MES_MEMORY_DEBUG_PopScope( void );
	void  MES_MEMORY_DEBUG_AppendMemoryBlock( int TypeSize, int NumberOfItems, void* Address, bool IsArray, const char* SourceFileName, int SourceLineNumber, const MES_MEMORY_DEBUG_AUTO_DESTROYER* pDestoryer );
	void  MES_MEMORY_DEBUG_RemoveMemoryBlock( void* Address, bool IsArray, const char* SourceFileName, int SourceLineNumber );

	template< typename T >
	void MES_MEMORY_DEBUG_DELETE_IMPL( T* Pointer, bool IsArray, const char* SourceFileName, int SourceLineNumber )
	{
		MES_MEMORY_DEBUG_RemoveMemoryBlock( static_cast<void*>(Pointer), IsArray, SourceFileName, SourceLineNumber );
		if( IsArray ) delete[] Pointer;
		else          delete Pointer;
	}

	template< typename T >
	class MES_MEMORY_DEBUG_AUTO_DESTROYER_SINGLE : public MES_MEMORY_DEBUG_AUTO_DESTROYER
	{
	public:
		virtual void Delete( void* pObject ) const { MES_DELETE( static_cast<T*>(pObject) ); }
		static const MES_MEMORY_DEBUG_AUTO_DESTROYER* GetDestroyer(void)
		{
			static MES_MEMORY_DEBUG_AUTO_DESTROYER_SINGLE<T> ms_Singleton;
			return &ms_Singleton;
		}
	};

	template< typename T >
	class MES_MEMORY_DEBUG_AUTO_DESTROYER_ARRAY : public MES_MEMORY_DEBUG_AUTO_DESTROYER
	{
	public:
		virtual void Delete( void* pObject ) const { MES_DELETE_ARRAY( static_cast<T*>(pObject) ); }
		static const MES_MEMORY_DEBUG_AUTO_DESTROYER* GetDestroyer(void)
		{
			static MES_MEMORY_DEBUG_AUTO_DESTROYER_ARRAY<T> ms_Singleton;
			return &ms_Singleton;
		}
	};

	template< typename T >
	T* MES_MEMORY_DEBUG_NEW_IMPL( const char* TypeName, const char* SourceFileName, int SourceLineNumber )
	{
		MES_MEMORY_DEBUG_PushScope( TypeName );
		T* result = new T;
		if( result )
		{
			MES_MEMORY_DEBUG_AppendMemoryBlock( sizeof(T), 1, static_cast<void*>(result), false, SourceFileName, SourceLineNumber, MES_MEMORY_DEBUG_AUTO_DESTROYER_SINGLE<T>::GetDestroyer() );
		}
		MES_MEMORY_DEBUG_PopScope();
		return result;
	}
	template< typename T >
	T* MES_MEMORY_DEBUG_NEW_IMPL( const char* TypeName, int NumberOfItems, const char* SourceFileName, int SourceLineNumber )
	{
		MES_MEMORY_DEBUG_PushScope( TypeName );
		T* result = new T[NumberOfItems];
		if( result )
		{
			MES_MEMORY_DEBUG_AppendMemoryBlock( sizeof(T), NumberOfItems, static_cast<void*>(result), true, SourceFileName, SourceLineNumber, MES_MEMORY_DEBUG_AUTO_DESTROYER_ARRAY<T>::GetDestroyer() );
		}
		MES_MEMORY_DEBUG_PopScope();
		return result;
	}

#endif // __cplusplus

#endif // MES_CHECK_MEMORY_LEAK


//------------------------------------------------------------------------------
//
//
//	Report function
//
//
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
	void  MES_MEMORY_DEBUG_ReportMemoryLeak( void );
#ifdef __cplusplus
}
#endif


#endif // _MES_MEMORY_DEBUG_H


