//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_hal.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//		2007/11/08 Yuni    �־��� window ������� �� ū ������ scissor �������� �����ϴ� ��쿡 ���� ó��
//		2007/09/04 Gamza    GLESHAL_OpenModule���� ��� �������� �ʱ�ȭ
//		2007/09/04 Gamza    g_WindowWidth/g_WindowHeight�ʱⰪ�� 1�� ó��.
//		2007/09/04 Gamza    g_WindowHeight�� 0�� ��� assert�߻����� �ʵ��� ó��.
//		2007/03/08 Gamza    g_CommandQueueFrontPointer����
//							triple buffering���� tearing�� ���� ������ �� �ִٰ� �Ǵ�.
//							rendering�� ���� �ſ����� ��� user input�� ���� ������ 
//							�ʾ����� ������ �߻��� �� ������, OpenGL���� ó������ ����
//							application level���� ó���ϵ��� ������ ������ �˷��ٰ�. - neo
//		2006/12/15 Yuni		GLESHAL_SetVertexFormatAsFloat/Fixed���� 
//								vertex format(fixed/float)�� �޶��� ���� �ٽ� �����ϵ��� ����.
//		2006/10/23 Gamza	MP2530F�� ���� clock control code�߰�
//		2006/10/16 Gamza	prototype�� �������� �ʴ� �Լ�����
//							Render_TLVERTEX/Render_VERTEX/Render_RECT
//		2006/09/25 Yuni		first implementation
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#include <libgles_cm_lite_hal.h>
#include <mes_base/mes_prototype.h>
#include <module/mes_grp3d.h>
#include <module/mes_memory_debug.h>
#include <math.h>
//#include <stdio.h>

#ifndef __CC_ARM
#pragma warning(disable:4800)	// GLESHALbool -> CBOOL�� ����ȯ �ϸ鼭 ����� ����.
#endif

//#define GLESHAL_TRUE	1
//#define GLESHAL_FALSE	0

// �������� �̸��� offset32�� ��ȯ�Ѵ�.
#define REGOFFSET(name)	( (unsigned int)(&(((MES_GRP3D_RegisterSet*)0)->name)) / 4 )
#define MAX_TEXTURE_STAGE	2

#define Max(a,b) ( ((a)>(b)) ? (a) : (b) )
#define Min(a,b) ( ((a)<(b)) ? (a) : (b) )

#define	GTE_CONST_DEST			(0x1000/4)
#define	TSE_INPUT_DEST			(0x0500/4)

static GLESHALbool	g_Open_GRP3D			= CFALSE;

static GLESHALbool	g_UseCommandQueue		= CFALSE;

static unsigned int g_WindowWidth			= 1;
static unsigned int g_WindowHeight			= 1;
static unsigned int g_DisplayBufferSegment	= 0;
static unsigned int g_DisplayBufferSegX		= 0;
static unsigned int g_DisplayBufferSegY		= 0;
static unsigned int g_ScissorX				= 0;
static unsigned int g_ScissorY				= 0;
static unsigned int g_ScissorWidth			= 0;
static unsigned int g_ScissorHeight			= 0;
static GLESHALbool	g_FSAAEnable			= CFALSE;

static unsigned int g_ViewportX				= 0;
static unsigned int g_ViewportY				= 0;
static unsigned int g_ViewportWidth			= 0;
static unsigned int g_ViewportHeight		= 0;

static unsigned int g_DepthBufferSegment	= 0;
static unsigned int g_DepthBufferSegX		= 0;
static unsigned int g_DepthBufferSegY		= 0;
static GLESHAL_CMPFUNC g_DepthFunc			= GLESHAL_CMPFUNC_LESS;

static GLESHAL_CULLFACE g_CullFaceMode		= GLESHAL_CULLFACE_BACK;
static GLESHAL_FRONTFACE g_FrontFaceMode	= GLESHAL_FRONTFACE_CCW;

static GLESHAL_FOGMODE g_FogMode	= GLESHAL_FOGMODE_EXP;
static float g_FogDensity			= 1.0f;
static float g_FogStart				= 0.0f;
static float g_FogEnd				= 1.0f;

// ���� ���� �Լ��� ���� �ʾƵ� �� �� ���� ������.
// �����Լ� �ʿ��� ������. ( �ʱ�ȭ ����� ���� �ʴ�. -_-;; )
static unsigned int				g_TextureSegment[MAX_TEXTURE_STAGE]			= { 0xFFFFFFFF, 0xFFFFFFFF };
static GLESHALbool				g_TextureMipmapEnable[MAX_TEXTURE_STAGE]	= { CFALSE, CFALSE };
static GLESHAL_TEXTUREADDRESS	g_TextureAddressingModeU[MAX_TEXTURE_STAGE] = 
									{	GLESHAL_TEXTUREADDRESS_WRAP, GLESHAL_TEXTUREADDRESS_WRAP };
static GLESHAL_TEXTUREADDRESS	g_TextureAddressingModeV[MAX_TEXTURE_STAGE] = 
									{	GLESHAL_TEXTUREADDRESS_WRAP, GLESHAL_TEXTUREADDRESS_WRAP };
static GLESHAL_COLORFORMAT		g_TextureColorFormat[MAX_TEXTURE_STAGE]		= 
									{ GLESHAL_COLORFORMAT_R5G6B5, GLESHAL_COLORFORMAT_R5G6B5 };
static unsigned int				g_TextureX[MAX_TEXTURE_STAGE]				= { 0, 0 };
static unsigned int				g_TextureY[MAX_TEXTURE_STAGE]				= { 0, 0 };
static unsigned int				g_TextureWidth[MAX_TEXTURE_STAGE]			= { 0, 0 };
static unsigned int				g_TextureHeight[MAX_TEXTURE_STAGE]			= { 0, 0 };

static unsigned __int64	g_CommandQueueFrontPointer = 0;	// Tearing ���Ÿ� ���� member ����.


//------------------------------------------------------------------------------
// internal functions
//------------------------------------------------------------------------------
inline unsigned char ConvTable( unsigned int SegmentPos )
{
	if( (0 == (SegmentPos%256)) && (1024 > SegmentPos) )
	{
		const unsigned char tablesy[4] = { 0xE4, 0x55, 0xEE, 0xFF };
		return tablesy[ (SegmentPos>>8) ];
	}
	else return 0;
}

GLESHALbool GLESHAL_GetValidDisplaySize( unsigned int* X, unsigned int* Y, 
								    unsigned int* Width, unsigned int* Height )
{
	unsigned int sx,sy,ex,ey;
	
	// Viewport�� window ������ �簢�� ���� ���.
	sx = g_ViewportX;//Max( 0, g_ViewportX );
	sy = g_ViewportY;//Max( 0, g_ViewportY );
	ex = Min( 0+g_WindowWidth, g_ViewportX+g_ViewportWidth  );
	ey = Min( 0+g_WindowHeight, g_ViewportY+g_ViewportHeight );
	// Scissor���� ������ �簢�� ���� ���.
	//if ( scissor�� enable�̸� )	// ���� scissor enable flag�� ����.
	// scissor disable �����̸� window size�� �����ϰ� ���� ���õǹǷ� �� �� �� ����ص� �ȵ� �� ����. -_-
	{
		sx = Max( sx, g_ScissorX );
		sy = Max( sy, g_ScissorY );
		ex = Min( ex, g_ScissorX+g_ScissorWidth );
		ey = Min( ey, g_ScissorY+g_ScissorHeight );
	}

	if( sx>=ex || sy>=ey ){ return 0; } // ������ ������ ����.

	// window coordinate�� ��ȯ.
	*X		= sx;
	*Y		= g_WindowHeight-ey;
	*Width	= ex-sx;
	*Height = ey-sy;

	if( g_FSAAEnable )
	{
		*Y *= 2;
		*Height *= 2;
	}
	return 1;
}

// CullFace mode��  FrontFace mode�� �����Ͽ� culling �ɼ� ����.
void GLESHAL_SetFaceCullingState( void )
{
	MES_ASSERT( g_Open_GRP3D );
	
	unsigned int curRenderState = MES_GRP3D_GetRenderState();

	switch( g_CullFaceMode )
	{
	case GLESHAL_CULLFACE_FRONT:
		{
			// front face ����� back face culling ������ ������ ��.
			if( g_FrontFaceMode == GLESHAL_FRONTFACE_CW )
				curRenderState |= GLESHAL_RS_BACKFACECULL_CW;
			else	// CW �ƴϸ� CCW �̹Ƿ�...
				curRenderState &= ~GLESHAL_RS_BACKFACECULL_CW;
		}
		break;
	case GLESHAL_CULLFACE_BACK:
		{
			if( g_FrontFaceMode == GLESHAL_FRONTFACE_CW )
				curRenderState &= ~GLESHAL_RS_BACKFACECULL_CW;
			else	
				curRenderState |= GLESHAL_RS_BACKFACECULL_CW;
		}
		break;
	case GLESHAL_CULLFACE_FRONTANDBACK:
		// rendering �� �� ó���ϼ���.
		break;
	default:
		break;
	}

	MES_GRP3D_SetRenderState( curRenderState );
}


GLESHALbool GLESHAL_SetLinearFog( float Start, float End )
{
	MES_ASSERT( g_Open_GRP3D );

	MES_DEBUG_CODE( const float MAX_ZVALUE = 65535.0f; )
	unsigned short fogtable[64];
	long index;
	float t, dt;

	if( Start == End )
		return 0;

	//MES_ASSERT( 0.0f <= Start );
	//MES_ASSERT( Start < End );
	MES_ASSERT( (MAX_ZVALUE >= End) || (MAX_ZVALUE >= Start) );

	t = 0;
	dt = ((Start < End) ? End : Start)/63.0f;
	for( index = 0; index<64; index++ )
	{
		//if( t<=Start )		fogtable[index] = 0;
		//else if( t>=End )	fogtable[index] = 255;
		//else
		//{
		//	fogtable[index] = (U16)(255*(End-t)/(End-Start));
		//	MES_ASSERT( (1<<8) > fogtable[index] );
		//}
		
		float f = (t-Start)/(End-Start);
		/*
		float f;
		if( Start < End )
			f = (t-Start)/(End-Start);
		else
			f = (t-End)/(Start-End);
		*/
		
		if( f<0 ){ f = 0; }
		if( f>1 ){ f = 1; }
		fogtable[index] = (U16)(255.5f * f);
		
		t += dt;
	}

	if( Start < End )
	{
		for( index = 0; index<63; index++ )
		{
			int f0	= fogtable[index];
			int f1	= fogtable[index+1];
			int df	= (f1-f0)>>2;
			MES_ASSERT( (1<<8) > df );
			fogtable[index] = (U16)(fogtable[index] | (df<<8) );
		}	
	}
	/*
	printf( "--- Fog Table ---\n" );	
	for( int i = 0; i < 64; i++ )
		printf( "%d\t: 0x%x  \n", i, fogtable[i]);	
	*/
	if( MES_GRP3D_SetFogTable( fogtable ) )
	{
		return MES_GRP3D_SetFogMaxZ( (Start < End) ? End : Start );
	}
	else
		return 0;
/*
	if( (End == 0.0f) || (Start == End ) )
		return 0;

	MES_GRP3D_SetLinearFog( Start, End );
	return 1;
*/
}


GLESHALbool GLESHAL_SetFog( GLESHAL_FOGMODE Mode, float Density )
{
	MES_ASSERT( g_Open_GRP3D );

	const float ln255 = 5.541263545158426f;
	//if( (Mode == g_FogMode) && (Density == g_FogDensity) )
	//	return 1;

	float fogMaxZ;
	unsigned short fogTable[64];
	float tempValue;
	int i;

	switch( Mode )
	{
	case GLESHAL_FOGMODE_EXP:
		fogMaxZ = ln255 / Density;
		tempValue = fogMaxZ/63.0f*Density;
		for( i=0; i<64; i++ )
		{
			fogTable[i] = (unsigned short)(255.5f*(1.0f-(1/exp(i*tempValue))));
			//fogTable[i] = (unsigned short)(255.0f*(1.0f-(1/exp(i*tempValue)))+0.5f);
		}
		break;
	case GLESHAL_FOGMODE_EXP2:
		fogMaxZ = (float)sqrt(ln255) / Density;
		tempValue = fogMaxZ/63.0f*Density;
		for( i=0; i<64; i++ )
		{
			fogTable[i] = (unsigned short)(255.5f*(1.0f-(1/exp( (i*tempValue)*(i*tempValue) ))));
			//fogTable[i] = (unsigned short)(255.0f*(1.0f-(1/exp( (i*tempValue)*(i*tempValue) )))+0.5f);
		}
		break;
	default:
		return 0;
	}
	if( MES_GRP3D_SetFogMaxZ( fogMaxZ ) )
	{
		for( i=0; i<63; i++ )
		{
			int f0	= fogTable[i];
			int f1	= fogTable[i+1];
			int df	= (f1-f0)>>2;
			
			MES_ASSERT( (1<<8)>df );
			fogTable[i] = (U16)(fogTable[i] | (df<<8) );
		}
		return MES_GRP3D_SetFogTable( fogTable );
	}
	else
		return 0;
}

//------------------------------------------------------------------------------
// external functions
//------------------------------------------------------------------------------
void GLESHAL_Initialize()
{
	if( !g_Open_GRP3D )
	{
		MES_GRP3D_Initialize();
	}

	g_Open_GRP3D = true;
}


void GLESHAL_InitializeWithAddress( unsigned int VirtualAddress )
{
	GLESHAL_Initialize();
	GLESHAL_SetVirtualAddressOfRegisterSet( 0, VirtualAddress );



}

// @Gamza 2008/07/31
void GLESHAL_RestoreModule( void )
{
	MES_GRP3D_RestoreModule();
}


void    GLESHAL_SelectModule( unsigned int ModuleIndex )
{
	MES_GRP3D_SelectModule( ModuleIndex );
}

unsigned int     GLESHAL_GetCurrentModule( void )
{
	return MES_GRP3D_GetCurrentModule();
}

unsigned int     GLESHAL_GetNumberOfModule( void )
{
	return MES_GRP3D_GetNumberOfModule();
}

unsigned int     GLESHAL_GetPhysicalAddress( void )
{
	return MES_GRP3D_GetPhysicalAddress();
}

unsigned int     GLESHAL_GetSizeOfRegisterSet( void )
{
	return MES_GRP3D_GetSizeOfRegisterSet();
}

void    GLESHAL_SetBaseAddress( unsigned int BaseAddress )
{
	MES_GRP3D_SetBaseAddress( BaseAddress );
}

unsigned int     GLESHAL_GetBaseAddress( void )
{
	return MES_GRP3D_GetBaseAddress();
}

CBOOL   GLESHAL_OpenModule( void )
{
	MES_ASSERT( g_Open_GRP3D );
	MES_GRP3D_SetClockPClkMode( MES_PCLKMODE_ALWAYS ); 
	MES_GRP3D_SetClockBClkMode( MES_BCLKMODE_ALWAYS );      

	CBOOL result = MES_GRP3D_OpenModule();
	if( !result )
		return CFALSE;	
	
	// global variable initialize
	g_UseCommandQueue		= CFALSE;	
	g_WindowWidth			= 1;
	g_WindowHeight			= 1;
	g_DisplayBufferSegment	= 0;
	g_DisplayBufferSegX		= 0;
	g_DisplayBufferSegY		= 0;
	g_ScissorX				= 0;
	g_ScissorY				= 0;
	g_ScissorWidth			= 0;
	g_ScissorHeight			= 0;
	g_FSAAEnable			= CFALSE;	
	g_ViewportX				= 0;
	g_ViewportY				= 0;
	g_ViewportWidth			= 0;
	g_ViewportHeight		= 0;	
	g_DepthBufferSegment	= 0;
	g_DepthBufferSegX		= 0;
	g_DepthBufferSegY		= 0;
	g_DepthFunc			    = GLESHAL_CMPFUNC_LESS;	
	g_CullFaceMode	        = GLESHAL_CULLFACE_BACK;
	g_FrontFaceMode	        = GLESHAL_FRONTFACE_CCW;	
	g_FogMode	            = GLESHAL_FOGMODE_EXP;
	g_FogDensity			= 1.0f;
	g_FogStart				= 0.0f;
	g_FogEnd				= 1.0f;	

	for( int i = 0; i < 2; i++ )
	{
		g_TextureSegment[i] = 0x7FFFFFFF;
		g_TextureMipmapEnable[i] = CFALSE;
		g_TextureColorFormat[i] = GLESHAL_COLORFORMAT_FORCES32;
		g_TextureAddressingModeU[i] = GLESHAL_TEXTUREADDRESS_WRAP;
		g_TextureAddressingModeV[i] = GLESHAL_TEXTUREADDRESS_WRAP;
		g_TextureX[i] = 0;
		g_TextureY[i] = 0;
		g_TextureWidth[i] = 0;
		g_TextureHeight[i] = 0;		
	}
	
	g_CommandQueueFrontPointer = 0;	// Tearing ���Ÿ� ���� member ����.
		
	// perspective correction�� �׻� �Ҵ�.
	unsigned int renderstate = MES_GRP3D_GetRenderState();
	renderstate |= MES_GRP3D_RS_PERSPECTIVE_ENB;
	result = MES_GRP3D_SetRenderState( renderstate );
	if( !result )
		return CFALSE;

	GLESHAL_SetFaceCullingState();	// culling ���úκ�, GL��� �ʱⰪ ��������� �ؿ�.
	result = GLESHAL_SetFog( g_FogMode, g_FogDensity );	// Fog �ʱⰪ ����.
	if( !result )
		return CFALSE;
	

	// TextureBlending�� �ʱ�ȭ�����־�� �Ѵ�.
	// (������ Texture ���� ���� ������ ���� ��쿡�� ȣ��ǹǷ� �������� �ʱ�ȭ�� �ʿ���.)
	{
		GLESHAL_RGBARG	rgbArg[3] = { 
				GLESHAL_RGBARG_FRAGMENT_C, 
				GLESHAL_RGBARG_SOURCE_C, 
				GLESHAL_RGBARG_FRAGMENT_C 
		};
		GLESHAL_RGBOP	rgbOp = GLESHAL_RGBOP_REPLACE;
		GLESHAL_AARG	aArg[3] = {
				GLESHAL_AARG_FRAGMENT_A,
				GLESHAL_AARG_SOURCE_A, 
				GLESHAL_AARG_FRAGMENT_A
		};
		GLESHAL_AOP		aOp = GLESHAL_AOP_REPLACE;

		GLESHAL_SetTextureBlend( 0, 
								rgbArg[0], rgbArg[1], rgbArg[2], rgbOp, 
								aArg[0], aArg[1], aArg[2], aOp );
								
		GLESHAL_SetTextureConstColor( 0.0f, 0.0f, 0.0f, 0.0f );
		
	}
	
	// color ����� ���� GTE const register ����.
	float GTEColorConst[] = {
		-0.5f, -0.5f, -0.5f, -0.5f,		// for line rendering
		255.5f,255.5f,255.5f,256.0f		// for color calculation
	};
	result = MES_GRP3D_SetGTEConst( 14*4, 8, GTEColorConst );
	if( !result )
		return CFALSE;
	else
		return CTRUE;
}

CBOOL   GLESHAL_CloseModule( void )
{
	MES_ASSERT( g_Open_GRP3D );
	CBOOL result = MES_GRP3D_CloseModule();
	MES_GRP3D_SetClockPClkMode( MES_PCLKMODE_DYNAMIC );
	MES_GRP3D_SetClockBClkMode( MES_BCLKMODE_DISABLE );   

	g_Open_GRP3D = CFALSE;
	return result;
}

CBOOL   GLESHAL_CheckBusy( void )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_CheckBusy());
}

CBOOL   GLESHAL_CanPowerDown( void )
{
	return MES_GRP3D_CanPowerDown();
}
/*
S32     GLESHAL_GetInterruptNumber( void )
{
	return MES_GRP3D_GetInterruptNumber();
}
*/

void    GLESHAL_SetInterruptEnable( S32 IntNum, CBOOL Enable )
{
	MES_GRP3D_SetInterruptEnable( IntNum, Enable );
}

CBOOL   GLESHAL_GetInterruptEnable( S32 IntNum )
{
	return MES_GRP3D_GetInterruptEnable( IntNum );
}

CBOOL   GLESHAL_GetInterruptPending( S32 IntNum )
{
	return MES_GRP3D_GetInterruptPending( IntNum );
}

void    GLESHAL_ClearInterruptPending( S32 IntNum )
{
	MES_GRP3D_ClearInterruptPending( IntNum );
}

void    GLESHAL_SetInterruptEnableAll( CBOOL Enable )
{
	MES_GRP3D_SetInterruptEnableAll( Enable );
}

CBOOL   GLESHAL_GetInterruptEnableAll( void )
{
	return MES_GRP3D_GetInterruptEnableAll();
}

CBOOL   GLESHAL_GetInterruptPendingAll( void )
{
	return MES_GRP3D_GetInterruptPendingAll();
}

void    GLESHAL_ClearInterruptPendingAll( void )
{
	MES_GRP3D_ClearInterruptPendingAll();
}

S32     GLESHAL_GetInterruptPendingNumber( void )  // -1 if None
{
	return MES_GRP3D_GetInterruptPendingNumber();
}

//void            GLESHAL_SetClockPClkMode( MES_PCLKMODE mode )
//MES_PCLKMODE    GLESHAL_GetClockPClkMode( void )
//void            GLESHAL_SetClockBClkMode( MES_BCLKMODE mode )
//MES_BCLKMODE    GLESHAL_GetClockBClkMode( void )

GLESHALbool GLESHAL_RunPrimitive( void )
{
	return MES_GRP3D_RunPrimitive();
}




//------------------------------------------------------------------------------
// Export constant definitions
//------------------------------------------------------------------------------
const unsigned int GLESHAL_RS_PERSPECTIVE_ENB      = (1<<0) ;
const unsigned int GLESHAL_RS_TEXTURE_ENB          = (1<<1) ;
const unsigned int GLESHAL_RS_MULTITEX_ENB         = (1<<2) ;
const unsigned int GLESHAL_RS_TRANSPARENCY_ENB     = (1<<3) ;
const unsigned int GLESHAL_RS_SHADE_ENB            = (1<<4) ;
const unsigned int GLESHAL_RS_BILINEAR_FILTER_ENB  = (1<<5) ;
const unsigned int GLESHAL_RS_ABILINEAR_FILTER_ENB = (1<<6) ;
const unsigned int GLESHAL_RS_ALPHA_ENB            = (1<<7) ;
const unsigned int GLESHAL_RS_ZBUFFER_ENB          = (1<<8) ;
const unsigned int GLESHAL_RS_ZBUFFERWRITE_ENB     = (1<<9) ;
const unsigned int GLESHAL_RS_FOG_ENB              = (1<<10);
const unsigned int GLESHAL_RS_DITHER_ENB           = (1<<11);
const unsigned int GLESHAL_RS_BACKFACECULL_ENB     = (1<<12);
const unsigned int GLESHAL_RS_BACKFACECULL_CW      = (1<<13);
const unsigned int GLESHAL_RS_BACKFACECULL_CCW     = (0<<13);
const unsigned int GLESHAL_RS_ALPHATEST_ENB		   = (1<<14);


//------------------------------------------------------------------------------
// Export function definitions
//------------------------------------------------------------------------------


GLESHALbool GLESHAL_SetRenderState( unsigned int RenderState )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetRenderState( RenderState ));
}

unsigned int   GLESHAL_GetRenderState( void )
{
	MES_ASSERT( g_Open_GRP3D );
	return (unsigned int)(MES_GRP3D_GetRenderState());
}

GLESHALbool GLESHAL_SetBlendFactor( GLESHAL_BLEND SrcBlend, 
								   GLESHAL_BLEND DstBlend )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetBlendFactor( 
		(MES_GRP3D_BLEND)SrcBlend, 
		(MES_GRP3D_BLEND)DstBlend ));
}

GLESHALbool GLESHAL_ClearTextureCache( void )
{
	MES_ASSERT( g_Open_GRP3D );	
	return MES_GRP3D_ClearTextureCache();
}

/*
// GLESHAL_SetTextureSegment �Լ� ȣ�� �ڿ��� �ݵ�� SetTextureXXX �ٸ� �Լ��� ȣ������� �Ѵ�.
// �� �Լ��� ��¥�� texture�� ���� ������ �޸𸮸� �Ҵ��ϴ� ������ ȣ��� ���̹Ƿ� SetTextureSize�� pair�� �Ͼ ���̴�.
// �׷����� �ұ��ϰ� �� �Լ� ������ MES_GRP3D_SetTexture�� ȣ���ϴ� �� ���ʿ��� �Լ� ȣ���̶�� �������Ƿ�..
GLESHALbool GLESHAL_SetTextureSegment( unsigned int TextureStage, unsigned int TextureSegment )
{
	// texture cache clear�� ����..??

	MES_ASSERT( g_Open_GRP3D );
	MES_ASSERT( MAX_TEXTURE_STAGE > TextureStage );
	
	if( TextureSegment != g_TextureSegment[TextureStage] )
	{
		unsigned int otherStage = (TextureStage+1)%2;

		if( TextureSegment != g_TextureSegment[otherStage] )	// ���ο� segment
		{
			g_TextureSegmentIndex[TextureStage] = otherStage;
			MES_GRP3D_ClearTextureCache();	// ??
		}
		else	// ���� segment
			g_TextureSegment[ TextureStage ] = TextureSegment; 

		if(	MES_GRP3D_SetTexture( TextureStage, 
							g_TextureSegmentIndex[TextureStage],
							(MES_GRP3D_COLORFORMAT)g_TextureColorFormat[TextureStage], 
							g_TextureMipmapEnable[TextureStage], 
							CFALSE, //g_TextureTileEnable[TextureStage],
							(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeU[TextureStage], 
							(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeV[TextureStage], 
							g_TextureX[TextureStage], g_TextureY[TextureStage], 
							g_TextureWidth[TextureStage], g_TextureHeight[TextureStage] ) )

			return CTRUE;
		else return CFALSE;
	}
	else
		return CTRUE;	// ���� �� �ƹ��͵� ����.
}	
*/
GLESHALbool GLESHAL_SetTextureWithSegment( 
								unsigned int			TextureStage, 
								GLESHALbool	 			IsCacheClear,
								unsigned int 			TextureSegment,
								GLESHAL_COLORFORMAT 	ColorFormat, 
								GLESHALbool 			MipmapEnb,
								GLESHAL_TEXTUREADDRESS 	TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS 	TextureAddressingModeV,
							    unsigned int 	X, 		unsigned int 	Y, 
								unsigned int 	Width, 	unsigned int 	Height )
{
	// texture cache clear�� ����..??

	MES_ASSERT( g_Open_GRP3D );
	MES_ASSERT( MAX_TEXTURE_STAGE > TextureStage );

	if( g_TextureSegment[ TextureStage ] != TextureSegment )
	{
		MES_GRP3D_ClearTextureCache();
		if( !MES_GRP3D_SetTextureSegment( TextureStage, TextureSegment ) )
			return CFALSE;
		g_TextureSegment[ TextureStage ] = TextureSegment;
	}
	else if( IsCacheClear )
	{
		MES_GRP3D_ClearTextureCache();
		g_TextureSegment[ TextureStage ] = TextureSegment;
	}
	
	if(	MES_GRP3D_SetTexture( TextureStage, 
						TextureStage, //g_TextureSegmentIndex[TextureStage], 
						(MES_GRP3D_COLORFORMAT)ColorFormat, 
						MipmapEnb, CFALSE, 
						(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeU, 
						(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeV, 
						X, Y, Width, Height ) )
	{
		g_TextureMipmapEnable[TextureStage] = MipmapEnb;
		g_TextureAddressingModeU[TextureStage]	= TextureAddressingModeU;
		g_TextureAddressingModeV[TextureStage]	= TextureAddressingModeV;
		g_TextureColorFormat[TextureStage] = ColorFormat;
		g_TextureX[TextureStage] = X;
		g_TextureY[TextureStage] = Y;
		g_TextureWidth[TextureStage] = Width;
		g_TextureHeight[TextureStage] = Height;

		return CTRUE;
	}
	else
		return CFALSE;	// ���� �� �ƹ��͵� ����.
}	

/*
GLESHALAPI 
GLESHALbool GLESHAL_SetTexture( unsigned int TextureStage, 
								GLESHAL_COLORFORMAT ColorFormat, 
								GLESHALbool MipmapEnb,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeV,
							    unsigned int X, unsigned int Y, 
								unsigned int Width, unsigned int Height )
{
	MES_ASSERT( g_Open_GRP3D );

	if(	MES_GRP3D_SetTexture( TextureStage, 
		TextureStage, //g_TextureSegmentIndex[TextureStage], 
		(MES_GRP3D_COLORFORMAT)ColorFormat, 
		MipmapEnb, CFALSE, //g_TextureTileEnable[TextureStage],
		(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeU, 
		(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeV, 
		X, Y, Width, Height ) )
	{
		g_TextureMipmapEnable[TextureStage] = MipmapEnb;
		g_TextureAddressingModeU[TextureStage]	= TextureAddressingModeU;
		g_TextureAddressingModeV[TextureStage]	= TextureAddressingModeV;
		g_TextureColorFormat[TextureStage] = ColorFormat;
		g_TextureX[TextureStage] = X;
		g_TextureY[TextureStage] = Y;
		g_TextureWidth[TextureStage] = Width;
		g_TextureHeight[TextureStage] = Height;

		return CTRUE;
	}
	else 
		return CFALSE;
}
*/
GLESHALbool GLESHAL_SetTransparencyColor( unsigned short TransparencyColor )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetTransparencyColor( TransparencyColor ));
}
/*
GLESHALbool GLESHAL_SetMipmapBias( unsigned short MipmapBias )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetMipmapBias( MipmapBias ));
}
*/

GLESHALbool GLESHAL_SetPalette16( unsigned int TextureStage, 
								 unsigned int TextureSegment, 
								 unsigned int X, unsigned int Y )
{
	MES_ASSERT( g_Open_GRP3D );
	if( ! MES_GRP3D_SetTextureSegment( TextureStage, TextureSegment ) )
		return CFALSE;
	if( ! MES_GRP3D_SetPalette16( TextureStage, 0, X, Y ) )
		return CFALSE;
	return (GLESHALbool)(MES_GRP3D_SetTextureSegment( TextureStage, g_TextureSegment[TextureStage] ));
}

GLESHALbool GLESHAL_SetPalette256( unsigned int TextureStage, 
								  unsigned int TextureSegment,
								  unsigned int X, unsigned int Y )
{
	MES_ASSERT( g_Open_GRP3D );
	if( ! MES_GRP3D_SetTextureSegment( TextureStage, TextureSegment ) )
		return CFALSE;
	if( ! MES_GRP3D_SetPalette256( TextureStage, X, Y ) )
		return CFALSE;
	return (GLESHALbool)(MES_GRP3D_SetTextureSegment( TextureStage, g_TextureSegment[TextureStage] ));
}

/*
GLESHALbool GLESHAL_SetTextureMipmapEnable(
								unsigned int TextureStage, 
								GLESHALbool MipmapEnb )
{
	MES_ASSERT( g_Open_GRP3D );

	if( MipmapEnb == g_TextureMipmapEnable[TextureStage] )
		return CTRUE;

	if(	MES_GRP3D_SetTexture( TextureStage, 
		TextureStage, //g_TextureSegmentIndex[ TextureStage ], 
		(MES_GRP3D_COLORFORMAT)g_TextureColorFormat[TextureStage], 
		MipmapEnb, CFALSE,
		(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeU[TextureStage], 
		(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeV[TextureStage], 
		g_TextureX[TextureStage], g_TextureY[TextureStage], 
		g_TextureWidth[TextureStage], g_TextureHeight[TextureStage] ) )

	{
		g_TextureMipmapEnable[TextureStage] = MipmapEnb;
		return CTRUE;
	}
	else 
		return CFALSE;
}
*/
GLESHALbool GLESHAL_SetTextureWrappingMode( unsigned int TextureStage, 
								GLESHAL_TEXTUREADDRESS TextureAddressingModeU,
								GLESHAL_TEXTUREADDRESS TextureAddressingModeV )
{
	MES_ASSERT( g_Open_GRP3D );

	if( (TextureAddressingModeU == g_TextureAddressingModeU[TextureStage] ) || 
		(TextureAddressingModeV == g_TextureAddressingModeV[TextureStage] ) )
		return CTRUE;

	if(	MES_GRP3D_SetTexture( TextureStage, 
		TextureStage, //g_TextureSegmentIndex[TextureStage], 
		(MES_GRP3D_COLORFORMAT)g_TextureColorFormat[TextureStage], 
		g_TextureMipmapEnable[TextureStage], CFALSE,
		(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeU, 
		(MES_GRP3D_TEXTUREADDRESS)TextureAddressingModeV, 
		g_TextureX[TextureStage], g_TextureY[TextureStage], 
		g_TextureWidth[TextureStage], g_TextureHeight[TextureStage] ) )

	{
		g_TextureAddressingModeU[TextureStage]	= TextureAddressingModeU;
		g_TextureAddressingModeV[TextureStage]	= TextureAddressingModeV;
		return CTRUE;
	}
	else 
		return CFALSE;
}

GLESHALbool GLESHAL_SetTextureFormat( unsigned int TextureStage, GLESHAL_COLORFORMAT ColorFormat )
{
	MES_ASSERT( g_Open_GRP3D );

	if( ColorFormat == g_TextureColorFormat[TextureStage] )
		return CTRUE;

	if(	MES_GRP3D_SetTexture( TextureStage, 
							TextureStage, //g_TextureSegmentIndex[TextureStage], 
							(MES_GRP3D_COLORFORMAT)ColorFormat, 
							g_TextureMipmapEnable[TextureStage], CFALSE, //g_TextureTileEnable[TextureStage],
							(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeU[TextureStage], 
							(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeV[TextureStage], 
							g_TextureX[TextureStage], g_TextureY[TextureStage], 
							g_TextureWidth[TextureStage], g_TextureHeight[TextureStage] ) )
	{
		g_TextureColorFormat[TextureStage] = ColorFormat;
		return CTRUE;
	}
	else 
		return CFALSE;
}

/*
GLESHALbool GLESHAL_SetTexture( unsigned int TextureStage, 
								GLESHAL_COLORFORMAT ColorFormat, 
							    unsigned int X, unsigned int Y, 
								unsigned int Width, unsigned int Height )
{
	MES_ASSERT( g_Open_GRP3D );

	if(	MES_GRP3D_SetTexture( TextureStage, 
		g_TextureSegmentIndex[TextureStage], 
		(MES_GRP3D_COLORFORMAT)ColorFormat, 
		g_TextureMipmapEnable[TextureStage], g_TextureTileEnable[TextureStage],
		(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeU[TextureStage], 
		(MES_GRP3D_TEXTUREADDRESS)g_TextureAddressingModeV[TextureStage], 
		X, Y, Width, Height ) )
	{
		g_TextureColorFormat[TextureStage] = ColorFormat;
		g_TextureX[TextureStage] = X;
		g_TextureY[TextureStage] = Y;
		g_TextureWidth[TextureStage] = Width;
		g_TextureHeight[TextureStage] = Height;
		return CTRUE;
	}
	else 
		return CFALSE;
}
*/

CBOOL GLESHAL_SetTextureBlend( unsigned int TextureStage, 
								GLESHAL_RGBARG RGBArg0, GLESHAL_RGBARG RGBArg1, GLESHAL_RGBARG RGBArg2,
								GLESHAL_RGBOP	RGBOp,
								GLESHAL_AARG AlphaArg0, GLESHAL_AARG AlphaArg1, GLESHAL_AARG AlphaArg2,
								GLESHAL_AOP	AlphaOp )
{
	return MES_GRP3D_SetTextureBlend( TextureStage, 
								(MES_GRP3D_RGBARG)RGBArg0, (MES_GRP3D_RGBARG)RGBArg1, (MES_GRP3D_RGBARG)RGBArg2,
								(MES_GRP3D_RGBOP)	RGBOp,
								(MES_GRP3D_AARG)AlphaArg0, (MES_GRP3D_AARG)AlphaArg1, (MES_GRP3D_AARG)AlphaArg2,
								(MES_GRP3D_AOP)	AlphaOp );
}

CBOOL GLESHAL_SetAlphaFunction( float RefValue, GLESHAL_ALPHAFUNC AlphaFunction )
{
	float tempValue = RefValue * 256.0f + 0.5f;
	if( 256 == (U16)tempValue )
		tempValue = 255.0f;
	
	return MES_GRP3D_SetAlphaFunction( (unsigned char)(tempValue), (MES_GRP3D_ALPHAFUNC)AlphaFunction );
}
/*
CBOOL GLESHAL_SetTextureConstColor( unsigned int ConstColor )
{
	return MES_GRP3D_SetTextureConstColor( ConstColor );
}
*/
GLESHALbool GLESHAL_SetTextureConstColor( float R, float G, float B, float A )
{
/*
	return MES_GRP3D_SetTextureConstColor( (unsigned char)(A*255.0f+0.5f), 
											(unsigned char)(R*255.0f+0.5f), 
											(unsigned char)(G*255.0f+0.5f),
											(unsigned char)(B*255.0f+0.5f) );
*/
	return MES_GRP3D_SetTextureConstColor( (unsigned char)(A*255.5f), 
											(unsigned char)(R*255.5f), 
											(unsigned char)(G*255.5f),
											(unsigned char)(B*255.5f) );											
}


GLESHALbool GLESHAL_SetPrimitiveControl( unsigned int StreamValid, 
							GLESHAL_INDEXTYPE IndexType, 
							GLESHALbool ClearCache, GLESHALbool LoopEnb, 
							GLESHALbool UseIndexEnb, GLESHALbool UseMatrixPaletteEnb,
							unsigned int StartIndex,
							unsigned int EndIndex )
{
	CBOOL result;
	result = MES_GRP3D_SetPrimitiveControl( MES_GRP3D_MEMBUST_16, MES_GRP3D_MEMBUST_16, // ES���� ����.
							StreamValid, (MES_GRP3D_INDEXTYPE)IndexType, 
							ClearCache, LoopEnb, 
							UseIndexEnb, UseMatrixPaletteEnb,
							CTRUE );	// ������ GTE �����.
							
	if( !result )
		return CFALSE;
	
	result = GLESHAL_SetIndexStart( StartIndex );
	if( !result )
		return CFALSE;
	
	result = GLESHAL_SetIndexEnd( EndIndex );
	if( !result )
		return CFALSE;	
	
	return CTRUE;
}

/*
	GLESHAL_VERTEXSTREAM_MATRIXINDEX	= 0,
	GLESHAL_VERTEXSTREAM_POSITION		= 1,
	GLESHAL_VERTEXSTREAM_COLOR			= 2,
	GLESHAL_VERTEXSTREAM_NORMAL			= 3,
	GLESHAL_VERTEXSTREAM_TEXCOORD0		= 4,
	GLESHAL_VERTEXSTREAM_TEXCOORD1		= 5,
	GLESHAL_VERTEXSTREAM_POINTSIZE		= 6,
	GLESHAL_VERTEXSTREAM_WEIGHT			= 6,
	GLESHAL_VERTEXSTREAM_PALETTEMATRIX	= 7,
*/
// matrix index
CBOOL GLESHAL_SetMatrixIndexVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_MATRIXINDEX, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// position
CBOOL GLESHAL_SetPositionVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_POSITION, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// color
CBOOL GLESHAL_SetColorVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_COLOR, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// normal
CBOOL GLESHAL_SetNormalVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_NORMAL, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// texture coord
CBOOL GLESHAL_SetTexCoordVertexStream( unsigned int Index, 
						const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	int vertexIndex;
	
	if( 0 == Index )
		vertexIndex = (int)GLESHAL_VERTEXSTREAM_TEXCOORD0;
	else if( 1 == Index )
		vertexIndex = (int)GLESHAL_VERTEXSTREAM_TEXCOORD1;
	else
		return CFALSE;

	return MES_GRP3D_SetVertexStream( vertexIndex, Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// point size
CBOOL GLESHAL_SetPointSizeVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_POINTSIZE, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}

// weight
CBOOL GLESHAL_SetWeightVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	//printf("Weight stride:%d, size:%d, offset:%d\n", Stride, Size, DstOffset);
	//float* pvalue = (float*)Addr;
	//printf("%f,%f,%f,%f\n", pvalue[0], pvalue[1],  pvalue[2], pvalue[3] );	
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_WEIGHT, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );		
}

// palette matrix
CBOOL GLESHAL_SetPaletteMatrixVertexStream( const void* Addr, unsigned int Stride, 
						unsigned int DstOffset, unsigned int Size, GLESHAL_VSTYPE Type )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetVertexStream( (int)GLESHAL_VERTEXSTREAM_MATRIXPALETTE, 
			Addr, Stride, GTE_CONST_DEST + DstOffset, Size, (MES_GRP3D_VSTYPE)Type );
}


CBOOL GLESHAL_SetVertexStreams( const unsigned int* Data )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetVertexStreams( Data );
}


CBOOL GLESHAL_SetIndexStart( unsigned int Start )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetIndexStart( Start );
}

CBOOL GLESHAL_SetIndexEnd( unsigned int End )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetIndexEnd( End );
}

CBOOL GLESHAL_SetPrimitiveParamLoopControl( unsigned int ParamLoop, unsigned int ParamEnd )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetPrimitiveParamLoopControl( ParamLoop, ParamEnd );
}

CBOOL GLESHAL_SetParamData( unsigned int Index, 
					unsigned char Param0, unsigned char Param1, unsigned char Param2, unsigned char Param3 )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_SetParamData( Index, Param0, Param1, Param2, Param3 );
}

GLESHALbool GLESHAL_RegisterFill ( unsigned int RegisterOffset32, 
								  unsigned int NumberOfData32,
								  const unsigned int* pData32, 
								  unsigned int WaitFlag,
								  GLESHALbool InterruptRequest )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_RegisterFill( RegisterOffset32, 
		NumberOfData32, pData32, WaitFlag, InterruptRequest ));
}


GLESHALbool GLESHAL_SetFogColor( float R, float G, float B, float A )
{
	MES_ASSERT( g_Open_GRP3D );
/*
	unsigned int fogColor = ((unsigned int)(R*255.5f))<<16		|
							 ((unsigned int)(G*255.5f))<<8		|
							 (unsigned int)(B*255.5f);
*/	
	unsigned int fogColor = ((unsigned int)(R*255.0f+0.5f))<<16		|
							 ((unsigned int)(G*255.0f+0.5f))<<8		|
							 (unsigned int)(B*255.0f+0.5f);
								 
	return (GLESHALbool)(MES_GRP3D_SetFogColor( fogColor ));
}


GLESHALbool GLESHAL_SetFogMode( GLESHAL_FOGMODE Mode )
{
	MES_ASSERT( g_Open_GRP3D );

	g_FogMode = Mode;

	if( Mode == GLESHAL_FOGMODE_LINEAR )
	{
		GLESHAL_SetLinearFog( g_FogStart, g_FogEnd );
		return 1;
	}
	else
		return GLESHAL_SetFog( Mode, g_FogDensity );
}

void GLESHAL_SetFogDensity( float Density )
{
	MES_ASSERT( g_Open_GRP3D );
	GLESHAL_SetFog( g_FogMode, Density );
}

void GLESHAL_SetFogStart( float Start )
{
	MES_ASSERT( g_Open_GRP3D );

	// linear ����� ��쿡�� �������Ϳ� ����.
	// ���̺� ������� ����ϱ�.. ���� ������� ��쿡�� ���̺��� ���� �����.
	//if( ( g_FogMode == GLESHAL_FOGMODE_LINEAR ) && ( g_FogStart != Start ) )
	if( (g_FogMode == GLESHAL_FOGMODE_LINEAR)/* && (Start < g_FogEnd )*/ )
	{
		GLESHAL_SetLinearFog( Start, g_FogEnd );	
	}
	g_FogStart = Start;
}

void GLESHAL_SetFogEnd( float End )
{
	MES_ASSERT( g_Open_GRP3D );
	//if( ( g_FogMode == GLESHAL_FOGMODE_LINEAR ) && ( g_FogEnd != End ) )
	if( g_FogMode == GLESHAL_FOGMODE_LINEAR )
	{
		GLESHAL_SetLinearFog( g_FogStart, End );	
	}
	g_FogEnd = End;
}

GLESHALbool GLESHAL_FlipDisplayBuffer( GLESHALbool WaitSync, 
						   GLESHALbool FSAAEnb )
{
	MES_ASSERT( g_Open_GRP3D );

	// MES_GRP3D02 �Լ� ȣ���� �� table convert ����� �Ѵ�.
	if( MES_GRP3D_Flip( g_DisplayBufferSegment, 
				      ConvTable(g_DisplayBufferSegX), ConvTable(g_DisplayBufferSegY), 
				      WaitSync, 0, FSAAEnb ))
	{
		if( g_UseCommandQueue )
			g_CommandQueueFrontPointer = MES_GRP3D_GetFrontOfCommandQueue();
		return 1;
	}
	else
		return 0;
}
/*
void GLESHAL_WaitToIdleState( void )
{
	MES_ASSERT( g_Open_GRP3D );

	if( g_UseCommandQueue )
	{
		unsigned __int64 curFrontPointer = g_GRP3D.GetFrontOfCommandQueue();
		if( 0 != (curFrontPointer&7) )//if( 0 != (curFrontPointer%8) )
		{
			g_GRP3D.Nop();
			curFrontPointer = g_GRP3D.GetFrontOfCommandQueue();
		}
		unsigned __int64 curRearPointer = g_GRP3D.GetRearOfCommandQueue();
		while( curRearPointer < curFrontPointer )
		{
			curRearPointer = g_GRP3D.GetRearOfCommandQueue();
		}		
	}
}
*/

GLESHALbool GLESHAL_IsIdleState( void )
{
	MES_ASSERT( g_Open_GRP3D );

	if( g_UseCommandQueue )
	{
		if( MES_GRP3D_GetRearOfCommandQueue() < MES_GRP3D_GetFrontOfCommandQueue() )
		{			
			return 0;
		}
		else
			return 1;
	}
	else
		return !(MES_GRP3D_CheckBusy());
}

void GLESHAL_Flush( void )
{
	MES_ASSERT( g_Open_GRP3D );

	if( g_UseCommandQueue )
	{
		unsigned __int64 curFrontPointer;
		
		for( int i=0; i<64; i++ ){ MES_GRP3D_Nop(); }
		
		while( true )
		{
			curFrontPointer = MES_GRP3D_GetFrontOfCommandQueue();
			if( 0 != (curFrontPointer&7) )
				MES_GRP3D_Nop();
			else
				break;
		}
	}
}

GLESHALbool GLESHAL_IsDoneFlipCommand( void )
{
	MES_ASSERT( g_Open_GRP3D );

	if( g_UseCommandQueue )
	{
		if( MES_GRP3D_GetRearOfCommandQueue() < g_CommandQueueFrontPointer )
		{
			return 0;
		}
		else
			return 1;
	}

	else
		return 1;
}


// CreateWindowSurface �� �� �ѹ��� 
void GLESHAL_SetWindowSize( unsigned int Width, unsigned int Height )
{
	MES_ASSERT( g_Open_GRP3D );

	g_WindowWidth = Width;
	g_WindowHeight = Height;

	g_ScissorWidth = g_ViewportWidth = Width;
	g_ScissorHeight = g_ViewportHeight = Height;
}

GLESHALAPI 
GLESHALbool GLESHAL_ClearColorBuffer( float R, float G, float B, float A )
{
	// �׸��� �׷��� window �������� ������ ���ϱ�.
	unsigned int x, y, width, height;
	if ( GLESHAL_GetValidDisplaySize( &x, &y, &width, &height ) )
	{
		//unsigned short fillColor = (unsigned short)( ((pColor[2]>>3)<<11)|((pColor[1]>>2)<<5)|(pColor[0]>>3) );
		unsigned short fillColor = (unsigned short)( ((unsigned short)(R*31.0f)<<11)
							|((unsigned short)(G*63.0f)<<5)
							|(unsigned short)(B*31.0f) );
		return MES_GRP3D_FillRectangle( MES_GRP3D_BLOCKADDRESSMODE_DISPLAY,
	        						  g_DisplayBufferSegment, 
									  x+g_DisplayBufferSegX, y+g_DisplayBufferSegY,
	               					  width, height, fillColor );
	}
	else
		return 0;
}


GLESHALAPI 
GLESHALbool GLESHAL_ClearDepthBuffer( unsigned short Depth )
{
// depth���� float�ϼ��� �ְ� fixed�� ���� �����Ƿ� 
// ���ʿ� ���� �� 16bit ������ ���Ǿ��� ���� �޴´�.
	unsigned int x, y, width, height;
	if( GLESHAL_GetValidDisplaySize( &x, &y, &width, &height ) )
	{
		return MES_GRP3D_FillRectangle( MES_GRP3D_BLOCKADDRESSMODE_DISPLAY,
	        						  g_DepthBufferSegment, 
									  x+g_DepthBufferSegX, y+g_DepthBufferSegY,
	               					  width, height, Depth );
	}
	else
		return 0;
}

GLESHALbool GLESHAL_SetDisplayBuffer( unsigned int Segment, 
									  unsigned int SegmentX, unsigned int SegmentY,
									  GLESHALbool FSAAEnb )
{
	MES_ASSERT( g_Open_GRP3D );

	// Block address mode�� �׻� display ���.
	if( MES_GRP3D_SetRenderTarget( //(MES_GRP3D_BLOCKADDRESSMODE)GLESHAL_BLOCKADDRESSMODE_DISPLAY, 
						MES_GRP3D_BLOCKADDRESSMODE_DISPLAY,
						Segment, ConvTable(SegmentX), ConvTable(SegmentY), 
						g_ScissorX, g_ScissorY, 
						g_ScissorWidth, g_ScissorHeight, 
						FSAAEnb ) )	
	{
		g_DisplayBufferSegment	= Segment;
		g_DisplayBufferSegX		= SegmentX;
		g_DisplayBufferSegY		= SegmentY;
		g_FSAAEnable			= FSAAEnb;

		return 1;
	}
	else
		return 0;
}


GLESHALbool GLESHAL_ScissorDisable( void )
{
	return GLESHAL_SetScissorSize( 0, 0, g_WindowWidth, g_WindowHeight );
}


GLESHALbool GLESHAL_SetScissorSize( unsigned int ScissorRect_X, 
									unsigned int ScissorRect_Y,
									unsigned int ScissorRect_Width, 
									unsigned int ScissorRect_Height )
{
	MES_ASSERT( g_Open_GRP3D );

	//!!! scissor enable flag�� �־� �ϴ°�?
	// gl coord -> window coord
	//printf("g_WindowHeight: %d, ScissorRect_Y: %d, ScissorRect_Height: %d\n", g_WindowHeight, ScissorRect_Y, ScissorRect_Height );
	int result = g_WindowHeight - ScissorRect_Y - ScissorRect_Height;

	// �־��� window ������� �� ū ������ scissor �������� �����ϴ� ��쿡 ���� ó��.
	if( result < 0 )
	{
		ScissorRect_Height += result;
		ScissorRect_Y = 0;
	}
	else
		ScissorRect_Y = result;

	//printf("g_WindowHeight: %d, ScissorRect_Y: %d, ScissorRect_Height: %d\n", g_WindowHeight, ScissorRect_Y, ScissorRect_Height );

	if( MES_GRP3D_SetRenderTarget( //(MES_GRP3D_BLOCKADDRESSMODE)GLESHAL_BLOCKADDRESSMODE_DISPLAY, 
						MES_GRP3D_BLOCKADDRESSMODE_DISPLAY,
						g_DisplayBufferSegment, ConvTable(g_DisplayBufferSegX), ConvTable(g_DisplayBufferSegY), 
						ScissorRect_X, ScissorRect_Y,
						ScissorRect_Width, ScissorRect_Height, 
						g_FSAAEnable ) )
	{
		g_ScissorX		= ScissorRect_X;
		g_ScissorY		= ScissorRect_Y;
		g_ScissorWidth	= ScissorRect_Width;
		g_ScissorHeight = ScissorRect_Height;

		return 1;
	}
	else
		return 0;
}

GLESHALbool GLESHAL_SetDepthBuffer( unsigned int Segment, 
								    unsigned int SegmentX, unsigned int SegmentY )
{
	MES_ASSERT( g_Open_GRP3D );

	// Block address mode�� �׻� display ���.
	if( MES_GRP3D_SetZBuffer( MES_GRP3D_BLOCKADDRESSMODE_DISPLAY, 
  						    Segment, ConvTable(SegmentX), ConvTable(SegmentY), 
						    (MES_GRP3D_CMPFUNC)g_DepthFunc ) )
	{
		g_DepthBufferSegment	= Segment;
		g_DepthBufferSegX		= SegmentX;
		g_DepthBufferSegY		= SegmentY;

		return 1;
	}
	else
		return 0;
}

GLESHALbool GLESHAL_SetDepthFunc( GLESHAL_CMPFUNC ZFunc )
{
	MES_ASSERT( g_Open_GRP3D );
	if( MES_GRP3D_SetZBuffer( MES_GRP3D_BLOCKADDRESSMODE_DISPLAY, 
						 g_DepthBufferSegment, ConvTable(g_DepthBufferSegX), ConvTable(g_DepthBufferSegY), 
						 (MES_GRP3D_CMPFUNC)ZFunc ) )
	{
		g_DepthFunc = ZFunc;
		return 1;
	}
	else
		return 0;
}


GLESHALbool GLESHAL_SetViewport( int X, int Y, 
								 int Width, int Height )
{
	MES_ASSERT( g_Open_GRP3D );

	float viewport[4] = { (float)(g_WindowHeight-Y), (float)Height, (float)X, (float)Width };
	// ���� �ϴ� �𼭸�, width, height
	if( ! g_FSAAEnable )
	{
		viewport[0] -= 0.4f;
		viewport[2] -= 0.5f;
	}
	else
	{
		viewport[0] -= 0.25f;
		viewport[2] -= 0.25f;
	}	

	if( MES_GRP3D_RegisterFill ( REGOFFSET(VPORTBOT), 4,
		(const unsigned int*)viewport, MES_GRP3D_WAIT_ALLIDLE,
							   CFALSE ) )
	{
		// glClear ���� ����� ���� ���̹Ƿ� unsigned int���� ����ȯ�ؼ� �ִ´�.
		g_ViewportX = ( (X>0) ? (unsigned int)X : 0 );
		g_ViewportY = ( (Y>0) ? (unsigned int)Y : 0 );
		g_ViewportWidth = (unsigned int)Width;
		g_ViewportHeight = (unsigned int)Height;

		return 1;
	}
	else
		return 0;
}

GLESHALbool GLESHAL_SetGTECode( const unsigned int* pCodeList, 
							   unsigned int CodeOffset,
							   unsigned int CodeSize32 )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetGTECode( pCodeList, CodeOffset, CodeSize32 ));
}

GLESHALbool GLESHAL_SetGTECodeWithOffset( const unsigned int* pCodeList, 
										 unsigned int CodeBase32, 
										 unsigned int CodeSize32 )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetGTECode( pCodeList, CodeBase32, CodeSize32 ));
}

GLESHALbool GLESHAL_SetGTEConst( unsigned int Index, 
								unsigned int NumberOfValue,
								const float* pValueList )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetGTEConst( Index, NumberOfValue, pValueList ));
}

GLESHALbool GLESHAL_SetTSEInput ( unsigned int Index, 
								 unsigned int NumberOfValue,
								 const float* pValueList )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_SetTSEInput( Index, NumberOfValue, pValueList ));
}

GLESHALbool GLESHAL_RunGTE ( unsigned int Vnum,				
							 GLESHALbool Rendering,		
							 GLESHALbool InverseCullMode )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_RunGTE( Vnum, Rendering, InverseCullMode ));
}

GLESHALbool GLESHAL_RunTSE_Triangle( GLESHALbool InverseCullMode )
{
	MES_ASSERT( g_Open_GRP3D );
	return (GLESHALbool)(MES_GRP3D_RunTSE_Triangle( InverseCullMode ));
}

void GLESHAL_SetCullFace( GLESHAL_CULLFACE CullfaceState )
{
	g_CullFaceMode = CullfaceState;
	GLESHAL_SetFaceCullingState();
}

void GLESHAL_SetFrontFace( GLESHAL_FRONTFACE FrontfaceState )
{
	g_FrontFaceMode = FrontfaceState;
	GLESHAL_SetFaceCullingState();
}

void GLESHAL_SetVolumeCullingState ( GLESHAL_VOLUMECULLSTATE State )
{
	MES_ASSERT( g_Open_GRP3D );
	MES_GRP3D_SetVolumeCullingState( (MES_GRP3D_VOLUMECULLSTATE)State );
}


void GLESHAL_OpenCommandQueue(
	unsigned int* pCommand_Virtual,	
	unsigned int* pCommand_Physical,
	unsigned int Size64
)
{
	// Command Queue�� ���ڴٴ� �ǹ��̹Ƿ� front pointer�� �ʱ�ȭ�صд�.
	MES_ASSERT( g_Open_GRP3D );
	MES_GRP3D_OpenCommandQueue( pCommand_Virtual, pCommand_Physical, Size64 );
	g_UseCommandQueue = CTRUE;

	g_CommandQueueFrontPointer = 0; 
}

void GLESHAL_CloseCommandQueue()
{
	MES_ASSERT( g_Open_GRP3D );
	if( g_UseCommandQueue )
	{
		MES_GRP3D_CloseCommandQueue();
		g_UseCommandQueue = CFALSE;
	}
}


unsigned __int64 GLESHAL_GetFrontOfCommandQueue( void )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_GetFrontOfCommandQueue();
}

unsigned __int64 GLESHAL_GetRearOfCommandQueue( void )
{
	MES_ASSERT( g_Open_GRP3D );
	return MES_GRP3D_GetRearOfCommandQueue();
}


void GLESHAL_SetVirtualAddressOfRegisterSet( unsigned int RegisterSetIndex, unsigned int VirtualAddress )
{
	MES_ASSERT( g_Open_GRP3D );

	MES_GRP3D_SelectModule( 0 );
	MES_GRP3D_SetBaseAddress( VirtualAddress );

}

void GLESHAL_Nop( void )
{
	MES_ASSERT( g_Open_GRP3D );
	MES_GRP3D_Nop();
}

void GLESHAL_Nops( unsigned int count )
{
	MES_ASSERT( g_Open_GRP3D );
	MES_GRP3D_Nops( count );
}
/*
GLESHALbool GLESHAL_RegisterFill ( unsigned int RegisterOffset, unsigned int NumberOfData,
						const unsigned int* pData, unsigned int WaitFalg,
						GLESHALbool InterruptRequest )
{
	return MES_GRP3D_RegisterFill ( RegisterOffset, NumberOfData,
							   pData, WaitFalg, InterruptRequest );
}
*/
/*
BOOL WINAPI DllMain( HANDLE, DWORD dwReason, LPVOID ) 
{
	FILE *fd;
	fd = fopen("NAND Flash/resources/DllMain.txt", "at");
	fprintf( fd, "-------DLLMain in GLESHAL excuted--------\n" );
	switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		fprintf( fd, "DLL_PROCESS_ATTACH!\n" );
		break;
	case DLL_THREAD_ATTACH :
		fprintf( fd, "DLL_THREAD_ATTACH!\n" );
		break;
	case DLL_THREAD_DETACH :
		fprintf( fd, "DLL_THREAD_DETACH!\n" );
		break;
	case DLL_PROCESS_DETACH:
		fprintf( fd, "DLL_PROCESS_DETACH!\n" );
		GLESHAL_CloseCommandQueue();
		fprintf( fd, "GLESHAL_CloseCommandQueue!\n" );
		while( GLESHAL_CheckBusy() ){ }
		GLESHAL_CloseModule();
		fprintf( fd, "GLESHAL_CloseModule!\n" );
		break;
	}
	fclose(fd);
	return TRUE;
}
*/
