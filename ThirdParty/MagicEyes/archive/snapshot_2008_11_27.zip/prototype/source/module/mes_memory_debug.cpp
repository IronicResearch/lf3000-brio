//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : 
//	File       : mes_memory_debug.cpp
//	Description:
//	Author     : Gamza (gamza@mesgraphics.com)
//	Export     : 
//	History    :
//     2007/10/11 Gamza	������忡�� MES_FREE�� free�� ȣ������ �ʴ� ���׼���.
//						iter = MES_MEMORY_DEBUG_MemoryList.begin(); ȣ������ ++iterȣ�⹮�� ����.
//     2007/09/12 Gamza	AUTO_DESTROYER�Ҵ���п� ���� ���ܻ�Ȳ�� �������� �ʾƵ� �ǵ��� ������.
//						AUTO_DESTROYER�� heap�� �������� �ʰ�, singleton�� ���.
//     2007/08/24 Gamza	������� �Ǽ������� memory leak���� �����ϵ��� ����.
//						�̰��� ���� MES_MEMORY_DEBUG_ReportMemoryLeak ȣ���
//						�������� ���� ��� �޸𸮸� �����ϵ��� �Ѵ�.
//     2007/08/23 Gamza	first description
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//
//
//	if MES_CHECK_MEMORY_LEAK is not defined
//
//
//------------------------------------------------------------------------------
#ifndef MES_CHECK_MEMORY_LEAK

extern "C" void  MES_MEMORY_DEBUG_ReportMemoryLeak( void )
{
	// do not anything
}

//------------------------------------------------------------------------------
//
//
//	if MES_CHECK_MEMORY_LEAK is defined
//
//
//------------------------------------------------------------------------------
#else // MES_CHECK_MEMORY_LEAK

#include "mes_memory_debug.h"

#ifdef WIN32
	#include <stdio.h>
	#include <stdarg.h>
	#include <windows.h>
	#define MES_MEMORY_DEBUG_TRACE(expr)	MES_MEMORY_DEBUG_TRACE_IMPL expr
	static void MES_MEMORY_DEBUG_TRACE_IMPL( const char* const Format, ... )
	{
		va_list args;
		static char buffer[2048];
		va_start( args, Format );
		vsprintf( buffer,Format,args );
		va_end  ( args );
		OutputDebugString( buffer );
		printf( "%s", buffer );
	}
#else
	#include <stdio.h>
	#define MES_MEMORY_DEBUG_TRACE(expr)	printf expr
#endif

#if defined(WIN32) || defined(UNDER_CE)
	#pragma warning(disable:4786)
	#pragma warning(disable:4514)
	#pragma warning(disable:4530)
	#pragma warning(push,3)
#endif
#include <string>
#include <list>
#include <vector>
#include <algorithm>
#ifdef WIN32
	#pragma warning(pop)
#endif

struct MES_MEMORY_DEBUG_RECORD
{
	std::string m_TypeName;
	int         m_TypeSize;
	int         m_NumberOfItems;
	void*       m_Address;
	bool		m_IsArray;
	const char* m_SourceFileName;
	int         m_SourceLineNumber;
	const MES_MEMORY_DEBUG_AUTO_DESTROYER* m_pDestoryer;
	unsigned int m_ScopeLevel;
	bool operator==(void* Address) const { return (m_Address == Address); }
};
typedef std::list<MES_MEMORY_DEBUG_RECORD> MEMORYBLOCKLIST;

static unsigned int MES_MEMORY_DEBUG_ScopeMax = 0;
static std::vector < std::string > MES_MEMORY_DEBUG_Scope;
static MEMORYBLOCKLIST MES_MEMORY_DEBUG_MemoryList;

class MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE : public MES_MEMORY_DEBUG_AUTO_DESTROYER
{
public:
	virtual void Delete( void* pObject ) const
	{
		MES_MEMORY_DEBUG_Free( pObject, __FILE__, __LINE__ );
	}
	static const MES_MEMORY_DEBUG_AUTO_DESTROYER* GetDestroyer(void)
	{
		static MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE ms_Singleton;
		return &ms_Singleton;
	}
};

static const char* MES_MEMORY_DEBUG_GetScope( void )
{
	if( MES_MEMORY_DEBUG_Scope.empty() ){ return ""; }
	return MES_MEMORY_DEBUG_Scope.rbegin()->c_str();
}

void  MES_MEMORY_DEBUG_PushScope( const char* Name )
{
	if( MES_MEMORY_DEBUG_Scope.empty() )
		MES_MEMORY_DEBUG_Scope.push_back( Name );
	else
		MES_MEMORY_DEBUG_Scope.push_back( std::string(MES_MEMORY_DEBUG_GetScope()) + "::" + Name );
	if( MES_MEMORY_DEBUG_Scope.size() > MES_MEMORY_DEBUG_ScopeMax )
		MES_MEMORY_DEBUG_ScopeMax = MES_MEMORY_DEBUG_Scope.size();
}

void  MES_MEMORY_DEBUG_PopScope( void )
{
	MES_MEMORY_DEBUG_Scope.pop_back();
}

void  MES_MEMORY_DEBUG_AppendMemoryBlock
(
	int TypeSize,
	int NumberOfItems,
	void* Address,
	bool IsArray,
	const char* SourceFileName,
	int SourceLineNumber,
	const MES_MEMORY_DEBUG_AUTO_DESTROYER* pDestoryer
)
{
	if( 0 == Address || 0 == pDestoryer )
	{
		if( IsArray )
			MES_MEMORY_DEBUG_TRACE(( "*E: MES_NEW_ARRAY is failed. (new %s[%d]) %s(%d)\n", MES_MEMORY_DEBUG_GetScope(), NumberOfItems, SourceFileName, SourceLineNumber ));
		else
			MES_MEMORY_DEBUG_TRACE(( "*E: MES_NEW is failed. (new %s) %s(%d)\n", MES_MEMORY_DEBUG_GetScope(), SourceFileName, SourceLineNumber ));
		return;
	}
	MES_MEMORY_DEBUG_RECORD temp;
	temp.m_TypeName         = MES_MEMORY_DEBUG_GetScope();
	temp.m_TypeSize         = TypeSize        ;
	temp.m_NumberOfItems    = NumberOfItems   ;
	temp.m_Address          = Address         ;
	temp.m_IsArray          = IsArray         ;
	temp.m_SourceFileName   = SourceFileName  ;
	temp.m_SourceLineNumber = SourceLineNumber;
	temp.m_pDestoryer       = pDestoryer;
	temp.m_ScopeLevel       = MES_MEMORY_DEBUG_Scope.size();
	MES_MEMORY_DEBUG_MemoryList.push_back(temp);
}

void  MES_MEMORY_DEBUG_RemoveMemoryBlock
(
	void* Address,
	bool IsArray,
	const char* SourceFileName,
	int SourceLineNumber
)
{
	if( 0 == Address ){ return; } // delete 0; �� ���Ǵ� �ƹ��ϵ� ���� �ʴ� ���� C++ ǥ���̴�.
	MEMORYBLOCKLIST::iterator iter = std::find( MES_MEMORY_DEBUG_MemoryList.begin() , MES_MEMORY_DEBUG_MemoryList.end(), Address );
	if( MES_MEMORY_DEBUG_MemoryList.end() == iter ||
		MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE::GetDestroyer() == iter->m_pDestoryer )
	{
		if( IsArray )
			MES_MEMORY_DEBUG_TRACE(( "*E: MES_DELETE_ARRAY (invalid pointer:%08x). %s(%d)\n", Address, SourceFileName, SourceLineNumber ));
		else
			MES_MEMORY_DEBUG_TRACE(( "*E: MES_DELETE (invalid pointer:%08x). %s(%d)\n", Address, SourceFileName, SourceLineNumber ));
		return;
	}
	MES_MEMORY_DEBUG_RECORD temp = (*iter);
	MES_MEMORY_DEBUG_MemoryList.erase(iter);

	if( IsArray && ! temp.m_IsArray ) 
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: You have to call MES_DELETE. %s(%d)\n", SourceFileName, SourceLineNumber ));
	}
	if( ! IsArray && temp.m_IsArray )
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: You have to call MES_DELETE_ARRAY. %s(%d)\n", SourceFileName, SourceLineNumber ));
	}
}

void* MES_MEMORY_DEBUG_Malloc
(
	int Size,
	const char* SourceFileName,
	int SourceLineNumber
)
{
	void* result = malloc(Size+4);
	if( ! result )
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: MES_MALLOC is failed. (%s bytes) %s(%d)\n", Size, SourceFileName, SourceLineNumber ));
		return 0;
	}

	// for overwrite checking
	((unsigned char*)result)[Size+0] = 0xAB;
	((unsigned char*)result)[Size+1] = 0xCD;
	((unsigned char*)result)[Size+2] = 0xEF;
	((unsigned char*)result)[Size+3] = 0xCC;

	MES_MEMORY_DEBUG_PushScope( "MES_MALLOC" );

	MES_MEMORY_DEBUG_RECORD temp;
	temp.m_TypeName         = MES_MEMORY_DEBUG_GetScope();
	temp.m_TypeSize         = 1               ;
	temp.m_NumberOfItems    = Size            ;
	temp.m_Address          = result          ;
	temp.m_IsArray          = true            ;
	temp.m_SourceFileName   = SourceFileName  ;
	temp.m_SourceLineNumber = SourceLineNumber;
	temp.m_pDestoryer       = MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE::GetDestroyer();
	temp.m_ScopeLevel       = MES_MEMORY_DEBUG_Scope.size();
	MES_MEMORY_DEBUG_MemoryList.push_back(temp);

	MES_MEMORY_DEBUG_PopScope();
	return result;
}

void  MES_MEMORY_DEBUG_Free
(
	void* Address,
	const char* SourceFileName,
	int SourceLineNumber
)
{
	if( ! Address )
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: MES_FREE (invalid pointer: %08x) %s(%d)\n", Address, SourceFileName, SourceLineNumber ));
		return;
	}
	MEMORYBLOCKLIST::iterator iter = std::find( MES_MEMORY_DEBUG_MemoryList.begin() , MES_MEMORY_DEBUG_MemoryList.end(), Address );
	if( MES_MEMORY_DEBUG_MemoryList.end() == iter ||
		MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE::GetDestroyer() != iter->m_pDestoryer )
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: MES_FREE (invalid pointer:%08x). %s(%d)\n", Address, SourceFileName, SourceLineNumber ));
		return;
	}

	// for overwrite checking
	if( ((unsigned char*)(iter->m_Address))[iter->m_NumberOfItems+0] != 0xAB ||
		((unsigned char*)(iter->m_Address))[iter->m_NumberOfItems+1] != 0xCD ||
		((unsigned char*)(iter->m_Address))[iter->m_NumberOfItems+2] != 0xEF ||
		((unsigned char*)(iter->m_Address))[iter->m_NumberOfItems+3] != 0xCC )
	{
		MES_MEMORY_DEBUG_TRACE(( "*E: MES_FREE (memory is cracked:%08x). %s(%d)\n", Address, SourceFileName, SourceLineNumber ));
		return;
	}

	free( Address );

	MES_MEMORY_DEBUG_MemoryList.erase(iter);
}

void  MES_MEMORY_DEBUG_ReportMemoryLeak ( void )
{
	unsigned int total_leaks = 0;
	unsigned int scope_level;

	MEMORYBLOCKLIST::iterator iter;

	for( iter = MES_MEMORY_DEBUG_MemoryList.begin(); iter != MES_MEMORY_DEBUG_MemoryList.end(); ++iter )
	{
		total_leaks += (*iter).m_TypeSize * (*iter).m_NumberOfItems;
	}
	
	for( scope_level=0; scope_level <= MES_MEMORY_DEBUG_ScopeMax; scope_level++ )
	{
		for( iter = MES_MEMORY_DEBUG_MemoryList.begin(); iter != MES_MEMORY_DEBUG_MemoryList.end(); )
		{
			if( (*iter).m_ScopeLevel <= scope_level )
			{
				if( MES_MEMORY_DEBUG_AUTO_DESTROYER_FREE::GetDestroyer() != iter->m_pDestoryer )
				{
					if( (*iter).m_IsArray )
						MES_MEMORY_DEBUG_TRACE(( "*E: MES_MEMORY_DEBUG Memory leak %s[%d] %s(%d)\n", (*iter).m_TypeName.c_str(), (*iter).m_NumberOfItems, (*iter).m_SourceFileName, (*iter).m_SourceLineNumber ));
					else
						MES_MEMORY_DEBUG_TRACE(( "*E: MES_MEMORY_DEBUG Memory leak %s %s(%d)\n", (*iter).m_TypeName.c_str(), (*iter).m_SourceFileName, (*iter).m_SourceLineNumber ));
				}
				else
				{
					MES_MEMORY_DEBUG_TRACE(( "*E: MES_MEMORY_DEBUG Memory leak %s (%d bytes) %s(%d)\n", (*iter).m_TypeName.c_str(), (*iter).m_NumberOfItems, (*iter).m_SourceFileName, (*iter).m_SourceLineNumber ));
				}
				MES_MEMORY_DEBUG_RECORD temp = (*iter);

				for( iter = MES_MEMORY_DEBUG_MemoryList.begin(); iter != MES_MEMORY_DEBUG_MemoryList.end(); )
				{
					if( (*iter).m_TypeName        == temp.m_TypeName         &&
						(*iter).m_TypeSize        == temp.m_TypeSize         &&
						(*iter).m_NumberOfItems   == temp.m_NumberOfItems    &&
						//(*iter).m_Address         == temp.m_Address          &&
						(*iter).m_IsArray         == temp.m_IsArray          &&
						(*iter).m_SourceFileName  == temp.m_SourceFileName   &&
						(*iter).m_SourceLineNumber== temp.m_SourceLineNumber &&
						//(*iter).m_pDestoryer      == temp.m_pDestoryer       &&
						(*iter).m_ScopeLevel      == temp.m_ScopeLevel       )
					{
						(*iter).m_pDestoryer->Delete( (*iter).m_Address );
						iter = MES_MEMORY_DEBUG_MemoryList.begin();
					}
					else
					{
						++iter;
					}
				}
				iter = MES_MEMORY_DEBUG_MemoryList.begin();
			}
			else
			{
				++iter;
			}
		}
	}				

	if( total_leaks )
	{
		MES_MEMORY_DEBUG_TRACE(( "---------------------------------------\n" ));
		MES_MEMORY_DEBUG_TRACE(( "*E: MES_MEMORY_DEBUG total memory leaks : %d bytes (%d Kbytes)\n", total_leaks, (total_leaks+1023)/1024  ));
		MES_MEMORY_DEBUG_TRACE(( "---------------------------------------\n" ));
	}
}

#endif // MES_CHECK_MEMORY_LEAK

