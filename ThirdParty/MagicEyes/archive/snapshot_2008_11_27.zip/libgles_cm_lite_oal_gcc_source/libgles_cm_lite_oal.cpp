//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : libgles_cm_lite_oal.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//     2007/01/23 Gamza FW team���� �ۼ��� MP2530F platform�� virtual address��
//                      physical address�� ������ ����.
//	   2007/01/03 Yuni first implementation
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//	includes
//------------------------------------------------------------------------------
#include "libgles_cm_lite_oal.h"
#include <GLESOAL_Private.h>

int					__GLESOAL__::g_WindowWidth		= 0;
int					__GLESOAL__::g_WindowHeight		= 0;

static unsigned int	g_AddressOf3DCore = 0;

//  this function's implementation is in OS
#ifdef __cplusplus
extern "C" {
#endif
    typedef struct
    {
        unsigned int	VirtualAddressOf3DCore  ; // virtual addres of the 3D core register
        
    	unsigned int	Memory1D_VirtualAddress ; // must be 8byte aligned, non-cacheable
    	unsigned int    Memory1D_PhysicalAddress; // must be 8byte aligned, non-cacheable
    	unsigned int	Memory1D_SizeInMbyte    ; // size (Mbyte)
    
    	unsigned int	Memory2D_VirtualAddress ; // must be 4Mbyte aligned, non-cacheable
    	unsigned int    Memory2D_PhysicalAddress; // must be 4Mbyte aligned, non-cacheable
    	unsigned int	Memory2D_SizeInMbyte    ; // size (Mbyte), must be multiple of 4
    } ___OAL_MEMORY_INFORMATION__;
    GLESOALbool GLESOAL_Initalize( ___OAL_MEMORY_INFORMATION__* pMemoryInfomation, int FSAAEnb );
    void        GLESOAL_SetWindow    ( void* pNativeWindow  );
    void        GLESOAL_GetWindowSize( int* pWidth, int* pHeight );

	void         GLESOAL_WaitForDisplayAddressPatched( void );
	void		 GLESOAL_SetDisplayAddress( const unsigned int DisplayBufferPhysicalAddress );
	GLESOALbool  GLESOAL_IsSoftwareSyncNeeded( void );
#ifdef __cplusplus
}
#endif
 
void GLESOAL_SetNativeWindow( void* pNativeWindow )
{
    GLESOAL_SetWindow    ( pNativeWindow );
	GLESOAL_GetWindowSize( &g_WindowWidth, &g_WindowHeight );
}
 
void GLESOAL_SetNativeDisplay( void* pNativeDisplay )
{
}

void GLESOAL_GetNativeWindowSize( int* pWidth, int* pHeight )
{
    GLESOAL_GetWindowSize( &g_WindowWidth, &g_WindowHeight );
	*pWidth 	= g_WindowWidth;
	*pHeight 	= g_WindowHeight;
}

GLESOALbool GLESOAL_Initialize_Internal( GLESOALbool FSAAEnb )
{    
	___OAL_MEMORY_INFORMATION__ memoryinformation;
	if( ! GLESOAL_Initalize( &memoryinformation, FSAAEnb ) ){ return 0; }
	
	if( 0 != ( memoryinformation.Memory1D_VirtualAddress  % 8) ){ return 0; }
	if( 0 != ( memoryinformation.Memory1D_PhysicalAddress % 8) ){ return 0; }
	if( 0 >=   memoryinformation.Memory1D_SizeInMbyte )         { return 0; }
	
	if( 0 != ( memoryinformation.Memory2D_VirtualAddress  % 0x400000) ){ return 0; }
	if( 0 != ( memoryinformation.Memory2D_PhysicalAddress % 0x400000) ){ return 0; }
	if( 0 != ( memoryinformation.Memory2D_SizeInMbyte     % 2       ) ){ return 0; }
	if( 0 >=   memoryinformation.Memory2D_SizeInMbyte )                { return 0; }
	
    ___OEM_CUSTOMHEAP memory1d = { 
        memoryinformation.Memory1D_VirtualAddress,
        memoryinformation.Memory1D_PhysicalAddress,
        memoryinformation.Memory1D_SizeInMbyte
        };
    ___OEM_CUSTOMHEAP memory2d = { 
        memoryinformation.Memory2D_VirtualAddress,
        memoryinformation.Memory2D_PhysicalAddress,
        memoryinformation.Memory2D_SizeInMbyte
        };
    ___MES_1D_Manager_Initialize( &memory1d, 1 );
    ___MES_2D_Manager_Initialize( &memory2d, 1 );
	
	g_AddressOf3DCore = memoryinformation.VirtualAddressOf3DCore;
	
    return 1;
}

unsigned int GLESOAL_GetVirtualAddressOf3DCore( void )
{
    return g_AddressOf3DCore;
}


//------------------------------------------------------------------------------
void GLESOAL_PushDisplayAddressPatch( const GLESOAL_MEMORY2D* pDisplayBuffer )
{
	GLESOAL_SetDisplayAddress( ___MES_2D_Manager_GetPhysicalAddress( pDisplayBuffer ) );
}

//------------------------------------------------------------------------------
GLESOALbool  GLESOAL_IsSoftwareSyncNeeded( void )
{
	// if you used dual display in MP2530F, this function must return 1
	return 1;
}
