//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.h
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#ifndef _GLESOAL_TEXTURECOPY_H
#define _GLESOAL_TEXTURECOPY_H

//#include "libgles_cm_lite_oal.h"
#include "GLESOAL_Private.h"

namespace __GLESOAL__
{

template< typename WRITECLASS, typename READCLASS >
inline void TextureCopyWithObject( WRITECLASS Writer, READCLASS Reader, unsigned int Width, unsigned int Height )
{
	unsigned int i, j;
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
			Writer.Write( i, j, Reader.Read(i, j) );
}

template< typename WRITECLASS, typename READCLASS >
inline void ReadDisplayWriteTexture( WRITECLASS Writer, READCLASS Reader, 
										    unsigned int Width, unsigned int Height )
{
	unsigned int i, j;
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
			Writer.Write( i, j, Reader.Read(i, g_WindowHeight-j) );
}

template< typename WRITECLASS, typename READCLASS >
inline void ReadDisplayWriteValidTexture( WRITECLASS Writer, READCLASS Reader, 
										unsigned int Width, unsigned int Height,
										unsigned int CountX, unsigned int CountY )
{
	unsigned int i, j;
	for( j=0; j<Height; j++)
		for( i=0; i<Width; i++)
		{
			unsigned int x, y;
			for( y=0; y<CountY; y++ )
				for( x=0; x<CountX; x++ )
				{
					unsigned short value = Reader.Read(i, g_WindowHeight-j);
					Writer.Write( i*CountX + x, j*CountY + y, value );
				}
		}
}

template< typename WRITECLASS, typename READCLASS >
inline GLESOALbool TextureCopy( const GLESOAL_MEMORY2D* pMemory2D, 
					 unsigned int X, unsigned int Y,
					 unsigned int Width, unsigned int Height, 
					 const void* pSrc, unsigned int SrcStride )
{
	//if( Memory2D )
	{
		if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
			return 0;
		
		READCLASS Reader( pSrc, SrcStride );
		WRITECLASS Writer( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+X, pMemory2D->VirtualSegY+Y );


		unsigned int curWidth = SrcStride / READCLASS::BYTE_PER_PIXEL;	// source�� ���� width ���.
		if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
			curWidth = Width;

		TextureCopyWithObject< WRITECLASS, READCLASS >( Writer, Reader, curWidth, Height );
		return 1;
	}
	//else
		//return 0;
}

} // namespace __GLESOAL__

using namespace __GLESOAL__;

#endif // _GLESOAL_TEXTURECOPY_H
