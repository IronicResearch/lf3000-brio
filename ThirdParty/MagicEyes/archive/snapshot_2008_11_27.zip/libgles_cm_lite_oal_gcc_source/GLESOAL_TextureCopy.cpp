//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     :
//	File       : GLESOAL_TextureCopy.cpp
//	Description:
//	Author     : Yuni(yuni@mesdigital.com)
//	Export     :
//	History    :
//	   2007/09/06 Gamza GLESOAL_WritePixel_RGBA8 ������Ʈ�� ������Ʈ �����ϵ��� ����.
//	   2007/08/28 Gamza 2�� �¼����� �ƴ� �ؽ����� ����ó���� ���� �Լ� �߰�.
//						GLESOAL_MakeEdgeForNonPowerOf2_8BPP
//						GLESOAL_MakeEdgeForNonPowerOf2_16BPP
//	   2006/10/09 Yuni first implementation
//------------------------------------------------------------------------------
#include <GLESOAL_TextureCopy.h>

#if defined(WIN32) || defined(UNDER_CE)
#pragma warning( disable:4514 )
#endif


namespace {

#define MAKE_R5G6B5( R, G, B )	(unsigned short)((((unsigned int)(R)&0xf8)<<8)|(((unsigned int)(G)&0xfc)<<3)|(((unsigned int)(B)&0xf8)>>3))


#define AddressTMEM_MP2530F( SubSegment, X, Y )		(						\
					(((SubSegment)&~1)<<21) | (((SubSegment)&1)<<16) |		\
					(((Y)&0x03E0)<<12)|(((Y)&0x001E)<<6)|(((Y)&0x0001)<<2)|	\
					(((X)&0x07C0)<< 5)|(((X)&0x003C)<<1)|(((X)&0x0003)<<0)	\
					)
#define AddressDMEM_MP2530F( SubSegment, X, Y )		(						\
					(((SubSegment)&~1)<<21) | (((SubSegment)&1)<<16) |		\
					(((Y)&0x03E0)<<12)|(((Y)&0x001F)<<6)|					\
					(((X)&0x07C0)<< 5)|(((X)&0x003F)<<0)					\
					)


static void WriteTMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,				/// [in] x position in block memory (unit:16bit)
	unsigned int Y,				/// [in] y position in block memory
	unsigned short Data			/// [in] 16bit data
)
{

	*((unsigned short*)AddressTMEM_MP2530F( SubSegment, X*2, Y )) = Data;
}

static void WriteTMEM8
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,				/// [in] x position in block memory (unit:8bit)
	unsigned int Y,				/// [in] y position in block memory
	unsigned char Data			/// [in] 16bit data
)
{
	*((unsigned char*)AddressTMEM_MP2530F( SubSegment, X, Y )) = Data;
}

static unsigned short ReadDMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned short*)AddressDMEM_MP2530F( SubSegment, X*2, Y ));
}

static unsigned char ReadTMEM8
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned char*)AddressTMEM_MP2530F( SubSegment, X, Y ));
}

static unsigned short ReadTMEM16
(
	unsigned int SubSegment,	/// [in] sub-segment number
	unsigned int X,			/// [in] x position in block memory (unit:16bit)
	unsigned int Y			/// [in] y position in block memory
)
{
	return *((unsigned short*)AddressTMEM_MP2530F( SubSegment, X*2, Y ));
}

GLESOALbool GLESOAL_CopyPixelToTexture_U4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned char value;
	unsigned int offsetX = X + pMemory2D->VirtualSegX;
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	Width = (Width+1)/2;	// char�� �д� ��� Width�� 1/2 �Ѵ�.
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *((unsigned char*)pSrc+(i + SrcStride*j));
			WriteTMEM8( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}

GLESOALbool GLESOAL_CopyPixelToTexture_U8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned char value;
	unsigned int offsetX = X + pMemory2D->VirtualSegX;
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *((unsigned char*)pSrc+(i+ SrcStride*j));
			WriteTMEM8( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}


GLESOALbool GLESOAL_CopyPixelToTexture_U16( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned short value;
	unsigned int offsetX = X + (pMemory2D->VirtualSegX/2);
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	int pixelPerByte = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = *( (unsigned short*)((unsigned char*)pSrc+(i*pixelPerByte + SrcStride*j)) );
			WriteTMEM16( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}

	return 1;
}



//------------------------------------------------------------------------------
//
//	classes for template function
//
//------------------------------------------------------------------------------

/* read class */
class GLESOAL_ReadPixel_RGB8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 3
	};

// functions
public:
	GLESOAL_ReadPixel_RGB8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned char* pStart = (unsigned char*)m_pAddress+(X*BYTE_PER_PIXEL + m_Stride*Y);
		//unsigned short dstValue = MAKE_R5G6B5(pStart[0], pStart[1], pStart[2]);
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>3)<<11) |
												    ((pStart[1]>>2)<<5) |
												    (pStart[2]>>3) );

		return dstValue;
	}
};

class GLESOAL_ReadPixel_RGBA8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 4
	};

// functions
public:
	GLESOAL_ReadPixel_RGBA8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned char* pStart = (unsigned char*)m_pAddress+(X*BYTE_PER_PIXEL + m_Stride*Y);
/*
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>3)<<11) |
								  ((pStart[1]>>2)<<5) |
								  (pStart[2]>>3) );
*/
		unsigned short dstValue = (unsigned short)( ((pStart[0]>>4)<<12) |
								  ((pStart[1]>>4)<<8) |
								  ((pStart[2]>>4)<<4 ) |
								  (pStart[3]>>4) );
		return dstValue;
	}
};


/* write class */
class GLESOAL_WritePixel_RGBA8
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 4
	};

// functions
public:
	GLESOAL_WritePixel_RGBA8( const void *pSrc, unsigned int SrcStride )
	{
		m_pAddress = pSrc;
		m_Stride = SrcStride;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		unsigned int curValue;
		unsigned char r = (unsigned char)((Value>>11)<<3);
		unsigned char g = (unsigned char)(((Value>>5)&0x3F)<<2);
		unsigned char b = (unsigned char)((Value&0x1F)<<3);
		unsigned char a = 0xFF;
		r = (unsigned char)( r | ( r>>5 ) );
		g = (unsigned char)( g | ( g>>6 ) );
		b = (unsigned char)( b | ( b>>5 ) );
		((unsigned char*)&curValue)[0] = r;
		((unsigned char*)&curValue)[1] = g;
		((unsigned char*)&curValue)[2] = b;
		((unsigned char*)&curValue)[3] = a;
		*((unsigned int*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y )) = curValue;
	}
};

class GLESOAL_WritePixel_R5G6B5
{
// variables
protected:
	const void *m_pAddress;
	unsigned int m_Stride;

public:
	enum{
		BYTE_PER_PIXEL = 2
	};

// functions
public:
	GLESOAL_WritePixel_R5G6B5( const void *pDst, unsigned int DstStride )
	{
		m_pAddress = pDst;
		m_Stride = DstStride;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		*((unsigned short*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y)) = Value;
	}
};

//------------------------------------------------------------------------------
//
//	Memory2D Read/Write classes
//
//------------------------------------------------------------------------------
class GLESOAL_ReadMem2D_R5G6B5
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_ReadMem2D_R5G6B5( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		//return ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y);
		return ReadDMEM16( m_Segment, m_OffsetX+X, (m_OffsetY-g_WindowHeight+Y) );
	}
};

class GLESOAL_ReadMem2D_R5G6B5_FSAA
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_ReadMem2D_R5G6B5_FSAA( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	unsigned short Read( unsigned int X, unsigned int Y )
	{
		unsigned short color0 = ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY-(g_WindowHeight-Y)*2 + 0 );
		unsigned short color1 = ReadDMEM16( m_Segment, m_OffsetX+X, m_OffsetY-(g_WindowHeight-Y)*2 + 1 );
		int r = ( ((color0>>11) & 0x1F) + ((color1>>11) & 0x1F) ) >> 1 ;
		int g = ( ((color0>> 5) & 0x3F) + ((color1>> 5) & 0x3F) ) >> 1 ;
		int b = ( ((color0>> 0) & 0x1F) + ((color1>> 0) & 0x1F) ) >> 1 ;
		return ((r<<11) | (g<<5) | b);
	}
};

class GLESOAL_WriteMem2D_R5G6B5
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_WriteMem2D_R5G6B5( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{
		WriteTMEM16( m_Segment, m_OffsetX+X, m_OffsetY+Y, Value );
		//*((unsigned short*)((unsigned char*)m_pAddress + X*BYTE_PER_PIXEL + m_Stride*Y)) = Value;
	}
};

class GLESOAL_WriteMem2D_L8
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_WriteMem2D_L8( unsigned int Segment,
						unsigned int X, unsigned int Y )
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	void Write( unsigned int X, unsigned int Y, unsigned short Value )
	{		
		// refer to Table 3.15 in OpenGL v2.1 spec(3.8 Textureing)
		unsigned char curValue = (unsigned char)(Value>>11);
		curValue = (unsigned char)((curValue<<3)|(curValue>>2));
		WriteTMEM8( m_Segment, m_OffsetX+X, m_OffsetY+Y, curValue );
	}
};

/*
class GLESOAL_WriteMem2D_UB1
{
// variables
protected:
	unsigned int m_Segment;
	unsigned int m_OffsetX;
	unsigned int m_OffsetY;
	//GLESOAL_HMEMORY2D m_HMemory2D;

public:

	GLESOAL_WriteMem2D_UB1( unsigned int Segment,
							unsigned int X, unsigned int Y )//8bpp
	{
		m_OffsetX = X;
		m_OffsetY = Y;
		m_Segment = Segment;
	}

	void Write( unsigned int X, unsigned int Y, unsigned char Value )
	{
		WriteTMEM8( m_Segment, m_OffsetX+X, m_OffsetY+Y, Value );
	}
};
*/
}	// namespace

//------------------------------------------------------------------------------
//
//	export functions
//
//------------------------------------------------------------------------------
GLESOALbool GLESOAL_UploadTexture_index4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{

	unsigned int curWidth = SrcStride * 2;	// 4bit �̹Ƿ� 1/2byte�� ��.
	if( curWidth != Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		return 0;

	return GLESOAL_CopyPixelToTexture_U4( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
	
/*
	unsigned int curWidth = SrcStride;
	if( curWidth != Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		return 0;

	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
*/	
}

GLESOALbool GLESOAL_UploadTexture_index8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	unsigned int curWidth = SrcStride;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_A8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
	unsigned int curWidth = SrcStride;	// source�� ���� width ���.
	if( curWidth != Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		return 0;

	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;

	GLESOAL_ReadPixel_RGB8 Reader( pSrc, SrcStride );
	GLESOAL_WriteMem2D_R5G6B5 Writer( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+X, pMemory2D->VirtualSegY+Y );
	
	unsigned int curWidth = SrcStride / GLESOAL_ReadPixel_RGB8::BYTE_PER_PIXEL;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	TextureCopyWithObject< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGB8 >( Writer, Reader, curWidth, Height );
	return 1;
}

GLESOALbool GLESOAL_UploadTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGBA8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );

	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;
	
	GLESOAL_ReadPixel_RGBA8 Reader( pSrc, SrcStride );
	//GLESOAL_WriteMem2D_R5G6B5 Writer( pMemory2D->VirtualSegment, pMemory2D->VirtualSegX/2+X, pMemory2D->VirtualSegY+Y );


	unsigned int curWidth = SrcStride / GLESOAL_ReadPixel_RGBA8::BYTE_PER_PIXEL;	// source�� ���� width ���.
	if( curWidth > Width )	// source�� width�� copy �Ϸ��� width���� ũ��, �־��� width��ŭ�� ����.
		curWidth = Width;

	//TextureCopyWithObject< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGBA8 >( Writer, Reader, curWidth, Height );
	
	unsigned short value;
	unsigned int offsetX = X + (pMemory2D->VirtualSegX/2);
	unsigned int offsetY = Y + pMemory2D->VirtualSegY;

	//int pixelPerByte = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<curWidth; i++ )
		{
			value = Reader.Read( i, j );
			WriteTMEM16( pMemory2D->VirtualSegment, offsetX+i, offsetY+j, value );
		}	

	return 1;
}

GLESOALbool GLESOAL_UploadTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_R5G6B5 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;

	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGBA4 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	//if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )	// width�� ���� �ʳ�..?
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )
		return 0;

	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_RGB5A1 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );

	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	//if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )	// width�� ���� �ʳ�..?	
		return 0;
		
	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_L8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;
	
	return GLESOAL_CopyPixelToTexture_U8( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}

GLESOALbool GLESOAL_UploadTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	//return TextureCopy< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadPixel_LA8 >( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
		
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pMemory2D->Width/2) ) || ((Y+Height)>pMemory2D->Height) )		
		return 0;
	
	return GLESOAL_CopyPixelToTexture_U16( pMemory2D, X, Y, Width, Height, pSrc, SrcStride );
}


GLESOALbool GLESOAL_CopyDisplayToMemory_RGB565( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );
	GLESOAL_WritePixel_R5G6B5 Writer( pDst, DstStride );

	unsigned int curWidth = DstStride / GLESOAL_WritePixel_R5G6B5::BYTE_PER_PIXEL;
	if( curWidth > Width )
		curWidth = Width;

	if( !FSAA )
		ReadDisplayWriteTexture< GLESOAL_WritePixel_R5G6B5, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, curWidth, Height );
	else
		ReadDisplayWriteTexture< GLESOAL_WritePixel_R5G6B5, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, curWidth, Height );
	return 1;
/*
	unsigned int curWidth = DstStride / 2;
	if( Width > curWidth )
		Width = curWidth;

	unsigned short value;
	unsigned int offsetX = X + pSrcMemory2D->VirtualSegX/2;
	unsigned int offsetY = pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y;

	int bytePerPixel = 2;
	unsigned int i, j;
	for( j=0; j<Height; j++ )
		for( i=0; i<Width; i++ )
		{
			value = ReadDMEM16( pSrcMemory2D->VirtualSegment, offsetX+i, (offsetY-j) );
			*((unsigned short*)((unsigned char*)pDst + (i*bytePerPixel + DstStride*j))) = value;
		}
	return 1;		
*/
}

GLESOALbool GLESOAL_CopyDisplayToMemory_RGBA8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										void* pDst, unsigned int DstStride,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
									 
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );
	GLESOAL_WritePixel_RGBA8 Writer( pDst, DstStride );

	unsigned int curWidth = DstStride / GLESOAL_WritePixel_RGBA8::BYTE_PER_PIXEL;
	if( curWidth > Width )
		curWidth = Width;

	if( !FSAA )
		ReadDisplayWriteTexture< GLESOAL_WritePixel_RGBA8, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, curWidth, Height );
	else
		ReadDisplayWriteTexture< GLESOAL_WritePixel_RGBA8, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, curWidth, Height );
	return 1;				
}

GLESOALbool GLESOAL_CopyDisplayToTexture_R5G6B5( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	if( ( (OffsetX+Width)>(pDstMemory2D->Width/2) ) || ((OffsetY+Height)>pDstMemory2D->Height) )		
		return 0;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );

	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 			pSrcMemory2D->VirtualSegX/2+X, 
									 			pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );

	GLESOAL_WriteMem2D_R5G6B5 Writer( pDstMemory2D->VirtualSegment, 
									  pDstMemory2D->VirtualSegX/2+OffsetX, 
									  pDstMemory2D->VirtualSegY+OffsetY );

	if( ! FSAA )	
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, Width, Height, ScaleX, ScaleY );
	else
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_R5G6B5, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, Width, Height, ScaleX, ScaleY );
	return 1;
}

GLESOALbool GLESOAL_CopyDisplayToTexture_L8( const GLESOAL_MEMORY2D* pSrcMemory2D,
										unsigned int X, unsigned int Y, 
										unsigned int Width, unsigned int Height,
										unsigned int ScaleX, unsigned int ScaleY,
										const GLESOAL_MEMORY2D* pDstMemory2D, 
										unsigned int OffsetX, unsigned int OffsetY,
										int FSAA )
{
	// �޸𸮿� �־��� �������� �� ū ������ ī���Ϸ� �ϴ��� �˻�.
	if( ( (X+Width)>(pSrcMemory2D->Width/2) ) || ((Y+Height)>pSrcMemory2D->Height) )		
		return 0;

	if( X+Width>(unsigned int)g_WindowWidth )
		Width = g_WindowWidth-X;
	if( Y+Height>(unsigned int)g_WindowHeight )
		Height = g_WindowHeight-Y;

	if( ( (OffsetX+Width)>(pDstMemory2D->Width) ) || ((OffsetY+Height)>pDstMemory2D->Height) )		
		return 0;

	GLESOAL_ReadMem2D_R5G6B5 Reader( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+g_WindowHeight-1-Y );
									 
	GLESOAL_ReadMem2D_R5G6B5_FSAA Reader_FSAA( pSrcMemory2D->VirtualSegment, 
									 pSrcMemory2D->VirtualSegX/2+X, 
									 pSrcMemory2D->VirtualSegY+(g_WindowHeight-1-Y)*2 );

	GLESOAL_WriteMem2D_L8 Writer( pDstMemory2D->VirtualSegment, 
								  pDstMemory2D->VirtualSegX+OffsetX, 
								  pDstMemory2D->VirtualSegY+OffsetY );

	if( ! FSAA )
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_L8, GLESOAL_ReadMem2D_R5G6B5 >( Writer, Reader, Width, Height, ScaleX, ScaleY );
	else
		ReadDisplayWriteValidTexture< GLESOAL_WriteMem2D_L8, GLESOAL_ReadMem2D_R5G6B5_FSAA >( Writer, Reader_FSAA, Width, Height, ScaleX, ScaleY );

	return 1;
}


GLESOALbool GLESOAL_CreateMipmapTexture_A8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}
									

GLESOALbool GLESOAL_CreateMipmapTexture_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGBA4( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_RGB5A1( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapTexture_LA8( const GLESOAL_MEMORY2D* pMemory2D, 
									 unsigned int X, unsigned int Y,
									 unsigned int Width, unsigned int Height, 
									 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}


// Create Mipmap Texture - glCopyTexImage2D
GLESOALbool GLESOAL_CreateMipmapCopyTexture_R5G6B5( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height )
{
	return 0;
}

GLESOALbool GLESOAL_CreateMipmapCopyTexture_L8( const GLESOAL_MEMORY2D* pMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int Width, unsigned int Height )
{
	return 0;
}


// for texture mipmap
GLESOALbool GLESOAL_CopyTexture_U8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height )
{
	return 0;
}

GLESOALbool GLESOAL_CopyTexture_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pDstMemory2D, 
									unsigned int Width, unsigned int Height )
{
	return 0;
}

GLESOALbool GLESOAL_GetMipmapPosition_U16(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y )
{
	return 0;
}

GLESOALbool GLESOAL_GetMipmapPosition_U8(  const GLESOAL_MEMORY2D* pMemory2D, int Level, 
									  unsigned int *X, unsigned int *Y )
{
	return 0;
}

GLESOALbool GLESOAL_UploadMipmap_U8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_UploadMipmap_U16( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_UploadMipmap_RGB8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_UploadMipmap_RGBA8( const GLESOAL_MEMORY2D* pMemory2D, 
							 unsigned int X, unsigned int Y,
							 unsigned int Width, unsigned int Height, 
							 const void* pSrc, unsigned int SrcStride )
{
	return 0;
}

GLESOALbool GLESOAL_UploadCopyTextureMipmap_L8( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height )
{
	return 0;
}

GLESOALbool GLESOAL_UploadCopyTextureMipmap_U16( const GLESOAL_MEMORY2D* pSrcMemory2D, 
									const GLESOAL_MEMORY2D* pTexMemory2D, 
									unsigned int X, unsigned int Y,
									unsigned int OffsetX, unsigned int OffsetY,
									unsigned int Width, unsigned int Height )
{
	return 0;
}


void GLESOAL_MakeEdgeForNonPowerOf2_8BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height )
{
	int seg   = pMemory2D->VirtualSegment;
	int seg_x = pMemory2D->VirtualSegX;
	int seg_y = pMemory2D->VirtualSegY;
	int mem_w = pMemory2D->Width;
	int mem_h = pMemory2D->Height;
	if( mem_h > Height )
	{
		for( int x=0; x < Width; x++ )
		{
			unsigned char data0 = ReadTMEM8 ( seg, seg_x+x, seg_y          );
			unsigned char data1 = ReadTMEM8 ( seg, seg_x+x, seg_y+Height-1 );
			WriteTMEM8( seg, seg_x+x, seg_y+mem_h-1, data0 );
			WriteTMEM8( seg, seg_x+x, seg_y+Height,  data1 );
		}
	}
	if( mem_w > Width )
	{
		for( int y=0; y < Height; y++ )
		{
			unsigned char data0 = ReadTMEM8 ( seg, seg_x,         seg_y+y );
			unsigned char data1 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y+y );
			WriteTMEM8( seg, seg_x+mem_w-1, seg_y+y, data0 );
			WriteTMEM8( seg, seg_x+Width,   seg_y+y, data1 );
		}
	}
	
	if( mem_w > Width && mem_h > Height )
	{
		unsigned char data0 = ReadTMEM8 ( seg, seg_x        , seg_y );
		unsigned char data1 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y );
		unsigned char data2 = ReadTMEM8 ( seg, seg_x        , seg_y+Height-1 );
		unsigned char data3 = ReadTMEM8 ( seg, seg_x+Width-1, seg_y+Height-1 );
		WriteTMEM8( seg, seg_x+mem_w-1, seg_y+mem_h-1, data0 );
		WriteTMEM8( seg, seg_x+Width,   seg_y+mem_h-1, data1 );
		WriteTMEM8( seg, seg_x+mem_w-1, seg_y+Height,  data2 );
		WriteTMEM8( seg, seg_x+Width,   seg_y+Height,  data3 );
	}
}

void GLESOAL_MakeEdgeForNonPowerOf2_16BPP( const GLESOAL_MEMORY2D* pMemory2D, int Width, int Height )
{
	int seg   = pMemory2D->VirtualSegment;
	int seg_x = pMemory2D->VirtualSegX / 2;
	int seg_y = pMemory2D->VirtualSegY;
	int mem_w = pMemory2D->Width / 2;
	int mem_h = pMemory2D->Height;
	if( mem_h > Height )
	{
		for( int x=0; x < Width; x++ )
		{
			unsigned short data0 = ReadTMEM16 ( seg, seg_x+x, seg_y          );
			unsigned short data1 = ReadTMEM16 ( seg, seg_x+x, seg_y+Height-1 );
			WriteTMEM16( seg, seg_x+x, seg_y+mem_h-1, data0 );
			WriteTMEM16( seg, seg_x+x, seg_y+Height,  data1 );
		}
	}
	if( mem_w > Width )
	{
		for( int y=0; y < Height; y++ )
		{
			unsigned short data0 = ReadTMEM16 ( seg, seg_x,         seg_y+y );
			unsigned short data1 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y+y );
			WriteTMEM16( seg, seg_x+mem_w-1, seg_y+y, data0 );
			WriteTMEM16( seg, seg_x+Width,   seg_y+y, data1 );
		}
	}
	
	if( mem_w > Width && mem_h > Height )
	{
		unsigned short data0 = ReadTMEM16 ( seg, seg_x        , seg_y );
		unsigned short data1 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y );
		unsigned short data2 = ReadTMEM16 ( seg, seg_x        , seg_y+Height-1 );
		unsigned short data3 = ReadTMEM16 ( seg, seg_x+Width-1, seg_y+Height-1 );
		WriteTMEM16( seg, seg_x+mem_w-1, seg_y+mem_h-1, data0 );
		WriteTMEM16( seg, seg_x+Width,   seg_y+mem_h-1, data1 );
		WriteTMEM16( seg, seg_x+mem_w-1, seg_y+Height,  data2 );
		WriteTMEM16( seg, seg_x+Width,   seg_y+Height,  data3 );
	}
}
