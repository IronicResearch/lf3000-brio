//------------------------------------------------------------------------------
//
//	Copyright (C) 2003 MagicEyes Digital Co., Ltd All Rights Reserved
//	MagicEyes Digital Co. Proprietary & Confidential
//
//	MAGICEYES INFORMS THAT THIS CODE AND INFORMATION IS PROVIDED "AS IS" BASE AND 
//	WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
//	THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
//	Module     : memory management (1D)
//	File       : mes_memory1d.cpp
//	Description:
//	Author     : Gamza(nik@mesdigital.com)
//	Export     :
//	History    :
//	   2007/04/05 Gamza �޸� ���� ȿ�� ����
//	   2007/01/03 Yuni  modify for GLESOAL
//	   2005/01/11 Gamza heap�� �ʱ� ũ�Ⱑ power of 2�� �ƴҶ� ����� ��������
//						heap�ʱ�ȭ �Ҷ� SplitToPowerOf2�� ȣ�����ش�.
//	   2004/10/07 Gamza first implementation
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//	custom heap structure
//------------------------------------------------------------------------------
typedef struct
{
	unsigned int VirtualAddress;	// virtual address
	unsigned int PhysicalAddress;	// pysical address
	unsigned int SizeInMbyte;		// size (Mbyte)
} ___OEM_CUSTOMHEAP;

#define BYTES_PER_LINE  4096

//------------------------------------------------------------------------------
//	2D memory manager
//------------------------------------------------------------------------------
#define MES_ASSERT(exp)
#define MES_DEBUG_CODE(debugging_codes)
#define CNULL   0
#define CTRUE	1
#define CFALSE	0
typedef int		        CBOOL;
typedef char    		S8 ;
typedef short   		S16;
typedef long   			S32;
typedef unsigned char	U8 ;
typedef unsigned short	U16;
typedef unsigned long	U32;

class __MES_MCB_2D
{
private:
	U32					m_nX;
	U32					m_nY;
	U32					m_nWidth;
	U32					m_nHeight;
	U32					m_nAlign;
	__MES_MCB_2D		*m_pParent;
	__MES_MCB_2D		*m_pChild1;
	__MES_MCB_2D		*m_pChild2;
	CBOOL				m_Solid;

	void GetClosest ( U32 width, U32 height, U32 align_x, U32 align_y,
						U32 *pLeastWaste, __MES_MCB_2D **ppBestFit );
	__MES_MCB_2D *SplitHorizontal ( U32 width, U32 height );
	__MES_MCB_2D *SplitVertical ( U32 width, U32 height );
	__MES_MCB_2D *Split ( U32 width, U32 height );

	CBOOL SplitPowerOf2Horizontal ( void );
	CBOOL SplitPowerOf2Vertical ( void );
	CBOOL IsFreeNode( void );

	//MES_ObjectPool m_NodePool;
public:
	void SplitToPowerOf2 ( void );
	void Initialize ( U32 width, U32 height,
			U32 x=0, U32 y=0, U32 align=1,	// = multiple to align to
			__MES_MCB_2D *pParent=(__MES_MCB_2D *)CNULL );
	__MES_MCB_2D( void );
	__MES_MCB_2D ( U32 width, U32 height,
			U32 x=0, U32 y=0, U32 align=1,	// = multiple to align to
			__MES_MCB_2D *pParent=(__MES_MCB_2D *)CNULL );
	~__MES_MCB_2D( void );
	void	Free();
	__MES_MCB_2D	*Alloc ( U32 width, U32 height, U32 align_x=1, U32 align_y=1 );
	U32		Top() const { return m_nY; }
	U32		Left() const { return m_nX; }
	U32		Width() const { return m_nWidth; }
	U32		Height() const { return m_nHeight; }
	U32		AvailSpace();
};

inline CBOOL IsPowerOf2( U32 value ) { return ( 0 == (value & (value-1)) ); }
#define MES_ASSERT_VALIDRECT( rect )								\
			MES_ASSERT( IsPowerOf2((rect)->m_nWidth) );				\
			MES_ASSERT( IsPowerOf2((rect)->m_nHeight) );            \
			MES_ASSERT( 0 == ((rect)->m_nX%(rect)->m_nWidth ) );    \
			MES_ASSERT( 0 == ((rect)->m_nY%(rect)->m_nHeight) );

__MES_MCB_2D::
__MES_MCB_2D( void )
{
}

__MES_MCB_2D::
__MES_MCB_2D( U32 width, U32 height, U32 x, U32 y,
		U32 align,	__MES_MCB_2D *pParent )
{
	Initialize( width, height, x, y, align,	pParent );
}

void
__MES_MCB_2D::
Initialize( U32 width, U32 height, U32 x, U32 y,
		U32 align,	__MES_MCB_2D *pParent )
{
	MES_ASSERT( 0 < width  );
	MES_ASSERT( 0 < height );
	//	Creating initial Node2d
	m_nX = x;
	m_nY = y;
	m_nWidth = width;
	m_nHeight = height;
	m_nAlign = align;
	m_pParent = pParent;
	m_pChild1 = (__MES_MCB_2D *)CNULL;
	m_pChild2 = (__MES_MCB_2D *)CNULL;
	//m_pSystemMem = (unsigned char *)CNULL;
	m_Solid = CFALSE;
}

__MES_MCB_2D::
~__MES_MCB_2D( void )
{
	if( m_pChild1 ){ delete m_pChild1; }
	if( m_pChild2 ){ delete m_pChild2; }
}

void __MES_MCB_2D::
GetClosest( U32 width, U32 height, U32 align_x, U32 align_y,
			U32 *pLeastWaste, __MES_MCB_2D **ppBestFit )
{
	if( m_Solid )
		return; // this node is in use
	if( m_nWidth < width || m_nHeight < height )
		return; // this one (and any children) are too small
	if( m_pChild2 ) // This is a parent node, just check child nodes for better fit
	{
		MES_ASSERT( CNULL != m_pChild1 );
		m_pChild1->GetClosest( width, height, align_x, align_y, pLeastWaste, ppBestFit );
		if( 0 == pLeastWaste ){ return; }
		m_pChild2->GetClosest( width, height, align_x, align_y, pLeastWaste, ppBestFit );
		//if( 0 == pLeastWaste ){ return; }
	}
	else
	{
		//MES_ASSERT_VALIDRECT( this );
		if( 0 == (m_nX % align_x) && 0 == (m_nY % align_y) )
		{
			// This node is free & big enough - check for fit
			U32 waste = m_nWidth * m_nHeight - width * height;
			if( *ppBestFit == (__MES_MCB_2D *)CNULL || waste < *pLeastWaste )
			{
				*pLeastWaste = waste;
				*ppBestFit = this;
			}
		}
	}
}

__MES_MCB_2D* __MES_MCB_2D::
SplitHorizontal ( U32 width, U32 height )
{
	// ��������� width*height�� ������ ������ ��������
	// ����ū 2�� �¼��� �簢���� �߶󳽴�.
	U32 newsize;
	for( newsize=1; width+newsize <= m_nWidth; newsize<<=1 ){ /* do nothing */ }
	newsize>>=1;
	MES_ASSERT( 0 < newsize );
	//MES_ASSERT( 0 == ( (m_nX+(m_nWidth-newsize)) % newsize ) );
	m_pChild1 = new __MES_MCB_2D( (m_nWidth-newsize), m_nHeight, m_nX, m_nY, m_nAlign, this );
	m_pChild2 = new __MES_MCB_2D( newsize, m_nHeight, m_nX+(m_nWidth-newsize), m_nY, m_nAlign, this );
	m_pChild2->SplitToPowerOf2();
	return m_pChild1->Split( width, height );
}
__MES_MCB_2D* __MES_MCB_2D::
SplitVertical ( U32 width, U32 height )
{
	// ��������� width*height�� ������ ������ ��������
	// ����ū 2�� �¼��� �簢���� �߶󳽴�.
	U32 newsize;
	for( newsize=1; height+newsize <= m_nHeight; newsize<<=1 ){ /* do nothing */ }
	newsize>>=1;
	MES_ASSERT( 0 < newsize );
	//MES_ASSERT( 0 == ( (m_nY+(m_nHeight-newsize)) % newsize ) );
	m_pChild1 = new __MES_MCB_2D( m_nWidth, (m_nHeight-newsize), m_nX, m_nY, m_nAlign, this );
	m_pChild2 = new __MES_MCB_2D( m_nWidth, newsize, m_nX, m_nY+(m_nHeight-newsize), m_nAlign, this );
	m_pChild2->SplitToPowerOf2();
	return m_pChild1->Split( width, height );
}
__MES_MCB_2D* __MES_MCB_2D::
Split( U32 width, U32 height )
{
	// Splitting Node2d (m_nWidthxm_nHeight) to give (widthxheight) space
	MES_ASSERT( ! m_Solid );
	MES_ASSERT( width <= m_nWidth );
	MES_ASSERT( height <= m_nHeight );
	U32 dw = m_nWidth  - width ;
	U32 dh = m_nHeight - height;
	if ( dh > 0 || dw > 0 )
	{
		CBOOL hdivide = (dw>dh);
		//U32 numofdivide[4]={0,0,0,0};
		//U32 i;
		//for( i=0; i<32; i++ )
		//{
		//	if( dw     & (1<<i) ){ numofdivide[0]++; }
		//	if( width  & (1<<i) ){ numofdivide[1]++; }
		//	if( dh     & (1<<i) ){ numofdivide[2]++; }
		//	if( height & (1<<i) ){ numofdivide[3]++; }
		//}
		//U32 numofhdivide = numofdivide[0] + numofdivide[1]*numofdivide[2];
		//U32 numofvdivide = numofdivide[2] + numofdivide[3]*numofdivide[0];
		//MES_ASSERT( 0 < numofvdivide );
		//MES_ASSERT( 0 < numofhdivide );
		//CBOOL hdivide = (dw>0) && (numofvdivide>=numofhdivide);
		if( hdivide )	{ return SplitHorizontal( width, height ); }
		else 			{ return SplitVertical( width, height ); }
	}
	return this;
}

CBOOL __MES_MCB_2D::
SplitPowerOf2Horizontal ( void )
{
	U32 newsize;
	// �簢���� ��ġ��(m_nY)�� ������ ���� ������ �ִ� �ִ� 2�� �¼��� ����.
    for( newsize=1;
        (0 == (m_nX & newsize)) && (newsize<m_nWidth)//((newsize<<1)<=m_nWidth)
        ; newsize<<=1 ){ /* do nothing */ }
    // ������ ���� ���� ũ��(m_nHeight)���� �۴ٸ� �ɰ��� �Ѵ�.
    if( newsize < m_nWidth )
	{
		m_pChild1 = new __MES_MCB_2D( newsize, m_nHeight, m_nX, m_nY, m_nAlign, this );
		m_pChild2 = new __MES_MCB_2D( m_nWidth-newsize, m_nHeight, m_nX+newsize, m_nY, m_nAlign, this );
		m_pChild1->SplitToPowerOf2();
		m_pChild2->SplitToPowerOf2();
		return CTRUE;
	}
	return CFALSE;
}

CBOOL __MES_MCB_2D::
SplitPowerOf2Vertical ( void )
{
	U32 newsize;
    // �簢���� ��ġ��(m_nY)�� ������ ���� ������ �ִ� �ִ� 2�� �¼��� ����.
    for( newsize=1;
        (0 == (m_nY & newsize)) && (newsize<m_nHeight)//((newsize<<1)<=m_nHeight)
        ; newsize<<=1 ){ /* do nothing */ }
    // ������ ���� ���� ũ��(m_nHeight)���� �۴ٸ� �ɰ��� �Ѵ�.
    if( newsize < m_nHeight )
	{
		m_pChild1 = new __MES_MCB_2D( m_nWidth, newsize, m_nX, m_nY, m_nAlign, this );
		m_pChild2 = new __MES_MCB_2D( m_nWidth, m_nHeight-newsize, m_nX, m_nY+newsize, m_nAlign, this );
		m_pChild1->SplitToPowerOf2();
		m_pChild2->SplitToPowerOf2();
		return CTRUE;
	}
	return CFALSE;
}

void __MES_MCB_2D::
SplitToPowerOf2 ( void )
{
	MES_ASSERT( 0 < m_nWidth );
	MES_ASSERT( 0 < m_nHeight );
	CBOOL hdivide = ( m_nWidth >= m_nHeight ); // ū���� �ɰ���
	if( hdivide )
	{
		if( SplitPowerOf2Horizontal() ){ return; }
		if( SplitPowerOf2Vertical() ){ return; }
	}
	else
	{
		if( SplitPowerOf2Vertical() ){ return; }
		if( SplitPowerOf2Horizontal() ){ return; }
	}
}

CBOOL __MES_MCB_2D::
IsFreeNode( void )
{
	if ( m_Solid ){ return CFALSE; }
	if ( m_pChild1 )
	{ if( ! m_pChild1->IsFreeNode() ){ return CFALSE; } }
	if ( m_pChild2 )
	{ if( ! m_pChild2->IsFreeNode() ){ return CFALSE; } }
	return CTRUE;
}

//long totalVideoMemUsed = 0;

__MES_MCB_2D* __MES_MCB_2D::
Alloc( U32 width, U32 height, U32 align_x, U32 align_y )
{
	__MES_MCB_2D *pNode = (__MES_MCB_2D *)CNULL;
	U32 waste;
	width = ( width + m_nAlign - 1 ) & ( - m_nAlign );	// Round up to alignment

	// Find the best node to contain the new area
	// Attempting to allocate (widthxheight) space
	GetClosest( width, height, align_x, align_y, &waste, &pNode );
	if( pNode )
	{
		// Split the node into the required space & remainder piece(s)
		pNode = pNode->Split( width, height );
		// Succesfully allocated pNode (m_nX,m_nY,m_nWidth,m_nHeight)
		MES_ASSERT( CNULL != pNode );
		// node�� ��������� ǥ���صд�.
		pNode->m_Solid = CTRUE;
		MES_ASSERT( CNULL == pNode->m_pChild1 );
		MES_ASSERT( CNULL == pNode->m_pChild2 );
		MES_DEBUG_CODE(
			U32 size;
			for( size=1; size<pNode->m_nWidth; size<<=1 ){/* do nothing */}
			MES_ASSERT( 0 == (pNode->m_nX % size) );
			for( size=1; size<pNode->m_nHeight; size<<=1 ){/* do nothing */}
			MES_ASSERT( 0 == (pNode->m_nY % size) );
		);
		//totalVideoMemUsed += ((m_nWidth / m_nAlign ) * 4) * m_nHeight;
	}
	else
	{
		// Failed to allocate Node2d !!
	}
	return pNode;
}

void __MES_MCB_2D::
Free()
{

	if( m_Solid )
	{
		MES_ASSERT( CNULL == m_pChild1 );
		MES_ASSERT( CNULL == m_pChild2 );
		m_Solid = CFALSE;
	}
	else
	{
		MES_ASSERT( m_pChild1 );
		MES_ASSERT( m_pChild2 );
		// We are being told to delete both child nodes as they are now free
		if( m_pChild1->IsFreeNode() && m_pChild2->IsFreeNode() )
		{
			delete m_pChild1;
			delete m_pChild2;
			m_pChild1 = m_pChild2 = (__MES_MCB_2D *)CNULL;
		}
	}
	if( m_pParent )
	{
		if( m_pParent->IsFreeNode() )
		{
			// Now this & sibling are free so we can erase both & coalesce
			m_pParent->Free();
		}
		else
		{
			SplitToPowerOf2();
		}
	}
}

U32 __MES_MCB_2D::
AvailSpace()
{
	if( m_pChild2 )
		return m_pChild1->AvailSpace()+m_pChild2->AvailSpace();
	else if( m_pChild1 != (__MES_MCB_2D *)CNULL )
		return 0;
	else
		return m_nWidth * m_nHeight;
}

//------------------------------------------------------------------------------
//
//	__MES_MCB_2D_Manager
//
//------------------------------------------------------------------------------
class __MES_MCB_2D_Manager //: public MES_Singleton<__MES_MCB_2D_Manager>
{
public:
	CBOOL Malloc( U32 HeapID, U32 Width, U32 Height, U32 AlignX, U32 AlignY,
				  __MES_MCB_2D* &pMemory2D );
	static void  Free( __MES_MCB_2D* pMemory2D );

	enum { ALIGH = 8 };
	void Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps );
	void Deinitialize();
	virtual ~__MES_MCB_2D_Manager();
	
	unsigned int GetVirtualAddress( U32 HeapID ){ return m_ListOfHeapRoot[HeapID].m_HeapDefinition.VirtualAddress; }
	unsigned int GetPhysicalAddress( U32 HeapID ){ return m_ListOfHeapRoot[HeapID].m_HeapDefinition.PhysicalAddress; }
private:
	U32			  m_NumberOfHeap;
	
	struct Heap
	{
	    __MES_MCB_2D         m_Root;
	    ___OEM_CUSTOMHEAP m_HeapDefinition;
	};	
	Heap* m_ListOfHeapRoot;	
};

void __MES_MCB_2D_Manager::Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps )
{
	m_NumberOfHeap=NumberOfHeaps;

	// alloc heap root
	m_ListOfHeapRoot = new __MES_MCB_2D_Manager::Heap[(unsigned int)m_NumberOfHeap];
	MES_ASSERT( CNULL != m_ListOfHeapRoot );

	// init heap root
	U32 i;
	for( i=0; i<m_NumberOfHeap; i++ )
	{
	    m_ListOfHeapRoot[i].m_HeapDefinition = pHeapList[i];
		m_ListOfHeapRoot[i].m_Root.Initialize( BYTES_PER_LINE, (pHeapList[i].SizeInMbyte * 0x100000) / BYTES_PER_LINE );
		m_ListOfHeapRoot[i].m_Root.SplitToPowerOf2();
	}
}

void __MES_MCB_2D_Manager::Deinitialize()
{
    delete[] m_ListOfHeapRoot;
}

__MES_MCB_2D_Manager::~__MES_MCB_2D_Manager()
{
	Deinitialize();
}

void  __MES_MCB_2D_Manager::Free
(
	__MES_MCB_2D* pMemory2D
)
{
	MES_ASSERT( CNULL != pMemory2D );
	pMemory2D->Free();
}

CBOOL __MES_MCB_2D_Manager::Malloc
(
	U32 HeapID,
	U32 Width,
	U32 Height,
	U32 AlignX,
	U32 AlignY,
	__MES_MCB_2D* &pMemory2D
)
{
	MES_ASSERT( m_NumberOfHeap > HeapID );
	__MES_MCB_2D* pmemnode = &m_ListOfHeapRoot[HeapID].m_Root;
	pMemory2D = pmemnode->Alloc ( Width, Height, AlignX, AlignY );
	return (CNULL != pMemory2D);
}


//------------------------------------------------------------------------------
// singleton
//------------------------------------------------------------------------------
static __MES_MCB_2D_Manager s__MES_MCB_2D_Manager;

void ___MES_2D_Manager_Initialize( const ___OEM_CUSTOMHEAP* pHeapList, int NumberOfHeaps )
{
    s__MES_MCB_2D_Manager.Initialize( pHeapList, NumberOfHeaps );
}


//------------------------------------------------------------------------------
//	OAL interface
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif
    typedef int GLESOALbool;
    
	enum GLESOAL_MEMORY2D_TYPE
	{
		GLESOAL_MEMORY2D_TYPE_FRAMEBUFFER			= 0,
		GLESOAL_MEMORY2D_TYPE_DEPTHBUFFER			= 1,
		GLESOAL_MEMORY2D_TYPE_TEXTURE					= 2,
		GLESOAL_MEMORY2D_TYPE_VIDEOTEXTURE    = 3,
		GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE = 4,
		GLESOAL_MEMORY2D_TYPE_FORCEU32		= 0x7FFFFFFF
	};

	typedef struct
	{
		unsigned long			MemoryHandle;		///< memory handle for internal (do not modified it)
		GLESOAL_MEMORY2D_TYPE	Type;				/// memory2D type
		unsigned long			VirtualSegment;		///< virtual address of memory block (16byte aligned)
		unsigned long			VirtualSegX;
		unsigned long			VirtualSegY;
		unsigned long			PhysicalSegment;	///< physical address of memory block (16byte aligned)
		unsigned long			PhysicalSegX;
		unsigned long			PhysicalSegY;
		unsigned long			Width;
		unsigned long			Height;
	} GLESOAL_MEMORY2D;
    
    GLESOALbool GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE Type, 
    							unsigned int  Width, unsigned int  Height, 
                                unsigned int  AlignX, unsigned int  AlignY, 
                                GLESOAL_MEMORY2D* pMemory2D );
    void GLESOAL_Free2D         ( GLESOAL_MEMORY2D* pMemory2D );
#ifdef __cplusplus
}
#endif

//------------------------------------------------------------------------------
//	OAL implementation
//------------------------------------------------------------------------------
#define DEFAULT_HEAP_ID 0
#define Segment_MP2530F( Address )		((((Address)>>22)<<1) | (((Address)>>11)&1))
#define Segment_X_MP2530F( Address )	((Address)&((1<<11)-1))
#define Segment_Y_MP2530F( Address )	(((Address)>>12)&((1<<10)-1))

//GLESOALbool GLESOAL_Malloc2D( unsigned int  Width, unsigned int  Height, 
//							 unsigned int  AlignX, unsigned int  AlignY, 
//							 GLESOAL_MEMORY2D* pMemory2D )
GLESOALbool GLESOAL_Malloc2D( GLESOAL_MEMORY2D_TYPE Type,
							 unsigned int  Width, unsigned int  Height, 
							 unsigned int  AlignX, unsigned int  AlignY, 
							 GLESOAL_MEMORY2D* pMemory2D )
{
	__MES_MCB_2D* pmemory2d;
	
	if( Type == GLESOAL_MEMORY2D_TYPE_MIPMAPEDTEXTURE )
	{
		return CFALSE;
	}
	else
	{
		if( s__MES_MCB_2D_Manager.Malloc( DEFAULT_HEAP_ID, Width, Height, AlignX, AlignY, pmemory2d ) )
		{
			pMemory2D->MemoryHandle = (U32)pmemory2d;
			
			unsigned long v_addr      	= s__MES_MCB_2D_Manager.GetVirtualAddress(DEFAULT_HEAP_ID) +
										pmemory2d->Top() * BYTES_PER_LINE + pmemory2d->Left();
			unsigned long p_addr       	= s__MES_MCB_2D_Manager.GetPhysicalAddress(DEFAULT_HEAP_ID) +
										pmemory2d->Top() * BYTES_PER_LINE + pmemory2d->Left();
	
			pMemory2D->Width        	= pmemory2d->Width();
			pMemory2D->Height       	= pmemory2d->Height();											
			pMemory2D->PhysicalSegment 	= Segment_MP2530F  (p_addr);
			pMemory2D->PhysicalSegX 	= Segment_X_MP2530F(p_addr);
			pMemory2D->PhysicalSegY 	= Segment_Y_MP2530F(p_addr);
			pMemory2D->VirtualSegment 	= Segment_MP2530F  (v_addr);
			pMemory2D->VirtualSegX 		= Segment_X_MP2530F(v_addr);
			pMemory2D->VirtualSegY 		= Segment_Y_MP2530F(v_addr);
			pMemory2D->Type 			= Type;
			
			return CTRUE;
		}
		else
			return CFALSE;
	}
}


void GLESOAL_Free2D( GLESOAL_MEMORY2D* pMemory2D )
{
	if( pMemory2D->MemoryHandle )
	{
		__MES_MCB_2D* pmemnode = (__MES_MCB_2D*)pMemory2D->MemoryHandle;
		s__MES_MCB_2D_Manager.Free( pmemnode );
		
		pMemory2D->PhysicalSegment	= 0;
		pMemory2D->PhysicalSegX 	= 0;
		pMemory2D->PhysicalSegY 	= 0;
		pMemory2D->VirtualSegment 	= 0;
		pMemory2D->VirtualSegX 		= 0;
		pMemory2D->VirtualSegY 		= 0;
		pMemory2D->Width        	= 0;
		pMemory2D->Height       	= 0;
		pMemory2D->Type				= (GLESOAL_MEMORY2D_TYPE)0;
		pMemory2D->MemoryHandle 	= 0;
	}
}


unsigned int ___MES_2D_Manager_GetPhysicalAddress( const GLESOAL_MEMORY2D* pMemory2D )
{
	if( pMemory2D->MemoryHandle )
	{
		const __MES_MCB_2D* pmemory2d = (const __MES_MCB_2D*)pMemory2D->MemoryHandle;
		unsigned int p_addr    = s__MES_MCB_2D_Manager.GetPhysicalAddress(DEFAULT_HEAP_ID) +
								  pmemory2d->Top() * BYTES_PER_LINE + pmemory2d->Left();		
		return p_addr | 0x20000000;
	}
	else
	{
		return 0;
	}
}
