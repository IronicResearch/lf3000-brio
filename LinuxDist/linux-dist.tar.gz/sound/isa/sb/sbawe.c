#define SNDRV_SBAWE
#include "sb16.c"
